
#ifndef _pvf_vst_cpp_
#define _pvf_vst_cpp_

#include <stddef.h>
#include <stdio.h>
#include <math.h>
VstIntPtr AudioEffect::dispatchEffectClass (AEffect* e, VstInt32 opCode, VstInt32 index, VstIntPtr value, void* ptr, float opt) {
  AudioEffect* ae = (AudioEffect*)(e->object);
  if (opCode == effClose) {
    ae->dispatcher (opCode, index, value, ptr, opt);
    delete ae;
    return 1;
  }
  return ae->dispatcher (opCode, index, value, ptr, opt);
}
float AudioEffect::getParameterClass (AEffect* e, VstInt32 index) {
  AudioEffect* ae = (AudioEffect*)(e->object);
  return ae->getParameter (index);
}
void AudioEffect::setParameterClass (AEffect* e, VstInt32 index, float value) {
  AudioEffect* ae = (AudioEffect*)(e->object);
  ae->setParameter (index, value);
}
void AudioEffect::DECLARE_VST_DEPRECATED (processClass) (AEffect* e, float** inputs, float** outputs, VstInt32 sampleFrames) {
  AudioEffect* ae = (AudioEffect*)(e->object);
  ae->DECLARE_VST_DEPRECATED (process) (inputs, outputs, sampleFrames);
}
void AudioEffect::processClassReplacing (AEffect* e, float** inputs, float** outputs, VstInt32 sampleFrames) {
  AudioEffect* ae = (AudioEffect*)(e->object);
  ae->processReplacing (inputs, outputs, sampleFrames);
}
#if VST_2_4_EXTENSIONS
void AudioEffect::processClassDoubleReplacing (AEffect* e, double** inputs, double** outputs, VstInt32 sampleFrames) {
  AudioEffect* ae = (AudioEffect*)(e->object);
  ae->processDoubleReplacing (inputs, outputs, sampleFrames);
}
#endif
AudioEffect::AudioEffect (audioMasterCallback audioMaster, VstInt32 numPrograms, VstInt32 numParams)
: audioMaster (audioMaster)
, beditor (0)
, sampleRate (44100.f)
, blockSize (1024)
, numPrograms (numPrograms)
, numParams (numParams)
, curProgram (0) {
  memset (&cEffect, 0, sizeof (cEffect));
  cEffect.magic = kEffectMagic;
  cEffect.dispatcher = dispatchEffectClass;
  cEffect.DECLARE_VST_DEPRECATED (process) = DECLARE_VST_DEPRECATED (processClass);
  cEffect.setParameter = setParameterClass;
  cEffect.getParameter = getParameterClass;
  cEffect.numPrograms  = numPrograms;
  cEffect.numParams    = numParams;
  cEffect.numInputs  = 1;
  cEffect.numOutputs = 2;
  cEffect.DECLARE_VST_DEPRECATED (ioRatio) = 1.f;
  cEffect.object = this;
  cEffect.uniqueID = CCONST ('N', 'o', 'E', 'f');
  cEffect.version  = 1;
  cEffect.processReplacing = processClassReplacing;
#if VST_2_4_EXTENSIONS
  canProcessReplacing ();
  cEffect.processDoubleReplacing = processClassDoubleReplacing;
#endif
}
AudioEffect::~AudioEffect () {
  if (beditor)
    delete beditor;
}
void AudioEffect::setEditor (AEffEditor* editor) {
  this->beditor = editor;
  if (editor)
    cEffect.flags |= effFlagsHasEditor;
  else
    cEffect.flags &= ~effFlagsHasEditor;
}
VstIntPtr AudioEffect::dispatcher (VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt) {
  VstIntPtr v = 0;
  switch (opcode) {
    case effOpen:        open ();                       break;
    case effClose:        close ();                       break;
    case effSetProgram:      if (value < numPrograms) setProgram ((VstInt32)value);  break;
    case effGetProgram:      v = getProgram ();                   break;
    case effSetProgramName:   setProgramName ((char*)ptr);             break;
    case effGetProgramName:   getProgramName ((char*)ptr);             break;
    case effGetParamLabel:    getParameterLabel (index, (char*)ptr);         break;
    case effGetParamDisplay:  getParameterDisplay (index, (char*)ptr);       break;
    case effGetParamName:    getParameterName (index, (char*)ptr);         break;
    case effSetSampleRate:    setSampleRate (opt);                 break;
    case effSetBlockSize:    setBlockSize ((VstInt32)value);             break;
    case effMainsChanged:    if (!value) suspend ();  else resume ();         break;
#if !VST_FORCE_DEPRECATED
    case effGetVu:        v = (VstIntPtr)(getVu () * 32767.);           break;
#endif
    case effEditGetRect:    if (beditor) v = beditor->getRect ((ERect**)ptr) ? 1 : 0;   break;
    case effEditOpen:      if (beditor) v = beditor->open (ptr) ? 1 : 0;       break;
    case effEditClose:      if (beditor) beditor->close ();             break;
    case effEditIdle:      if (beditor) beditor->idle ();             break;
#if (TARGET_API_MAC_CARBON && !VST_FORCE_DEPRECATED)
    case effEditDraw:      if (beditor) beditor->draw ((ERect*)ptr);         break;
    case effEditMouse:      if (beditor) v = beditor->mouse (index, value);     break;
    case effEditKey:      if (beditor) v = beditor->key (value);         break;
    case effEditTop:      if (beditor) beditor->top ();               break;
    case effEditSleep:      if (beditor) beditor->sleep ();             break;
#endif
    case DECLARE_VST_DEPRECATED (effIdentify):  v = CCONST ('N', 'v', 'E', 'f');   break;
    case effGetChunk:      v = getChunk ((void**)ptr, index ? true : false);   break;
    case effSetChunk:      v = setChunk (ptr, (VstInt32)value, index ? true : false);   break;
  }
  return v;
}
VstInt32 AudioEffect::getMasterVersion () {
  VstInt32 version = 1;
  if (audioMaster) {
    version = (VstInt32)audioMaster (&cEffect, audioMasterVersion, 0, 0, 0, 0);
    if (!version)
      version = 1;
  }
  return version;
}
VstInt32 AudioEffect::getCurrentUniqueId () {
  VstInt32 id = 0;
  if (audioMaster)
    id = (VstInt32)audioMaster (&cEffect, audioMasterCurrentId, 0, 0, 0, 0);
  return id;
}
void AudioEffect::masterIdle () {
  if (audioMaster)
    audioMaster (&cEffect, audioMasterIdle, 0, 0, 0, 0);
}
bool AudioEffect::DECLARE_VST_DEPRECATED (isInputConnected) (VstInt32 input) {
  VstInt32 ret = 0;
  if (audioMaster)
    ret = (VstInt32)audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterPinConnected), input, 0, 0, 0);
  return ret ? false : true;
}
bool AudioEffect::DECLARE_VST_DEPRECATED (isOutputConnected) (VstInt32 output) {
  VstInt32 ret = 0;
  if (audioMaster)
    ret = (VstInt32)audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterPinConnected), output, 1, 0, 0);
  return ret ? false : true;
}
void AudioEffect::setParameterAutomated (VstInt32 index, float value) {
  setParameter (index, value);
  if (audioMaster)
    audioMaster (&cEffect, audioMasterAutomate, index, 0, 0, value);
}
void AudioEffect::DECLARE_VST_DEPRECATED (hasVu) (bool state) {
  if (state)
    cEffect.flags |= DECLARE_VST_DEPRECATED (effFlagsHasVu);
  else
    cEffect.flags &= ~DECLARE_VST_DEPRECATED (effFlagsHasVu);
}
void AudioEffect::DECLARE_VST_DEPRECATED (hasClip) (bool state) {
  if (state)
    cEffect.flags |= DECLARE_VST_DEPRECATED (effFlagsHasClip);
  else
    cEffect.flags &= ~DECLARE_VST_DEPRECATED (effFlagsHasClip);
}
void AudioEffect::DECLARE_VST_DEPRECATED (canMono) (bool state) {
  if (state)
    cEffect.flags |= DECLARE_VST_DEPRECATED (effFlagsCanMono);
  else
    cEffect.flags &= ~DECLARE_VST_DEPRECATED (effFlagsCanMono);
}
void AudioEffect::canProcessReplacing (bool state) {
  if (state)
    cEffect.flags |= effFlagsCanReplacing;
  else
    cEffect.flags &= ~effFlagsCanReplacing;
}
#if VST_2_4_EXTENSIONS
void AudioEffect::canDoubleReplacing (bool state) {
  if (state)
    cEffect.flags |= effFlagsCanDoubleReplacing;
  else
    cEffect.flags &= ~effFlagsCanDoubleReplacing;
}
#endif
void AudioEffect::programsAreChunks (bool state) {
  if (state)
    cEffect.flags |= effFlagsProgramChunks;
  else
    cEffect.flags &= ~effFlagsProgramChunks;
}
void AudioEffect::DECLARE_VST_DEPRECATED (setRealtimeQualities) (VstInt32 qualities) {
  cEffect.DECLARE_VST_DEPRECATED (realQualities) = qualities;
}
void AudioEffect::DECLARE_VST_DEPRECATED (setOfflineQualities) (VstInt32 qualities) {
  cEffect.DECLARE_VST_DEPRECATED (offQualities) = qualities;
}
void AudioEffect::setInitialDelay (VstInt32 delay) {
  cEffect.initialDelay = delay;
}
void AudioEffect::dB2string (float value, char* text, VstInt32 maxLen) {
  if (value <= 0)
    vst_strncpy (text, "-oo", maxLen);
  else
    float2string ((float)(20. * log10 (value)), text, maxLen);
}
void AudioEffect::Hz2string (float samples, char* text, VstInt32 maxLen) {
  float sampleRate = getSampleRate ();
  if (!samples)
    float2string (0, text, maxLen);
  else
    float2string (sampleRate / samples, text, maxLen);
}
void AudioEffect::ms2string (float samples, char* text, VstInt32 maxLen) {
  float2string ((float)(samples * 1000. / getSampleRate ()), text, maxLen);
}
void AudioEffect::float2string (float value, char* text, VstInt32 maxLen) {
  VstInt32 c = 0, neg = 0;
  char string[32];
  char* s;
  double v, integ, i10, mantissa, m10, ten = 10.;
  v = (double)value;
  if (v < 0) {
    neg = 1;
    value = -value;
    v = -v;
    c++;
    if (v > 9999999.) {
      vst_strncpy (string, "Huge!", 31);
      return;
    }
  }
  else if (v > 99999999.) {
    vst_strncpy (string, "Huge!", 31);
    return;
  }
  s = string + 31;
  *s-- = 0;
  *s-- = '.';
  c++;
  integ = floor (v);
  i10 = fmod (integ, ten);
  *s-- = (char)((VstInt32)i10 + '0');
  integ  /=  ten;
  c++;
  while (integ >= 1. && c < 8) {
    i10 = fmod (integ, ten);
    *s-- = (char)((VstInt32)i10 + '0');
    integ  /=  ten;
    c++;
  }
  if (neg)
    *s-- = '-';
  vst_strncpy (text, s + 1, maxLen);
  if (c >= 8)
    return;
  s = string + 31;
  *s-- = 0;
  mantissa = fmod (v, 1.);
  mantissa  *=  pow (ten, (double)(8 - c));
  while (c < 8) {
    if (mantissa <= 0)
      *s-- = '0';
    else {
      m10 = fmod (mantissa, ten);
      *s-- = (char)((VstInt32)m10 + '0');
      mantissa  /=  10.;
    }
    c++;
  }
  vst_strncat (text, s + 1, maxLen);
}
void AudioEffect::int2string (VstInt32 value, char* text, VstInt32 maxLen) {
  if (value >= 100000000) {
    vst_strncpy (text, "Huge!", maxLen);
    return;
  }
  if (value < 0) {
    vst_strncpy (text, "-", maxLen);
    value = -value;
  }
  else
    vst_strncpy (text, "", maxLen);
  bool state = false;
  for (VstInt32 div = 100000000; div >= 1; div  /=  10) {
    VstInt32 digit = value / div;
    value  -=  digit * div;
    if (state || digit > 0) {
      char temp[2] = {'0' + (char)digit, '\0'};
      vst_strncat (text, temp, maxLen);
      state = true;
    }
  }
}
namespace HostCanDos {
  const char* canDoSendVstEvents = "sendVstEvents";
  const char* canDoSendVstMidiEvent = "sendVstMidiEvent";
  const char* canDoSendVstTimeInfo = "sendVstTimeInfo";
  const char* canDoReceiveVstEvents = "receiveVstEvents";
  const char* canDoReceiveVstMidiEvent = "receiveVstMidiEvent";
  const char* canDoReportConnectionChanges = "reportConnectionChanges";
  const char* canDoAcceptIOChanges = "acceptIOChanges";
  const char* canDoSizeWindow = "sizeWindow";
  const char* canDoOffline = "offline";
  const char* canDoOpenFileSelector = "openFileSelector";
  const char* canDoCloseFileSelector = "closeFileSelector";
  const char* canDoStartStopProcess = "startStopProcess";
  const char* canDoShellCategory = "shellCategory";
  const char* canDoSendVstMidiEventFlagIsRealtime = "sendVstMidiEventFlagIsRealtime";
}
namespace PlugCanDos {
  const char* canDoSendVstEvents = "sendVstEvents";
  const char* canDoSendVstMidiEvent = "sendVstMidiEvent";
  const char* canDoReceiveVstEvents = "receiveVstEvents";
  const char* canDoReceiveVstMidiEvent = "receiveVstMidiEvent";
  const char* canDoReceiveVstTimeInfo = "receiveVstTimeInfo";
  const char* canDoOffline = "offline";
  const char* canDoMidiProgramNames = "midiProgramNames";
  const char* canDoBypass = "bypass";
}
AudioEffectX::AudioEffectX (audioMasterCallback audioMaster, VstInt32 numPrograms, VstInt32 numParams)
: AudioEffect (audioMaster, numPrograms, numParams) {}
VstIntPtr AudioEffectX::dispatcher (VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt) {
  VstIntPtr v = 0;
  switch (opcode) {
    case effProcessEvents:
      v = processEvents ((VstEvents*)ptr);
      break;
    case effCanBeAutomated:
      v = canParameterBeAutomated (index) ? 1 : 0;
      break;
    case effString2Parameter:
      v = string2parameter (index, (char*)ptr) ? 1 : 0;
      break;
    case effGetProgramNameIndexed:
      v = getProgramNameIndexed ((VstInt32)value, index, (char*)ptr) ? 1 : 0;
      break;
#if !VST_FORCE_DEPRECATED
    case effGetNumProgramCategories:
      v = getNumCategories ();
      break;
    case effCopyProgram:
      v = copyProgram (index) ? 1 : 0;
      break;
    case effConnectInput:
      inputConnected (index, value ? true : false);
      v = 1;
      break;
    case effConnectOutput:
      outputConnected (index, value ? true : false);
      v = 1;
      break;
#endif
    case effGetInputProperties:
      v = getInputProperties (index, (VstPinProperties*)ptr) ? 1 : 0;
      break;
    case effGetOutputProperties:
      v = getOutputProperties (index, (VstPinProperties*)ptr) ? 1 : 0;
      break;
    case effGetPlugCategory:
      v = (VstIntPtr)getPlugCategory ();
      break;
#if !VST_FORCE_DEPRECATED
    case effGetCurrentPosition:
      v = reportCurrentPosition ();
      break;
    case effGetDestinationBuffer:
      v = ToVstPtr<float> (reportDestinationBuffer ());
      break;
#endif
    case effOfflineNotify:
      v = offlineNotify ((VstAudioFile*)ptr, (VstInt32)value, index != 0);
      break;
    case effOfflinePrepare:
      v = offlinePrepare ((VstOfflineTask*)ptr, (VstInt32)value);
      break;
    case effOfflineRun:
      v = offlineRun ((VstOfflineTask*)ptr, (VstInt32)value);
      break;
    case effSetSpeakerArrangement:
      v = setSpeakerArrangement (FromVstPtr<VstSpeakerArrangement> (value), (VstSpeakerArrangement*)ptr) ? 1 : 0;
      break;
    case effProcessVarIo:
      v = processVariableIo ((VstVariableIo*)ptr) ? 1 : 0;
      break;
#if !VST_FORCE_DEPRECATED
    case effSetBlockSizeAndSampleRate:
      setBlockSizeAndSampleRate ((VstInt32)value, opt);
      v = 1;
      break;
#endif
    case effSetBypass:
      v = setBypass (value ? true : false) ? 1 : 0;
      break;
    case effGetEffectName:
      v = getEffectName ((char*)ptr) ? 1 : 0;
      break;
    case effGetVendorString:
      v = getVendorString ((char*)ptr) ? 1 : 0;
      break;
    case effGetProductString:
      v = getProductString ((char*)ptr) ? 1 : 0;
      break;
    case effGetVendorVersion:
      v = getVendorVersion ();
      break;
    case effVendorSpecific:
      v = vendorSpecific (index, value, ptr, opt);
      break;
    case effCanDo:
      v = canDo ((char*)ptr);
      break;
    case effGetTailSize:
      v = getGetTailSize ();
      break;
#if !VST_FORCE_DEPRECATED
    case effGetErrorText:
      v = getErrorText ((char*)ptr) ? 1 : 0;
      break;
    case effGetIcon:
      v = ToVstPtr<void> (getIcon ());
      break;
    case effSetViewPosition:
      v = setViewPosition (index, (VstInt32)value) ? 1 : 0;
      break;
    case effIdle:
      v = fxIdle ();
      break;
    case effKeysRequired:
      v = (keysRequired () ? 0 : 1);
      break;
#endif
    case effGetParameterProperties:
      v = getParameterProperties (index, (VstParameterProperties*)ptr) ? 1 : 0;
      break;
    case effGetVstVersion:
      v = getVstVersion ();
      break;
#if VST_2_1_EXTENSIONS
    case effEditKeyDown:
      if (beditor) {
        VstKeyCode keyCode = {index, (unsigned char)value, (unsigned char)opt};
        v = beditor->onKeyDown (keyCode) ? 1 : 0;
      }
      break;
    case effEditKeyUp:
      if (beditor) {
        VstKeyCode keyCode = {index, (unsigned char)value, (unsigned char)opt};
        v = beditor->onKeyUp (keyCode) ? 1 : 0;
      }
      break;
    case effSetEditKnobMode:
      if (beditor)
        v = beditor->setKnobMode ((VstInt32)value) ? 1 : 0;
      break;
    case effGetMidiProgramName:
      v = getMidiProgramName (index, (MidiProgramName*)ptr);
      break;
    case effGetCurrentMidiProgram:
      v = getCurrentMidiProgram (index, (MidiProgramName*)ptr);
      break;
    case effGetMidiProgramCategory:
      v = getMidiProgramCategory (index, (MidiProgramCategory*)ptr);
      break;
    case effHasMidiProgramsChanged:
      v = hasMidiProgramsChanged (index) ? 1 : 0;
      break;
    case effGetMidiKeyName:
      v = getMidiKeyName (index, (MidiKeyName*)ptr) ? 1 : 0;
      break;
    case effBeginSetProgram:
      v = beginSetProgram () ? 1 : 0;
      break;
    case effEndSetProgram:
      v = endSetProgram () ? 1 : 0;
      break;
#endif
#if VST_2_3_EXTENSIONS
    case effGetSpeakerArrangement:
      v = getSpeakerArrangement (FromVstPtr<VstSpeakerArrangement*> (value), (VstSpeakerArrangement**)ptr) ? 1 : 0;
      break;
    case effSetTotalSampleToProcess:
      v = setTotalSampleToProcess ((VstInt32)value);
      break;
    case effShellGetNextPlugin:
      v = getNextShellPlugin ((char*)ptr);
      break;
    case effStartProcess:
      v = startProcess ();
      break;
    case effStopProcess:
      v = stopProcess ();
      break;
    case effSetPanLaw:
      v = setPanLaw ((VstInt32)value, opt) ? 1 : 0;
      break;
    case effBeginLoadBank:
      v = beginLoadBank ((VstPatchChunkInfo*)ptr);
      break;
    case effBeginLoadProgram:
      v = beginLoadProgram ((VstPatchChunkInfo*)ptr);
      break;
#endif
#if VST_2_4_EXTENSIONS
    case effSetProcessPrecision :
      v = setProcessPrecision ((VstInt32)value) ? 1 : 0;
      break;
    case effGetNumMidiInputChannels :
      v = getNumMidiInputChannels ();
      break;
    case effGetNumMidiOutputChannels :
      v = getNumMidiOutputChannels ();
      break;
#endif
    default:
      v = AudioEffect::dispatcher (opcode, index, value, ptr, opt);
  }
  return v;
}
void AudioEffectX::resume () {
  if (cEffect.flags & effFlagsIsSynth || canDo ("receiveVstMidiEvent") == 1)
    DECLARE_VST_DEPRECATED (wantEvents) ();
}
void AudioEffectX::DECLARE_VST_DEPRECATED (wantEvents) (VstInt32 filter) {
  if (audioMaster)
    audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterWantMidi), 0, filter, 0, 0);
}
VstTimeInfo* AudioEffectX::getTimeInfo (VstInt32 filter) {
  if (audioMaster) {
    VstIntPtr ret = audioMaster (&cEffect, audioMasterGetTime, 0, filter, 0, 0);
    return FromVstPtr<VstTimeInfo> (ret);
  }
  return 0;
}
VstInt32 AudioEffectX::DECLARE_VST_DEPRECATED (tempoAt) (VstInt32 pos) {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterTempoAt), 0, pos, 0, 0);
  return 0;
}
bool AudioEffectX::sendVstEventsToHost (VstEvents* events) {
  if (audioMaster)
    return audioMaster (&cEffect, audioMasterProcessEvents, 0, 0, events, 0) == 1;
  return 0;
}
VstInt32 AudioEffectX::DECLARE_VST_DEPRECATED (getNumAutomatableParameters) () {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterGetNumAutomatableParameters), 0, 0, 0, 0);
  return 0;
}
VstInt32 AudioEffectX::DECLARE_VST_DEPRECATED (getParameterQuantization) () {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterGetParameterQuantization), 0, 0, 0, 0);
  return 0;
}
bool AudioEffectX::ioChanged () {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterIOChanged, 0, 0, 0, 0) != 0);
  return false;
}
bool AudioEffectX::DECLARE_VST_DEPRECATED (needIdle) () {
  if (audioMaster)
    return (audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterNeedIdle), 0, 0, 0, 0) != 0);
  return false;
}
bool AudioEffectX::sizeWindow (VstInt32 width, VstInt32 height) {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterSizeWindow, width, height, 0, 0) != 0);
  return false;
}
double AudioEffectX::updateSampleRate () {
  if (audioMaster) {
    VstIntPtr res = audioMaster (&cEffect, audioMasterGetSampleRate, 0, 0, 0, 0);
    if (res > 0)
      sampleRate = (float)res;
  }
  return sampleRate;
}
VstInt32 AudioEffectX::updateBlockSize () {
  if (audioMaster) {
    VstInt32 res = (VstInt32)audioMaster (&cEffect, audioMasterGetBlockSize, 0, 0, 0, 0);
    if (res > 0)
      blockSize = res;
  }
  return blockSize;
}
VstInt32 AudioEffectX::getInputLatency () {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, audioMasterGetInputLatency, 0, 0, 0, 0);
  return 0;
}
VstInt32 AudioEffectX::getOutputLatency () {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, audioMasterGetOutputLatency, 0, 0, 0, 0);
  return 0;
}
AEffect* AudioEffectX::DECLARE_VST_DEPRECATED (getPreviousPlug) (VstInt32 input) {
  if (audioMaster) {
    VstIntPtr ret = audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterGetPreviousPlug), 0, 0, 0, 0);
    return FromVstPtr<AEffect> (ret);
  }
  return 0;
}
AEffect* AudioEffectX::DECLARE_VST_DEPRECATED (getNextPlug) (VstInt32 output) {
  if (audioMaster) {
    VstIntPtr ret = audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterGetNextPlug), 0, 0, 0, 0);
    return FromVstPtr<AEffect> (ret);
  }
  return 0;
}
VstPlugCategory AudioEffectX::getPlugCategory () {
  if (cEffect.flags & effFlagsIsSynth)
    return kPlugCategSynth;
  return kPlugCategUnknown;
}
VstInt32 AudioEffectX::DECLARE_VST_DEPRECATED (willProcessReplacing) () {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterWillReplaceOrAccumulate), 0, 0, 0, 0);
  return 0;
}
VstInt32 AudioEffectX::getCurrentProcessLevel () {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, audioMasterGetCurrentProcessLevel, 0, 0, 0, 0);
  return 0;
}
VstInt32 AudioEffectX::getAutomationState () {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, audioMasterGetAutomationState, 0, 0, 0, 0);
  return 0;
}
void AudioEffectX::DECLARE_VST_DEPRECATED (wantAsyncOperation) (bool state) {
  if (state)
    cEffect.flags |= DECLARE_VST_DEPRECATED (effFlagsExtIsAsync);
  else
    cEffect.flags &= ~DECLARE_VST_DEPRECATED (effFlagsExtIsAsync);
}
void AudioEffectX::DECLARE_VST_DEPRECATED (hasExternalBuffer) (bool state) {
  if (state)
    cEffect.flags |= DECLARE_VST_DEPRECATED (effFlagsExtHasBuffer);
  else
    cEffect.flags &= ~DECLARE_VST_DEPRECATED (effFlagsExtHasBuffer);
}
bool AudioEffectX::offlineRead (VstOfflineTask* offline, VstOfflineOption option, bool readSource) {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterOfflineRead, readSource, option, offline, 0) != 0);
  return false;
}
bool AudioEffectX::offlineWrite (VstOfflineTask* offline, VstOfflineOption option) {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterOfflineWrite, 0, option, offline, 0) != 0);
  return false;
}
bool AudioEffectX::offlineStart (VstAudioFile* audioFiles, VstInt32 numAudioFiles, VstInt32 numNewAudioFiles) {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterOfflineStart, numNewAudioFiles, numAudioFiles, audioFiles, 0) != 0);
  return false;
}
VstInt32 AudioEffectX::offlineGetCurrentPass () {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterOfflineGetCurrentPass, 0, 0, 0, 0) != 0);
  return false;
}
VstInt32 AudioEffectX::offlineGetCurrentMetaPass () {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterOfflineGetCurrentMetaPass, 0, 0, 0, 0) != 0);
  return false;
}
void AudioEffectX::DECLARE_VST_DEPRECATED (setOutputSamplerate) (float sampleRate) {
  if (audioMaster)
    audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterSetOutputSampleRate), 0, 0, 0, sampleRate);
}
VstSpeakerArrangement* AudioEffectX::DECLARE_VST_DEPRECATED (getInputSpeakerArrangement) () {
  if (audioMaster) {
    VstIntPtr ret = audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterGetInputSpeakerArrangement), 0, 0, 0, 0);
    return FromVstPtr<VstSpeakerArrangement> (ret);
  }
  return 0;
}
VstSpeakerArrangement* AudioEffectX::DECLARE_VST_DEPRECATED (getOutputSpeakerArrangement) () {
  if (audioMaster) {
    VstIntPtr ret = audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterGetOutputSpeakerArrangement), 0, 0, 0, 0);
    return FromVstPtr<VstSpeakerArrangement> (ret);
  }
  return 0;
}
bool AudioEffectX::getHostVendorString (char* text) {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterGetVendorString, 0, 0, text, 0) != 0);
  return false;
}
bool AudioEffectX::getHostProductString (char* text) {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterGetProductString, 0, 0, text, 0) != 0);
  return false;
}
VstInt32 AudioEffectX::getHostVendorVersion () {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, audioMasterGetVendorVersion, 0, 0, 0, 0);
  return 0;
}
VstIntPtr AudioEffectX::hostVendorSpecific (VstInt32 lArg1, VstIntPtr lArg2, void* ptrArg, float floatArg) {
  if (audioMaster)
    return audioMaster (&cEffect, audioMasterVendorSpecific, lArg1, lArg2, ptrArg, floatArg);
  return 0;
}
VstInt32 AudioEffectX::canHostDo (char* text) {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterCanDo, 0, 0, text, 0) != 0);
  return 0;
}
void AudioEffectX::isSynth (bool state) {
  if (state)
    cEffect.flags |= effFlagsIsSynth;
  else
    cEffect.flags &= ~effFlagsIsSynth;
}
void AudioEffectX::noTail (bool state) {
  if (state)
    cEffect.flags |= effFlagsNoSoundInStop;
  else
    cEffect.flags &= ~effFlagsNoSoundInStop;
}
VstInt32 AudioEffectX::getHostLanguage () {
  if (audioMaster)
    return (VstInt32)audioMaster (&cEffect, audioMasterGetLanguage, 0, 0, 0, 0);
  return 0;
}
void* AudioEffectX::DECLARE_VST_DEPRECATED (openWindow) (DECLARE_VST_DEPRECATED (VstWindow)* window) {
  if (audioMaster) {
    VstIntPtr ret = audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterOpenWindow), 0, 0, window, 0);
    return FromVstPtr<void> (ret);
  }
  return 0;
}
bool AudioEffectX::DECLARE_VST_DEPRECATED (closeWindow) (DECLARE_VST_DEPRECATED (VstWindow)* window) {
  if (audioMaster)
    return (audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterCloseWindow), 0, 0, window, 0) != 0);
  return false;
}
void* AudioEffectX::getDirectory () {
  if (audioMaster) {
    VstIntPtr ret = (audioMaster (&cEffect, audioMasterGetDirectory, 0, 0, 0, 0));
    return FromVstPtr<void> (ret);
  }
  return 0;
}
bool AudioEffectX::updateDisplay () {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterUpdateDisplay, 0, 0, 0, 0)) ? true : false;
  return 0;
}
#if VST_2_1_EXTENSIONS
bool AudioEffectX::beginEdit (VstInt32 index) {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterBeginEdit, index, 0, 0, 0)) ? true : false;
  return 0;
}
bool AudioEffectX::endEdit (VstInt32 index) {
  if (audioMaster)
    return (audioMaster (&cEffect, audioMasterEndEdit, index, 0, 0, 0)) ? true : false;
  return 0;
}
bool AudioEffectX::openFileSelector (VstFileSelect* ptr) {
  if (audioMaster && ptr)
    return (audioMaster (&cEffect, audioMasterOpenFileSelector, 0, 0, ptr, 0)) ? true : false;
  return 0;
}
#endif
#if VST_2_2_EXTENSIONS
bool AudioEffectX::closeFileSelector (VstFileSelect* ptr) {
  if (audioMaster && ptr)
    return (audioMaster (&cEffect, audioMasterCloseFileSelector, 0, 0, ptr, 0)) ? true : false;
  return 0;
}
bool AudioEffectX::DECLARE_VST_DEPRECATED (getChunkFile) (void* nativePath) {
  if (audioMaster && nativePath)
    return (audioMaster (&cEffect, DECLARE_VST_DEPRECATED (audioMasterGetChunkFile), 0, 0, nativePath, 0)) ? true : false;
  return 0;
}
#endif
#if VST_2_3_EXTENSIONS
bool AudioEffectX::allocateArrangement (VstSpeakerArrangement** arrangement, VstInt32 nbChannels) {
  if (*arrangement) {
    char *ptr = (char*)(*arrangement);
    delete [] ptr;
  }
  VstInt32 size = 2 * sizeof (VstInt32) + nbChannels * sizeof (VstSpeakerProperties);
  char* ptr = new char[size];
  if (!ptr)
    return false;
  memset (ptr, 0, size);
  *arrangement = (VstSpeakerArrangement*)ptr;
  (*arrangement)->numChannels = nbChannels;
  return true;
}
bool AudioEffectX::deallocateArrangement (VstSpeakerArrangement** arrangement) {
  if (*arrangement) {
    char *ptr = (char*)(*arrangement);
    delete [] ptr;
    *arrangement = 0;
  }
  return true;
}
bool AudioEffectX::copySpeaker (VstSpeakerProperties* to, VstSpeakerProperties* from) {
  if ((from == NULL) || (to == NULL))
    return false;
  vst_strncpy (to->name, from->name, 63);
  to->type      = from->type;
  to->azimuth   = from->azimuth;
  to->elevation = from->elevation;
  to->radius    = from->radius;
  to->reserved  = from->reserved;
  memcpy (to->future, from->future, 28);
  return true;
}
bool AudioEffectX::matchArrangement (VstSpeakerArrangement** to, VstSpeakerArrangement* from) {
  if (from == NULL)
    return false;
  if ((!deallocateArrangement (to)) || (!allocateArrangement (to, from->numChannels)))
    return false;
  (*to)->type = from->type;
  for (VstInt32 i = 0; i < (*to)->numChannels; i++) {
    if (!copySpeaker (&((*to)->speakers[i]), &(from->speakers[i])))
      return false;
  }
  return true;
}
#endif

#endif