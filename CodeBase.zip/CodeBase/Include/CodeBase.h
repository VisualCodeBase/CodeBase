/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*    This file was generated with    */
/*    CodeBase - Compiler Frontend To C++ - (Version 1.00)    */
/*    Copyright � SoftBase Labs.    */
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

#ifndef CodeBase_h_
#define CodeBase_h_


/*((((((((((((((  Compilers/Platforms Definitions  ))))))))))))))*/


#ifdef __cplusplus
#define cb_EXPORT EXTERN_C __declspec(dllexport)
#define cb_IMPORT EXTERN_C __declspec(dllimport)
#else
#define cb_EXPORT __declspec(dllexport)
#define cb_IMPORT __declspec(dllimport)
#endif
#define cb_CDECL __cdecl
#define cb_STDCALL __stdcall
#define cb_FASTCALL __fastcall
#define cb_PASCAL PASCAL

#if defined __clang__
#define cb_DEFCALL
#elif defined(__GNUC__) || defined(__GNUG__)
#define cb_DEFCALL cb_CDECL
#else
#define cb_DEFCALL cb_STDCALL
#endif
#define cb_CLIBCALL cb_CDECL
#if defined(__GNUC__) || defined(__GNUG__) || defined(__clang__)
#endif
#ifndef cb_BeginExternC
#ifdef __cplusplus
#define cb_BeginExternC extern "C" {
#define cb_EndExternC }
#else
#define cb_BeginExternC
#define cb_EndExternC
#endif
#endif
#define cb_STRING_SIZE 6144
#define cb_MAX_FILE_NAME 4096
#define cb_INVALID ((void*)-1)
#define cb_MAX_TMPDYNSTR_CYCLES_ 0x600
#define cb_MAX_DLL_CYCLES_ 0x300
#define cb_MAX_INTEGER64 ((signed long long)0x7FFFFFFFFFFFFFFF)
#define cb_MAX_INTEGER32 ((signed int)0x7FFFFFFF)
#define cb_MAX_INTEGER16 ((signed short)0x7FFF)
#define cb_MAX_INTEGER8 ((signed char)0x7f)
#define cb_MIN_INTEGER64 ((signed long long)0x8000000000000000)
#define cb_MIN_INTEGER32 ((signed int)0x80000000)
#define cb_MIN_INTEGER16 ((signed short)0x8000)
#define cb_MIN_INTEGER8 ((signed char)0x80)
#define cb_MAX_INTEGER cb_MAX_INTEGER32
#define cb_MIN_INTEGER cb_MIN_INTEGER32
#define cb_PTR_SIZE64 8
#define cb_PTR_SIZE32 4
#define cb_PATH_SEPARATOR '\\'
#define cb_PATH_SEPARATORW L'\\'
#define cb_PATH_SEPARATOR_STR "\\"
#define cb_PATH_SEPARATOR_STRW L"\\"
#define cb_EMPTYSTRW (wchar_t*)cb_EMPTYSTR
#define cb_ASC1(x) (*(unsigned char*)(x))
#define cb_ASC1W(x) (*(wchar_t*)(x))
#define cb_ASC2(x,y) (((unsigned char*)(x))[y])
#define cb_ASC2W(x,y) (((wchar_t*)(x))[y])
#define cb_pasASC1(x) (*(unsigned char*)(sizeof(cb_Integer)+(cb_Integer)(x)))
#define cb_pasASC1W(x) (*(wchar_t*)(sizeof(cb_Integer)+(cb_Integer)(x)))
#define cb_pasASC2(x,y) (((unsigned char*)(sizeof(cb_Integer)+(cb_Integer)(x)))[y])
#define cb_pasASC2W(x,y) (((wchar_t*)(sizeof(cb_Integer)+(cb_Integer)(x)))[y])
#define cb_AS(x) x
#define cb_AT(x,y) (*(x*)(y))
#define cb_ATptr(x,y) ((x*)(y))
#define cb_CAST(x,y) ((x)(y))
#define cb_CASTrev(x,y) ((y)(x))
#define cb_CBYTE(x) ((BYTE)(x))
#define cb_CCHAR(x) ((char)(x))
#define cb_CDWD(x) ((DWORD)(x))
#define cb_CINT(x) ((cb_Integer)(x))
#define cb_CUINT(x) ((cb_UInteger)(x))
#define cb_CLNG(x) ((long)(x))
#define cb_CULNG(x) ((unsigned long)(x))
#define cb_CLNGLNG(x) ((long long)(x))
#define cb_CULNGLNG(x) ((unsigned long long)(x))
#define cb_CREAL(x) ((float)(x))
#define cb_CSHORT(x) ((short)(x))
#define cb_CSNG(x) ((float)(x))
#define cb_CDBL(x) ((double)(x))
#define cb_CLDBL(x) ((long double)(x))
#define cb_CWORD(x) ((WORD)(x))
#define cb_CBOOL(x) ((x)?1:0)
#define cb_CBOOLSTR(x) ((x) ? "True" : "False")
#define cb_EQV(x,y) ~((x)^(y))
#define cb_Max(x,y) ((x)>(y)?(x):(y))
#define cb_Min(x,y) ((x)<(y)?(x):(y))
#define Not !
#define cb_StrPtr(x) ((char*)(x))
#define cb_StrWPtr(x) ((wchar_t*)(x))
#define cb_CStrPtr(x) ((const char*)(x))
#define cb_CStrWPtr(x) ((const wchar_t*)(x))
#define cb_pasStrPtr(x) ((char*)(sizeof(cb_Integer)+(cb_Integer)(x)))
#define cb_pasStrWPtr(x) ((wchar_t*)(sizeof(cb_Integer)+(cb_Integer)(x)))
#define cb_pasCStrPtr(x) ((const char*)(sizeof(cb_Integer)+(cb_Integer)(x)))
#define cb_pasCStrWPtr(x) ((const wchar_t*)(sizeof(cb_Integer)+(cb_Integer)(x)))
#define cb_UBound1_(x) ((sizeof(x)/sizeof((x)[0]))-1)
#define cb_UBound1(x) ((sizeof(x)/sizeof((x)[0]))-1)
#define cb_CountOf1_(x) (sizeof(x)/sizeof((x)[0]))
#define cb_CountOf1(x) (sizeof(x)/sizeof((x)[0]))
#define cb_HIGH(x,y) ((x*)&(y))[1]
#define cb_LOW(x,y) ((x*)&(y))[0]
#define cb_HighByte(x) ((BYTE*)&(x))[1]
#define cb_LowByte(x) ((BYTE*)&(x))[0]
#define cb_HighChar(x) ((char*)&(x))[1]
#define cb_LowChar(x) ((char*)&(x))[0]
#define cb_LowCharW(x) ((wchar_t*)&(x))[0]
#define cb_HighDWord(x) ((DWORD*)&(x))[1]
#define cb_LowDWord(x) ((DWORD*)&(x))[0]
#define cb_HighInt(x) ((cb_Integer*)&(x))[1]
#define cb_LowInt(x) ((cb_Integer*)&(x))[0]
#define cb_HighLong(x) ((signed int*)&(x))[1]
#define cb_LowLong(x) ((signed int*)&(x))[0]
#define cb_HighShort(x) ((short*)&(x))[1]
#define cb_LowShort(x) ((short*)&(x))[0]
#define cb_HighUInt(x) ((cb_UInteger*)&(x))[1]
#define cb_LowUInt(x) ((cb_UInteger*)&(x))[0]
#define cb_HighWord(x) ((WORD*)&(x))[1]
#define cb_LowWord(x) ((WORD*)&(x))[0]
#define cb_IIF1(x,z) ((x) ? : (z))
#define cb_IIF2(x,y,z) ((x) ? (y) : (z))
#define cb_MkTB(x) (unsigned long long)((x)*1099511627776.0)
#define cb_MkGB(x) (cb_UInteger)((x)*1073741824.0)
#define cb_MkKB(x) (cb_UInteger)((x)*1024.0)
#define cb_MkMB(x) (cb_UInteger)((x)*1048576.0)
#define  cbBlack  RGB(0,0,0)
#define  cbLightBlack  RGB(16,16,16)
#define  cbDarkBlue  RGB(0,0,192)
#define  cbBlue  RGB(0,0,224)
#define  cbLightBlue  RGB(0,0,255)
#define  cbDarkBrown  RGB(0x86,0x0A,0x0A)
#define  cbBrown  RGB(0xA6,0x2A,0x2A)
#define  cbLightBrown  RGB(0xC6,0x4A,0x4A)
#define  cbDarkCyan  RGB(0,192,192)
#define  cbCyan  RGB(0,224,224)
#define  cbLightCyan  RGB(0,255,255)
#define  cbDarkSilver  RGB(48,48,48)
#define  cbSilver  RGB(80,80,80)
#define  cbLightSilver  RGB(112,112,112)
#define  cbDarkGreen  RGB(0,192,0)
#define  cbGreen  RGB(0,224,0)
#define  cbLightGreen  RGB(0,255,0)
#define  cbDarkMagenta  RGB(192,0,192)
#define  cbMagenta  RGB(224,0,224)
#define  cbLightMagenta  RGB(255,0,255)
#define  cbDarkOrange  RGB(192,64,0)
#define  cbOrange  RGB(224,96,0)
#define  cbLightOrange  RGB(255,128,0)
#define  cbDarkPink  RGB(0x8C,0x5F,0x5F)
#define  cbPink  RGB(0xAC,0x7F,0x7F)
#define  cbLightPink  RGB(0xCC,0x9F,0x9F)
#define  cbDarkPurple  RGB(80,0,80)
#define  cbPurple  RGB(112,0,112)
#define  cbLightPurple  RGB(144,0,144)
#define  cbDarkRed  RGB(192,0,0)
#define  cbRed  RGB(224,0,0)
#define  cbLightRed  RGB(255,0,0)
#define  cbDarkGray  RGB(144,144,144)
#define  cbGray  RGB(176,176,176)
#define  cbLightGray  RGB(208,208,208)
#define  cbDarkViolet  RGB(192,64,192)
#define  cbViolet  RGB(224,96,224)
#define  cbLightViolet  RGB(255,128,255)
#define  cbDarkWhite  RGB(240,240,240)
#define  cbWhite  RGB(255,255,255)
#define  cbDarkYellow  RGB(192,192,0)
#define  cbYellow  RGB(224,224,0)
#define  cbLightYellow  RGB(255,255,0)
#ifndef cb_ABORT_EXIT_CODE
#define cb_ABORT_EXIT_CODE EXIT_FAILURE
#endif
#ifdef __cplusplus
#define cb_ExtendsStruct(x) : x {
#else
#define cb_ExtendsStruct(x) { x;
#endif
#define _O_UNICODE 0x40000000
#define _O_MEMORY 0x20000000
#define _O_OPEN 0x10000000
#define cb_GetWndData(x) GetWindowLongPtr(x,GWLP_USERDATA)
#define cb_SetWndData(x,y) SetWindowLongPtr(x,GWLP_USERDATA,(LONG_PTR)(y))

/*((((((((((((((  System Types  ))))))))))))))*/


#define cb_Bit BYTE
#define cb_Bits cb_Bit*
#define cb_comObject VARIANT
#define Pcb_comObject VARIANT*
#define cb_File void
#define cb_Int8 signed char
#define cb_UInt8 unsigned char
#define cb_Int16 signed short
#define cb_UInt16 unsigned short
#define cb_Int32 signed int
#define cb_UInt32 unsigned int
#define cb_Int64 signed long long
#define cb_UInt64 unsigned long long
#define cb_Integer signed int
#define cb_UInteger unsigned int
#define cb_Boolean signed int
#ifndef INTEGER
#define INTEGER signed int
#endif
#ifndef UINTEGER
#define UINTEGER unsigned int
#endif
#define cb_PString char*
#define cb_PStringT _TCHAR*
#define cb_PStringW wchar_t*
#define cb_String char*
#define cb_StringT _TCHAR*
#define cb_StringW wchar_t*
#define cb_PpasString BYTE*
#define cb_PpasStringT BYTE*
#define cb_PpasStringW BYTE*
#define cb_pasString BYTE*
#define cb_pasStringW BYTE*
#define cb_pasStringT BYTE*
#define HTHREAD HANDLE

typedef struct cb_FIND_DATA_
#ifdef __cplusplus
 : WIN32_FIND_DATA
#endif
{
#ifndef __cplusplus
  WIN32_FIND_DATA;
#endif
  char  sPath[0x1000];
  HANDLE  FileHandle;
}cb_FIND_DATA;

typedef struct cb_FIND_DATAW_
#ifdef __cplusplus
 : WIN32_FIND_DATAW
#endif
{
#ifndef __cplusplus
  WIN32_FIND_DATAW;
#endif
  wchar_t  sPath[0x1000];
  HANDLE  FileHandle;
}cb_FIND_DATAW;
typedef cb_Integer (cb_CDECL *cbApp_EventsType_)(const void*,MSG*);

typedef struct cb_LOGFONT_
#ifdef __cplusplus
 : LOGFONT
#endif
{
#ifndef __cplusplus
  LOGFONT;
#endif
  cb_Integer Size;
  COLORREF Color;
}cb_LOGFONT;

typedef struct structcbApp_Error_ {
  cb_Integer Number;
  char Description[2048<<1];
}structcbApp_Error;

typedef struct structcbApp_ {
  char Path[0x1000];
  char *EXEName;
  DWORD_PTR ProcessId;
  DWORD ThreadId;
  HINSTANCE  hInstance;
  char *ClassName;
  cb_Integer ShowCmd;
}structcbApp;

typedef struct cb_TGroupBox_ {
  WNDPROC Events;
  HWND hWndP;
  COLORREF BackColor;
  HBITMAP hBmp, hBmp_;
  HBRUSH hBrush;
  cb_Integer iStretch;
  cb_Integer iTrans;
  cb_Integer UserData;
}cb_TGroupBox;

typedef struct cb_TFrameBox_ {
  HWND hWndP;
  HWND hWndLabel;
  COLORREF BackColor;
  HBITMAP hBmp, hBmp_;
  HBRUSH hBrush;
  cb_Integer iStretch;
  cb_Integer iTrans;
  cb_Integer UserData;
}cb_TFrameBox;

typedef struct cb_TPictureBox_ {
  HWND hWndP;
  COLORREF BackColor;
  COLORREF ExBackColor;
  COLORREF ForeColor;
  HBITMAP hBmp, hBmp_;
  HBRUSH hBrush;
  HFONT hFont;
  cb_Integer iStretch;
  cb_Integer iTrans;
  char *sCaption;
  cb_Integer UserData;
}cb_TPictureBox;

/*((((((((((((((  System Variables  ))))))))))))))*/

cb_BeginExternC
EXTERN_C char  cb_EMPTYSTR[4];
cb_EndExternC

/*((((((((((((((  Public Declarations  ))))))))))))))*/

EXTERN_C void CodeBase_Terminate (void);

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Declarations -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


#endif  // CodeBase_h_
