
#ifndef RegisteryINI_H_
#define RegisteryINI_H_

#include <windows.h>

#define RegCloseKey RegisteryINI_CloseKey
#define RegQueryValueEx RegisteryINI_QueryValueEx
#define RegQueryValue RegisteryINI_QueryValue
#define RegQueryInfoKey RegisteryINI_QueryInfoKey
#define RegSetValueEx RegisteryINI_SetValueEx
#define RegSetValue RegisteryINI_SetValue
#define RegDeleteValue RegisteryINI_DeleteValue
#define RegDeleteKeyEx RegisteryINI_DeleteKeyEx
#define RegDeleteKey RegisteryINI_DeleteKey
#define RegCreateKeyEx RegisteryINI_CreateKeyEx
#define RegCreateKey RegisteryINI_CreateKey
#define RegEnumKeyEx RegisteryINI_EnumKeyEx
#define RegEnumKey RegisteryINI_EnumKey
#define RegEnumValue RegisteryINI_EnumValue
#define RegOpenKeyEx RegisteryINI_OpenKeyEx
#define RegOpenKey RegisteryINI_OpenKey
#define RegSetKeyValue RegisteryINI_SetKeyValue
#define RegSetKeySecurity RegisteryINI_SetKeySecurity
#define RegFlushKey RegisteryINI_FlushKey
#define RegNotifyChangeKeyValue RegisteryINI_NotifyChangeKeyValue

#ifndef LPCBYTE
#define LPCBYTE const unsigned char*
#endif

#ifdef __cplusplus
extern "C" {
#endif
LONG WINAPI RegisteryINI_CloseKey(HKEY hKey);
LONG WINAPI RegisteryINI_QueryValueEx(HKEY hKey, LPCTSTR lpValueName, LPDWORD lpr1, LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData);
LONG WINAPI RegisteryINI_QueryValue(HKEY hKey, LPCTSTR lpSubKey, LPTSTR lpValue, PLONG lpcbValue);
LONG WINAPI RegisteryINI_QueryInfoKey(HKEY hKey, LPTSTR lpClass, LPDWORD lpcClass, LPDWORD lpr1, LPDWORD lpcSubKeys, LPDWORD lpcMaxSubKeyLen, LPDWORD lpcMaxClassLen, LPDWORD lpcValues, LPDWORD lpcMaxValueNameLen, LPDWORD lpcMaxValueLen, LPDWORD lpcbSecurityDescriptor, PFILETIME lpftLastWriteTime);
LONG WINAPI RegisteryINI_SetValueEx(HKEY hKey, LPCTSTR lpValueName, DWORD r1, DWORD dwType, LPCBYTE lpData, DWORD cbData);
LONG WINAPI RegisteryINI_SetValue(HKEY hKey, LPCTSTR lpSubKey, DWORD dwType, LPCTSTR lpData, DWORD cbData);
LONG WINAPI RegisteryINI_DeleteValue(HKEY hKey, LPCTSTR lpValueName);
LONG WINAPI RegisteryINI_DeleteKeyEx(HKEY hKey, LPCTSTR lpSubKey, REGSAM samDesired, DWORD dwr1);
LONG WINAPI RegisteryINI_DeleteKey(HKEY hKey, LPCTSTR lpSubKey);
LONG WINAPI RegisteryINI_CreateKeyEx(HKEY hKey, LPCTSTR lpSubKey, DWORD r1, LPCTSTR lpClass, DWORD dwOptions, REGSAM samDesired, LPSECURITY_ATTRIBUTES lpSecurityAttributes, PHKEY phkResult, LPDWORD lpdwDisposition);
LONG WINAPI RegisteryINI_CreateKey(HKEY hKey, LPCTSTR lpSubKey, PHKEY phkResult);
LONG WINAPI RegisteryINI_EnumKeyEx(HKEY hKey, DWORD dwIndex, LPTSTR lpName, LPDWORD lpcName, LPDWORD lpr1, LPTSTR lpClass, LPDWORD lpcClass, PFILETIME lpftLastWriteTime);
LONG WINAPI RegisteryINI_EnumKey(HKEY hKey, DWORD dwIndex, LPTSTR lpName, DWORD cchName);
LONG WINAPI RegisteryINI_EnumValue(HKEY hKey, DWORD dwIndex, LPTSTR lpValueName, LPDWORD lpcchValueName, LPDWORD lpr1, LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData);
LONG WINAPI RegisteryINI_OpenKeyEx(HKEY hKey, LPCTSTR lpSubKey, DWORD ulOptions, REGSAM samDesired, PHKEY phkResult);
LONG WINAPI RegisteryINI_OpenKey(HKEY hKey, LPCTSTR lpSubKey, PHKEY phkResult);
LONG WINAPI RegisteryINI_SetKeyValue(HKEY hKey,/*_In_opt_*/ LPCTSTR lpSubKey,/*_In_opt_*/ LPCTSTR lpValueName, DWORD dwType,/*_In_opt_*/ LPCVOID lpData, DWORD cbData);
LONG WINAPI RegisteryINI_SetKeySecurity(HKEY hKey, SECURITY_INFORMATION si, PSECURITY_DESCRIPTOR psd);
LONG WINAPI RegisteryINI_FlushKey(HKEY hKey);
LONG WINAPI RegisteryINI_NotifyChangeKeyValue(HKEY hKey, BOOL WatchSubtree, DWORD dwNotifyFilter, HANDLE hEvent, BOOL IsAsync);

#ifndef RegisteryINI_FileName
EXTERN_C char RegisteryINI_FileName[4096];
#endif

#ifdef __cplusplus
}
#endif

#endif
