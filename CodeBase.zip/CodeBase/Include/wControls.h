/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*    This file was generated with    */
/*    CodeBase - Compiler Frontend To C++ - (Version 1.00)    */
/*    Copyright � SoftBase Labs.    */
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

#ifndef wControls_h_
#define wControls_h_

#if defined(__GNUC__) || defined(__GNUG__)
#include <malloc.h>
#endif
#include <wchar.h>
#include <tchar.h>
#include <winsock2.h>
#include <wininet.h>
#include <richedit.h>
#include <commctrl.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <ocidl.h>
#include <olectl.h>
#include <ole2.h>
#include <oleauto.h>
#include <cb_Def.h>
#include <vb_Def.h>

/*((((((((((((((  Compilers/Platforms Definitions  ))))))))))))))*/

#ifndef WINSOCK_VERSION
#define WINSOCK_VERSION  MAKEWORD(2,2)
#endif
#define cb_CLIBCALL cb_CDECL
#if defined(__GNUC__) || defined(__GNUG__) || defined(__clang__)
#define INTERNET_DIAL_FORCE_PROMPT 0x2000
#define INTERNET_DIAL_SHOW_OFFLINE 0x4000
#define FLAG_ICC_FORCE_CONNECTION 0x00000001
#endif

/*((((((((((((((  Public Headers  ))))))))))))))*/

#include <cCollection.h>
#include <cString.h>
#include <cHRTimer.h>
#ifndef _COOLSBLIB_INCLUDED
#define _COOLSBLIB_INCLUDED

#ifdef __cplusplus
extern "C"{
#endif

#include <windows.h>

// To complement the exisiting SB_HORZ, SB_VERT, SB_BOTH
// scrollbar identifiers
#define COOLSB_NONE (-1)
#define SB_INSBUT  (-2)

//
//  Arrow size defines
//
#define SYSTEM_METRIC (-1)


//
// general scrollbar styles
//
// use the standard ESB_DISABLE_xxx flags to represent the
// enabled / disabled states. (defined in winuser.h)
//
#define CSBS_THUMBALWAYS    4
//#define CSBS_VISIBLE      8

//cool scrollbar styles for Flat scrollbars
#define CSBS_NORMAL      0
#define CSBS_FLAT      1
#define CSBS_HOTTRACKED    2

//
//  Button mask flags for indicating which members of CoolSB_SCROLLBUT
//  to use during a button insertion / modification
//
#define SBBF_TYPE      0x0001
#define SBBF_ID        0x0002
#define SBBF_PLACEMENT    0x0004
#define SBBF_SIZE      0x0008
#define SBBF_BITMAP      0x0010
#define SBBF_ENHMETAFILE  0x0020
//#define SBBF_OWNERDRAW    0x0040  //unused at present
#define SBBF_CURSOR      0x0080
#define SBBF_BUTMINMAX    0x0100
#define SBBF_STATE      0x0200

//button styles (states)
#define SBBS_NORMAL      0
#define SBBS_PUSHED      1
#define SBBS_CHECKED    SBBS_PUSHED

//
// scrollbar button types
//
#define SBBT_PUSHBUTTON    1  //standard push button
#define SBBT_TOGGLEBUTTON  2  //toggle button
#define SBBT_FIXED      3  //fixed button (non-clickable)
#define SBBT_FLAT      4  //blank area (flat, with border)
#define SBBT_BLANK      5  //blank area (flat, no border)
#define SBBT_DARK      6  //dark blank area (flat)
#define SBBT_OWNERDRAW    7  //user draws the button via a WM_NOTIFY

#define SBBT_MASK      0x1f  //mask off low 5 bits

//button type modifiers
#define SBBM_RECESSED    0x0020  //recessed when clicked (like Word 97)
#define SBBM_LEFTARROW    0x0040
#define SBBM_RIGHTARROW    0x0080
#define SBBM_UPARROW    0x0100
#define SBBM_DOWNARROW    0x0200
#define SBBM_RESIZABLE    0x0400
#define SBBM_TYPE2      0x0800
#define SBBM_TYPE3      0x1000
#define SBBM_TOOLTIPS    0x2000  //currently unused (define COOLSB_TOOLTIPS in userdefs.h)

//button placement flags
#define SBBP_LEFT  1
#define SBBP_RIGHT  2
#define SBBP_TOP  1  //3
#define SBBP_BOTTOM 2  //4


//
//  Button command notification codes
//  for sending with a WM_COMMAND message
//
#define CSBN_BASE  0
#define CSBN_CLICKED (1 + CSBN_BASE)
#define CSBN_HILIGHT (2 + CSBN_BASE)

//
//  Minimum size in pixels of a scrollbar thumb
//
#define MINTHUMBSIZE_NT4   8
#define MINTHUMBSIZE_2000  6

//define some more hittest values for our cool-scrollbar
#define HTSCROLL_LEFT    (SB_LINELEFT)
#define HTSCROLL_RIGHT    (SB_LINERIGHT)
#define HTSCROLL_UP      (SB_LINEUP)
#define HTSCROLL_DOWN    (SB_LINEDOWN)
#define HTSCROLL_THUMB    (SB_THUMBTRACK)
#define HTSCROLL_PAGEGUP  (SB_PAGEUP)
#define HTSCROLL_PAGEGDOWN  (SB_PAGEDOWN)
#define HTSCROLL_PAGELEFT  (SB_PAGELEFT)
#define HTSCROLL_PAGERIGHT  (SB_PAGERIGHT)

#define HTSCROLL_NONE    (-1)
#define HTSCROLL_NORMAL    (-1)

#define HTSCROLL_INSERTED  (128)
#define HTSCROLL_PRE    (32 | HTSCROLL_INSERTED)
#define HTSCROLL_POST    (64 | HTSCROLL_INSERTED)

/* maximum number of inserted buttons per bar */
#define MAX_COOLSB_BUTS 16

/*

  Public interface to the Cool Scrollbar library


cb_Integer  WINAPI InitializeCoolSB(HWND hwnd);
HRESULT WINAPI UninitializeCoolSB  (HWND hwnd);
*/


cb_Integer WINAPI CoolSB_SetMinThumbSize(HWND hwnd, cb_UInteger wBar, cb_UInteger size);
cb_Integer WINAPI CoolSB_IsThumbTracking(HWND hwnd);
cb_Integer WINAPI CoolSB_IsCoolScrollEnabled(HWND hwnd);

//
cb_Integer WINAPI CoolSB_EnableScrollBar  (HWND hwnd, cb_Integer wSBflags, cb_UInteger wArrows);
cb_Integer WINAPI CoolSB_GetScrollInfo  (HWND hwnd, cb_Integer fnBar, LPSCROLLINFO lpsi);
cb_Integer   WINAPI CoolSB_GetScrollPos  (HWND hwnd, cb_Integer nBar);
cb_Integer WINAPI CoolSB_GetScrollRange  (HWND hwnd, cb_Integer nBar, LPINT lpMinPos, LPINT lpMaxPos);

//
cb_Integer   WINAPI CoolSB_SetScrollInfo  (HWND hwnd, cb_Integer fnBar, LPSCROLLINFO lpsi, cb_Integer fRedraw);
cb_Integer  WINAPI CoolSB_SetScrollPos  (HWND hwnd, cb_Integer nBar, cb_Integer nPos, cb_Integer fRedraw);
cb_Integer  WINAPI CoolSB_SetScrollRange  (HWND hwnd, cb_Integer nBar, cb_Integer nMinPos, cb_Integer nMaxPos, cb_Integer fRedraw);
cb_Integer WINAPI CoolSB_ShowScrollBar  (HWND hwnd, cb_Integer wBar, cb_Integer fShow);

//
// Scrollbar dimension functions
//
cb_Integer WINAPI CoolSB_SetSize      (HWND hwnd, cb_Integer wBar, cb_Integer nLength, cb_Integer nWidth);

//
// Set the visual nature of a scrollbar (flat, normal etc)
//
cb_Integer WINAPI CoolSB_SetStyle    (HWND hwnd, cb_Integer wBar, cb_UInteger nStyle, HDC=NULL);
cb_Integer WINAPI CoolSB_SetThumbAlways  (HWND hwnd, cb_Integer wBar, cb_Integer fThumbAlways);

//
//  Scrollbar button structure, for inserted buttons only
//
typedef struct
{
  cb_UInteger      fMask;      //which members are in use
  cb_UInteger      uPlacement;    //is this button to the left/right (above/below) of the scrollbar??
  cb_UInteger      uCmdId;      //command identifier (WM_COMMAND value to send)
  cb_UInteger      uButType;    //
  cb_UInteger      uState;      //toggled etc
  cb_Integer        nSize;      //size in pixels. -1 for autosize

  HBITMAP      hBmp;      //handle to a bitmap to use as the button face
  HENHMETAFILE  hEmf;      //handle to an enhanced metafile

  HCURSOR      hCurs;      //handle to a user-supplied mouse cursor to apply
                  //to this button

  cb_Integer        nSizeReserved;  //internal variable used for resizing
  cb_Integer        nMinSize;    //min size
  cb_Integer        nMaxSize;    //max size

} CoolSB_SCROLLBUT;

//
//  CoolSB_SCROLLBAR datatype. There are two of these structures per window
//
typedef struct
{
  cb_UInteger    fScrollFlags;    //flags
  cb_Integer    fScrollVisible;    //if this scrollbar visible?
  SCROLLINFO  scrollInfo;      //positional data (range, position, page size etc)

  cb_Integer      nArrowLength;    //perpendicular size (height of a horizontal, width of a vertical)
  cb_Integer      nArrowWidth;    //parallel size (width of horz, height of vert)

  //data for inserted buttons
  CoolSB_SCROLLBUT  sbButtons[MAX_COOLSB_BUTS];
  cb_Integer      nButtons;
  cb_Integer      nButSizeBefore;    //size to the left / above the bar
  cb_Integer      nButSizeAfter;    //size to the right / below the bar

  cb_Integer    fButVisibleBefore;  //if the buttons to the left are visible
  cb_Integer    fButVisibleAfter;  //if the buttons to the right are visible

  cb_Integer      nBarType;      //SB_HORZ / SB_VERT

  cb_UInteger    fFlatScrollbar;    //do we display flat scrollbars?
  cb_Integer      nMinThumbSize;

} CoolSB_SCROLLBAR;

//
//  Container structure for a cool scrollbar window.
//
typedef struct
{
  //cb_UInteger bars;        //which of the scrollbars do we handle? SB_VERT / SB_HORZ / SB_BOTH
  WNDPROC oldproc;    //old window procedure to call for every message

  CoolSB_SCROLLBAR sbarHorz;    //one scrollbar structure each for
  CoolSB_SCROLLBAR sbarVert;    //the horizontal and vertical scrollbars

  cb_Integer fThumbTracking;  // are we currently thumb-tracking??
  cb_Integer fLeftScrollbar;  // support the WS_EX_LEFTCoolSB_SCROLLBAR style

  HWND hwndToolTip;    // tooltip support!!!

  //size of the window borders
  cb_Integer cxLeftEdge, cxRightEdge;
  cb_Integer cyTopEdge,  cyBottomEdge;

  HDC hdc;  // optional handle to user skin DC

  // To prevent calling original WindowProc in response
  // to our own temporary style change (fixes TreeView problem)
  cb_Integer bPreventStyleChange;

} CoolSB_SCROLLWND;

cb_Integer WINAPI CoolSB_InsertButton(HWND hwnd, cb_Integer wSBflags, cb_UInteger nPos,  CoolSB_SCROLLBUT *psb);
cb_Integer WINAPI CoolSB_ModifyButton(HWND hwnd, cb_Integer wSBflags, cb_UInteger uItem, cb_Integer fByCmd, CoolSB_SCROLLBUT *psb);
cb_Integer WINAPI CoolSB_RemoveButton(HWND hwnd, cb_Integer wSBflags, cb_UInteger uItem, cb_Integer fByCmd);
cb_Integer WINAPI CoolSB_GetButton(HWND hwnd, cb_Integer wSBflags, cb_UInteger uItem, cb_Integer fByCmd, CoolSB_SCROLLBUT *psb);

//void WINAPI CoolSB_SetESBProc(cb_Integer (WINAPI *proc)(HWND, cb_UInteger, cb_UInteger));

typedef struct
{
  NMHDR  hdr;
  DWORD   dwDrawStage;
  HDC    hdc;
  RECT  rect;
  cb_UInteger  uItem;
  cb_UInteger  uState;
  cb_UInteger  nBar;

} NMCSBCUSTOMDRAW;

typedef struct
{
  NMHDR  hdr;
  RECT  rect;
  POINT  pt;
  cb_UInteger  uCmdId;
  cb_UInteger  uState;
  cb_Integer    nBar;
} NMCOOLBUTMSG;

/*
typedef struct
{
  NMHDR  hdr;
  DWORD   dwDrawStage;
  HDC    hdc;
  RECT  rect;
  cb_UInteger  uCmdId;
  cb_UInteger  uState;

} NMCOOLBUTTON_CUSTOMDRAW;
*/


//
//  Define the WM_NOTIFY code value for cool-scrollbar custom drawing
//
#define NM_COOLSB_CUSTOMDRAW (0-0xfffU)

LRESULT CoolSB_HandleCustomDraw(HDC hdcSkin, NMCSBCUSTOMDRAW *nm, cb_Integer fCustomDraw);

#ifdef __cplusplus
}
#endif

#endif
#include <commdlg.h>
/* Scintilla source code edit control */
/** @file SciLexer.h
 ** Interface to the added lexer functions in the SciLexer version of the edit control.
 **/
/* Copyright 1998-2002 by Neil Hodgson <neilh@scintilla.org>
 * The License.txt file describes the conditions under which this software may be distributed. */

/* Most of this file is automatically generated from the Scintilla.iface interface definition
 * file which contains any comments about the definitions. HFacer.py does the generation. */

#ifndef SCILEXER_H
#define SCILEXER_H

/* SciLexer features - not in standard Scintilla */

/* ++Autogenerated -- start of section automatically generated from Scintilla.iface */
#define SCLEX_CONTAINER 0
#define SCLEX_NULL 1
#define SCLEX_PYTHON 2
#define SCLEX_CPP 3
#define SCLEX_HTML 4
#define SCLEX_XML 5
#define SCLEX_PERL 6
#define SCLEX_SQL 7
#define SCLEX_VB 8
#define SCLEX_PROPERTIES 9
#define SCLEX_ERRORLIST 10
#define SCLEX_MAKEFILE 11
#define SCLEX_BATCH 12
#define SCLEX_XCODE 13
#define SCLEX_LATEX 14
#define SCLEX_LUA 15
#define SCLEX_DIFF 16
#define SCLEX_CONF 17
#define SCLEX_PASCAL 18
#define SCLEX_AVE 19
#define SCLEX_ADA 20
#define SCLEX_LISP 21
#define SCLEX_RUBY 22
#define SCLEX_EIFFEL 23
#define SCLEX_EIFFELKW 24
#define SCLEX_TCL 25
#define SCLEX_NNCRONTAB 26
#define SCLEX_BULLANT 27
#define SCLEX_VBSCRIPT 28
#define SCLEX_BAAN 31
#define SCLEX_MATLAB 32
#define SCLEX_SCRIPTOL 33
#define SCLEX_ASM 34
#define SCLEX_CPPNOCASE 35
#define SCLEX_FORTRAN 36
#define SCLEX_F77 37
#define SCLEX_CSS 38
#define SCLEX_POV 39
#define SCLEX_LOUT 40
#define SCLEX_ESCRIPT 41
#define SCLEX_PS 42
#define SCLEX_NSIS 43
#define SCLEX_MMIXAL 44
#define SCLEX_CLW 45
#define SCLEX_CLWNOCASE 46
#define SCLEX_LOT 47
#define SCLEX_YAML 48
#define SCLEX_TEX 49
#define SCLEX_METAPOST 50
#define SCLEX_POWERBASIC 51
#define SCLEX_FORTH 52
#define SCLEX_ERLANG 53
#define SCLEX_OCTAVE 54
#define SCLEX_MSSQL 55
#define SCLEX_VERILOG 56
#define SCLEX_KIX 57
#define SCLEX_GUI4CLI 58
#define SCLEX_SPECMAN 59
#define SCLEX_AU3 60
#define SCLEX_APDL 61
#define SCLEX_BASH 62
#define SCLEX_ASN1 63
#define SCLEX_VHDL 64
#define SCLEX_CAML 65
#define SCLEX_BLITZBASIC 66
#define SCLEX_PUREBASIC 67
#define SCLEX_HASKELL 68
#define SCLEX_PHPSCRIPT 69
#define SCLEX_TADS3 70
#define SCLEX_REBOL 71
#define SCLEX_SMALLTALK 72
#define SCLEX_FLAGSHIP 73
#define SCLEX_CSOUND 74
#define SCLEX_FREEBASIC 75
#define SCLEX_INNOSETUP 76
#define SCLEX_OPAL 77
#define SCLEX_SPICE 78
#define SCLEX_D 79
#define SCLEX_CMAKE 80
#define SCLEX_GAP 81
#define SCLEX_PLM 82
#define SCLEX_PROGRESS 83
#define SCLEX_ABAQUS 84
#define SCLEX_ASYMPTOTE 85
#define SCLEX_R 86
#define SCLEX_MAGIK 87
#define SCLEX_POWERSHELL 88
#define SCLEX_MYSQL 89
#define SCLEX_PO 90
#define SCLEX_TAL 91
#define SCLEX_COBOL 92
#define SCLEX_TACL 93
#define SCLEX_SORCUS 94
#define SCLEX_POWERPRO 95
#define SCLEX_NIMROD 96
#define SCLEX_SML 97
#define SCLEX_MARKDOWN 98
#define SCLEX_TXT2TAGS 99
#define SCLEX_A68K 100
#define SCLEX_MODULA 101
#define SCLEX_COFFEESCRIPT 102
#define SCLEX_TCMD 103
#define SCLEX_AVS 104
#define SCLEX_ECL 105
#define SCLEX_OSCRIPT 106
#define SCLEX_VISUALPROLOG 107
#define SCLEX_LITERATEHASKELL 108
#define SCLEX_STTXT 109
#define SCLEX_KVIRC 110
#define SCLEX_RUST 111
#define SCLEX_DMAP 112
#define SCLEX_AS 113
#define SCLEX_DMIS 114
#define SCLEX_REGISTRY 115
#define SCLEX_BIBTEX 116
#define SCLEX_SREC 117
#define SCLEX_IHEX 118
#define SCLEX_TEHEX 119
#define SCLEX_JSON 120
#define SCLEX_EDIFACT 121
#define SCLEX_INDENT 122
#define SCLEX_MAXIMA 123
#define SCLEX_STATA 124
#define SCLEX_SAS 125
#define SCLEX_NIM 126
#define SCLEX_CIL 127
#define SCLEX_X12 128
#define SCLEX_DATAFLEX 129
#define SCLEX_HOLLYWOOD 130
#define SCLEX_RAKU 131
#define SCLEX_FSHARP 132
#define SCLEX_JULIA 133
#define SCLEX_ASCIIDOC 134
#define SCLEX_GDSCRIPT 135
#define SCLEX_AUTOMATIC 1000
#define SCE_P_DEFAULT 0
#define SCE_P_COMMENTLINE 1
#define SCE_P_NUMBER 2
#define SCE_P_STRING 3
#define SCE_P_CHARACTER 4
#define SCE_P_WORD 5
#define SCE_P_TRIPLE 6
#define SCE_P_TRIPLEDOUBLE 7
#define SCE_P_CLASSNAME 8
#define SCE_P_DEFNAME 9
#define SCE_P_OPERATOR 10
#define SCE_P_IDENTIFIER 11
#define SCE_P_COMMENTBLOCK 12
#define SCE_P_STRINGEOL 13
#define SCE_P_WORD2 14
#define SCE_P_DECORATOR 15
#define SCE_P_FSTRING 16
#define SCE_P_FCHARACTER 17
#define SCE_P_FTRIPLE 18
#define SCE_P_FTRIPLEDOUBLE 19
#define SCE_C_DEFAULT 0
#define SCE_C_COMMENT 1
#define SCE_C_COMMENTLINE 2
#define SCE_C_COMMENTDOC 3
#define SCE_C_NUMBER 4
#define SCE_C_WORD 5
#define SCE_C_STRING 6
#define SCE_C_CHARACTER 7
#define SCE_C_UUID 8
#define SCE_C_PREPROCESSOR 9
#define SCE_C_OPERATOR 10
#define SCE_C_IDENTIFIER 11
#define SCE_C_STRINGEOL 12
#define SCE_C_VERBATIM 13
#define SCE_C_REGEX 14
#define SCE_C_COMMENTLINEDOC 15
#define SCE_C_WORD2 16
#define SCE_C_COMMENTDOCKEYWORD 17
#define SCE_C_COMMENTDOCKEYWORDERROR 18
#define SCE_C_GLOBALCLASS 19
#define SCE_C_STRINGRAW 20
#define SCE_C_TRIPLEVERBATIM 21
#define SCE_C_HASHQUOTEDSTRING 22
#define SCE_C_PREPROCESSORCOMMENT 23
#define SCE_C_PREPROCESSORCOMMENTDOC 24
#define SCE_C_USERLITERAL 25
#define SCE_C_TASKMARKER 26
#define SCE_C_ESCAPESEQUENCE 27
#define SCE_D_DEFAULT 0
#define SCE_D_COMMENT 1
#define SCE_D_COMMENTLINE 2
#define SCE_D_COMMENTDOC 3
#define SCE_D_COMMENTNESTED 4
#define SCE_D_NUMBER 5
#define SCE_D_WORD 6
#define SCE_D_WORD2 7
#define SCE_D_WORD3 8
#define SCE_D_TYPEDEF 9
#define SCE_D_STRING 10
#define SCE_D_STRINGEOL 11
#define SCE_D_CHARACTER 12
#define SCE_D_OPERATOR 13
#define SCE_D_IDENTIFIER 14
#define SCE_D_COMMENTLINEDOC 15
#define SCE_D_COMMENTDOCKEYWORD 16
#define SCE_D_COMMENTDOCKEYWORDERROR 17
#define SCE_D_STRINGB 18
#define SCE_D_STRINGR 19
#define SCE_D_WORD5 20
#define SCE_D_WORD6 21
#define SCE_D_WORD7 22
#define SCE_TCL_DEFAULT 0
#define SCE_TCL_COMMENT 1
#define SCE_TCL_COMMENTLINE 2
#define SCE_TCL_NUMBER 3
#define SCE_TCL_WORD_IN_QUOTE 4
#define SCE_TCL_IN_QUOTE 5
#define SCE_TCL_OPERATOR 6
#define SCE_TCL_IDENTIFIER 7
#define SCE_TCL_SUBSTITUTION 8
#define SCE_TCL_SUB_BRACE 9
#define SCE_TCL_MODIFIER 10
#define SCE_TCL_EXPAND 11
#define SCE_TCL_WORD 12
#define SCE_TCL_WORD2 13
#define SCE_TCL_WORD3 14
#define SCE_TCL_WORD4 15
#define SCE_TCL_WORD5 16
#define SCE_TCL_WORD6 17
#define SCE_TCL_WORD7 18
#define SCE_TCL_WORD8 19
#define SCE_TCL_COMMENT_BOX 20
#define SCE_TCL_BLOCK_COMMENT 21
#define SCE_H_DEFAULT 0
#define SCE_H_TAG 1
#define SCE_H_TAGUNKNOWN 2
#define SCE_H_ATTRIBUTE 3
#define SCE_H_ATTRIBUTEUNKNOWN 4
#define SCE_H_NUMBER 5
#define SCE_H_DOUBLESTRING 6
#define SCE_H_SINGLESTRING 7
#define SCE_H_OTHER 8
#define SCE_H_COMMENT 9
#define SCE_H_ENTITY 10
#define SCE_H_TAGEND 11
#define SCE_H_XMLSTART 12
#define SCE_H_XMLEND 13
#define SCE_H_SCRIPT 14
#define SCE_H_ASP 15
#define SCE_H_ASPAT 16
#define SCE_H_CDATA 17
#define SCE_H_QUESTION 18
#define SCE_H_VALUE 19
#define SCE_H_XCCOMMENT 20
#define SCE_H_SGML_DEFAULT 21
#define SCE_H_SGML_COMMAND 22
#define SCE_H_SGML_1ST_PARAM 23
#define SCE_H_SGML_DOUBLESTRING 24
#define SCE_H_SGML_SIMPLESTRING 25
#define SCE_H_SGML_ERROR 26
#define SCE_H_SGML_SPECIAL 27
#define SCE_H_SGML_ENTITY 28
#define SCE_H_SGML_COMMENT 29
#define SCE_H_SGML_1ST_PARAM_COMMENT 30
#define SCE_H_SGML_BLOCK_DEFAULT 31
#define SCE_HJ_START 40
#define SCE_HJ_DEFAULT 41
#define SCE_HJ_COMMENT 42
#define SCE_HJ_COMMENTLINE 43
#define SCE_HJ_COMMENTDOC 44
#define SCE_HJ_NUMBER 45
#define SCE_HJ_WORD 46
#define SCE_HJ_KEYWORD 47
#define SCE_HJ_DOUBLESTRING 48
#define SCE_HJ_SINGLESTRING 49
#define SCE_HJ_SYMBOLS 50
#define SCE_HJ_STRINGEOL 51
#define SCE_HJ_REGEX 52
#define SCE_HJA_START 55
#define SCE_HJA_DEFAULT 56
#define SCE_HJA_COMMENT 57
#define SCE_HJA_COMMENTLINE 58
#define SCE_HJA_COMMENTDOC 59
#define SCE_HJA_NUMBER 60
#define SCE_HJA_WORD 61
#define SCE_HJA_KEYWORD 62
#define SCE_HJA_DOUBLESTRING 63
#define SCE_HJA_SINGLESTRING 64
#define SCE_HJA_SYMBOLS 65
#define SCE_HJA_STRINGEOL 66
#define SCE_HJA_REGEX 67
#define SCE_HB_START 70
#define SCE_HB_DEFAULT 71
#define SCE_HB_COMMENTLINE 72
#define SCE_HB_NUMBER 73
#define SCE_HB_WORD 74
#define SCE_HB_STRING 75
#define SCE_HB_IDENTIFIER 76
#define SCE_HB_STRINGEOL 77
#define SCE_HBA_START 80
#define SCE_HBA_DEFAULT 81
#define SCE_HBA_COMMENTLINE 82
#define SCE_HBA_NUMBER 83
#define SCE_HBA_WORD 84
#define SCE_HBA_STRING 85
#define SCE_HBA_IDENTIFIER 86
#define SCE_HBA_STRINGEOL 87
#define SCE_HP_START 90
#define SCE_HP_DEFAULT 91
#define SCE_HP_COMMENTLINE 92
#define SCE_HP_NUMBER 93
#define SCE_HP_STRING 94
#define SCE_HP_CHARACTER 95
#define SCE_HP_WORD 96
#define SCE_HP_TRIPLE 97
#define SCE_HP_TRIPLEDOUBLE 98
#define SCE_HP_CLASSNAME 99
#define SCE_HP_DEFNAME 100
#define SCE_HP_OPERATOR 101
#define SCE_HP_IDENTIFIER 102
#define SCE_HPHP_COMPLEX_VARIABLE 104
#define SCE_HPA_START 105
#define SCE_HPA_DEFAULT 106
#define SCE_HPA_COMMENTLINE 107
#define SCE_HPA_NUMBER 108
#define SCE_HPA_STRING 109
#define SCE_HPA_CHARACTER 110
#define SCE_HPA_WORD 111
#define SCE_HPA_TRIPLE 112
#define SCE_HPA_TRIPLEDOUBLE 113
#define SCE_HPA_CLASSNAME 114
#define SCE_HPA_DEFNAME 115
#define SCE_HPA_OPERATOR 116
#define SCE_HPA_IDENTIFIER 117
#define SCE_HPHP_DEFAULT 118
#define SCE_HPHP_HSTRING 119
#define SCE_HPHP_SIMPLESTRING 120
#define SCE_HPHP_WORD 121
#define SCE_HPHP_NUMBER 122
#define SCE_HPHP_VARIABLE 123
#define SCE_HPHP_COMMENT 124
#define SCE_HPHP_COMMENTLINE 125
#define SCE_HPHP_HSTRING_VARIABLE 126
#define SCE_HPHP_OPERATOR 127
#define SCE_PL_DEFAULT 0
#define SCE_PL_ERROR 1
#define SCE_PL_COMMENTLINE 2
#define SCE_PL_POD 3
#define SCE_PL_NUMBER 4
#define SCE_PL_WORD 5
#define SCE_PL_STRING 6
#define SCE_PL_CHARACTER 7
#define SCE_PL_PUNCTUATION 8
#define SCE_PL_PREPROCESSOR 9
#define SCE_PL_OPERATOR 10
#define SCE_PL_IDENTIFIER 11
#define SCE_PL_SCALAR 12
#define SCE_PL_ARRAY 13
#define SCE_PL_HASH 14
#define SCE_PL_SYMBOLTABLE 15
#define SCE_PL_VARIABLE_INDEXER 16
#define SCE_PL_REGEX 17
#define SCE_PL_REGSUBST 18
#define SCE_PL_LONGQUOTE 19
#define SCE_PL_BACKTICKS 20
#define SCE_PL_DATASECTION 21
#define SCE_PL_HERE_DELIM 22
#define SCE_PL_HERE_Q 23
#define SCE_PL_HERE_QQ 24
#define SCE_PL_HERE_QX 25
#define SCE_PL_STRING_Q 26
#define SCE_PL_STRING_QQ 27
#define SCE_PL_STRING_QX 28
#define SCE_PL_STRING_QR 29
#define SCE_PL_STRING_QW 30
#define SCE_PL_POD_VERB 31
#define SCE_PL_SUB_PROTOTYPE 40
#define SCE_PL_FORMAT_IDENT 41
#define SCE_PL_FORMAT 42
#define SCE_PL_STRING_VAR 43
#define SCE_PL_XLAT 44
#define SCE_PL_REGEX_VAR 54
#define SCE_PL_REGSUBST_VAR 55
#define SCE_PL_BACKTICKS_VAR 57
#define SCE_PL_HERE_QQ_VAR 61
#define SCE_PL_HERE_QX_VAR 62
#define SCE_PL_STRING_QQ_VAR 64
#define SCE_PL_STRING_QX_VAR 65
#define SCE_PL_STRING_QR_VAR 66
#define SCE_RB_DEFAULT 0
#define SCE_RB_ERROR 1
#define SCE_RB_COMMENTLINE 2
#define SCE_RB_POD 3
#define SCE_RB_NUMBER 4
#define SCE_RB_WORD 5
#define SCE_RB_STRING 6
#define SCE_RB_CHARACTER 7
#define SCE_RB_CLASSNAME 8
#define SCE_RB_DEFNAME 9
#define SCE_RB_OPERATOR 10
#define SCE_RB_IDENTIFIER 11
#define SCE_RB_REGEX 12
#define SCE_RB_GLOBAL 13
#define SCE_RB_SYMBOL 14
#define SCE_RB_MODULE_NAME 15
#define SCE_RB_INSTANCE_VAR 16
#define SCE_RB_CLASS_VAR 17
#define SCE_RB_BACKTICKS 18
#define SCE_RB_DATASECTION 19
#define SCE_RB_HERE_DELIM 20
#define SCE_RB_HERE_Q 21
#define SCE_RB_HERE_QQ 22
#define SCE_RB_HERE_QX 23
#define SCE_RB_STRING_Q 24
#define SCE_RB_STRING_QQ 25
#define SCE_RB_STRING_QX 26
#define SCE_RB_STRING_QR 27
#define SCE_RB_STRING_QW 28
#define SCE_RB_WORD_DEMOTED 29
#define SCE_RB_STDIN 30
#define SCE_RB_STDOUT 31
#define SCE_RB_STDERR 40
#define SCE_RB_UPPER_BOUND 41
#define SCE_B_DEFAULT 0
#define SCE_B_COMMENT 1
#define SCE_B_NUMBER 2
#define SCE_B_KEYWORD 3
#define SCE_B_STRING 4
#define SCE_B_PREPROCESSOR 5
#define SCE_B_OPERATOR 6
#define SCE_B_IDENTIFIER 7
#define SCE_B_DATE 8
#define SCE_B_STRINGEOL 9
#define SCE_B_KEYWORD2 10
#define SCE_B_KEYWORD3 11
#define SCE_B_KEYWORD4 12
#define SCE_B_CONSTANT 13
#define SCE_B_ASM 14
#define SCE_B_LABEL 15
#define SCE_B_ERROR 16
#define SCE_B_HEXNUMBER 17
#define SCE_B_BINNUMBER 18
#define SCE_B_COMMENTBLOCK 19
#define SCE_B_DOCLINE 20
#define SCE_B_DOCBLOCK 21
#define SCE_B_DOCKEYWORD 22
#define SCE_PROPS_DEFAULT 0
#define SCE_PROPS_COMMENT 1
#define SCE_PROPS_SECTION 2
#define SCE_PROPS_ASSIGNMENT 3
#define SCE_PROPS_DEFVAL 4
#define SCE_PROPS_KEY 5
#define SCE_L_DEFAULT 0
#define SCE_L_COMMAND 1
#define SCE_L_TAG 2
#define SCE_L_MATH 3
#define SCE_L_COMMENT 4
#define SCE_L_TAG2 5
#define SCE_L_MATH2 6
#define SCE_L_COMMENT2 7
#define SCE_L_VERBATIM 8
#define SCE_L_SHORTCMD 9
#define SCE_L_SPECIAL 10
#define SCE_L_CMDOPT 11
#define SCE_L_ERROR 12
#define SCE_LUA_DEFAULT 0
#define SCE_LUA_COMMENT 1
#define SCE_LUA_COMMENTLINE 2
#define SCE_LUA_COMMENTDOC 3
#define SCE_LUA_NUMBER 4
#define SCE_LUA_WORD 5
#define SCE_LUA_STRING 6
#define SCE_LUA_CHARACTER 7
#define SCE_LUA_LITERALSTRING 8
#define SCE_LUA_PREPROCESSOR 9
#define SCE_LUA_OPERATOR 10
#define SCE_LUA_IDENTIFIER 11
#define SCE_LUA_STRINGEOL 12
#define SCE_LUA_WORD2 13
#define SCE_LUA_WORD3 14
#define SCE_LUA_WORD4 15
#define SCE_LUA_WORD5 16
#define SCE_LUA_WORD6 17
#define SCE_LUA_WORD7 18
#define SCE_LUA_WORD8 19
#define SCE_LUA_LABEL 20
#define SCE_ERR_DEFAULT 0
#define SCE_ERR_PYTHON 1
#define SCE_ERR_GCC 2
#define SCE_ERR_MS 3
#define SCE_ERR_CMD 4
#define SCE_ERR_BORLAND 5
#define SCE_ERR_PERL 6
#define SCE_ERR_NET 7
#define SCE_ERR_LUA 8
#define SCE_ERR_CTAG 9
#define SCE_ERR_DIFF_CHANGED 10
#define SCE_ERR_DIFF_ADDITION 11
#define SCE_ERR_DIFF_DELETION 12
#define SCE_ERR_DIFF_MESSAGE 13
#define SCE_ERR_PHP 14
#define SCE_ERR_ELF 15
#define SCE_ERR_IFC 16
#define SCE_ERR_IFORT 17
#define SCE_ERR_ABSF 18
#define SCE_ERR_TIDY 19
#define SCE_ERR_JAVA_STACK 20
#define SCE_ERR_VALUE 21
#define SCE_ERR_GCC_INCLUDED_FROM 22
#define SCE_ERR_ESCSEQ 23
#define SCE_ERR_ESCSEQ_UNKNOWN 24
#define SCE_ERR_GCC_EXCERPT 25
#define SCE_ERR_ES_BLACK 40
#define SCE_ERR_ES_RED 41
#define SCE_ERR_ES_GREEN 42
#define SCE_ERR_ES_BROWN 43
#define SCE_ERR_ES_BLUE 44
#define SCE_ERR_ES_MAGENTA 45
#define SCE_ERR_ES_CYAN 46
#define SCE_ERR_ES_GRAY 47
#define SCE_ERR_ES_DARK_GRAY 48
#define SCE_ERR_ES_BRIGHT_RED 49
#define SCE_ERR_ES_BRIGHT_GREEN 50
#define SCE_ERR_ES_YELLOW 51
#define SCE_ERR_ES_BRIGHT_BLUE 52
#define SCE_ERR_ES_BRIGHT_MAGENTA 53
#define SCE_ERR_ES_BRIGHT_CYAN 54
#define SCE_ERR_ES_WHITE 55
#define SCE_BAT_DEFAULT 0
#define SCE_BAT_COMMENT 1
#define SCE_BAT_WORD 2
#define SCE_BAT_LABEL 3
#define SCE_BAT_HIDE 4
#define SCE_BAT_COMMAND 5
#define SCE_BAT_IDENTIFIER 6
#define SCE_BAT_OPERATOR 7
#define SCE_TCMD_DEFAULT 0
#define SCE_TCMD_COMMENT 1
#define SCE_TCMD_WORD 2
#define SCE_TCMD_LABEL 3
#define SCE_TCMD_HIDE 4
#define SCE_TCMD_COMMAND 5
#define SCE_TCMD_IDENTIFIER 6
#define SCE_TCMD_OPERATOR 7
#define SCE_TCMD_ENVIRONMENT 8
#define SCE_TCMD_EXPANSION 9
#define SCE_TCMD_CLABEL 10
#define SCE_MAKE_DEFAULT 0
#define SCE_MAKE_COMMENT 1
#define SCE_MAKE_PREPROCESSOR 2
#define SCE_MAKE_IDENTIFIER 3
#define SCE_MAKE_OPERATOR 4
#define SCE_MAKE_TARGET 5
#define SCE_MAKE_IDEOL 9
#define SCE_DIFF_DEFAULT 0
#define SCE_DIFF_COMMENT 1
#define SCE_DIFF_COMMAND 2
#define SCE_DIFF_HEADER 3
#define SCE_DIFF_POSITION 4
#define SCE_DIFF_DELETED 5
#define SCE_DIFF_ADDED 6
#define SCE_DIFF_CHANGED 7
#define SCE_DIFF_PATCH_ADD 8
#define SCE_DIFF_PATCH_DELETE 9
#define SCE_DIFF_REMOVED_PATCH_ADD 10
#define SCE_DIFF_REMOVED_PATCH_DELETE 11
#define SCE_CONF_DEFAULT 0
#define SCE_CONF_COMMENT 1
#define SCE_CONF_NUMBER 2
#define SCE_CONF_IDENTIFIER 3
#define SCE_CONF_EXTENSION 4
#define SCE_CONF_PARAMETER 5
#define SCE_CONF_STRING 6
#define SCE_CONF_OPERATOR 7
#define SCE_CONF_IP 8
#define SCE_CONF_DIRECTIVE 9
#define SCE_AVE_DEFAULT 0
#define SCE_AVE_COMMENT 1
#define SCE_AVE_NUMBER 2
#define SCE_AVE_WORD 3
#define SCE_AVE_STRING 6
#define SCE_AVE_ENUM 7
#define SCE_AVE_STRINGEOL 8
#define SCE_AVE_IDENTIFIER 9
#define SCE_AVE_OPERATOR 10
#define SCE_AVE_WORD1 11
#define SCE_AVE_WORD2 12
#define SCE_AVE_WORD3 13
#define SCE_AVE_WORD4 14
#define SCE_AVE_WORD5 15
#define SCE_AVE_WORD6 16
#define SCE_ADA_DEFAULT 0
#define SCE_ADA_WORD 1
#define SCE_ADA_IDENTIFIER 2
#define SCE_ADA_NUMBER 3
#define SCE_ADA_DELIMITER 4
#define SCE_ADA_CHARACTER 5
#define SCE_ADA_CHARACTEREOL 6
#define SCE_ADA_STRING 7
#define SCE_ADA_STRINGEOL 8
#define SCE_ADA_LABEL 9
#define SCE_ADA_COMMENTLINE 10
#define SCE_ADA_ILLEGAL 11
#define SCE_BAAN_DEFAULT 0
#define SCE_BAAN_COMMENT 1
#define SCE_BAAN_COMMENTDOC 2
#define SCE_BAAN_NUMBER 3
#define SCE_BAAN_WORD 4
#define SCE_BAAN_STRING 5
#define SCE_BAAN_PREPROCESSOR 6
#define SCE_BAAN_OPERATOR 7
#define SCE_BAAN_IDENTIFIER 8
#define SCE_BAAN_STRINGEOL 9
#define SCE_BAAN_WORD2 10
#define SCE_BAAN_WORD3 11
#define SCE_BAAN_WORD4 12
#define SCE_BAAN_WORD5 13
#define SCE_BAAN_WORD6 14
#define SCE_BAAN_WORD7 15
#define SCE_BAAN_WORD8 16
#define SCE_BAAN_WORD9 17
#define SCE_BAAN_TABLEDEF 18
#define SCE_BAAN_TABLESQL 19
#define SCE_BAAN_FUNCTION 20
#define SCE_BAAN_DOMDEF 21
#define SCE_BAAN_FUNCDEF 22
#define SCE_BAAN_OBJECTDEF 23
#define SCE_BAAN_DEFINEDEF 24
#define SCE_LISP_DEFAULT 0
#define SCE_LISP_COMMENT 1
#define SCE_LISP_NUMBER 2
#define SCE_LISP_KEYWORD 3
#define SCE_LISP_KEYWORD_KW 4
#define SCE_LISP_SYMBOL 5
#define SCE_LISP_STRING 6
#define SCE_LISP_STRINGEOL 8
#define SCE_LISP_IDENTIFIER 9
#define SCE_LISP_OPERATOR 10
#define SCE_LISP_SPECIAL 11
#define SCE_LISP_MULTI_COMMENT 12
#define SCE_EIFFEL_DEFAULT 0
#define SCE_EIFFEL_COMMENTLINE 1
#define SCE_EIFFEL_NUMBER 2
#define SCE_EIFFEL_WORD 3
#define SCE_EIFFEL_STRING 4
#define SCE_EIFFEL_CHARACTER 5
#define SCE_EIFFEL_OPERATOR 6
#define SCE_EIFFEL_IDENTIFIER 7
#define SCE_EIFFEL_STRINGEOL 8
#define SCE_NNCRONTAB_DEFAULT 0
#define SCE_NNCRONTAB_COMMENT 1
#define SCE_NNCRONTAB_TASK 2
#define SCE_NNCRONTAB_SECTION 3
#define SCE_NNCRONTAB_KEYWORD 4
#define SCE_NNCRONTAB_MODIFIER 5
#define SCE_NNCRONTAB_ASTERISK 6
#define SCE_NNCRONTAB_NUMBER 7
#define SCE_NNCRONTAB_STRING 8
#define SCE_NNCRONTAB_ENVIRONMENT 9
#define SCE_NNCRONTAB_IDENTIFIER 10
#define SCE_FORTH_DEFAULT 0
#define SCE_FORTH_COMMENT 1
#define SCE_FORTH_COMMENT_ML 2
#define SCE_FORTH_IDENTIFIER 3
#define SCE_FORTH_CONTROL 4
#define SCE_FORTH_KEYWORD 5
#define SCE_FORTH_DEFWORD 6
#define SCE_FORTH_PREWORD1 7
#define SCE_FORTH_PREWORD2 8
#define SCE_FORTH_NUMBER 9
#define SCE_FORTH_STRING 10
#define SCE_FORTH_LOCALE 11
#define SCE_MATLAB_DEFAULT 0
#define SCE_MATLAB_COMMENT 1
#define SCE_MATLAB_COMMAND 2
#define SCE_MATLAB_NUMBER 3
#define SCE_MATLAB_KEYWORD 4
#define SCE_MATLAB_STRING 5
#define SCE_MATLAB_OPERATOR 6
#define SCE_MATLAB_IDENTIFIER 7
#define SCE_MATLAB_DOUBLEQUOTESTRING 8
#define SCE_MAXIMA_OPERATOR 0
#define SCE_MAXIMA_COMMANDENDING 1
#define SCE_MAXIMA_COMMENT 2
#define SCE_MAXIMA_NUMBER 3
#define SCE_MAXIMA_STRING 4
#define SCE_MAXIMA_COMMAND 5
#define SCE_MAXIMA_VARIABLE 6
#define SCE_MAXIMA_UNKNOWN 7
#define SCE_SCRIPTOL_DEFAULT 0
#define SCE_SCRIPTOL_WHITE 1
#define SCE_SCRIPTOL_COMMENTLINE 2
#define SCE_SCRIPTOL_PERSISTENT 3
#define SCE_SCRIPTOL_CSTYLE 4
#define SCE_SCRIPTOL_COMMENTBLOCK 5
#define SCE_SCRIPTOL_NUMBER 6
#define SCE_SCRIPTOL_STRING 7
#define SCE_SCRIPTOL_CHARACTER 8
#define SCE_SCRIPTOL_STRINGEOL 9
#define SCE_SCRIPTOL_KEYWORD 10
#define SCE_SCRIPTOL_OPERATOR 11
#define SCE_SCRIPTOL_IDENTIFIER 12
#define SCE_SCRIPTOL_TRIPLE 13
#define SCE_SCRIPTOL_CLASSNAME 14
#define SCE_SCRIPTOL_PREPROCESSOR 15
#define SCE_ASM_DEFAULT 0
#define SCE_ASM_COMMENT 1
#define SCE_ASM_NUMBER 2
#define SCE_ASM_STRING 3
#define SCE_ASM_OPERATOR 4
#define SCE_ASM_IDENTIFIER 5
#define SCE_ASM_CPUINSTRUCTION 6
#define SCE_ASM_MATHINSTRUCTION 7
#define SCE_ASM_REGISTER 8
#define SCE_ASM_DIRECTIVE 9
#define SCE_ASM_DIRECTIVEOPERAND 10
#define SCE_ASM_COMMENTBLOCK 11
#define SCE_ASM_CHARACTER 12
#define SCE_ASM_STRINGEOL 13
#define SCE_ASM_EXTINSTRUCTION 14
#define SCE_ASM_COMMENTDIRECTIVE 15
#define SCE_F_DEFAULT 0
#define SCE_F_COMMENT 1
#define SCE_F_NUMBER 2
#define SCE_F_STRING1 3
#define SCE_F_STRING2 4
#define SCE_F_STRINGEOL 5
#define SCE_F_OPERATOR 6
#define SCE_F_IDENTIFIER 7
#define SCE_F_WORD 8
#define SCE_F_WORD2 9
#define SCE_F_WORD3 10
#define SCE_F_PREPROCESSOR 11
#define SCE_F_OPERATOR2 12
#define SCE_F_LABEL 13
#define SCE_F_CONTINUATION 14
#define SCE_CSS_DEFAULT 0
#define SCE_CSS_TAG 1
#define SCE_CSS_CLASS 2
#define SCE_CSS_PSEUDOCLASS 3
#define SCE_CSS_UNKNOWN_PSEUDOCLASS 4
#define SCE_CSS_OPERATOR 5
#define SCE_CSS_IDENTIFIER 6
#define SCE_CSS_UNKNOWN_IDENTIFIER 7
#define SCE_CSS_VALUE 8
#define SCE_CSS_COMMENT 9
#define SCE_CSS_ID 10
#define SCE_CSS_IMPORTANT 11
#define SCE_CSS_DIRECTIVE 12
#define SCE_CSS_DOUBLESTRING 13
#define SCE_CSS_SINGLESTRING 14
#define SCE_CSS_IDENTIFIER2 15
#define SCE_CSS_ATTRIBUTE 16
#define SCE_CSS_IDENTIFIER3 17
#define SCE_CSS_PSEUDOELEMENT 18
#define SCE_CSS_EXTENDED_IDENTIFIER 19
#define SCE_CSS_EXTENDED_PSEUDOCLASS 20
#define SCE_CSS_EXTENDED_PSEUDOELEMENT 21
#define SCE_CSS_GROUP_RULE 22
#define SCE_CSS_VARIABLE 23
#define SCE_POV_DEFAULT 0
#define SCE_POV_COMMENT 1
#define SCE_POV_COMMENTLINE 2
#define SCE_POV_NUMBER 3
#define SCE_POV_OPERATOR 4
#define SCE_POV_IDENTIFIER 5
#define SCE_POV_STRING 6
#define SCE_POV_STRINGEOL 7
#define SCE_POV_DIRECTIVE 8
#define SCE_POV_BADDIRECTIVE 9
#define SCE_POV_WORD2 10
#define SCE_POV_WORD3 11
#define SCE_POV_WORD4 12
#define SCE_POV_WORD5 13
#define SCE_POV_WORD6 14
#define SCE_POV_WORD7 15
#define SCE_POV_WORD8 16
#define SCE_LOUT_DEFAULT 0
#define SCE_LOUT_COMMENT 1
#define SCE_LOUT_NUMBER 2
#define SCE_LOUT_WORD 3
#define SCE_LOUT_WORD2 4
#define SCE_LOUT_WORD3 5
#define SCE_LOUT_WORD4 6
#define SCE_LOUT_STRING 7
#define SCE_LOUT_OPERATOR 8
#define SCE_LOUT_IDENTIFIER 9
#define SCE_LOUT_STRINGEOL 10
#define SCE_ESCRIPT_DEFAULT 0
#define SCE_ESCRIPT_COMMENT 1
#define SCE_ESCRIPT_COMMENTLINE 2
#define SCE_ESCRIPT_COMMENTDOC 3
#define SCE_ESCRIPT_NUMBER 4
#define SCE_ESCRIPT_WORD 5
#define SCE_ESCRIPT_STRING 6
#define SCE_ESCRIPT_OPERATOR 7
#define SCE_ESCRIPT_IDENTIFIER 8
#define SCE_ESCRIPT_BRACE 9
#define SCE_ESCRIPT_WORD2 10
#define SCE_ESCRIPT_WORD3 11
#define SCE_PS_DEFAULT 0
#define SCE_PS_COMMENT 1
#define SCE_PS_DSC_COMMENT 2
#define SCE_PS_DSC_VALUE 3
#define SCE_PS_NUMBER 4
#define SCE_PS_NAME 5
#define SCE_PS_KEYWORD 6
#define SCE_PS_LITERAL 7
#define SCE_PS_IMMEVAL 8
#define SCE_PS_PAREN_ARRAY 9
#define SCE_PS_PAREN_DICT 10
#define SCE_PS_PAREN_PROC 11
#define SCE_PS_TEXT 12
#define SCE_PS_HEXSTRING 13
#define SCE_PS_BASE85STRING 14
#define SCE_PS_BADSTRINGCHAR 15
#define SCE_NSIS_DEFAULT 0
#define SCE_NSIS_COMMENT 1
#define SCE_NSIS_STRINGDQ 2
#define SCE_NSIS_STRINGLQ 3
#define SCE_NSIS_STRINGRQ 4
#define SCE_NSIS_FUNCTION 5
#define SCE_NSIS_VARIABLE 6
#define SCE_NSIS_LABEL 7
#define SCE_NSIS_USERDEFINED 8
#define SCE_NSIS_SECTIONDEF 9
#define SCE_NSIS_SUBSECTIONDEF 10
#define SCE_NSIS_IFDEFINEDEF 11
#define SCE_NSIS_MACRODEF 12
#define SCE_NSIS_STRINGVAR 13
#define SCE_NSIS_NUMBER 14
#define SCE_NSIS_SECTIONGROUP 15
#define SCE_NSIS_PAGEEX 16
#define SCE_NSIS_FUNCTIONDEF 17
#define SCE_NSIS_COMMENTBOX 18
#define SCE_MMIXAL_LEADWS 0
#define SCE_MMIXAL_COMMENT 1
#define SCE_MMIXAL_LABEL 2
#define SCE_MMIXAL_OPCODE 3
#define SCE_MMIXAL_OPCODE_PRE 4
#define SCE_MMIXAL_OPCODE_VALID 5
#define SCE_MMIXAL_OPCODE_UNKNOWN 6
#define SCE_MMIXAL_OPCODE_POST 7
#define SCE_MMIXAL_OPERANDS 8
#define SCE_MMIXAL_NUMBER 9
#define SCE_MMIXAL_REF 10
#define SCE_MMIXAL_CHAR 11
#define SCE_MMIXAL_STRING 12
#define SCE_MMIXAL_REGISTER 13
#define SCE_MMIXAL_HEX 14
#define SCE_MMIXAL_OPERATOR 15
#define SCE_MMIXAL_SYMBOL 16
#define SCE_MMIXAL_INCLUDE 17
#define SCE_CLW_DEFAULT 0
#define SCE_CLW_LABEL 1
#define SCE_CLW_COMMENT 2
#define SCE_CLW_STRING 3
#define SCE_CLW_USER_IDENTIFIER 4
#define SCE_CLW_INTEGER_CONSTANT 5
#define SCE_CLW_REAL_CONSTANT 6
#define SCE_CLW_PICTURE_STRING 7
#define SCE_CLW_KEYWORD 8
#define SCE_CLW_COMPILER_DIRECTIVE 9
#define SCE_CLW_RUNTIME_EXPRESSIONS 10
#define SCE_CLW_BUILTIN_PROCEDURES_FUNCTION 11
#define SCE_CLW_STRUCTURE_DATA_TYPE 12
#define SCE_CLW_ATTRIBUTE 13
#define SCE_CLW_STANDARD_EQUATE 14
#define SCE_CLW_ERROR 15
#define SCE_CLW_DEPRECATED 16
#define SCE_LOT_DEFAULT 0
#define SCE_LOT_HEADER 1
#define SCE_LOT_BREAK 2
#define SCE_LOT_SET 3
#define SCE_LOT_PASS 4
#define SCE_LOT_FAIL 5
#define SCE_LOT_ABORT 6
#define SCE_YAML_DEFAULT 0
#define SCE_YAML_COMMENT 1
#define SCE_YAML_IDENTIFIER 2
#define SCE_YAML_KEYWORD 3
#define SCE_YAML_NUMBER 4
#define SCE_YAML_REFERENCE 5
#define SCE_YAML_DOCUMENT 6
#define SCE_YAML_TEXT 7
#define SCE_YAML_ERROR 8
#define SCE_YAML_OPERATOR 9
#define SCE_TEX_DEFAULT 0
#define SCE_TEX_SPECIAL 1
#define SCE_TEX_GROUP 2
#define SCE_TEX_SYMBOL 3
#define SCE_TEX_COMMAND 4
#define SCE_TEX_TEXT 5
#define SCE_METAPOST_DEFAULT 0
#define SCE_METAPOST_SPECIAL 1
#define SCE_METAPOST_GROUP 2
#define SCE_METAPOST_SYMBOL 3
#define SCE_METAPOST_COMMAND 4
#define SCE_METAPOST_TEXT 5
#define SCE_METAPOST_EXTRA 6
#define SCE_ERLANG_DEFAULT 0
#define SCE_ERLANG_COMMENT 1
#define SCE_ERLANG_VARIABLE 2
#define SCE_ERLANG_NUMBER 3
#define SCE_ERLANG_KEYWORD 4
#define SCE_ERLANG_STRING 5
#define SCE_ERLANG_OPERATOR 6
#define SCE_ERLANG_ATOM 7
#define SCE_ERLANG_FUNCTION_NAME 8
#define SCE_ERLANG_CHARACTER 9
#define SCE_ERLANG_MACRO 10
#define SCE_ERLANG_RECORD 11
#define SCE_ERLANG_PREPROC 12
#define SCE_ERLANG_NODE_NAME 13
#define SCE_ERLANG_COMMENT_FUNCTION 14
#define SCE_ERLANG_COMMENT_MODULE 15
#define SCE_ERLANG_COMMENT_DOC 16
#define SCE_ERLANG_COMMENT_DOC_MACRO 17
#define SCE_ERLANG_ATOM_QUOTED 18
#define SCE_ERLANG_MACRO_QUOTED 19
#define SCE_ERLANG_RECORD_QUOTED 20
#define SCE_ERLANG_NODE_NAME_QUOTED 21
#define SCE_ERLANG_BIFS 22
#define SCE_ERLANG_MODULES 23
#define SCE_ERLANG_MODULES_ATT 24
#define SCE_ERLANG_UNKNOWN 31
#define SCE_JULIA_DEFAULT 0
#define SCE_JULIA_COMMENT 1
#define SCE_JULIA_NUMBER 2
#define SCE_JULIA_KEYWORD1 3
#define SCE_JULIA_KEYWORD2 4
#define SCE_JULIA_KEYWORD3 5
#define SCE_JULIA_CHAR 6
#define SCE_JULIA_OPERATOR 7
#define SCE_JULIA_BRACKET 8
#define SCE_JULIA_IDENTIFIER 9
#define SCE_JULIA_STRING 10
#define SCE_JULIA_SYMBOL 11
#define SCE_JULIA_MACRO 12
#define SCE_JULIA_STRINGINTERP 13
#define SCE_JULIA_DOCSTRING 14
#define SCE_JULIA_STRINGLITERAL 15
#define SCE_JULIA_COMMAND 16
#define SCE_JULIA_COMMANDLITERAL 17
#define SCE_JULIA_TYPEANNOT 18
#define SCE_JULIA_LEXERROR 19
#define SCE_JULIA_KEYWORD4 20
#define SCE_JULIA_TYPEOPERATOR 21
#define SCE_MSSQL_DEFAULT 0
#define SCE_MSSQL_COMMENT 1
#define SCE_MSSQL_LINE_COMMENT 2
#define SCE_MSSQL_NUMBER 3
#define SCE_MSSQL_STRING 4
#define SCE_MSSQL_OPERATOR 5
#define SCE_MSSQL_IDENTIFIER 6
#define SCE_MSSQL_VARIABLE 7
#define SCE_MSSQL_COLUMN_NAME 8
#define SCE_MSSQL_STATEMENT 9
#define SCE_MSSQL_DATATYPE 10
#define SCE_MSSQL_SYSTABLE 11
#define SCE_MSSQL_GLOBAL_VARIABLE 12
#define SCE_MSSQL_FUNCTION 13
#define SCE_MSSQL_STORED_PROCEDURE 14
#define SCE_MSSQL_DEFAULT_PREF_DATATYPE 15
#define SCE_MSSQL_COLUMN_NAME_2 16
#define SCE_V_DEFAULT 0
#define SCE_V_COMMENT 1
#define SCE_V_COMMENTLINE 2
#define SCE_V_COMMENTLINEBANG 3
#define SCE_V_NUMBER 4
#define SCE_V_WORD 5
#define SCE_V_STRING 6
#define SCE_V_WORD2 7
#define SCE_V_WORD3 8
#define SCE_V_PREPROCESSOR 9
#define SCE_V_OPERATOR 10
#define SCE_V_IDENTIFIER 11
#define SCE_V_STRINGEOL 12
#define SCE_V_USER 19
#define SCE_V_COMMENT_WORD 20
#define SCE_V_INPUT 21
#define SCE_V_OUTPUT 22
#define SCE_V_INOUT 23
#define SCE_V_PORT_CONNECT 24
#define SCE_KIX_DEFAULT 0
#define SCE_KIX_COMMENT 1
#define SCE_KIX_STRING1 2
#define SCE_KIX_STRING2 3
#define SCE_KIX_NUMBER 4
#define SCE_KIX_VAR 5
#define SCE_KIX_MACRO 6
#define SCE_KIX_KEYWORD 7
#define SCE_KIX_FUNCTIONS 8
#define SCE_KIX_OPERATOR 9
#define SCE_KIX_COMMENTSTREAM 10
#define SCE_KIX_IDENTIFIER 31
#define SCE_GC_DEFAULT 0
#define SCE_GC_COMMENTLINE 1
#define SCE_GC_COMMENTBLOCK 2
#define SCE_GC_GLOBAL 3
#define SCE_GC_EVENT 4
#define SCE_GC_ATTRIBUTE 5
#define SCE_GC_CONTROL 6
#define SCE_GC_COMMAND 7
#define SCE_GC_STRING 8
#define SCE_GC_OPERATOR 9
#define SCE_SN_DEFAULT 0
#define SCE_SN_CODE 1
#define SCE_SN_COMMENTLINE 2
#define SCE_SN_COMMENTLINEBANG 3
#define SCE_SN_NUMBER 4
#define SCE_SN_WORD 5
#define SCE_SN_STRING 6
#define SCE_SN_WORD2 7
#define SCE_SN_WORD3 8
#define SCE_SN_PREPROCESSOR 9
#define SCE_SN_OPERATOR 10
#define SCE_SN_IDENTIFIER 11
#define SCE_SN_STRINGEOL 12
#define SCE_SN_REGEXTAG 13
#define SCE_SN_SIGNAL 14
#define SCE_SN_USER 19
#define SCE_AU3_DEFAULT 0
#define SCE_AU3_COMMENT 1
#define SCE_AU3_COMMENTBLOCK 2
#define SCE_AU3_NUMBER 3
#define SCE_AU3_FUNCTION 4
#define SCE_AU3_KEYWORD 5
#define SCE_AU3_MACRO 6
#define SCE_AU3_STRING 7
#define SCE_AU3_OPERATOR 8
#define SCE_AU3_VARIABLE 9
#define SCE_AU3_SENT 10
#define SCE_AU3_PREPROCESSOR 11
#define SCE_AU3_SPECIAL 12
#define SCE_AU3_EXPAND 13
#define SCE_AU3_COMOBJ 14
#define SCE_AU3_UDF 15
#define SCE_APDL_DEFAULT 0
#define SCE_APDL_COMMENT 1
#define SCE_APDL_COMMENTBLOCK 2
#define SCE_APDL_NUMBER 3
#define SCE_APDL_STRING 4
#define SCE_APDL_OPERATOR 5
#define SCE_APDL_WORD 6
#define SCE_APDL_PROCESSOR 7
#define SCE_APDL_COMMAND 8
#define SCE_APDL_SLASHCOMMAND 9
#define SCE_APDL_STARCOMMAND 10
#define SCE_APDL_ARGUMENT 11
#define SCE_APDL_FUNCTION 12
#define SCE_SH_DEFAULT 0
#define SCE_SH_ERROR 1
#define SCE_SH_COMMENTLINE 2
#define SCE_SH_NUMBER 3
#define SCE_SH_WORD 4
#define SCE_SH_STRING 5
#define SCE_SH_CHARACTER 6
#define SCE_SH_OPERATOR 7
#define SCE_SH_IDENTIFIER 8
#define SCE_SH_SCALAR 9
#define SCE_SH_PARAM 10
#define SCE_SH_BACKTICKS 11
#define SCE_SH_HERE_DELIM 12
#define SCE_SH_HERE_Q 13
#define SCE_ASN1_DEFAULT 0
#define SCE_ASN1_COMMENT 1
#define SCE_ASN1_IDENTIFIER 2
#define SCE_ASN1_STRING 3
#define SCE_ASN1_OID 4
#define SCE_ASN1_SCALAR 5
#define SCE_ASN1_KEYWORD 6
#define SCE_ASN1_ATTRIBUTE 7
#define SCE_ASN1_DESCRIPTOR 8
#define SCE_ASN1_TYPE 9
#define SCE_ASN1_OPERATOR 10
#define SCE_VHDL_DEFAULT 0
#define SCE_VHDL_COMMENT 1
#define SCE_VHDL_COMMENTLINEBANG 2
#define SCE_VHDL_NUMBER 3
#define SCE_VHDL_STRING 4
#define SCE_VHDL_OPERATOR 5
#define SCE_VHDL_IDENTIFIER 6
#define SCE_VHDL_STRINGEOL 7
#define SCE_VHDL_KEYWORD 8
#define SCE_VHDL_STDOPERATOR 9
#define SCE_VHDL_ATTRIBUTE 10
#define SCE_VHDL_STDFUNCTION 11
#define SCE_VHDL_STDPACKAGE 12
#define SCE_VHDL_STDTYPE 13
#define SCE_VHDL_USERWORD 14
#define SCE_VHDL_BLOCK_COMMENT 15
#define SCE_CAML_DEFAULT 0
#define SCE_CAML_IDENTIFIER 1
#define SCE_CAML_TAGNAME 2
#define SCE_CAML_KEYWORD 3
#define SCE_CAML_KEYWORD2 4
#define SCE_CAML_KEYWORD3 5
#define SCE_CAML_LINENUM 6
#define SCE_CAML_OPERATOR 7
#define SCE_CAML_NUMBER 8
#define SCE_CAML_CHAR 9
#define SCE_CAML_WHITE 10
#define SCE_CAML_STRING 11
#define SCE_CAML_COMMENT 12
#define SCE_CAML_COMMENT1 13
#define SCE_CAML_COMMENT2 14
#define SCE_CAML_COMMENT3 15
#define SCE_HA_DEFAULT 0
#define SCE_HA_IDENTIFIER 1
#define SCE_HA_KEYWORD 2
#define SCE_HA_NUMBER 3
#define SCE_HA_STRING 4
#define SCE_HA_CHARACTER 5
#define SCE_HA_CLASS 6
#define SCE_HA_MODULE 7
#define SCE_HA_CAPITAL 8
#define SCE_HA_DATA 9
#define SCE_HA_IMPORT 10
#define SCE_HA_OPERATOR 11
#define SCE_HA_INSTANCE 12
#define SCE_HA_COMMENTLINE 13
#define SCE_HA_COMMENTBLOCK 14
#define SCE_HA_COMMENTBLOCK2 15
#define SCE_HA_COMMENTBLOCK3 16
#define SCE_HA_PRAGMA 17
#define SCE_HA_PREPROCESSOR 18
#define SCE_HA_STRINGEOL 19
#define SCE_HA_RESERVED_OPERATOR 20
#define SCE_HA_LITERATE_COMMENT 21
#define SCE_HA_LITERATE_CODEDELIM 22
#define SCE_T3_DEFAULT 0
#define SCE_T3_X_DEFAULT 1
#define SCE_T3_PREPROCESSOR 2
#define SCE_T3_BLOCK_COMMENT 3
#define SCE_T3_LINE_COMMENT 4
#define SCE_T3_OPERATOR 5
#define SCE_T3_KEYWORD 6
#define SCE_T3_NUMBER 7
#define SCE_T3_IDENTIFIER 8
#define SCE_T3_S_STRING 9
#define SCE_T3_D_STRING 10
#define SCE_T3_X_STRING 11
#define SCE_T3_LIB_DIRECTIVE 12
#define SCE_T3_MSG_PARAM 13
#define SCE_T3_HTML_TAG 14
#define SCE_T3_HTML_DEFAULT 15
#define SCE_T3_HTML_STRING 16
#define SCE_T3_USER1 17
#define SCE_T3_USER2 18
#define SCE_T3_USER3 19
#define SCE_T3_BRACE 20
#define SCE_REBOL_DEFAULT 0
#define SCE_REBOL_COMMENTLINE 1
#define SCE_REBOL_COMMENTBLOCK 2
#define SCE_REBOL_PREFACE 3
#define SCE_REBOL_OPERATOR 4
#define SCE_REBOL_CHARACTER 5
#define SCE_REBOL_QUOTEDSTRING 6
#define SCE_REBOL_BRACEDSTRING 7
#define SCE_REBOL_NUMBER 8
#define SCE_REBOL_PAIR 9
#define SCE_REBOL_TUPLE 10
#define SCE_REBOL_BINARY 11
#define SCE_REBOL_MONEY 12
#define SCE_REBOL_ISSUE 13
#define SCE_REBOL_TAG 14
#define SCE_REBOL_FILE 15
#define SCE_REBOL_EMAIL 16
#define SCE_REBOL_URL 17
#define SCE_REBOL_DATE 18
#define SCE_REBOL_TIME 19
#define SCE_REBOL_IDENTIFIER 20
#define SCE_REBOL_WORD 21
#define SCE_REBOL_WORD2 22
#define SCE_REBOL_WORD3 23
#define SCE_REBOL_WORD4 24
#define SCE_REBOL_WORD5 25
#define SCE_REBOL_WORD6 26
#define SCE_REBOL_WORD7 27
#define SCE_REBOL_WORD8 28
#define SCE_SQL_DEFAULT 0
#define SCE_SQL_COMMENT 1
#define SCE_SQL_COMMENTLINE 2
#define SCE_SQL_COMMENTDOC 3
#define SCE_SQL_NUMBER 4
#define SCE_SQL_WORD 5
#define SCE_SQL_STRING 6
#define SCE_SQL_CHARACTER 7
#define SCE_SQL_SQLPLUS 8
#define SCE_SQL_SQLPLUS_PROMPT 9
#define SCE_SQL_OPERATOR 10
#define SCE_SQL_IDENTIFIER 11
#define SCE_SQL_SQLPLUS_COMMENT 13
#define SCE_SQL_COMMENTLINEDOC 15
#define SCE_SQL_WORD2 16
#define SCE_SQL_COMMENTDOCKEYWORD 17
#define SCE_SQL_COMMENTDOCKEYWORDERROR 18
#define SCE_SQL_USER1 19
#define SCE_SQL_USER2 20
#define SCE_SQL_USER3 21
#define SCE_SQL_USER4 22
#define SCE_SQL_QUOTEDIDENTIFIER 23
#define SCE_SQL_QOPERATOR 24
#define SCE_ST_DEFAULT 0
#define SCE_ST_STRING 1
#define SCE_ST_NUMBER 2
#define SCE_ST_COMMENT 3
#define SCE_ST_SYMBOL 4
#define SCE_ST_BINARY 5
#define SCE_ST_BOOL 6
#define SCE_ST_SELF 7
#define SCE_ST_SUPER 8
#define SCE_ST_NIL 9
#define SCE_ST_GLOBAL 10
#define SCE_ST_RETURN 11
#define SCE_ST_SPECIAL 12
#define SCE_ST_KWSEND 13
#define SCE_ST_ASSIGN 14
#define SCE_ST_CHARACTER 15
#define SCE_ST_SPEC_SEL 16
#define SCE_FS_DEFAULT 0
#define SCE_FS_COMMENT 1
#define SCE_FS_COMMENTLINE 2
#define SCE_FS_COMMENTDOC 3
#define SCE_FS_COMMENTLINEDOC 4
#define SCE_FS_COMMENTDOCKEYWORD 5
#define SCE_FS_COMMENTDOCKEYWORDERROR 6
#define SCE_FS_KEYWORD 7
#define SCE_FS_KEYWORD2 8
#define SCE_FS_KEYWORD3 9
#define SCE_FS_KEYWORD4 10
#define SCE_FS_NUMBER 11
#define SCE_FS_STRING 12
#define SCE_FS_PREPROCESSOR 13
#define SCE_FS_OPERATOR 14
#define SCE_FS_IDENTIFIER 15
#define SCE_FS_DATE 16
#define SCE_FS_STRINGEOL 17
#define SCE_FS_CONSTANT 18
#define SCE_FS_WORDOPERATOR 19
#define SCE_FS_DISABLEDCODE 20
#define SCE_FS_DEFAULT_C 21
#define SCE_FS_COMMENTDOC_C 22
#define SCE_FS_COMMENTLINEDOC_C 23
#define SCE_FS_KEYWORD_C 24
#define SCE_FS_KEYWORD2_C 25
#define SCE_FS_NUMBER_C 26
#define SCE_FS_STRING_C 27
#define SCE_FS_PREPROCESSOR_C 28
#define SCE_FS_OPERATOR_C 29
#define SCE_FS_IDENTIFIER_C 30
#define SCE_FS_STRINGEOL_C 31
#define SCE_CSOUND_DEFAULT 0
#define SCE_CSOUND_COMMENT 1
#define SCE_CSOUND_NUMBER 2
#define SCE_CSOUND_OPERATOR 3
#define SCE_CSOUND_INSTR 4
#define SCE_CSOUND_IDENTIFIER 5
#define SCE_CSOUND_OPCODE 6
#define SCE_CSOUND_HEADERSTMT 7
#define SCE_CSOUND_USERKEYWORD 8
#define SCE_CSOUND_COMMENTBLOCK 9
#define SCE_CSOUND_PARAM 10
#define SCE_CSOUND_ARATE_VAR 11
#define SCE_CSOUND_KRATE_VAR 12
#define SCE_CSOUND_IRATE_VAR 13
#define SCE_CSOUND_GLOBAL_VAR 14
#define SCE_CSOUND_STRINGEOL 15
#define SCE_INNO_DEFAULT 0
#define SCE_INNO_COMMENT 1
#define SCE_INNO_KEYWORD 2
#define SCE_INNO_PARAMETER 3
#define SCE_INNO_SECTION 4
#define SCE_INNO_PREPROC 5
#define SCE_INNO_INLINE_EXPANSION 6
#define SCE_INNO_COMMENT_PASCAL 7
#define SCE_INNO_KEYWORD_PASCAL 8
#define SCE_INNO_KEYWORD_USER 9
#define SCE_INNO_STRING_DOUBLE 10
#define SCE_INNO_STRING_SINGLE 11
#define SCE_INNO_IDENTIFIER 12
#define SCE_OPAL_SPACE 0
#define SCE_OPAL_COMMENT_BLOCK 1
#define SCE_OPAL_COMMENT_LINE 2
#define SCE_OPAL_INTEGER 3
#define SCE_OPAL_KEYWORD 4
#define SCE_OPAL_SORT 5
#define SCE_OPAL_STRING 6
#define SCE_OPAL_PAR 7
#define SCE_OPAL_BOOL_CONST 8
#define SCE_OPAL_DEFAULT 32
#define SCE_SPICE_DEFAULT 0
#define SCE_SPICE_IDENTIFIER 1
#define SCE_SPICE_KEYWORD 2
#define SCE_SPICE_KEYWORD2 3
#define SCE_SPICE_KEYWORD3 4
#define SCE_SPICE_NUMBER 5
#define SCE_SPICE_DELIMITER 6
#define SCE_SPICE_VALUE 7
#define SCE_SPICE_COMMENTLINE 8
#define SCE_CMAKE_DEFAULT 0
#define SCE_CMAKE_COMMENT 1
#define SCE_CMAKE_STRINGDQ 2
#define SCE_CMAKE_STRINGLQ 3
#define SCE_CMAKE_STRINGRQ 4
#define SCE_CMAKE_COMMANDS 5
#define SCE_CMAKE_PARAMETERS 6
#define SCE_CMAKE_VARIABLE 7
#define SCE_CMAKE_USERDEFINED 8
#define SCE_CMAKE_WHILEDEF 9
#define SCE_CMAKE_FOREACHDEF 10
#define SCE_CMAKE_IFDEFINEDEF 11
#define SCE_CMAKE_MACRODEF 12
#define SCE_CMAKE_STRINGVAR 13
#define SCE_CMAKE_NUMBER 14
#define SCE_GAP_DEFAULT 0
#define SCE_GAP_IDENTIFIER 1
#define SCE_GAP_KEYWORD 2
#define SCE_GAP_KEYWORD2 3
#define SCE_GAP_KEYWORD3 4
#define SCE_GAP_KEYWORD4 5
#define SCE_GAP_STRING 6
#define SCE_GAP_CHAR 7
#define SCE_GAP_OPERATOR 8
#define SCE_GAP_COMMENT 9
#define SCE_GAP_NUMBER 10
#define SCE_GAP_STRINGEOL 11
#define SCE_PLM_DEFAULT 0
#define SCE_PLM_COMMENT 1
#define SCE_PLM_STRING 2
#define SCE_PLM_NUMBER 3
#define SCE_PLM_IDENTIFIER 4
#define SCE_PLM_OPERATOR 5
#define SCE_PLM_CONTROL 6
#define SCE_PLM_KEYWORD 7
#define SCE_ABL_DEFAULT 0
#define SCE_ABL_NUMBER 1
#define SCE_ABL_WORD 2
#define SCE_ABL_STRING 3
#define SCE_ABL_CHARACTER 4
#define SCE_ABL_PREPROCESSOR 5
#define SCE_ABL_OPERATOR 6
#define SCE_ABL_IDENTIFIER 7
#define SCE_ABL_BLOCK 8
#define SCE_ABL_END 9
#define SCE_ABL_COMMENT 10
#define SCE_ABL_TASKMARKER 11
#define SCE_ABL_LINECOMMENT 12
#define SCE_ABAQUS_DEFAULT 0
#define SCE_ABAQUS_COMMENT 1
#define SCE_ABAQUS_COMMENTBLOCK 2
#define SCE_ABAQUS_NUMBER 3
#define SCE_ABAQUS_STRING 4
#define SCE_ABAQUS_OPERATOR 5
#define SCE_ABAQUS_WORD 6
#define SCE_ABAQUS_PROCESSOR 7
#define SCE_ABAQUS_COMMAND 8
#define SCE_ABAQUS_SLASHCOMMAND 9
#define SCE_ABAQUS_STARCOMMAND 10
#define SCE_ABAQUS_ARGUMENT 11
#define SCE_ABAQUS_FUNCTION 12
#define SCE_ASY_DEFAULT 0
#define SCE_ASY_COMMENT 1
#define SCE_ASY_COMMENTLINE 2
#define SCE_ASY_NUMBER 3
#define SCE_ASY_WORD 4
#define SCE_ASY_STRING 5
#define SCE_ASY_CHARACTER 6
#define SCE_ASY_OPERATOR 7
#define SCE_ASY_IDENTIFIER 8
#define SCE_ASY_STRINGEOL 9
#define SCE_ASY_COMMENTLINEDOC 10
#define SCE_ASY_WORD2 11
#define SCE_R_DEFAULT 0
#define SCE_R_COMMENT 1
#define SCE_R_KWORD 2
#define SCE_R_BASEKWORD 3
#define SCE_R_OTHERKWORD 4
#define SCE_R_NUMBER 5
#define SCE_R_STRING 6
#define SCE_R_STRING2 7
#define SCE_R_OPERATOR 8
#define SCE_R_IDENTIFIER 9
#define SCE_R_INFIX 10
#define SCE_R_INFIXEOL 11
#define SCE_MAGIK_DEFAULT 0
#define SCE_MAGIK_COMMENT 1
#define SCE_MAGIK_HYPER_COMMENT 16
#define SCE_MAGIK_STRING 2
#define SCE_MAGIK_CHARACTER 3
#define SCE_MAGIK_NUMBER 4
#define SCE_MAGIK_IDENTIFIER 5
#define SCE_MAGIK_OPERATOR 6
#define SCE_MAGIK_FLOW 7
#define SCE_MAGIK_CONTAINER 8
#define SCE_MAGIK_BRACKET_BLOCK 9
#define SCE_MAGIK_BRACE_BLOCK 10
#define SCE_MAGIK_SQBRACKET_BLOCK 11
#define SCE_MAGIK_UNKNOWN_KEYWORD 12
#define SCE_MAGIK_KEYWORD 13
#define SCE_MAGIK_PRAGMA 14
#define SCE_MAGIK_SYMBOL 15
#define SCE_POWERSHELL_DEFAULT 0
#define SCE_POWERSHELL_COMMENT 1
#define SCE_POWERSHELL_STRING 2
#define SCE_POWERSHELL_CHARACTER 3
#define SCE_POWERSHELL_NUMBER 4
#define SCE_POWERSHELL_VARIABLE 5
#define SCE_POWERSHELL_OPERATOR 6
#define SCE_POWERSHELL_IDENTIFIER 7
#define SCE_POWERSHELL_KEYWORD 8
#define SCE_POWERSHELL_CMDLET 9
#define SCE_POWERSHELL_ALIAS 10
#define SCE_POWERSHELL_FUNCTION 11
#define SCE_POWERSHELL_USER1 12
#define SCE_POWERSHELL_COMMENTSTREAM 13
#define SCE_POWERSHELL_HERE_STRING 14
#define SCE_POWERSHELL_HERE_CHARACTER 15
#define SCE_POWERSHELL_COMMENTDOCKEYWORD 16
#define SCE_MYSQL_DEFAULT 0
#define SCE_MYSQL_COMMENT 1
#define SCE_MYSQL_COMMENTLINE 2
#define SCE_MYSQL_VARIABLE 3
#define SCE_MYSQL_SYSTEMVARIABLE 4
#define SCE_MYSQL_KNOWNSYSTEMVARIABLE 5
#define SCE_MYSQL_NUMBER 6
#define SCE_MYSQL_MAJORKEYWORD 7
#define SCE_MYSQL_KEYWORD 8
#define SCE_MYSQL_DATABASEOBJECT 9
#define SCE_MYSQL_PROCEDUREKEYWORD 10
#define SCE_MYSQL_STRING 11
#define SCE_MYSQL_SQSTRING 12
#define SCE_MYSQL_DQSTRING 13
#define SCE_MYSQL_OPERATOR 14
#define SCE_MYSQL_FUNCTION 15
#define SCE_MYSQL_IDENTIFIER 16
#define SCE_MYSQL_QUOTEDIDENTIFIER 17
#define SCE_MYSQL_USER1 18
#define SCE_MYSQL_USER2 19
#define SCE_MYSQL_USER3 20
#define SCE_MYSQL_HIDDENCOMMAND 21
#define SCE_MYSQL_PLACEHOLDER 22
#define SCE_PO_DEFAULT 0
#define SCE_PO_COMMENT 1
#define SCE_PO_MSGID 2
#define SCE_PO_MSGID_TEXT 3
#define SCE_PO_MSGSTR 4
#define SCE_PO_MSGSTR_TEXT 5
#define SCE_PO_MSGCTXT 6
#define SCE_PO_MSGCTXT_TEXT 7
#define SCE_PO_FUZZY 8
#define SCE_PO_PROGRAMMER_COMMENT 9
#define SCE_PO_REFERENCE 10
#define SCE_PO_FLAGS 11
#define SCE_PO_MSGID_TEXT_EOL 12
#define SCE_PO_MSGSTR_TEXT_EOL 13
#define SCE_PO_MSGCTXT_TEXT_EOL 14
#define SCE_PO_ERROR 15
#define SCE_PAS_DEFAULT 0
#define SCE_PAS_IDENTIFIER 1
#define SCE_PAS_COMMENT 2
#define SCE_PAS_COMMENT2 3
#define SCE_PAS_COMMENTLINE 4
#define SCE_PAS_PREPROCESSOR 5
#define SCE_PAS_PREPROCESSOR2 6
#define SCE_PAS_NUMBER 7
#define SCE_PAS_HEXNUMBER 8
#define SCE_PAS_WORD 9
#define SCE_PAS_STRING 10
#define SCE_PAS_STRINGEOL 11
#define SCE_PAS_CHARACTER 12
#define SCE_PAS_OPERATOR 13
#define SCE_PAS_ASM 14
#define SCE_SORCUS_DEFAULT 0
#define SCE_SORCUS_COMMAND 1
#define SCE_SORCUS_PARAMETER 2
#define SCE_SORCUS_COMMENTLINE 3
#define SCE_SORCUS_STRING 4
#define SCE_SORCUS_STRINGEOL 5
#define SCE_SORCUS_IDENTIFIER 6
#define SCE_SORCUS_OPERATOR 7
#define SCE_SORCUS_NUMBER 8
#define SCE_SORCUS_CONSTANT 9
#define SCE_POWERPRO_DEFAULT 0
#define SCE_POWERPRO_COMMENTBLOCK 1
#define SCE_POWERPRO_COMMENTLINE 2
#define SCE_POWERPRO_NUMBER 3
#define SCE_POWERPRO_WORD 4
#define SCE_POWERPRO_WORD2 5
#define SCE_POWERPRO_WORD3 6
#define SCE_POWERPRO_WORD4 7
#define SCE_POWERPRO_DOUBLEQUOTEDSTRING 8
#define SCE_POWERPRO_SINGLEQUOTEDSTRING 9
#define SCE_POWERPRO_LINECONTINUE 10
#define SCE_POWERPRO_OPERATOR 11
#define SCE_POWERPRO_IDENTIFIER 12
#define SCE_POWERPRO_STRINGEOL 13
#define SCE_POWERPRO_VERBATIM 14
#define SCE_POWERPRO_ALTQUOTE 15
#define SCE_POWERPRO_FUNCTION 16
#define SCE_SML_DEFAULT 0
#define SCE_SML_IDENTIFIER 1
#define SCE_SML_TAGNAME 2
#define SCE_SML_KEYWORD 3
#define SCE_SML_KEYWORD2 4
#define SCE_SML_KEYWORD3 5
#define SCE_SML_LINENUM 6
#define SCE_SML_OPERATOR 7
#define SCE_SML_NUMBER 8
#define SCE_SML_CHAR 9
#define SCE_SML_STRING 11
#define SCE_SML_COMMENT 12
#define SCE_SML_COMMENT1 13
#define SCE_SML_COMMENT2 14
#define SCE_SML_COMMENT3 15
#define SCE_MARKDOWN_DEFAULT 0
#define SCE_MARKDOWN_LINE_BEGIN 1
#define SCE_MARKDOWN_STRONG1 2
#define SCE_MARKDOWN_STRONG2 3
#define SCE_MARKDOWN_EM1 4
#define SCE_MARKDOWN_EM2 5
#define SCE_MARKDOWN_HEADER1 6
#define SCE_MARKDOWN_HEADER2 7
#define SCE_MARKDOWN_HEADER3 8
#define SCE_MARKDOWN_HEADER4 9
#define SCE_MARKDOWN_HEADER5 10
#define SCE_MARKDOWN_HEADER6 11
#define SCE_MARKDOWN_PRECHAR 12
#define SCE_MARKDOWN_ULIST_ITEM 13
#define SCE_MARKDOWN_OLIST_ITEM 14
#define SCE_MARKDOWN_BLOCKQUOTE 15
#define SCE_MARKDOWN_STRIKEOUT 16
#define SCE_MARKDOWN_HRULE 17
#define SCE_MARKDOWN_LINK 18
#define SCE_MARKDOWN_CODE 19
#define SCE_MARKDOWN_CODE2 20
#define SCE_MARKDOWN_CODEBK 21
#define SCE_TXT2TAGS_DEFAULT 0
#define SCE_TXT2TAGS_LINE_BEGIN 1
#define SCE_TXT2TAGS_STRONG1 2
#define SCE_TXT2TAGS_STRONG2 3
#define SCE_TXT2TAGS_EM1 4
#define SCE_TXT2TAGS_EM2 5
#define SCE_TXT2TAGS_HEADER1 6
#define SCE_TXT2TAGS_HEADER2 7
#define SCE_TXT2TAGS_HEADER3 8
#define SCE_TXT2TAGS_HEADER4 9
#define SCE_TXT2TAGS_HEADER5 10
#define SCE_TXT2TAGS_HEADER6 11
#define SCE_TXT2TAGS_PRECHAR 12
#define SCE_TXT2TAGS_ULIST_ITEM 13
#define SCE_TXT2TAGS_OLIST_ITEM 14
#define SCE_TXT2TAGS_BLOCKQUOTE 15
#define SCE_TXT2TAGS_STRIKEOUT 16
#define SCE_TXT2TAGS_HRULE 17
#define SCE_TXT2TAGS_LINK 18
#define SCE_TXT2TAGS_CODE 19
#define SCE_TXT2TAGS_CODE2 20
#define SCE_TXT2TAGS_CODEBK 21
#define SCE_TXT2TAGS_COMMENT 22
#define SCE_TXT2TAGS_OPTION 23
#define SCE_TXT2TAGS_PREPROC 24
#define SCE_TXT2TAGS_POSTPROC 25
#define SCE_A68K_DEFAULT 0
#define SCE_A68K_COMMENT 1
#define SCE_A68K_NUMBER_DEC 2
#define SCE_A68K_NUMBER_BIN 3
#define SCE_A68K_NUMBER_HEX 4
#define SCE_A68K_STRING1 5
#define SCE_A68K_OPERATOR 6
#define SCE_A68K_CPUINSTRUCTION 7
#define SCE_A68K_EXTINSTRUCTION 8
#define SCE_A68K_REGISTER 9
#define SCE_A68K_DIRECTIVE 10
#define SCE_A68K_MACRO_ARG 11
#define SCE_A68K_LABEL 12
#define SCE_A68K_STRING2 13
#define SCE_A68K_IDENTIFIER 14
#define SCE_A68K_MACRO_DECLARATION 15
#define SCE_A68K_COMMENT_WORD 16
#define SCE_A68K_COMMENT_SPECIAL 17
#define SCE_A68K_COMMENT_DOXYGEN 18
#define SCE_MODULA_DEFAULT 0
#define SCE_MODULA_COMMENT 1
#define SCE_MODULA_DOXYCOMM 2
#define SCE_MODULA_DOXYKEY 3
#define SCE_MODULA_KEYWORD 4
#define SCE_MODULA_RESERVED 5
#define SCE_MODULA_NUMBER 6
#define SCE_MODULA_BASENUM 7
#define SCE_MODULA_FLOAT 8
#define SCE_MODULA_STRING 9
#define SCE_MODULA_STRSPEC 10
#define SCE_MODULA_CHAR 11
#define SCE_MODULA_CHARSPEC 12
#define SCE_MODULA_PROC 13
#define SCE_MODULA_PRAGMA 14
#define SCE_MODULA_PRGKEY 15
#define SCE_MODULA_OPERATOR 16
#define SCE_MODULA_BADSTR 17
#define SCE_COFFEESCRIPT_DEFAULT 0
#define SCE_COFFEESCRIPT_COMMENT 1
#define SCE_COFFEESCRIPT_COMMENTLINE 2
#define SCE_COFFEESCRIPT_COMMENTDOC 3
#define SCE_COFFEESCRIPT_NUMBER 4
#define SCE_COFFEESCRIPT_WORD 5
#define SCE_COFFEESCRIPT_STRING 6
#define SCE_COFFEESCRIPT_CHARACTER 7
#define SCE_COFFEESCRIPT_UUID 8
#define SCE_COFFEESCRIPT_PREPROCESSOR 9
#define SCE_COFFEESCRIPT_OPERATOR 10
#define SCE_COFFEESCRIPT_IDENTIFIER 11
#define SCE_COFFEESCRIPT_STRINGEOL 12
#define SCE_COFFEESCRIPT_VERBATIM 13
#define SCE_COFFEESCRIPT_REGEX 14
#define SCE_COFFEESCRIPT_COMMENTLINEDOC 15
#define SCE_COFFEESCRIPT_WORD2 16
#define SCE_COFFEESCRIPT_COMMENTDOCKEYWORD 17
#define SCE_COFFEESCRIPT_COMMENTDOCKEYWORDERROR 18
#define SCE_COFFEESCRIPT_GLOBALCLASS 19
#define SCE_COFFEESCRIPT_STRINGRAW 20
#define SCE_COFFEESCRIPT_TRIPLEVERBATIM 21
#define SCE_COFFEESCRIPT_COMMENTBLOCK 22
#define SCE_COFFEESCRIPT_VERBOSE_REGEX 23
#define SCE_COFFEESCRIPT_VERBOSE_REGEX_COMMENT 24
#define SCE_COFFEESCRIPT_INSTANCEPROPERTY 25
#define SCE_AVS_DEFAULT 0
#define SCE_AVS_COMMENTBLOCK 1
#define SCE_AVS_COMMENTBLOCKN 2
#define SCE_AVS_COMMENTLINE 3
#define SCE_AVS_NUMBER 4
#define SCE_AVS_OPERATOR 5
#define SCE_AVS_IDENTIFIER 6
#define SCE_AVS_STRING 7
#define SCE_AVS_TRIPLESTRING 8
#define SCE_AVS_KEYWORD 9
#define SCE_AVS_FILTER 10
#define SCE_AVS_PLUGIN 11
#define SCE_AVS_FUNCTION 12
#define SCE_AVS_CLIPPROP 13
#define SCE_AVS_USERDFN 14
#define SCE_ECL_DEFAULT 0
#define SCE_ECL_COMMENT 1
#define SCE_ECL_COMMENTLINE 2
#define SCE_ECL_NUMBER 3
#define SCE_ECL_STRING 4
#define SCE_ECL_WORD0 5
#define SCE_ECL_OPERATOR 6
#define SCE_ECL_CHARACTER 7
#define SCE_ECL_UUID 8
#define SCE_ECL_PREPROCESSOR 9
#define SCE_ECL_UNKNOWN 10
#define SCE_ECL_IDENTIFIER 11
#define SCE_ECL_STRINGEOL 12
#define SCE_ECL_VERBATIM 13
#define SCE_ECL_REGEX 14
#define SCE_ECL_COMMENTLINEDOC 15
#define SCE_ECL_WORD1 16
#define SCE_ECL_COMMENTDOCKEYWORD 17
#define SCE_ECL_COMMENTDOCKEYWORDERROR 18
#define SCE_ECL_WORD2 19
#define SCE_ECL_WORD3 20
#define SCE_ECL_WORD4 21
#define SCE_ECL_WORD5 22
#define SCE_ECL_COMMENTDOC 23
#define SCE_ECL_ADDED 24
#define SCE_ECL_DELETED 25
#define SCE_ECL_CHANGED 26
#define SCE_ECL_MOVED 27
#define SCE_OSCRIPT_DEFAULT 0
#define SCE_OSCRIPT_LINE_COMMENT 1
#define SCE_OSCRIPT_BLOCK_COMMENT 2
#define SCE_OSCRIPT_DOC_COMMENT 3
#define SCE_OSCRIPT_PREPROCESSOR 4
#define SCE_OSCRIPT_NUMBER 5
#define SCE_OSCRIPT_SINGLEQUOTE_STRING 6
#define SCE_OSCRIPT_DOUBLEQUOTE_STRING 7
#define SCE_OSCRIPT_CONSTANT 8
#define SCE_OSCRIPT_IDENTIFIER 9
#define SCE_OSCRIPT_GLOBAL 10
#define SCE_OSCRIPT_KEYWORD 11
#define SCE_OSCRIPT_OPERATOR 12
#define SCE_OSCRIPT_LABEL 13
#define SCE_OSCRIPT_TYPE 14
#define SCE_OSCRIPT_FUNCTION 15
#define SCE_OSCRIPT_OBJECT 16
#define SCE_OSCRIPT_PROPERTY 17
#define SCE_OSCRIPT_METHOD 18
#define SCE_VISUALPROLOG_DEFAULT 0
#define SCE_VISUALPROLOG_KEY_MAJOR 1
#define SCE_VISUALPROLOG_KEY_MINOR 2
#define SCE_VISUALPROLOG_KEY_DIRECTIVE 3
#define SCE_VISUALPROLOG_COMMENT_BLOCK 4
#define SCE_VISUALPROLOG_COMMENT_LINE 5
#define SCE_VISUALPROLOG_COMMENT_KEY 6
#define SCE_VISUALPROLOG_COMMENT_KEY_ERROR 7
#define SCE_VISUALPROLOG_IDENTIFIER 8
#define SCE_VISUALPROLOG_VARIABLE 9
#define SCE_VISUALPROLOG_ANONYMOUS 10
#define SCE_VISUALPROLOG_NUMBER 11
#define SCE_VISUALPROLOG_OPERATOR 12
#define SCE_VISUALPROLOG_CHARACTER 13
#define SCE_VISUALPROLOG_CHARACTER_TOO_MANY 14
#define SCE_VISUALPROLOG_CHARACTER_ESCAPE_ERROR 15
#define SCE_VISUALPROLOG_STRING 16
#define SCE_VISUALPROLOG_STRING_ESCAPE 17
#define SCE_VISUALPROLOG_STRING_ESCAPE_ERROR 18
#define SCE_VISUALPROLOG_STRING_EOL_OPEN 19
#define SCE_VISUALPROLOG_STRING_VERBATIM 20
#define SCE_VISUALPROLOG_STRING_VERBATIM_SPECIAL 21
#define SCE_VISUALPROLOG_STRING_VERBATIM_EOL 22
#define SCE_STTXT_DEFAULT 0
#define SCE_STTXT_COMMENT 1
#define SCE_STTXT_COMMENTLINE 2
#define SCE_STTXT_KEYWORD 3
#define SCE_STTXT_TYPE 4
#define SCE_STTXT_FUNCTION 5
#define SCE_STTXT_FB 6
#define SCE_STTXT_NUMBER 7
#define SCE_STTXT_HEXNUMBER 8
#define SCE_STTXT_PRAGMA 9
#define SCE_STTXT_OPERATOR 10
#define SCE_STTXT_CHARACTER 11
#define SCE_STTXT_STRING1 12
#define SCE_STTXT_STRING2 13
#define SCE_STTXT_STRINGEOL 14
#define SCE_STTXT_IDENTIFIER 15
#define SCE_STTXT_DATETIME 16
#define SCE_STTXT_VARS 17
#define SCE_STTXT_PRAGMAS 18
#define SCE_KVIRC_DEFAULT 0
#define SCE_KVIRC_COMMENT 1
#define SCE_KVIRC_COMMENTBLOCK 2
#define SCE_KVIRC_STRING 3
#define SCE_KVIRC_WORD 4
#define SCE_KVIRC_KEYWORD 5
#define SCE_KVIRC_FUNCTION_KEYWORD 6
#define SCE_KVIRC_FUNCTION 7
#define SCE_KVIRC_VARIABLE 8
#define SCE_KVIRC_NUMBER 9
#define SCE_KVIRC_OPERATOR 10
#define SCE_KVIRC_STRING_FUNCTION 11
#define SCE_KVIRC_STRING_VARIABLE 12
#define SCE_RUST_DEFAULT 0
#define SCE_RUST_COMMENTBLOCK 1
#define SCE_RUST_COMMENTLINE 2
#define SCE_RUST_COMMENTBLOCKDOC 3
#define SCE_RUST_COMMENTLINEDOC 4
#define SCE_RUST_NUMBER 5
#define SCE_RUST_WORD 6
#define SCE_RUST_WORD2 7
#define SCE_RUST_WORD3 8
#define SCE_RUST_WORD4 9
#define SCE_RUST_WORD5 10
#define SCE_RUST_WORD6 11
#define SCE_RUST_WORD7 12
#define SCE_RUST_STRING 13
#define SCE_RUST_STRINGR 14
#define SCE_RUST_CHARACTER 15
#define SCE_RUST_OPERATOR 16
#define SCE_RUST_IDENTIFIER 17
#define SCE_RUST_LIFETIME 18
#define SCE_RUST_MACRO 19
#define SCE_RUST_LEXERROR 20
#define SCE_RUST_BYTESTRING 21
#define SCE_RUST_BYTESTRINGR 22
#define SCE_RUST_BYTECHARACTER 23
#define SCE_DMAP_DEFAULT 0
#define SCE_DMAP_COMMENT 1
#define SCE_DMAP_NUMBER 2
#define SCE_DMAP_STRING1 3
#define SCE_DMAP_STRING2 4
#define SCE_DMAP_STRINGEOL 5
#define SCE_DMAP_OPERATOR 6
#define SCE_DMAP_IDENTIFIER 7
#define SCE_DMAP_WORD 8
#define SCE_DMAP_WORD2 9
#define SCE_DMAP_WORD3 10
#define SCE_DMIS_DEFAULT 0
#define SCE_DMIS_COMMENT 1
#define SCE_DMIS_STRING 2
#define SCE_DMIS_NUMBER 3
#define SCE_DMIS_KEYWORD 4
#define SCE_DMIS_MAJORWORD 5
#define SCE_DMIS_MINORWORD 6
#define SCE_DMIS_UNSUPPORTED_MAJOR 7
#define SCE_DMIS_UNSUPPORTED_MINOR 8
#define SCE_DMIS_LABEL 9
#define SCE_REG_DEFAULT 0
#define SCE_REG_COMMENT 1
#define SCE_REG_VALUENAME 2
#define SCE_REG_STRING 3
#define SCE_REG_HEXDIGIT 4
#define SCE_REG_VALUETYPE 5
#define SCE_REG_ADDEDKEY 6
#define SCE_REG_DELETEDKEY 7
#define SCE_REG_ESCAPED 8
#define SCE_REG_KEYPATH_GUID 9
#define SCE_REG_STRING_GUID 10
#define SCE_REG_PARAMETER 11
#define SCE_REG_OPERATOR 12
#define SCE_BIBTEX_DEFAULT 0
#define SCE_BIBTEX_ENTRY 1
#define SCE_BIBTEX_UNKNOWN_ENTRY 2
#define SCE_BIBTEX_KEY 3
#define SCE_BIBTEX_PARAMETER 4
#define SCE_BIBTEX_VALUE 5
#define SCE_BIBTEX_COMMENT 6
#define SCE_HEX_DEFAULT 0
#define SCE_HEX_RECSTART 1
#define SCE_HEX_RECTYPE 2
#define SCE_HEX_RECTYPE_UNKNOWN 3
#define SCE_HEX_BYTECOUNT 4
#define SCE_HEX_BYTECOUNT_WRONG 5
#define SCE_HEX_NOADDRESS 6
#define SCE_HEX_DATAADDRESS 7
#define SCE_HEX_RECCOUNT 8
#define SCE_HEX_STARTADDRESS 9
#define SCE_HEX_ADDRESSFIELD_UNKNOWN 10
#define SCE_HEX_EXTENDEDADDRESS 11
#define SCE_HEX_DATA_ODD 12
#define SCE_HEX_DATA_EVEN 13
#define SCE_HEX_DATA_UNKNOWN 14
#define SCE_HEX_DATA_EMPTY 15
#define SCE_HEX_CHECKSUM 16
#define SCE_HEX_CHECKSUM_WRONG 17
#define SCE_HEX_GARBAGE 18
#define SCE_JSON_DEFAULT 0
#define SCE_JSON_NUMBER 1
#define SCE_JSON_STRING 2
#define SCE_JSON_STRINGEOL 3
#define SCE_JSON_PROPERTYNAME 4
#define SCE_JSON_ESCAPESEQUENCE 5
#define SCE_JSON_LINECOMMENT 6
#define SCE_JSON_BLOCKCOMMENT 7
#define SCE_JSON_OPERATOR 8
#define SCE_JSON_URI 9
#define SCE_JSON_COMPACTIRI 10
#define SCE_JSON_KEYWORD 11
#define SCE_JSON_LDKEYWORD 12
#define SCE_JSON_ERROR 13
#define SCE_EDI_DEFAULT 0
#define SCE_EDI_SEGMENTSTART 1
#define SCE_EDI_SEGMENTEND 2
#define SCE_EDI_SEP_ELEMENT 3
#define SCE_EDI_SEP_COMPOSITE 4
#define SCE_EDI_SEP_RELEASE 5
#define SCE_EDI_UNA 6
#define SCE_EDI_UNH 7
#define SCE_EDI_BADSEGMENT 8
#define SCE_STATA_DEFAULT 0
#define SCE_STATA_COMMENT 1
#define SCE_STATA_COMMENTLINE 2
#define SCE_STATA_COMMENTBLOCK 3
#define SCE_STATA_NUMBER 4
#define SCE_STATA_OPERATOR 5
#define SCE_STATA_IDENTIFIER 6
#define SCE_STATA_STRING 7
#define SCE_STATA_TYPE 8
#define SCE_STATA_WORD 9
#define SCE_STATA_GLOBAL_MACRO 10
#define SCE_STATA_MACRO 11
#define SCE_SAS_DEFAULT 0
#define SCE_SAS_COMMENT 1
#define SCE_SAS_COMMENTLINE 2
#define SCE_SAS_COMMENTBLOCK 3
#define SCE_SAS_NUMBER 4
#define SCE_SAS_OPERATOR 5
#define SCE_SAS_IDENTIFIER 6
#define SCE_SAS_STRING 7
#define SCE_SAS_TYPE 8
#define SCE_SAS_WORD 9
#define SCE_SAS_GLOBAL_MACRO 10
#define SCE_SAS_MACRO 11
#define SCE_SAS_MACRO_KEYWORD 12
#define SCE_SAS_BLOCK_KEYWORD 13
#define SCE_SAS_MACRO_FUNCTION 14
#define SCE_SAS_STATEMENT 15
#define SCE_NIM_DEFAULT 0
#define SCE_NIM_COMMENT 1
#define SCE_NIM_COMMENTDOC 2
#define SCE_NIM_COMMENTLINE 3
#define SCE_NIM_COMMENTLINEDOC 4
#define SCE_NIM_NUMBER 5
#define SCE_NIM_STRING 6
#define SCE_NIM_CHARACTER 7
#define SCE_NIM_WORD 8
#define SCE_NIM_TRIPLE 9
#define SCE_NIM_TRIPLEDOUBLE 10
#define SCE_NIM_BACKTICKS 11
#define SCE_NIM_FUNCNAME 12
#define SCE_NIM_STRINGEOL 13
#define SCE_NIM_NUMERROR 14
#define SCE_NIM_OPERATOR 15
#define SCE_NIM_IDENTIFIER 16
#define SCE_CIL_DEFAULT 0
#define SCE_CIL_COMMENT 1
#define SCE_CIL_COMMENTLINE 2
#define SCE_CIL_WORD 3
#define SCE_CIL_WORD2 4
#define SCE_CIL_WORD3 5
#define SCE_CIL_STRING 6
#define SCE_CIL_LABEL 7
#define SCE_CIL_OPERATOR 8
#define SCE_CIL_IDENTIFIER 9
#define SCE_CIL_STRINGEOL 10
#define SCE_X12_DEFAULT 0
#define SCE_X12_BAD 1
#define SCE_X12_ENVELOPE 2
#define SCE_X12_FUNCTIONGROUP 3
#define SCE_X12_TRANSACTIONSET 4
#define SCE_X12_SEGMENTHEADER 5
#define SCE_X12_SEGMENTEND 6
#define SCE_X12_SEP_ELEMENT 7
#define SCE_X12_SEP_SUBELEMENT 8
#define SCE_DF_DEFAULT 0
#define SCE_DF_IDENTIFIER 1
#define SCE_DF_METATAG 2
#define SCE_DF_IMAGE 3
#define SCE_DF_COMMENTLINE 4
#define SCE_DF_PREPROCESSOR 5
#define SCE_DF_PREPROCESSOR2 6
#define SCE_DF_NUMBER 7
#define SCE_DF_HEXNUMBER 8
#define SCE_DF_WORD 9
#define SCE_DF_STRING 10
#define SCE_DF_STRINGEOL 11
#define SCE_DF_SCOPEWORD 12
#define SCE_DF_OPERATOR 13
#define SCE_DF_ICODE 14
#define SCE_HOLLYWOOD_DEFAULT 0
#define SCE_HOLLYWOOD_COMMENT 1
#define SCE_HOLLYWOOD_COMMENTBLOCK 2
#define SCE_HOLLYWOOD_NUMBER 3
#define SCE_HOLLYWOOD_KEYWORD 4
#define SCE_HOLLYWOOD_STDAPI 5
#define SCE_HOLLYWOOD_PLUGINAPI 6
#define SCE_HOLLYWOOD_PLUGINMETHOD 7
#define SCE_HOLLYWOOD_STRING 8
#define SCE_HOLLYWOOD_STRINGBLOCK 9
#define SCE_HOLLYWOOD_PREPROCESSOR 10
#define SCE_HOLLYWOOD_OPERATOR 11
#define SCE_HOLLYWOOD_IDENTIFIER 12
#define SCE_HOLLYWOOD_CONSTANT 13
#define SCE_HOLLYWOOD_HEXNUMBER 14
#define SCE_RAKU_DEFAULT 0
#define SCE_RAKU_ERROR 1
#define SCE_RAKU_COMMENTLINE 2
#define SCE_RAKU_COMMENTEMBED 3
#define SCE_RAKU_POD 4
#define SCE_RAKU_CHARACTER 5
#define SCE_RAKU_HEREDOC_Q 6
#define SCE_RAKU_HEREDOC_QQ 7
#define SCE_RAKU_STRING 8
#define SCE_RAKU_STRING_Q 9
#define SCE_RAKU_STRING_QQ 10
#define SCE_RAKU_STRING_Q_LANG 11
#define SCE_RAKU_STRING_VAR 12
#define SCE_RAKU_REGEX 13
#define SCE_RAKU_REGEX_VAR 14
#define SCE_RAKU_ADVERB 15
#define SCE_RAKU_NUMBER 16
#define SCE_RAKU_PREPROCESSOR 17
#define SCE_RAKU_OPERATOR 18
#define SCE_RAKU_WORD 19
#define SCE_RAKU_FUNCTION 20
#define SCE_RAKU_IDENTIFIER 21
#define SCE_RAKU_TYPEDEF 22
#define SCE_RAKU_MU 23
#define SCE_RAKU_POSITIONAL 24
#define SCE_RAKU_ASSOCIATIVE 25
#define SCE_RAKU_CALLABLE 26
#define SCE_RAKU_GRAMMAR 27
#define SCE_RAKU_CLASS 28
#define SCE_FSHARP_DEFAULT 0
#define SCE_FSHARP_KEYWORD 1
#define SCE_FSHARP_KEYWORD2 2
#define SCE_FSHARP_KEYWORD3 3
#define SCE_FSHARP_KEYWORD4 4
#define SCE_FSHARP_KEYWORD5 5
#define SCE_FSHARP_IDENTIFIER 6
#define SCE_FSHARP_QUOT_IDENTIFIER 7
#define SCE_FSHARP_COMMENT 8
#define SCE_FSHARP_COMMENTLINE 9
#define SCE_FSHARP_PREPROCESSOR 10
#define SCE_FSHARP_LINENUM 11
#define SCE_FSHARP_OPERATOR 12
#define SCE_FSHARP_NUMBER 13
#define SCE_FSHARP_CHARACTER 14
#define SCE_FSHARP_STRING 15
#define SCE_FSHARP_VERBATIM 16
#define SCE_FSHARP_QUOTATION 17
#define SCE_FSHARP_ATTRIBUTE 18
#define SCE_FSHARP_FORMAT_SPEC 19
#define SCE_ASCIIDOC_DEFAULT 0
#define SCE_ASCIIDOC_STRONG1 1
#define SCE_ASCIIDOC_STRONG2 2
#define SCE_ASCIIDOC_EM1 3
#define SCE_ASCIIDOC_EM2 4
#define SCE_ASCIIDOC_HEADER1 5
#define SCE_ASCIIDOC_HEADER2 6
#define SCE_ASCIIDOC_HEADER3 7
#define SCE_ASCIIDOC_HEADER4 8
#define SCE_ASCIIDOC_HEADER5 9
#define SCE_ASCIIDOC_HEADER6 10
#define SCE_ASCIIDOC_ULIST_ITEM 11
#define SCE_ASCIIDOC_OLIST_ITEM 12
#define SCE_ASCIIDOC_BLOCKQUOTE 13
#define SCE_ASCIIDOC_LINK 14
#define SCE_ASCIIDOC_CODEBK 15
#define SCE_ASCIIDOC_PASSBK 16
#define SCE_ASCIIDOC_COMMENT 17
#define SCE_ASCIIDOC_COMMENTBK 18
#define SCE_ASCIIDOC_LITERAL 19
#define SCE_ASCIIDOC_LITERALBK 20
#define SCE_ASCIIDOC_ATTRIB 21
#define SCE_ASCIIDOC_ATTRIBVAL 22
#define SCE_ASCIIDOC_MACRO 23
#define SCE_GD_DEFAULT 0
#define SCE_GD_COMMENTLINE 1
#define SCE_GD_NUMBER 2
#define SCE_GD_STRING 3
#define SCE_GD_CHARACTER 4
#define SCE_GD_WORD 5
#define SCE_GD_TRIPLE 6
#define SCE_GD_TRIPLEDOUBLE 7
#define SCE_GD_CLASSNAME 8
#define SCE_GD_FUNCNAME 9
#define SCE_GD_OPERATOR 10
#define SCE_GD_IDENTIFIER 11
#define SCE_GD_COMMENTBLOCK 12
#define SCE_GD_STRINGEOL 13
#define SCE_GD_WORD2 14
#define SCE_GD_ANNOTATION 15
/* --Autogenerated -- end of section automatically generated from Scintilla.iface */

#endif






#include <commdlg.h>
#include <wincrypt.h>
#include <vfw.h>


/*((((((((((((((  Global Macros/Constants  ))))))))))))))*/

#define MAX_FILE_NAME 4*0x400
#define wControls_FLAT_BIT 0x20
#define wControls_POPUP_BIT 0x8000
#ifndef ONE_SECOND
#define ONE_SECOND 1000
#endif
#ifndef ONE_MINUTE
#define ONE_MINUTE (ONE_SECOND*60)
#endif
#define BASE64_MAX_CHARS_PER_LINE 76
#define clsANI_Create clsANI_Initialize
#define clsANI_Destroy clsANI_Terminate
#define wScrollBar_WIDTH 15
#define wScrollBar_HEIGHT 15
#define wScrollBar_HORIZONTAL_BIT 4
#define wScrollBar_BIT 8
#define wScrollBar_SUBCLASS_BIT 16
#define wBox_wScrl_WIDTH wScrollBar_WIDTH
#define wBox_wScrl_HEIGHT wScrollBar_HEIGHT
#define clsFTP_IsOpen(x) ((x)->m_State>=clsFTP_stateOpen)
#define clsFTP_IsConnected(x) ((x)->m_State>=clsFTP_stateConnected)
#define clsFTP_GetServer clsFTP_GetURL
#define clsFTP_SetServer clsFTP_SetURL
#define clsFTP_GetPort(x) (x)->m_iPort
#define clsFTP_AddConnect(x) clsFTP_ConnectSync(x,(const cb_String)-1,2)
#define clsFTP_CurDir clsFTP_GetDir
#define clsFTP_GetCurrentDir clsFTP_GetDir
#define clsFTP_ChDir clsFTP_SetDir
#define clsFTP_IsFolder(x,...) (clsFTP_IsExist(x,__VA_ARGS__) & (cb_MIN_INTEGER32 | FILE_ATTRIBUTE_DIRECTORY))
#define clsFTP_IsDir clsFTP_IsFolder
#define clsFTP_SetFile clsFTP_PutFile
#define clsFTP_Create clsFTP_Initialize
#define clsFTP_Destroy clsFTP_Terminate
#define watchDir_FILE_NOTIFY (FILE_NOTIFY_CHANGE_ATTRIBUTES | FILE_NOTIFY_CHANGE_SIZE | FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE)
#define watchDir_FILE_NOTIFY_ALL (watchDir_FILE_NOTIFY | FILE_NOTIFY_CHANGE_LAST_ACCESS | FILE_NOTIFY_CHANGE_CREATION | FILE_NOTIFY_CHANGE_SECURITY)
#define wScrollBtn_HORIZONTAL_BIT 4
#define wScrollBtn_COUNTER_BIT 8
#define ucCoolSB_HandleCustomDraw CoolSB_HandleCustomDraw
#define ucCoolSB_SetStyle CoolSB_SetStyle
#define ucCoolSB_SetSize CoolSB_SetSize
#define ucCoolSB_SetControlAddressM(x) cb_SetWndData((x)->hWnd,x)
#define wTextBox_MAXLEN 8*0x100000
#define wComboBox_HEIGHT_ 20
#define wComboBox_List_HEIGHT_ 50
#define tvwAscending 0
#define tvwDescending 1
#define wCommander_FILE_NOTIFY watchDir_FILE_NOTIFY
#define wCommander_FILE_NOTIFY_ALL watchDir_FILE_NOTIFY_ALL
#define clsBatch_STACK_SIZE_ 256
#define clsBatch_NESTED_ 128
#define clsBatch_VAR_SIZE_ 8
#define clsBatch_MAX_DIRSTACK_ 48*0x400
#define clsBatch_MAX_DIR_NAME_ MAX_FILE_NAME
#define clsBatch_MAX_SETSTACK_ 96*0x400
#define clsBatch_MAX_ARGS_ 20
#define clsBatch_Cancel clsBatch_Stop






#ifndef wListView_BASE
#define wListView_BASE 0
#endif
#define wMIDIKB_MAXOCTAVES 7
#define wRTFBox_MAXLEN 8*0x100000
#define wRTFBox_GetModify wRTFBox_GetDataChanged
#define wRTFBox_SetModify wRTFBox_SetDataChanged
#define wSCIBox_MAX_DOCS 8
#define wSCIBox_MAX_POSITIONS 16
#define modSocket_MSG (WM_USER+1)
#define modSocket_EVENTS_BITS FD_READ | FD_WRITE | FD_ACCEPT | FD_CONNECT | FD_CLOSE
#define modSocket_CONNECT_BIT_ 1
#define modSocket_ON_BIT_ (1 << 1)
#define modSocket_REGISTER_BIT_ (1 << 2)


/*((((((((((((((  Global Enums  ))))))))))))))*/


enum {
  id_clsANI = 1
};


enum {
  clsANI_GIF_ENGINE = 1,
  clsANI_AVI_ENGINE
};


enum {
  wButton_enumDisabled,
  wButton_enumDown,
  wButton_enumUp,
  wButton_enumOn1,
  wButton_enumOn2,
  wButton_enumChecked
};


enum {
  wButton_CHECKED_bit1 = 4,
  wButton_CHECKED_bit2 = wButton_CHECKED_bit1 << 1
  #define wButton_CHECKED_bits (wButton_CHECKED_bit1 | wButton_CHECKED_bit2)
,
  wButton_AUTOSIZE_bit = wButton_CHECKED_bit2 << 1,
  wButton_ROUNDRECT_bit = wButton_AUTOSIZE_bit << 1,
  wButton_HORIZONTAL_bit = wButton_ROUNDRECT_bit << 1
};


enum {
  wPushButton_enumDisabled,
  wPushButton_enumDown,
  wPushButton_enumUp,
  wPushButton_enumOn1
};


enum {
  wPushButton_CHECKED_bit1 = 4,
  wPushButton_CHECKED_bit2 = wPushButton_CHECKED_bit1 << 1
  #define wPushButton_CHECKED_bits (wPushButton_CHECKED_bit1 | wPushButton_CHECKED_bit2)
,
  wPushButton_AUTOSIZE_bit = wPushButton_CHECKED_bit2 << 1,
  wPushButton_ROUNDRECT_bit = wPushButton_AUTOSIZE_bit << 1,
  wPushButton_HORIZONTAL_bit = wPushButton_ROUNDRECT_bit << 1
};


enum {
  id_clsFTP = 1
};


enum {
  clsFTP_stateError = -1,
  clsFTP_stateClosed,
  clsFTP_stateOpen,
  clsFTP_stateDisconnected = clsFTP_stateOpen,
  clsFTP_stateConnecting,
  clsFTP_stateConnected,
  clsFTP_stateFindFirst
};


enum {
  id_ucCoolSB = 1
};


enum {
  lbAscending,
  lbDescending
};


enum {
  wComboBox_SCROLLBTN_BIT = 4,
  wComboBox_READONLY_BIT = wComboBox_SCROLLBTN_BIT << 1,
  wComboBox_AUTOSIZE_BIT = wComboBox_READONLY_BIT << 1
};


enum clsShellPipe_RESULTS {
  clsShellPipe_SUCCESS = 0,
  clsShellPipe_CREATEPIPEFAILED,
  clsShellPipe_CREATEPROCFAILED
};


enum {
  id_clsBatch = 1
};


enum {
  clsBatch_opBATCH = 1,
  clsBatch_opBREAK,
  clsBatch_opCALC,
  clsBatch_opCD,
  clsBatch_opCHDIR = clsBatch_opCD,
  clsBatch_opCHDRV,
  clsBatch_opCLOSE,
  clsBatch_opCLS,
  clsBatch_opCOPY,
  clsBatch_opDEL,
  clsBatch_opERASE = clsBatch_opDEL,
  clsBatch_opDIR,
  clsBatch_opECHO,
  clsBatch_opFOR,
  clsBatch_opMD,
  clsBatch_opMKDIR = clsBatch_opMD,
  clsBatch_opPAUSE,
  clsBatch_opPOPDIR,
  clsBatch_opPUSHDIR,
  clsBatch_opPOPSET,
  clsBatch_opPUSHSET,
  clsBatch_opPROMPT,
  clsBatch_opREN,
  clsBatch_opRENAME = clsBatch_opREN,
  clsBatch_opMOVE = clsBatch_opREN,
  clsBatch_opRD,
  clsBatch_opRMDIR = clsBatch_opRD,
  clsBatch_opRUN,
  clsBatch_opSET,
  clsBatch_opSTART,
  clsBatch_opTYPE
};


enum {
  wConsole_SCI_BIT_ = 8,
  wConsole_TEXT_BIT_ = wConsole_SCI_BIT_ << 1
};








enum {
  wInet_stateError = -1,
  wInet_stateClosed,
  wInet_stateOpen,
  wInet_stateDisconnected = wInet_stateOpen,
  wInet_stateConnecting,
  wInet_stateConnected,
  wInet_stateFindFirst,
  wInet_stateSendRequest,
  wInet_stateComplete,
  wInet_stateClosing,
  wInet_stateGet
};


enum {
  lvwAscending,
  lvwDescending
};


enum {
  modMediaType_PLAYLIST = -1,
  modMediaType_NONE,
  modMediaType_BMP,
  modMediaType_JPG,
  modMediaType_PNG,
  modMediaType_MIDI,
  modMediaType_CDA,
  modMediaType_WAV,
  modMediaType_AUDIO,
  modMediaType_AUDIO2,
  modMediaType_VIDEODISC,
  modMediaType_AVI,
  modMediaType_VIDEO,
  modMediaType_VIDEO2,
  modMediaType_SWF,
  modMediaType_GIF
};


enum {
  wSCIBox_NULL = SCLEX_NULL,
  wSCIBox_ASM = SCLEX_ASM,
  wSCIBox_BASIC,
  wSCIBox_BATCH = SCLEX_BATCH,
  wSCIBox_CPP = SCLEX_CPP,
  wSCIBox_PASCAL = SCLEX_PASCAL,
  wSCIBox_VB = SCLEX_VB,
  wSCIBox_AUTOMATIC = SCLEX_AUTOMATIC,
  wSCIBox_FoldMarkerArrow = 0,
  wSCIBox_FoldMarkerBox,
  wSCIBox_FoldMarkerCircle,
  wSCIBox_FoldMarkerPlusMinus
};


enum {
  modSocket_sckTCPProtocol,
  modSocket_sckUDPProtocol
};


enum {
  modSocket_INVALID_HANDLE = (SOCKET_ERROR-1),
  modSocket_ERROR = modSocket_INVALID_HANDLE - 1
};


enum {
  wSocket_sckError = -1,
  wSocket_sckClosed,
  wSocket_sckOpen,
  wSocket_sckListening,
  wSocket_sckConnectionPending,
  wSocket_sckResolvingHost,
  wSocket_sckHostResolved,
  wSocket_sckConnecting,
  wSocket_sckAccepted,
  wSocket_sckConnected,
  wSocket_sckClosing,
  wSocket_sckTCPProtocol = modSocket_sckTCPProtocol,
  wSocket_sckUDPProtocol = modSocket_sckUDPProtocol,
  wSocket_sckINETFamily = AF_INET,
  wSocket_sckINET6Family = AF_INET6
};



/*((((((((((((((  Global Types and Unions  ))))))))))))))*/


typedef struct cb_s_clsSharedMemory_ {
  HANDLE hMapFile;
  LPVOID pBuf;
  cb_Integer iBufSize;
  cb_Integer UserData;
  LPVOID clsParent;
  cb_Integer flag1_;
} clsSharedMemory, *PclsSharedMemory;

typedef void*  modAVI_HAVI;

typedef struct cb_s_modAVI2BMPType_ {
  const void* fName;
  modAVI_HAVI hAVI;
  PGETFRAME pObj;
  cb_Integer iFirst;
  cb_Integer iPos;
  cb_Integer iLen;
  cb_UInteger Interval;
  cb_Integer iTime;
} modAVI2BMPType, *PmodAVI2BMPType;


typedef struct cb_s_clsANI_bmp__ {
  cb_Integer left;
  cb_Integer top;
  cb_Integer width;
  cb_Integer height;
  cb_UInteger delay;
  cb_Integer disposal;
  COLORREF transcolor;
  COLORREF transfillcolor;
} clsANI_bmp_, *PclsANI_bmp_;


typedef struct cb_s_clsANI_ {
  HWND hWnd;
  wchar_t sFile[MAX_FILE_NAME];
  wchar_t sTmpDir[MAX_FILE_NAME];
  struct cb_s_modAVI2BMPType_ buf;
  HBITMAP hBmp;
  HBITMAP hBmpPrev;
  struct cb_s_clsANI_bmp__* bmpBuf_;
  cb_Integer UBoundbmpBuf_;
  void* ptr1;
  cb_Integer iEngine_;
  cb_Integer BmpMax_;
  cb_Integer BmpNdx_;
  cb_Integer bmpWidth_;
  cb_Integer bmpHeight_;
  cb_Integer wIterations_;
  COLORREF TransColor;
  COLORREF BackColor1;
  COLORREF BackColor2;
  COLORREF bmpBackColor_;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} clsANI, *PclsANI;


typedef struct cb_s_wButton_ {
  HWND hWnd;
  RECT m_Rect;
  cb_Integer bEvent;
  cb_PString sChecked;
  cb_PString sDisabled;
  cb_PString sDown;
  cb_PString sOn1;
  cb_PString sOn2;
  cb_PString sUp;
  cb_Integer iChecked;
  cb_Integer iDisabled;
  cb_Integer iDown;
  cb_Integer iOn1;
  cb_Integer iOn2;
  cb_Integer iUp;
  HBITMAP hBmpChecked;
  HBITMAP hBmpDisabled;
  HBITMAP hBmpDown;
  HBITMAP hBmpOn1;
  HBITMAP hBmpOn2;
  HBITMAP hBmpUp;
  HBITMAP hBmpChecked_;
  HBITMAP hBmpDisabled_;
  HBITMAP hBmpDown_;
  HBITMAP hBmpOn1_;
  HBITMAP hBmpOn2_;
  HBITMAP hBmpUp_;
  HBITMAP lastBmp_;
  cb_Integer lastOffsetOf_;
  COLORREF cColor1;
  COLORREF cColor2;
  COLORREF cColor3;
  COLORREF cColor4;
  COLORREF cColor5;
  COLORREF cColor6;
  COLORREF cColor7;
  COLORREF cColor8;
  COLORREF cColor9;
  COLORREF cColor10;
  COLORREF cColor11;
  COLORREF cColor12;
  COLORREF cColor13;
  COLORREF cColor14;
  COLORREF cColor15;
  COLORREF cColorChecked;
  COLORREF cColorDisabled;
  COLORREF cColorDown;
  COLORREF cColorOn1;
  COLORREF cColorOn2;
  COLORREF cColorUp;
  COLORREF cColorCheckedBorder;
  COLORREF cColorDisabledBorder;
  COLORREF cColorDownBorder;
  COLORREF cColorOn1Border;
  COLORREF cColorOn2Border;
  COLORREF cColorUpBorder;
  HRGN hRndRctRgn_;
  HFONT hFont;
  HCURSOR hCursor;
  cb_PString sCaption;
  cb_Integer Value;
  cb_Integer m_offsetLeft_;
  cb_Integer m_offsetTop_;
  cb_Integer m_Width;
  cb_Integer m_Height;
  cb_Integer Timer1_;
  cb_UInteger lastT_;
  cb_UInteger DblClk_;
  cb_UInteger PreRepeat_;
  cb_Integer ClickCnt_;
  cb_Integer ClickInterval;
  double radW;
  double radH;
  cb_Integer flag1_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  void (cb_CDECL *Click)(struct cb_s_wButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *MClick)(struct cb_s_wButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *KeyDown)(struct cb_s_wButton_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *KeyUp)(struct cb_s_wButton_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *KeyPress)(struct cb_s_wButton_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *GotFocus)(struct cb_s_wButton_*,HWND);
  cb_Boolean (cb_CDECL *LostFocus)(struct cb_s_wButton_*,HWND);
  void (cb_CDECL *MouseDown)(struct cb_s_wButton_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseEnter)(struct cb_s_wButton_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseLeave)(struct cb_s_wButton_*);
  void (cb_CDECL *MouseMove)(struct cb_s_wButton_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wButton_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Paint)(struct cb_s_wButton_*,HWND);
  void (cb_CDECL *Painting)(struct cb_s_wButton_*,HDC,cb_Integer);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wButton_*,HWND,cb_UInteger,WPARAM,LPARAM);
  void (cb_CDECL *Resize)(struct cb_s_wButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wButton_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wButton_*);
  void (cb_CDECL *Terminate)(struct cb_s_wButton_*);
} wButton, *PwButton;


typedef struct cb_s_wAnimation_
  cb_ExtendsStruct(clsANI)
  HWND hWndPanel;
  HWND hToolTip;
  HCURSOR hCursor;
  struct cb_s_wButton_ btnPlay;
  struct cb_s_wButton_ btnStop;
  struct cb_s_wButton_ btnRepeat;
  float sngRate;
  cb_Integer width_;
  cb_Integer height_;
  cb_Integer BmpIndex_;
  cb_UInteger TimerID;
  cb_Integer TimerInterval;
  cb_Integer GIFInterval_;
  cb_Integer iDirection_;
  cb_Integer iIterations_;
  void* ctlParent;
  cb_Boolean (cb_CDECL *OnPlay)(struct cb_s_wAnimation_*,cb_Boolean);
  cb_Boolean (cb_CDECL *OnPause)(struct cb_s_wAnimation_*);
  cb_Boolean (cb_CDECL *OnStop)(struct cb_s_wAnimation_*);
  cb_Boolean (cb_CDECL *OnRepeat)(struct cb_s_wAnimation_*);
  void (cb_CDECL *MouseDown)(struct cb_s_wAnimation_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wAnimation_*,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *OnStateChange)(struct cb_s_wAnimation_*,cb_Integer);
  void (cb_CDECL *DropFiles)(struct cb_s_wAnimation_*,const cb_StringW,cb_Integer);
  void (cb_CDECL *Resize)(struct cb_s_wAnimation_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wAnimation_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wAnimation_*);
  void (cb_CDECL *Terminate)(struct cb_s_wAnimation_*);
  HBITMAP (cb_CDECL *OnGetBMP)(struct cb_s_wAnimation_*,cb_Integer*);
} wAnimation, *PwAnimation;


typedef struct cb_s_wPushButton_ {
  HWND hWnd;
  RECT m_Rect;
  cb_Integer bEvent;
  cb_PString sDisabled;
  cb_PString sDown;
  cb_PString sOn1;
  cb_PString sUp;
  cb_Integer iDisabled;
  cb_Integer iDown;
  cb_Integer iOn1;
  cb_Integer iUp;
  HBITMAP hBmpDisabled;
  HBITMAP hBmpDown;
  HBITMAP hBmpOn1;
  HBITMAP hBmpUp;
  HBITMAP hBmpDisabled_;
  HBITMAP hBmpDown_;
  HBITMAP hBmpOn1_;
  HBITMAP hBmpUp_;
  HBITMAP lastBmp_;
  cb_Integer lastOffsetOf_;
  COLORREF cColor1;
  COLORREF cColor2;
  COLORREF cColor3;
  COLORREF cColor4;
  COLORREF cColor5;
  COLORREF cColor6;
  COLORREF cColor7;
  COLORREF cColor8;
  COLORREF cColor9;
  COLORREF cColor10;
  COLORREF cColor11;
  COLORREF cColor12;
  COLORREF cColor13;
  COLORREF cColor14;
  COLORREF cColor15;
  COLORREF cColorDisabled;
  COLORREF cColorDown;
  COLORREF cColorOn1;
  COLORREF cColorUp;
  COLORREF cColorDisabledBorder;
  COLORREF cColorDownBorder;
  COLORREF cColorOn1Border;
  COLORREF cColorUpBorder;
  HRGN hRndRctRgn_;
  HFONT hFont;
  HCURSOR hCursor;
  cb_PString sCaption;
  cb_Integer m_offsetLeft_;
  cb_Integer m_offsetTop_;
  cb_Integer m_Width;
  cb_Integer m_Height;
  cb_Integer Timer1_;
  cb_UInteger lastT_;
  cb_UInteger DblClk_;
  cb_UInteger PreRepeat_;
  cb_Integer ClickCnt_;
  cb_Integer ClickInterval;
  double radW;
  double radH;
  cb_Integer flag1_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  void (cb_CDECL *Click)(struct cb_s_wPushButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wPushButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *MClick)(struct cb_s_wPushButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wPushButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *KeyDown)(struct cb_s_wPushButton_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *KeyUp)(struct cb_s_wPushButton_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *KeyPress)(struct cb_s_wPushButton_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *GotFocus)(struct cb_s_wPushButton_*,HWND);
  cb_Boolean (cb_CDECL *LostFocus)(struct cb_s_wPushButton_*,HWND);
  void (cb_CDECL *MouseDown)(struct cb_s_wPushButton_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseEnter)(struct cb_s_wPushButton_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseLeave)(struct cb_s_wPushButton_*);
  void (cb_CDECL *MouseMove)(struct cb_s_wPushButton_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wPushButton_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Paint)(struct cb_s_wPushButton_*,HWND);
  void (cb_CDECL *Painting)(struct cb_s_wPushButton_*,HDC,cb_Integer);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wPushButton_*,HWND,cb_UInteger,WPARAM,LPARAM);
  void (cb_CDECL *Resize)(struct cb_s_wPushButton_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wPushButton_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wPushButton_*);
  void (cb_CDECL *Terminate)(struct cb_s_wPushButton_*);
} wPushButton, *PwPushButton;


typedef struct cb_s_wSlider_ {
  HWND hWnd;
  HWND hWndParent;
  HWND hWndPic;
  HCURSOR hCursor;
  struct cb_s_wPushButton_ btnSlider;
  cb_Integer bDragging_;
  double Value;
  double sngValue_;
  double sngInterval;
  double sngMin;
  double sngMax;
  COLORREF BackColor;
  COLORREF BackColor_;
  HBRUSH hBrush;
  HBITMAP hBmp;
  cb_Integer btnWidth;
  cb_Integer btnHeight;
  cb_Integer BtnW;
  cb_Integer BtnH;
  cb_Integer btnOffset;
  cb_Integer m_Width;
  cb_Integer m_Height;
  POINT ptCur;
  RECT rcBtn;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  void (cb_CDECL *Click)(struct cb_s_wSlider_*,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wSlider_*,cb_Integer);
  cb_Integer (cb_CDECL *MouseDown)(struct cb_s_wSlider_*,double,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wSlider_*,double,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wSlider_*,double,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Change)(struct cb_s_wSlider_*,double,double,double,double,double);
  void (cb_CDECL *Resize)(struct cb_s_wSlider_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wSlider_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wSlider_*);
  void (cb_CDECL *Terminate)(struct cb_s_wSlider_*);
} wSlider, *PwSlider;


typedef struct cb_s_wScrollBar_ {
  struct cb_s_wSlider_ wSld1;
  struct cb_s_wPushButton_ wBtn1;
  struct cb_s_wPushButton_ wBtn2;
  HWND hWnd;
  HWND hWndParent;
  HWND hWndPic;
  HCURSOR hCursor;
  cb_Integer bDragging_;
  double Value;
  double sngValue_;
  double sngInterval;
  double sngMin;
  double sngMax;
  COLORREF BackColor;
  COLORREF BackColor_;
  HBRUSH hBrush;
  cb_Integer btnSliderWidth;
  cb_Integer btnSliderHeight;
  cb_Integer btnWidth;
  cb_Integer btnHeight;
  cb_Integer m_Width;
  cb_Integer m_WidthX;
  cb_Integer m_Height;
  cb_Integer m_HeightX;
  cb_Integer W_;
  cb_Integer H_;
  POINT ptCur;
  RECT rcBtn;
  struct cb_s_wScrollBar_* Friend_;
  WNDPROC wndproc_;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  void (cb_CDECL *Click)(struct cb_s_wScrollBar_*,cb_Integer,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wScrollBar_*,cb_Integer,cb_Integer);
  cb_Integer (cb_CDECL *MouseDown)(struct cb_s_wScrollBar_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wScrollBar_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wScrollBar_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Change)(struct cb_s_wScrollBar_*,double,double,double,double,double);
  void (cb_CDECL *Resize)(struct cb_s_wScrollBar_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wScrollBar_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wScrollBar_*);
  void (cb_CDECL *Terminate)(struct cb_s_wScrollBar_*);
} wScrollBar, *PwScrollBar;


typedef struct cb_s_wBox_ {
  HWND hWnd;
  HWND hWndView;
  HWND hWndParent;
  struct cb_s_wScrollBar_ wScrlH;
  struct cb_s_wScrollBar_ wScrlV;
  WNDPROC wndproc_;
  cb_Integer m_Width;
  cb_Integer m_Height;
  cb_Integer m_LeftView;
  cb_Integer m_TopView;
  cb_Integer m_WidthView;
  cb_Integer m_HeightView;
  COLORREF backClr1;
  COLORREF backClr2;
  HCURSOR hCursor;
  HRGN hRgn;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  cb_Boolean bAutosize;
  void (cb_CDECL *Click)(struct cb_s_wBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *MClick)(struct cb_s_wBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *KeyDown)(struct cb_s_wBox_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *KeyUp)(struct cb_s_wBox_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *KeyPress)(struct cb_s_wBox_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *GotFocus)(struct cb_s_wBox_*);
  void (cb_CDECL *LostFocus)(struct cb_s_wBox_*);
  void (cb_CDECL *MouseDown)(struct cb_s_wBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseEnter)(struct cb_s_wBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseLeave)(struct cb_s_wBox_*);
  void (cb_CDECL *MouseMove)(struct cb_s_wBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *DropFiles)(struct cb_s_wBox_*,const cb_String,cb_Integer);
  void (cb_CDECL *Paint)(struct cb_s_wBox_*,HWND);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wBox_*,HWND,cb_UInteger,WPARAM,LPARAM);
  cb_Integer (cb_CDECL *EventsView)(struct cb_s_wBox_*,HWND,cb_UInteger,WPARAM,LPARAM);
  cb_Boolean (*HScroll)(struct cb_s_wBox_*,float,float);
  cb_Boolean (*VScroll)(struct cb_s_wBox_*,float,float);
  void (cb_CDECL *Resize)(struct cb_s_wBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wBox_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wBox_*);
  void (cb_CDECL *Terminate)(struct cb_s_wBox_*);
} wBox, *PwBox;

#ifndef DriveComboBox_Type_Def
typedef struct cb_s_DriveComboBox_Type_ {
#define DriveComboBox_Type_Def
  HIMAGELIST hImgList;
  cb_Integer nBitmapYOff;
} DriveComboBox_Type, *PDriveComboBox_Type;

#endif

typedef struct cb_s_clsFTP_ {
  char m_sProxy[0x0800];
  char m_sServer[0x0800];
  char m_sUserName[0x0400];
  char m_sPassword[0x0400];
  char m_sPath[MAX_FILE_NAME];
  WIN32_FIND_DATA m_FindData;
  cb_PString m_ptrUserName;
  cb_PString m_ptrPassword;
  cb_UInteger m_iPort;
  HINTERNET m_hInternet;
  HINTERNET m_hConnect;
  HINTERNET m_hFindFirst;
  HINTERNET m_hFindNext;
  cb_Integer m_State;
  void (cb_CDECL *StateChanged)(struct cb_s_clsFTP_*,cb_Integer,cb_Integer);
  void (cb_CDECL *OnComplete)(struct cb_s_clsFTP_*);
  void (cb_CDECL *OnConnection)(struct cb_s_clsFTP_*);
  void (cb_CDECL *OnDisconnect)(struct cb_s_clsFTP_*);
  void (cb_CDECL *OnError)(struct cb_s_clsFTP_*,cb_Integer,const cb_String,const cb_String);
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} clsFTP, *PclsFTP;


typedef struct cb_s_watchDir_ {
  HANDLE hndl_;
  HANDLE h_;
  char sPath[MAX_FILE_NAME];
  char cBuffer[(sizeof(FILE_NOTIFY_INFORMATION) + (MAX_FILE_NAME<<1))];
  HANDLE hThread_;
  unsigned ThreadID_;
  HWND hWnd;
  cb_UInteger uMsg;
  cb_Integer flag1_;
  DWORD_PTR flags_;
  cb_Boolean bSubFolder;
} watchDir, *PwatchDir;


typedef struct cb_s_wScrollBtn_ {
  HWND hWnd;
  HCURSOR hCursor;
  struct cb_s_wPushButton_ wBtn1;
  struct cb_s_wPushButton_ wBtn2;
  COLORREF BackColor;
  COLORREF BackColor_;
  HBRUSH hBrush;
  cb_Integer m_Width;
  cb_Integer m_Height;
  POINT ptCur;
  RECT rcBtn;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  void (cb_CDECL *Click)(struct cb_s_wScrollBtn_*,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wScrollBtn_*,cb_Integer);
  void (cb_CDECL *MClick)(struct cb_s_wScrollBtn_*,cb_Integer);
  void (cb_CDECL *MouseDown)(struct cb_s_wScrollBtn_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wScrollBtn_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wScrollBtn_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Resize)(struct cb_s_wScrollBtn_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wScrollBtn_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wScrollBtn_*);
  void (cb_CDECL *Terminate)(struct cb_s_wScrollBtn_*);
} wScrollBtn, *PwScrollBtn;


typedef struct cb_s_ucCoolSB_
  cb_ExtendsStruct(CoolSB_SCROLLWND)
  HWND hWnd;
  void* UserData;
  void* clsMain;
  void* clsParent;
  HWND hWndParent;
  cb_Integer flag1_;
} ucCoolSB, *PucCoolSB;


typedef struct cb_s_wListBoxCol_ {
  struct cb_s_wPushButton_ wPushBtn;
  COLORREF BackColor;
  COLORREF BackColor_;
  COLORREF ForeColor;
  cb_Integer iWidth;
  cb_Integer flag1;
} wListBoxCol, *PwListBoxCol;


typedef struct cb_s_wListBoxItem_ {
  cb_Integer imgIndex;
  COLORREF BackColor;
  COLORREF BackColor_;
  COLORREF ForeColor;
  cb_Integer UserData;
  cb_Integer flag1;
} wListBoxItem, *PwListBoxItem;


typedef struct cb_s_wListBox_ {
  HWND hWnd;
  struct cb_s_wScrollBar_ wScrlH;
  struct cb_s_wScrollBar_ wScrlV;
  struct cb_s_cb_cCollection_ Coll;
  struct cb_s_wListBoxCol_* ColsBuf;
  struct cb_s_wListBoxItem_* ItemsBuf;
  cb_UInteger ItemsCnt;
  HBITMAP* BMPsBuf;
  cb_UInteger BMPsCnt;
  cb_Integer SelectedItem;
  HCURSOR hCursor;
  cb_Integer SortKey;
  cb_Integer SortOrder;
  cb_Integer mLeft;
  cb_Integer mTop;
  cb_Integer mWidth;
  cb_Integer mHeight;
  cb_Integer mLeft_;
  cb_Integer mTop_;
  cb_Integer m_lstWidth_;
  cb_Integer m_lstHeight_;
  cb_Integer mLineWidth_;
  cb_Integer mVisibleItems_;
  cb_Integer ofsWidth;
  cb_Integer ofsHeight;
  HWND hWndLB;
  HWND hWndPanel;
  HWND hWndLabelEdit;
  cb_Integer ItemNdx_;
  cb_Integer lastNdx_;
  cb_Integer iFirstItem_;
  cb_Integer ColNdx_;
  cb_Integer iColCount;
  cb_Integer iColUsed;
  cb_Integer iFirst;
  cb_Integer InDrag_;
  cb_Integer iRedraw_;
  cb_Integer iPrevItem;
  cb_Integer iPrevCol;
  WNDPROC PrevProc;
  WNDPROC PrevProcLabelEdit;
  void* OldLabelEdit_;
  HFONT hFont_;
  HBRUSH hBrush1_;
  HBRUSH hBrush2_;
  HBRUSH hBrush3_;
  HBRUSH hBrush4_;
  cb_Integer PosL_;
  cb_Integer lastBottom_;
  cb_Integer ColHdrHeight_;
  cb_Integer x_;
  cb_Integer flag1_;
  cb_Integer iStartLabelEditInterval_;
  COLORREF clrText;
  COLORREF clrSelected;
  COLORREF clrSelectedText;
  COLORREF clrGrayed;
  COLORREF clrGrayedText;
  COLORREF clrCheckBoxes;
  COLORREF clrBar;
  COLORREF clrBar_;
  COLORREF clrBody;
  COLORREF clrBody_;
  COLORREF clrGridLine1;
  COLORREF clrGridLine2;
  COLORREF clrSeparator;
  COLORREF GridBackColor;
  COLORREF GridForeColor;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  void (cb_CDECL *ItemChanged)(struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemClick)(struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemRClick)(struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemMClick)(struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemDblClick)(struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemStateChanged)(struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *SelectionChanged)(struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyDown)(struct cb_s_wListBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyUp)(struct cb_s_wListBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyPress)(struct cb_s_wListBox_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *MouseDown)(struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *GotFocus)(struct cb_s_wListBox_*,HWND);
  void (cb_CDECL *LostFocus)(struct cb_s_wListBox_*,HWND);
  void (cb_CDECL *ColumnClick)(struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *BeforeLabelEdit)(struct cb_s_wListBox_*,cb_Integer*,cb_Integer,cb_Integer*,void**);
  void (cb_CDECL *AfterLabelEdit)(struct cb_s_wListBox_*,void**,const void*,cb_Integer*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *BeginDrag)(struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *EndDrag)(struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *Dragging)(struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *DropFiles)(struct cb_s_wListBox_*,const cb_String,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *BeforeColumnResize)(struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *ColumnResize)(struct cb_s_wListBox_*,cb_Integer,cb_Integer*);
  cb_Boolean (cb_CDECL *ColumnResizing)(struct cb_s_wListBox_*,cb_Integer,short*);
  void (cb_CDECL *DeleteItem)(struct cb_s_wListBox_*,cb_Integer);
  void (cb_CDECL *InsertItem)(struct cb_s_wListBox_*,cb_Integer);
  cb_Integer (cb_CDECL *DrawItem)(struct cb_s_wListBox_*,cb_Integer,cb_Integer,RECT*);
  void (cb_CDECL *BeforeDrawItems)(struct cb_s_wListBox_*);
  void (cb_CDECL *AfterDrawItems)(struct cb_s_wListBox_*);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wListBox_*,HWND,cb_UInteger,WPARAM,LPARAM);
  void (cb_CDECL *Resize)(struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Activate)(struct cb_s_wListBox_*,HWND,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wListBox_*,HWND,cb_Integer);
  cb_Boolean (cb_CDECL *Close)(struct cb_s_wListBox_*);
  void (cb_CDECL *Destroy)(struct cb_s_wListBox_*);
  void (cb_CDECL *Terminate)(struct cb_s_wListBox_*);
} wListBox, *PwListBox;


typedef struct cb_s_wTextBox_ {
  HWND hWnd;
  HWND hWndEDIT;
  WNDPROC WndProc_;
  cb_LOGFONT lFont;
  struct cb_s_ucCoolSB_ SB1;
  cb_Integer iRedraw_;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  COLORREF BackColor1;
  COLORREF BackColor2;
  COLORREF ForeColor;
  HBRUSH hBrush_;
  cb_Integer flag1_;
  void (cb_CDECL *Click)(struct cb_s_wTextBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wTextBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *MClick)(struct cb_s_wTextBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wTextBox_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyDown)(struct cb_s_wTextBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyUp)(struct cb_s_wTextBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyPress)(struct cb_s_wTextBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *GotFocus)(struct cb_s_wTextBox_*,HWND);
  cb_Boolean (cb_CDECL *LostFocus)(struct cb_s_wTextBox_*,HWND);
  void (cb_CDECL *MouseDown)(struct cb_s_wTextBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseEnter)(struct cb_s_wTextBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseLeave)(struct cb_s_wTextBox_*);
  void (cb_CDECL *MouseMove)(struct cb_s_wTextBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wTextBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *DropFiles)(struct cb_s_wTextBox_*,const cb_String,cb_Integer);
  void (cb_CDECL *Change)(struct cb_s_wTextBox_*);
  void (cb_CDECL *UpdateUI)(struct cb_s_wTextBox_*);
  void (cb_CDECL *Paint)(struct cb_s_wTextBox_*,HWND);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wTextBox_*,HWND,cb_UInteger,WPARAM,LPARAM);
  void (cb_CDECL *Resize)(struct cb_s_wTextBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Activate)(struct cb_s_wTextBox_*,HWND,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wTextBox_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wTextBox_*);
  void (cb_CDECL *Terminate)(struct cb_s_wTextBox_*);
} wTextBox, *PwTextBox;


typedef struct cb_s_wComboBox_ {
  HWND hWnd;
  HWND hWndParent;
  struct cb_s_wScrollBtn_ wScrlBtn1;
  struct cb_s_wListBox_ wListBox1;
  struct cb_s_wTextBox_ wTextBox1;
  cb_Integer ItemNdx_;
  cb_Integer iClk_;
  HCURSOR hCursor;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  void (cb_CDECL *Click)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *MClick)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyDown)(struct cb_s_wComboBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyUp)(struct cb_s_wComboBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyPress)(struct cb_s_wComboBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *GotFocus)(struct cb_s_wComboBox_*,HWND);
  cb_Boolean (cb_CDECL *LostFocus)(struct cb_s_wComboBox_*,HWND);
  void (cb_CDECL *MouseDown)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseEnter)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseLeave)(struct cb_s_wComboBox_*);
  void (cb_CDECL *MouseMove)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemChanged)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer,const void*);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wComboBox_*,HWND,cb_UInteger,WPARAM,LPARAM);
  void (cb_CDECL *Resize)(struct cb_s_wComboBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Activate)(struct cb_s_wComboBox_*,HWND,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wComboBox_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wComboBox_*);
  void (cb_CDECL *Terminate)(struct cb_s_wComboBox_*);
} wComboBox, *PwComboBox;


typedef struct cb_s_wTreeView_ {
  HTREEITEM SelectedItem;
  cb_Integer mLeft;
  cb_Integer mTop;
  cb_Integer mWidth;
  cb_Integer mHeight;
  HWND hWnd;
  HWND hWndTVW;
  struct cb_s_ucCoolSB_ SB1;
  HWND hWndLabelEdit;
  HTREEITEM ItemNdx;
  cb_Integer bItemActive;
  HTREEITEM InDrag;
  cb_Boolean bAutoLabelEdit;
  HTREEITEM iPrevItem;
  WNDPROC PrevProc;
  WNDPROC PrevProcLabelEdit;
  cb_PString OldLabelEdit_;
  cb_Integer flag1_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  void (cb_CDECL *ItemChanged)(struct cb_s_wTreeView_*,HTREEITEM,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemClick)(struct cb_s_wTreeView_*,HTREEITEM);
  void (cb_CDECL *ItemRClick)(struct cb_s_wTreeView_*,HTREEITEM);
  void (cb_CDECL *ItemDblClick)(struct cb_s_wTreeView_*,HTREEITEM);
  void (cb_CDECL *ItemLostFocus)(struct cb_s_wTreeView_*,HTREEITEM,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyDown)(struct cb_s_wTreeView_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyUp)(struct cb_s_wTreeView_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyPress)(struct cb_s_wTreeView_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *MouseDown)(struct cb_s_wTreeView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wTreeView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wTreeView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *BeforeLabelEdit)(struct cb_s_wTreeView_*,cb_Integer*,HTREEITEM,cb_PString*);
  void (cb_CDECL *AfterLabelEdit)(struct cb_s_wTreeView_*,cb_PString*,const cb_String,cb_Integer*,HTREEITEM);
  void (cb_CDECL *BeginDrag)(struct cb_s_wTreeView_*,HTREEITEM);
  void (cb_CDECL *EndDrag)(struct cb_s_wTreeView_*,HTREEITEM,HTREEITEM);
  cb_Boolean (cb_CDECL *DropFiles)(struct cb_s_wTreeView_*,cb_String,HTREEITEM,cb_Integer,cb_Integer);
  void (cb_CDECL *Dragging)(struct cb_s_wTreeView_*,HTREEITEM,HTREEITEM,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *DeleteItem)(struct cb_s_wTreeView_*,HTREEITEM);
  void (cb_CDECL *InsertItem)(struct cb_s_wTreeView_*,HTREEITEM);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wTreeView_*,HWND,cb_UInteger,WPARAM,LPARAM);
  void (cb_CDECL *Resize)(struct cb_s_wTreeView_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wTreeView_*);
  void (cb_CDECL *Terminate)(struct cb_s_wTreeView_*);
} wTreeView, *PwTreeView;


typedef struct cb_s_wCommander_ {
  struct cb_s_wListBox_ Folder_List;
  struct cb_s_wListBox_ File_List;
  struct cb_s_wTreeView_ Tree1;
  struct cb_s_wComboBox_ wcmbDrives;
  struct cb_s_clsFTP_ cFTP_;
  struct cb_s_watchDir_ watch1;
  char sPathName[MAX_FILE_NAME];
  char sTemp[MAX_FILE_NAME];
  char sFileName[MAX_FILE_NAME];
  char sMask[0x100];
  struct cb_s_DriveComboBox_Type_ DCB1_;
  HWND comboDrives;
  HWND hWnd;
  HWND hWndParent;
  HCURSOR hCursor;
  cb_Integer DrivesCnt_;
  cb_UInteger ThreadId_;
  void* OldLabelEdit_;
  cb_Integer bIcons;
  DWORD flags_;
  cb_Integer bSubFolder_;
  cb_Integer iSlash_;
  cb_Integer flag1_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  void (cb_CDECL *ItemClick)(struct cb_s_wCommander_*,const cb_String,struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemRClick)(struct cb_s_wCommander_*,const cb_String,struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemMClick)(struct cb_s_wCommander_*,const cb_String,struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *ItemDblClick)(struct cb_s_wCommander_*,const cb_String,struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyDown)(struct cb_s_wCommander_*,cb_Integer*,cb_Integer,struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyUp)(struct cb_s_wCommander_*,cb_Integer*,cb_Integer,struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyPress)(struct cb_s_wCommander_*,cb_Integer*,cb_Integer,struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseDown)(struct cb_s_wCommander_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,struct cb_s_wListBox_*,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wCommander_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,struct cb_s_wListBox_*,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wCommander_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,struct cb_s_wListBox_*,cb_Integer);
  void (cb_CDECL *GotFocus)(struct cb_s_wCommander_*,HWND);
  void (cb_CDECL *LostFocus)(struct cb_s_wCommander_*,HWND);
  cb_Integer (cb_CDECL *ColumnClick)(struct cb_s_wCommander_*,cb_Integer,struct cb_s_wListBox_*,cb_Integer);
  void (cb_CDECL *ItemChanged)(struct cb_s_wCommander_*,const cb_String,struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_Integer (cb_CDECL *DirChange)(struct cb_s_wCommander_*,cb_String,const cb_String,cb_Int64,struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *DriveChange)(struct cb_s_wCommander_*,cb_Integer,cb_Integer,const cb_String,HWND);
  cb_Boolean (cb_CDECL *Update)(struct cb_s_wCommander_*,const cb_String,const cb_String,cb_Integer);
  cb_Boolean (cb_CDECL *Scanning)(struct cb_s_wCommander_*,const cb_String,const cb_String);
  cb_Integer (cb_CDECL *BeforeLabelEdit)(struct cb_s_wCommander_*,struct cb_s_wListBox_*,cb_Integer,cb_Integer*,void**,cb_Integer);
  cb_Integer (cb_CDECL *AfterLabelEdit)(struct cb_s_wCommander_*,void**,const void*,struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *DropFiles)(struct cb_s_wCommander_*,const cb_String,struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_Integer (cb_CDECL *DriveKeyPress)(struct cb_s_wCommander_*,cb_Integer*,cb_Integer,HWND);
  void (cb_CDECL *Resize)(struct cb_s_wCommander_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Activate)(struct cb_s_wCommander_*,HWND,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wCommander_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wCommander_*);
  void (cb_CDECL *Terminate)(struct cb_s_wCommander_*);
  cb_Integer (cb_CDECL *BeforeDelete)(struct cb_s_wCommander_*,const void*,struct cb_s_wListBox_*,cb_Integer,cb_Integer);
  cb_Integer (cb_CDECL *BeforeRename)(struct cb_s_wCommander_*,void**,const void*,struct cb_s_wListBox_*,cb_Integer,cb_Integer,cb_Integer);
  cb_Integer (cb_CDECL *BeforeExec)(struct cb_s_wCommander_*,const void*,struct cb_s_wListBox_*,cb_Integer,cb_Integer);
} wCommander, *PwCommander;

typedef cb_Integer (cb_CDECL *clsSCIFunc)(void*,cb_Integer,cb_Integer,cb_Integer);

typedef struct cb_s_clsSCI_ {
  struct cb_s_ucCoolSB_ SB1;
  clsSCIFunc pFunc;
  void* hSci;
  HWND hWnd;
  cb_Integer flag1_;
} clsSCI, *PclsSCI;


typedef struct cb_s_clsShellPipe_ {
  HWND hWndProcess;
  HWND hWndTimer;
  cb_Integer LastResult;
  PROCESS_INFORMATION piProc;
  HANDLE hStdOutPipeRd;
  HANDLE hStdInPipeWr;
  HANDLE hStdIn_;
  HANDLE m_StdIn;
  HANDLE m_StdOut;
  cb_Boolean blnProcessActive;
  cb_Integer blnInPipeOpen;
  struct cb_s_cb_cString_ sbPipeRd;
  struct cb_s_cb_cString_ sbPipeWr;
  char* TmpPtr;
  cb_UInteger idTimer;
  void* clsParent;
  void (cb_CDECL *DataArrival)(struct cb_s_clsShellPipe_*,const cb_String,cb_Integer);
  cb_Boolean (cb_CDECL *Update)(struct cb_s_clsShellPipe_*);
  void (cb_CDECL *ProcessFinished)(struct cb_s_clsShellPipe_*,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_clsShellPipe_*);
  cb_Boolean flag1_;
} clsShellPipe, *PclsShellPipe;


typedef struct cb_s_clsBatch_ {
  char m_DirStack[clsBatch_MAX_DIRSTACK_];
  cb_Integer m_DirStackP;
  char m_SetStack[clsBatch_MAX_SETSTACK_];
  cb_Integer m_SetStackP;
  char m_sForPath_[5*0x400];
  char m_sForPathBuf_[MAX_FILE_NAME];
  char m_sBuf_[MAX_FILE_NAME];
  char m_sForBasePath_[MAX_FILE_NAME];
  char m_sForFileName_[MAX_FILE_NAME];
  cb_FIND_DATA m_ForFindData_;
  cb_FIND_DATA* m_ForFindData[clsBatch_STACK_SIZE_];
  cb_Integer m_ForFindDataStack[clsBatch_STACK_SIZE_];
  char m_sForVar[clsBatch_STACK_SIZE_][clsBatch_VAR_SIZE_];
  char m_sForVar_[clsBatch_VAR_SIZE_];
  cb_PString m_sForFileName[clsBatch_STACK_SIZE_];
  cb_PString m_sForPathBuf[clsBatch_STACK_SIZE_];
  cb_PString m_sForPathPtr;
  cb_PString m_sFor[clsBatch_STACK_SIZE_];
  cb_PString m_sForPtr;
  short m_ForFlag[clsBatch_STACK_SIZE_];
  HANDLE m_hThread;
  HANDLE m_StdIn;
  HANDLE m_StdOut;
  cb_PString m_dst;
  cb_PString m_Tmp;
  cb_PString m_Ptrs[clsBatch_NESTED_];
  cb_PString m_Args[clsBatch_NESTED_];
  cb_Integer m_Stack[clsBatch_STACK_SIZE_];
  char m_Shifts[clsBatch_MAX_ARGS_];
  cb_Integer m_Max;
  cb_Integer m_inBrackets;
  cb_Integer m_inBrackets_;
  cb_Integer m_ForFindDataIndex;
  cb_Integer m_ForFindDataIndex_;
  cb_Integer m_ReturnCode_;
  cb_Integer m_Flag_;
  cb_File* m_inFP;
  cb_File* m_outFP;
  struct cb_s_clsShellPipe_ m_ShellPipe;
  cb_PString m_sPath;
  cb_Integer m_ErrorLevel;
  cb_Integer m_Interval;
  cb_Integer m_Result_;
  cb_Integer m_Tmp_;
  void (cb_CDECL *DataArrival)(struct cb_s_clsBatch_*,const cb_String,cb_Integer);
  void (cb_CDECL *TextOutput)(struct cb_s_clsBatch_*,const cb_String);
  void (cb_CDECL *SetPrompt)(struct cb_s_clsBatch_*,const cb_String);
  void (cb_CDECL *onError)(struct cb_s_clsBatch_*,const cb_String);
  void (cb_CDECL *onComplete)(struct cb_s_clsBatch_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *BeforeExec)(struct cb_s_clsBatch_*,const cb_String,const cb_String,cb_Integer);
  void (cb_CDECL *AfterExec)(struct cb_s_clsBatch_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *onPause)(struct cb_s_clsBatch_*,const cb_String);
  cb_Boolean (cb_CDECL *onIdle)(struct cb_s_clsBatch_*,const cb_String);
  void (cb_CDECL *onProcessExit)(struct cb_s_clsBatch_*,cb_Integer);
  void (cb_CDECL *onExit)(struct cb_s_clsBatch_*,cb_Integer);
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} clsBatch, *PclsBatch;


typedef struct cb_s_wConsole_ {
  HWND hWnd;
  char sCmd[MAX_FILE_NAME];
  struct cb_s_clsShellPipe_ clsShellPipeBuf;
  struct cb_s_wTextBox_ wTextBox1;
  struct cb_s_wComboBox_ wComboBox1;
  struct cb_s_clsSCI_ clsSCI1;
  struct cb_s_clsBatch_ b1;
  cb_File* h1;
  cb_File* m_fIn;
  cb_File* m_fOut;
  HWND txtOut;
  HWND txtIn;
  HWND txtIn_hEdit;
  HWND lblStatus;
  cb_Integer TimerID;
  cb_Integer TimerInterval;
  HCURSOR hCursor;
  HMODULE hMdl;
  cb_Integer iEngine;
  WNDPROC wndproc_txtOut;
  WNDPROC wndproc_txtIn_hEdit;
  COLORREF txtInBC1;
  COLORREF txtInBC2;
  COLORREF txtInFC;
  COLORREF txtOutBC1;
  COLORREF txtOutBC2;
  COLORREF txtOutFC;
  cb_Boolean bKillChilds;
  cb_UInteger iCnt_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer flag1_;
  cb_Boolean (cb_CDECL *KeyDown)(struct cb_s_wConsole_*,cb_Integer*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyUp)(struct cb_s_wConsole_*,cb_Integer*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyPress)(struct cb_s_wConsole_*,cb_Integer*,cb_Integer,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wConsole_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseDown)(struct cb_s_wConsole_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wConsole_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wConsole_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *DataArrival)(struct cb_s_wConsole_*,const cb_String,cb_Integer);
  cb_Boolean (cb_CDECL *onIdle)(struct cb_s_wConsole_*,const cb_String);
  void (cb_CDECL *Error)(struct cb_s_wConsole_*,const cb_String);
  void (cb_CDECL *onComplete)(struct cb_s_wConsole_*,cb_Integer,cb_Integer);
  void (cb_CDECL *onExit)(struct cb_s_wConsole_*,cb_Integer);
  void (cb_CDECL *onFinish)(struct cb_s_wConsole_*);
  cb_Boolean (cb_CDECL *onPause)(struct cb_s_wConsole_*,const cb_String);
  cb_Boolean (cb_CDECL *ProcessFinished)(struct cb_s_wConsole_*,cb_Integer);
  void (cb_CDECL *DropFiles)(struct cb_s_wConsole_*,cb_String,cb_Integer);
  void (cb_CDECL *CaretMove)(struct cb_s_wConsole_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Resize)(struct cb_s_wConsole_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Activate)(struct cb_s_wConsole_*,HWND,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wConsole_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wConsole_*);
  void (cb_CDECL *Terminate)(struct cb_s_wConsole_*);
} wConsole, *PwConsole;


typedef struct cb_s_clsFormShadow_ {
  HWND hWndParent;
  HWND hWndW;
  HWND hWndH;
  WINDOWPOS wp;
  WNDPROC wndProc_;
  COLORREF m_Color;
  cb_Integer m_Depth;
  cb_Integer m_Right;
  cb_Integer m_Transparency;
  cb_Integer cx;
  cb_Integer cy;
  cb_Integer flag1_;
  cb_Boolean bIsLuna_;
  cb_Boolean bLastShow_;
  void (cb_CDECL *Terminate)(struct cb_s_clsFormShadow_*);
} clsFormShadow, *PclsFormShadow;


typedef struct cb_s_wPopupMenu_MNUITEM_ {
  void* Ptr1_;
  HMENU hMnu;
  HBITMAP hIml_;
  cb_Integer wID;
  DWORD dwItemData;
  cb_Integer Index;
  char txt[256];
  char acl[64];
  cb_Integer img;
  short int wdt;
  short int hgt;
  short int ntype;
} wPopupMenu_MNUITEM, *PwPopupMenu_MNUITEM;


typedef struct cb_s_wPopupMenu_ {
  HWND hWndParent;
  cb_Integer Array_[32];
  HMENU ArrayMenu_[32];
  HBRUSH ArrayBrush_[32];
  struct cb_s_wPopupMenu_* Friend_;
  WNDPROC wndproc_;
  struct cb_s_wPopupMenu_MNUITEM_* hMem_;
  HMENU hMnuPopup_;
  HFONT hMnuFont1_;
  HFONT hMnuFont2_;
  HBITMAP hIml_;
  HBITMAP hGrayIml_;
  HBITMAP hCheckedIml_;
  HBITMAP hGrayCheckedIml_;
  cb_Integer MnuFontHt_;
  cb_Boolean iMode_;
  cb_Boolean bRTL;
  cb_Integer iMax_;
  cb_Integer iCnt_;
  cb_Integer ShadowDepth;
  cb_Integer ShadowTransparency;
  COLORREF ShadowColor;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsModule;
  cb_Integer iTransparency;
  COLORREF clrText;
  COLORREF clrSelected;
  COLORREF clrSelectedText;
  COLORREF clrGrayed;
  COLORREF clrGrayedText;
  COLORREF clrCheckBoxes;
  COLORREF clrSeparator;
  COLORREF clrBar;
  COLORREF clrIconBar;
  COLORREF clrBody;
  cb_Integer iWidth_;
  cb_Integer iIconWidth_;
  cb_Integer StartPos_;
  cb_Integer flag1_;
  void (cb_CDECL *OnInitMenuPopup)(struct cb_s_wPopupMenu_*,HWND,HMENU,cb_Integer,cb_Integer);
  void (cb_CDECL *OnUnInitMenuPopup)(struct cb_s_wPopupMenu_*,HWND,HMENU,cb_Integer,cb_Integer);
  void (cb_CDECL *OnChange)(struct cb_s_wPopupMenu_*,HWND,HMENU,cb_Integer,cb_Integer);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wPopupMenu_*,HWND,cb_UInteger,cb_Integer,cb_Integer);
  void (cb_CDECL *Terminate)(struct cb_s_wPopupMenu_*);
} wPopupMenu, *PwPopupMenu;


#pragma pack(1)

typedef struct cb_s_wMenuBarPopup_ {
  void* Ptr1_;
  char* sCaption;
  HMENU hMnu;
  HBITMAP hIml_;
  cb_Integer wID;
  DWORD dwItemData;
  char txt[128];
  char acl[32];
  cb_Integer img;
  short wdt;
  short hgt;
  cb_Integer UserData;
  cb_Integer flags;
} wMenuBarPopup, *PwMenuBarPopup;

#pragma pack()

typedef struct cb_s_wMenuBar_ {
  HWND hWndParent;
  HMENU hMenu;
  struct cb_s_wMenuBarPopup_* Buf_;
  cb_Integer iUBound_;
  HBRUSH hBrush_;
  HFONT hFont_;
  HBITMAP hBmp_;
  HBITMAP hIml_;
  HBITMAP hGrayIml_;
  HBITMAP hCheckedIml_;
  HBITMAP hGrayCheckedIml_;
  cb_Integer FontHt_;
  cb_Integer m_Width;
  cb_Integer m_Height;
  cb_Integer m_MenuLeft;
  cb_Integer m_MenuTop;
  cb_Integer m_MenuWidth;
  cb_Integer m_MenuHeight;
  cb_Integer m_Width_;
  cb_Integer iWidth_;
  cb_Integer StartPos_;
  COLORREF clrBar;
  COLORREF clrBody1;
  COLORREF clrBody2;
  COLORREF clrText;
  COLORREF clrSeparator;
  COLORREF clrSelected;
  cb_Integer bAutoHide;
  cb_Integer bPos_;
  cb_Integer MenuSpace;
  cb_Integer iFirst_;
  cb_Integer iLast_;
  cb_Integer iCnt_;
  cb_Integer iSelected_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsModule;
  cb_Integer mWidth;
  cb_Boolean bNoAutoSize;
  cb_Integer flag1_;
  WNDPROC wndproc_;
  void (cb_CDECL *OnInitMenuPopup)(struct cb_s_wMenuBar_*,HWND,HMENU,cb_Integer,cb_Integer);
  void (cb_CDECL *OnUnInitMenuPopup)(struct cb_s_wMenuBar_*,HWND,HMENU,cb_Integer,cb_Integer);
  void (cb_CDECL *OnChange)(struct cb_s_wMenuBar_*,HWND,HMENU,cb_Integer,cb_Integer);
  void (cb_CDECL *OnChangeX)(struct cb_s_wMenuBar_*,HWND,HMENU,cb_Integer,cb_Integer);
  void (cb_CDECL *Terminate)(struct cb_s_wMenuBar_*);
} wMenuBar, *PwMenuBar;


typedef struct cb_s_wForm_ {
  HWND hWnd;
  HWND hWndParent;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsModule;
  cb_Integer flag1_;
  WNDPROC OnEvents;
} wForm, *PwForm;

typedef cb_Integer (cb_CDECL *wCOMEventSink)(const void*,cb_UInteger,DISPPARAMS*);
#ifdef __cplusplus
class  wEventSink;
#else
typedef struct cb_s_wEventSink_ {
  IDispatch Dispatch[2];
  cb_UInteger m_cRefs;
  REFIID m_iid;
  wCOMEventSink m_Sub;
  DWORD m_dwCookie;
  const void* m_Ptr;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
} wEventSink, *PwEventSink;

#endif



typedef struct cb_s_wIE_ {
  char sURL[MAX_FILE_NAME];
  cb_comObject comIE;
#ifdef __cplusplus
  wEventSink* pEventSink;
#else
  wEventSink TEventSink;
#endif
  HWND hWnd;
  HWND hWndParent;
  HWND hIE;
  HCURSOR hCursor;
  cb_UInteger mInterval;
  cb_UInteger mTimer;
  cb_Integer bOpen_;
  cb_Boolean bStretch_;
  cb_Integer lVolume;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  cb_Boolean (cb_CDECL *OnStop)(struct cb_s_wIE_*);
  cb_Boolean (cb_CDECL *OnStateChange)(struct cb_s_wIE_*,cb_Integer);
  cb_Boolean (cb_CDECL *OnUpdate)(struct cb_s_wIE_*);
  void (cb_CDECL *DropFiles)(struct cb_s_wIE_*,const cb_String,cb_Integer);
  void (cb_CDECL *Resize)(struct cb_s_wIE_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wIE_*);
  void (cb_CDECL *Terminate)(struct cb_s_wIE_*);
} wIE, *PwIE;



#ifdef __cplusplus
class  cWebBrowser;
#else
typedef struct cb_s_wIExplorer_IOleClientSite_ {
  IOleClientSite b;
  void* c;
} wIExplorer_IOleClientSite, *PwIExplorer_IOleClientSite;


typedef struct cb_s_wIExplorer_IOleInPlaceFrame_ {
  IOleInPlaceFrame b;
  void* c;
} wIExplorer_IOleInPlaceFrame, *PwIExplorer_IOleInPlaceFrame;


typedef struct cb_s_wIExplorer_IOleInPlaceSite_ {
  IOleInPlaceSite b;
  void* c;
} wIExplorer_IOleInPlaceSite, *PwIExplorer_IOleInPlaceSite;


typedef struct cb_s_wIExplorer_IStorage_ {
  IStorage b;
  void* c;
} wIExplorer_IStorage, *PwIExplorer_IStorage;

#endif

#pragma pack(1)

typedef struct cb_s_wIExplorer_ {
  HWND hWnd;
  cb_Integer ClientSite_ref_cnt;
  cb_Integer Dispatch_ref_cnt;
  cb_Integer Storage_ref_cnt;
  cb_Integer InPlaceFrame_ref_cnt;
  cb_Integer InPlaceSite_ref_cnt;
#ifdef __cplusplus
  cWebBrowser* pBrowser;
  wEventSink* pEventSink;
#else
  IWebBrowser2* pBrowser;
  wEventSink TEventSink;
  IOleInPlaceActiveObject* ActiveObject;
  struct cb_s_wIExplorer_IOleClientSite_ ClientSite;
  struct cb_s_wIExplorer_IOleInPlaceFrame_ InPlaceFrame;
  struct cb_s_wIExplorer_IOleInPlaceSite_ InPlaceSite;
  struct cb_s_wIExplorer_IStorage_ Storage;
#endif
  char sDst[0x1000];
  HWND hWndParent;
  HCURSOR hCursor;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  void (cb_CDECL *DownloadBegin)(struct cb_s_wIExplorer_*);
  void (cb_CDECL *DownloadComplete)(struct cb_s_wIExplorer_*);
  void (cb_CDECL *TitleChange)(struct cb_s_wIExplorer_*,const cb_String);
  void (cb_CDECL *StatusTextChange)(struct cb_s_wIExplorer_*,const cb_String);
  void (cb_CDECL *ProgressChange)(struct cb_s_wIExplorer_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *BeforeNavigate2)(struct cb_s_wIExplorer_*,IDispatch*,const cb_String);
  void (cb_CDECL *NavigateComplete2)(struct cb_s_wIExplorer_*,IDispatch*,const cb_String);
  void (cb_CDECL *DocumentComplete)(struct cb_s_wIExplorer_*,IDispatch*,const cb_String);
  cb_Boolean (cb_CDECL *FileDownload)(struct cb_s_wIExplorer_*,cb_Boolean);
  cb_Boolean (cb_CDECL *NewWindow)(struct cb_s_wIExplorer_*,IDispatch*);
  cb_Boolean (cb_CDECL *WindowClosing)(struct cb_s_wIExplorer_*,cb_Boolean);
  void (cb_CDECL *Resize)(struct cb_s_wIExplorer_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wIExplorer_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wIExplorer_*);
  void (cb_CDECL *Terminate)(struct cb_s_wIExplorer_*);
} wIExplorer, *PwIExplorer;

#pragma pack()



typedef struct cb_s_wInet_ {
  BYTE Buf[0x10000];
  char sFile[MAX_FILE_NAME];
  WIN32_FIND_DATA FindData;
  INTERNET_BUFFERS buffersIn;
  cb_UInteger mTimer;
  cb_File* FileHandle;
  cb_Integer Ndx;
  BYTE* RecvBuf;
  cb_Integer RecvBufLen;
  BYTE* bBuf;
  BYTE* SendBuf;
  cb_Integer SendBufLen;
  cb_Integer RecvBufSize;
  cb_Integer SendBufSize;
  char RemoteHostIP[0x20];
  void* dst_;
  struct cb_s_clsFTP_ cFTP_;
  HINTERNET hHTTP;
  cb_Integer lLastError;
  cb_Integer mInterval;
  cb_Boolean blnRegistered;
  cb_Integer Opr;
  cb_Integer bSecure;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer flag1_;
  void (cb_CDECL *OnConnection)(struct cb_s_wInet_*);
  void (cb_CDECL *OnDisconnect)(struct cb_s_wInet_*);
  void (cb_CDECL *OnDataArrival)(struct cb_s_wInet_*,cb_Integer);
  void (cb_CDECL *OnFileArrival)(struct cb_s_wInet_*,const cb_String);
  void (cb_CDECL *OnError)(struct cb_s_wInet_*,cb_Integer,const cb_String,const cb_String);
  void (cb_CDECL *OnSendComplete)(struct cb_s_wInet_*);
  void (cb_CDECL *OnSendProgress)(struct cb_s_wInet_*,cb_Integer,cb_Integer);
  void (cb_CDECL *OnTimer)(struct cb_s_wInet_*);
  void (cb_CDECL *OnClose)(struct cb_s_wInet_*);
  void (cb_CDECL *OnComplete)(struct cb_s_wInet_*);
  void (cb_CDECL *StateChanged)(struct cb_s_wInet_*,cb_Integer,cb_Integer);
} wInet, *PwInet;


typedef struct cb_s_wListView_ {
  cb_Integer SelectedItem;
  HCURSOR hCursor;
  cb_Integer SortKey;
  cb_Integer SortOrder;
  cb_Boolean bSorted;
  cb_Integer mLeft;
  cb_Integer mTop;
  cb_Integer mWidth;
  cb_Integer mHeight;
  HWND hWnd;
  HWND hWndLVW;
  struct cb_s_ucCoolSB_ SB1;
  HWND hWndLabelEdit;
  HWND hWndCol;
  cb_Integer ItemNdx_;
  cb_Integer lastNdx_;
  cb_Integer iCol_;
  cb_Integer iColCount;
  cb_Integer iColUsed;
  cb_Integer InDrag_;
  cb_Integer iRedraw_;
  cb_Boolean bAutoLabelEdit;
  cb_Boolean bMultiSelect;
  cb_Integer iPrevItem;
  cb_Integer iPrevCol;
  WNDPROC PrevProc;
  WNDPROC PrevProcLabelEdit;
  HIMAGELIST hImlIcons_;
  cb_PString OldLabelEdit_;
  cb_Integer flag1_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  void (cb_CDECL *ItemChanged)(struct cb_s_wListView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemClick)(struct cb_s_wListView_*,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemRClick)(struct cb_s_wListView_*,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemMClick)(struct cb_s_wListView_*,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemDblClick)(struct cb_s_wListView_*,cb_Integer,cb_Integer);
  void (cb_CDECL *ItemLostFocus)(struct cb_s_wListView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *KeyDown)(struct cb_s_wListView_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyUp)(struct cb_s_wListView_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyPress)(struct cb_s_wListView_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *MouseDown)(struct cb_s_wListView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wListView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wListView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *GotFocus)(struct cb_s_wListView_*,HWND);
  void (cb_CDECL *LostFocus)(struct cb_s_wListView_*,HWND);
  void (cb_CDECL *ColClick)(struct cb_s_wListView_*,cb_Integer);
  void (cb_CDECL *BeforeLabelEdit)(struct cb_s_wListView_*,cb_Integer*,cb_Integer,cb_Integer*,cb_PString*);
  void (cb_CDECL *AfterLabelEdit)(struct cb_s_wListView_*,cb_PString*,const cb_String,cb_Integer*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *BeginDrag)(struct cb_s_wListView_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *EndDrag)(struct cb_s_wListView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *DropFiles)(struct cb_s_wListView_*,const cb_String,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *Dragging)(struct cb_s_wListView_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (*ColResize)(struct cb_s_wListView_*,cb_Integer,cb_Integer,NMHEADER*);
  void (*ColResizing)(struct cb_s_wListView_*,cb_Integer,NMHEADER*);
  void (cb_CDECL *DeleteItem)(struct cb_s_wListView_*,cb_Integer);
  void (cb_CDECL *InsertItem)(struct cb_s_wListView_*,cb_Integer);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wListView_*,HWND,cb_UInteger,WPARAM,LPARAM);
  void (cb_CDECL *Resize)(struct cb_s_wListView_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wListView_*);
  void (cb_CDECL *Terminate)(struct cb_s_wListView_*);
} wListView, *PwListView;


typedef struct cb_s_clsMixer_ {
  MIXERCONTROL VolCtrl_Sys;
  MIXERCONTROL VolCtrl_Wav;
  MIXERCONTROL VolCtrl_Mid;
  MIXERCONTROL VolCtrl_CD;
  cb_Integer VolMin_Sys;
  cb_Integer VolMax_Sys;
  cb_Integer VolMin_Wav;
  cb_Integer VolMax_Wav;
  cb_Integer VolMin_Mid;
  cb_Integer VolMax_Mid;
  cb_Integer VolMin_CD;
  cb_Integer VolMax_CD;
  HMIXEROBJ hMixer;
} clsMixer, *PclsMixer;


typedef struct cb_s_clsMCIStr_ {
  struct cb_s_clsMixer_ cMixer_;
  wchar_t sFile[MAX_FILE_NAME];
  wchar_t sAlias[64];
  cb_Integer id;
  cb_Integer flag1_;
} clsMCIStr, *PclsMCIStr;


typedef struct cb_s_wMCIStr_ {
  struct cb_s_clsMCIStr_ cMCIStr_;
  cb_UInteger uID;
  cb_UInteger dwNum;
  cb_UInteger dwFrom;
  cb_UInteger dwTo;
  cb_Integer iCode;
  cb_Integer flag1_;
  cb_Integer iLastError;
  cb_Boolean (cb_CDECL *OnEndPlay)(struct cb_s_wMCIStr_*);
  void (cb_CDECL *OnEndRecord)(struct cb_s_wMCIStr_*);
  void (cb_CDECL *OnSave)(struct cb_s_wMCIStr_*);
  void (cb_CDECL *OnSetPosition)(struct cb_s_wMCIStr_*,cb_UInteger);
} wMCIStr, *PwMCIStr;


typedef struct cb_s_clsMCI_ {
  struct cb_s_clsMixer_ cMixer_;
  wchar_t sFile[MAX_FILE_NAME];
  wchar_t sAlias[64];
  wchar_t sDevice[256];
  cb_UInteger uID;
  cb_Integer id;
  cb_Integer flag1_;
} clsMCI, *PclsMCI;


typedef struct cb_s_wMCI_ {
  struct cb_s_clsMCI_ cMCI_;
  cb_UInteger uID;
  cb_UInteger dwNum;
  cb_UInteger dwFrom;
  cb_UInteger dwTo;
  cb_Integer iCode;
  cb_Integer flag1_;
  cb_Integer iLastError;
  cb_Boolean (cb_CDECL *OnEndPlay)(struct cb_s_wMCI_*);
  void (cb_CDECL *OnEndRecord)(struct cb_s_wMCI_*);
  void (cb_CDECL *OnSave)(struct cb_s_wMCI_*);
  void (cb_CDECL *OnSetPosition)(struct cb_s_wMCI_*,cb_UInteger);
} wMCI, *PwMCI;


typedef struct cb_s_wMPlayer_ {
  HWND hWnd;
  struct cb_s_wAnimation_ wAni1;
  struct cb_s_wSlider_ wSld1;
  HWND hWndPanel;
  HWND hWndPic;
  HWND hWMP;
  HWND hSWF;
  HWND hToolTip;
  HCURSOR hCursor;
  struct cb_s_wButton_ btnPlay;
  struct cb_s_wButton_ btnStop;
  struct cb_s_wButton_ btnRepeat;
  struct cb_s_wButton_ btnRecord;
  struct cb_s_wButton_ btnStopRecord;
  struct cb_s_wMCI_ ctrlMCI;
  struct cb_s_wMCI_ ctrlMCIRecord;
  cb_comObject comWMP;
  cb_UInteger mInterval;
  cb_UInteger mTimer;
  cb_UInteger m_Length;
  cb_Integer m_Width;
  cb_Integer m_Height;
  cb_Integer iEngine_;
  COLORREF BackColor1;
  COLORREF BackColor2;
  cb_Integer lVol;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  cb_Boolean (cb_CDECL *OnButtonPlay)(struct cb_s_wMPlayer_*,cb_Boolean);
  cb_Boolean (cb_CDECL *OnButtonStop)(struct cb_s_wMPlayer_*);
  cb_Boolean (cb_CDECL *OnButtonRepeat)(struct cb_s_wMPlayer_*);
  cb_Boolean (cb_CDECL *OnButtonRecord)(struct cb_s_wMPlayer_*,cb_Boolean);
  cb_Boolean (cb_CDECL *OnButtonStopRecord)(struct cb_s_wMPlayer_*);
  void (cb_CDECL *OnStop)(struct cb_s_wMPlayer_*);
  cb_Boolean (cb_CDECL *OnRepeat)(struct cb_s_wMPlayer_*);
  void (cb_CDECL *MouseDown)(struct cb_s_wMPlayer_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wMPlayer_*,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *OnUpdate)(struct cb_s_wMPlayer_*);
  void (cb_CDECL *DropFiles)(struct cb_s_wMPlayer_*,const cb_StringW,cb_Integer);
  void (cb_CDECL *Resize)(struct cb_s_wMPlayer_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wMPlayer_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wMPlayer_*);
  void (cb_CDECL *Terminate)(struct cb_s_wMPlayer_*);
} wMPlayer, *PwMPlayer;


typedef struct cb_s_wMIDIKB_ {
  HWND hWnd;
  struct cb_s_wBox_ wBox1;
  char Notes[wMIDIKB_MAXOCTAVES*12];
  cb_Integer lastNote;
  HBRUSH hBrush_;
  COLORREF clrNoteOn;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer flag1_;
  void (cb_CDECL *Click)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer);
  void (cb_CDECL *MClick)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer);
  void (cb_CDECL *KeyDown)(struct cb_s_wMIDIKB_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *KeyUp)(struct cb_s_wMIDIKB_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *KeyPress)(struct cb_s_wMIDIKB_*,cb_Integer*,cb_Integer);
  void (*GotFocus)(struct cb_s_wMIDIKB_*);
  void (*LostFocus)(struct cb_s_wMIDIKB_*);
  void (cb_CDECL *MouseDown)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseEnter)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseLeave)(struct cb_s_wMIDIKB_*);
  void (cb_CDECL *MouseMove)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Paint)(struct cb_s_wMIDIKB_*,HWND);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wMIDIKB_*,HWND,cb_UInteger,WPARAM,LPARAM);
  void (cb_CDECL *Resize)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer);
  void (cb_CDECL *OnMIDIMsg)(struct cb_s_wMIDIKB_*,cb_Int32);
  void (cb_CDECL *OnMIDINoteOn)(struct cb_s_wMIDIKB_*,cb_Integer,cb_Integer);
  void (cb_CDECL *OnMIDINoteOff)(struct cb_s_wMIDIKB_*,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wMIDIKB_*);
  void (cb_CDECL *Terminate)(struct cb_s_wMIDIKB_*);
} wMIDIKB, *PwMIDIKB;


typedef struct cb_s_wRTFBox_ {
  cb_Integer mLeft;
  cb_Integer mTop;
  cb_Integer mWidth;
  cb_Integer mHeight;
  HWND hWndRTF;
  HWND hWnd;
  struct cb_s_ucCoolSB_ SB1;
  cb_Integer Ndx;
  cb_Boolean bHideSel;
  cb_Boolean bNoDrop;
  cb_Integer flag1_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer PrevFirstLine_;
  cb_Boolean (cb_CDECL *KeyDown)(struct cb_s_wRTFBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyUp)(struct cb_s_wRTFBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyPress)(struct cb_s_wRTFBox_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wRTFBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseDown)(struct cb_s_wRTFBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wRTFBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wRTFBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *DropFiles)(struct cb_s_wRTFBox_*,const cb_String,cb_Integer);
  cb_Boolean (cb_CDECL *GotFocus)(struct cb_s_wRTFBox_*,HWND);
  cb_Boolean (cb_CDECL *LostFocus)(struct cb_s_wRTFBox_*,HWND);
  void (cb_CDECL *PosChanged)(struct cb_s_wRTFBox_*,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Change)(struct cb_s_wRTFBox_*);
  void (cb_CDECL *UpdateUI)(struct cb_s_wRTFBox_*);
  void (cb_CDECL *Resize)(struct cb_s_wRTFBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *LinkOver)(struct cb_s_wRTFBox_*,cb_String,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Activate)(struct cb_s_wRTFBox_*,HWND,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wRTFBox_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wRTFBox_*);
  void (cb_CDECL *Terminate)(struct cb_s_wRTFBox_*);
} wRTFBox, *PwRTFBox;


typedef struct cb_s_wSCI__ {
  struct cb_s_wScrollBar_ wScrlH;
  struct cb_s_wScrollBar_ wScrlV;
  struct cb_s_clsSCI_ b1;
  WNDPROC b2;
  HMODULE hMdl;
  cb_Integer Lines_;
  cb_Integer LinesOnScr_;
  cb_Integer ScrollWidth_;
  cb_Integer mWidth_;
  cb_LOGFONT lFont;
  cb_Integer flag1;
} wSCI_, *PwSCI_;


typedef struct cb_s_wSCIBox_ {
  struct cb_s_wSCI__ clsSCIBuf[wSCIBox_MAX_DOCS];
  struct cb_s_wSCI__* SCI1;
  struct cb_s_clsSCI_* clsSCI1;
  cb_Integer iDocCnt;
  cb_Integer Index_;
  cb_Integer mWidth;
  cb_Integer mHeight;
  HWND hWnd;
  HWND hWndParent;
  char sFile[MAX_FILE_NAME];
  cb_Integer Pos1[wSCIBox_MAX_POSITIONS];
  cb_Integer PosCnt1;
  void* Ptr1[4];
  HCURSOR hCursor;
  HMODULE hMdl;
  cb_Integer Ndx;
  cb_Integer iLang;
  char* FntName;
  cb_Integer FntSize;
  COLORREF ClrFchar;
  COLORREF ClrBchar;
  COLORREF ClrFcmd;
  COLORREF ClrBcmd;
  COLORREF ClrFcmnt;
  COLORREF ClrBcmnt;
  COLORREF ClrFcmntblk;
  COLORREF ClrBcmntblk;
  COLORREF ClrFcmntdoc;
  COLORREF ClrBcmntdoc;
  COLORREF ClrFdate;
  COLORREF ClrBdate;
  COLORREF ClrFdef;
  COLORREF ClrBdef;
  COLORREF ClrFhide;
  COLORREF ClrBhide;
  COLORREF ClrFidf;
  COLORREF ClrBidf;
  COLORREF ClrFkwd1;
  COLORREF ClrBkwd1;
  COLORREF ClrFkwd2;
  COLORREF ClrBkwd2;
  COLORREF ClrFkwd3;
  COLORREF ClrBkwd3;
  COLORREF ClrFkwd4;
  COLORREF ClrBkwd4;
  COLORREF ClrFlbl;
  COLORREF ClrBlbl;
  COLORREF ClrFln;
  COLORREF ClrBln;
  COLORREF ClrFmeta;
  COLORREF ClrBmeta;
  COLORREF ClrFmetaop;
  COLORREF ClrBmetaop;
  COLORREF ClrFnum;
  COLORREF ClrBnum;
  COLORREF ClrFpp;
  COLORREF ClrBpp;
  COLORREF ClrFppcmnt;
  COLORREF ClrBppcmnt;
  COLORREF ClrFppcmntdoc;
  COLORREF ClrBppcmntdoc;
  COLORREF ClrFop;
  COLORREF ClrBop;
  COLORREF ClrFreg;
  COLORREF ClrBreg;
  COLORREF ClrFsel;
  COLORREF ClrBsel;
  COLORREF ClrFstr;
  COLORREF ClrBstr;
  COLORREF ClrFstreol;
  COLORREF ClrBstreol;
  COLORREF ClrFbmg;
  COLORREF ClrBbmg;
  COLORREF ClrFbmb;
  COLORREF ClrBbmb;
  COLORREF ClrFctip;
  COLORREF ClrBctip;
  COLORREF ClrCaret;
  cb_Integer CaretWidth;
  cb_Boolean bHideSel;
  cb_Boolean bNumbers;
  cb_Boolean bNoDrop;
  cb_Integer flag1_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  void (cb_CDECL *Click)(struct cb_s_wSCIBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wSCIBox_*,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *GotFocus)(struct cb_s_wSCIBox_*,HWND);
  cb_Boolean (cb_CDECL *LostFocus)(struct cb_s_wSCIBox_*,HWND);
  cb_Boolean (cb_CDECL *KeyDown)(struct cb_s_wSCIBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyUp)(struct cb_s_wSCIBox_*,cb_Integer*,cb_Integer);
  cb_Boolean (cb_CDECL *KeyPress)(struct cb_s_wSCIBox_*,cb_Integer*,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wSCIBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseDown)(struct cb_s_wSCIBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseUp)(struct cb_s_wSCIBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *MouseMove)(struct cb_s_wSCIBox_*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *DropFiles)(struct cb_s_wSCIBox_*,const cb_String,cb_Integer);
  void (cb_CDECL *MarginClick)(struct cb_s_wSCIBox_*,const void*);
  void (cb_CDECL *PosChanged)(struct cb_s_wSCIBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Change)(struct cb_s_wSCIBox_*,cb_Integer);
  void (cb_CDECL *UpdateUI)(struct cb_s_wSCIBox_*,cb_Integer);
  void (cb_CDECL *DocChanged)(struct cb_s_wSCIBox_*,cb_Integer,cb_Integer);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wSCIBox_*,HWND,cb_UInteger,WPARAM,LPARAM);
  void (cb_CDECL *Paint)(struct cb_s_wSCIBox_*,HWND);
  void (cb_CDECL *Resize)(struct cb_s_wSCIBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Activate)(struct cb_s_wSCIBox_*,HWND,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wSCIBox_*,HWND,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wSCIBox_*,cb_Integer);
  void (cb_CDECL *Terminate)(struct cb_s_wSCIBox_*);
} wSCIBox, *PwSCIBox;


typedef struct cb_s_wShell_ {
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer flag1_;
} wShell, *PwShell;


typedef struct cb_s_wCrypt_ {
  HCRYPTPROV hCryptProv;
  HCRYPTKEY hClientWriteKey;
  HCRYPTKEY hClientReadKey;
  HCRYPTKEY hMasterKey;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer flag1_;
} wCrypt, *PwCrypt;


typedef struct cb_s_wSSL_ {
  struct cb_s_wCrypt_ wCrypt1;
  char MASTER_KEY[32+4];
  char CHALLENGE_DATA[16+4];
  cb_PString CLIENT_READ_KEY;
  cb_PString CLIENT_WRITE_KEY;
  cb_PString ENCODED_CERT;
  cb_PString CONNECTION_ID;
  cb_Integer SEND_SEQUENCE_NUMBER;
  cb_Integer RECV_SEQUENCE_NUMBER;
  cb_Integer RSA_KEY_LEN;
  char* sBuffer1;
  char* sBuffer2;
  cb_Integer iSeekLen;
  cb_Integer iLayer;
  cb_Integer Pos1;
  cb_Integer bytesTotal;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer flag1_;
  void (cb_CDECL *OnAuth)(struct cb_s_wSSL_*);
  void (cb_CDECL *OnProcessData)(struct cb_s_wSSL_*,const cb_String,cb_Integer);
} wSSL, *PwSSL;


typedef struct cb_s_modSocket_ {
  struct sockaddr_in sockin;
  struct cb_s_wSSL_ wSSL1;
  LPBYTE RecvBuf;
  cb_Integer RecvBufLen;
  LPBYTE SendBuf;
  cb_Integer SendBufLen;
  cb_Integer RecvBufSize;
  cb_Integer SendBufSize;
  char RemoteHost[0x0800];
  char RemoteHostIP[0x20];
  cb_UInteger RemotePort;
  char LocalHostName[0x0800];
  char LocalIP[0x20];
  cb_UInteger LocalPort;
  SOCKET SocketHandle;
  cb_Integer iLastError;
  cb_Integer Prot;
  cb_Integer Family;
  cb_Integer LastChar;
  cb_Integer iFlag;
} modSocket, *PmodSocket;


typedef struct cb_s_wSocket_ {
  cb_Integer mTimer;
  struct cb_s_modSocket_ Buf;
  char sTemp[0x0800];
  LPBYTE bBuf;
  cb_Integer Ndx;
  SOCKET TempHandle;
  cb_Integer mInterval;
  cb_Integer enmState;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer flag1_;
  void (cb_CDECL *OnConnection)(struct cb_s_wSocket_*);
  void (cb_CDECL *OnConnectionRequest)(struct cb_s_wSocket_*,SOCKET);
  void (cb_CDECL *OnDataArrival)(struct cb_s_wSocket_*,cb_Integer);
  void (cb_CDECL *OnError)(struct cb_s_wSocket_*,cb_Integer,const cb_String,const cb_String);
  void (cb_CDECL *OnSendComplete)(struct cb_s_wSocket_*);
  void (cb_CDECL *OnSendProgress)(struct cb_s_wSocket_*,cb_Integer,cb_Integer);
  void (cb_CDECL *OnTimer)(struct cb_s_wSocket_*);
  cb_Integer (cb_CDECL *OnEvents)(struct cb_s_wSocket_*,LPARAM);
  void (cb_CDECL *OnClose)(struct cb_s_wSocket_*);
  void (cb_CDECL *OnAuth)(struct cb_s_wSocket_*);
} wSocket, *PwSocket;


#pragma pack(1)

typedef struct cb_s_wTabItem_ {
  struct cb_s_wButton_ wBtn;
  struct cb_s_wPushButton_ wBtnX;
  struct cb_s_wPushButton_ wBtnAdd;
  HWND hWnd;
  HBITMAP hBmp;
  HBRUSH hBrush;
  char* sCaption;
  cb_Integer flag1;
  cb_Integer UserData;
  cb_Integer iWidth_;
  cb_Integer iHeight_;
} wTabItem, *PwTabItem;

#pragma pack()

typedef struct cb_s_wTab_ {
  HWND hWnd;
  HWND hWndPanel;
  struct cb_s_cb_cCollection_ Coll;
  struct cb_s_wScrollBtn_ ScrlBtn;
  struct cb_s_wTabItem_* Buf;
  HBITMAP hBmp;
  HBRUSH hBrush;
  HCURSOR hCursor;
  HWND hTool_;
  cb_Integer m_Left;
  cb_Integer m_Top;
  cb_Integer m_Width;
  cb_Integer m_Height;
  cb_Integer m_TabLeft;
  cb_Integer m_TabTop;
  cb_Integer m_TabWidth;
  cb_Integer m_TabHeight;
  cb_Integer m_Width_;
  cb_Integer m_iWidth;
  cb_Integer m_iHeight;
  cb_Integer btnWidth;
  cb_Integer btnHeight;
  cb_Integer btnOffset;
  cb_Integer bPos_;
  cb_Integer TabSpace;
  cb_Integer iFirst_;
  cb_Integer iLast_;
  cb_Integer iCnt_;
  cb_Integer iSelected_;
  cb_Integer Timer1_;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  cb_Integer (cb_CDECL *Click)(struct cb_s_wTab_*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *DblClick)(struct cb_s_wTab_*,HWND,cb_Integer);
  void (cb_CDECL *RClick)(struct cb_s_wTab_*,HWND,cb_Integer);
  void (cb_CDECL *MClick)(struct cb_s_wTab_*,HWND,cb_Integer);
  void (cb_CDECL *Scroll)(struct cb_s_wTab_*);
  void (cb_CDECL *Resize)(struct cb_s_wTab_*,HWND,cb_Integer,cb_Integer,cb_Integer);
  void (cb_CDECL *Deactivate)(struct cb_s_wTab_*,HWND,cb_Integer);
  cb_Boolean (cb_CDECL *Add)(struct cb_s_wTab_*,HWND,cb_Integer,cb_Integer,cb_Integer);
  cb_Boolean (cb_CDECL *Close)(struct cb_s_wTab_*,HWND,cb_Integer);
  cb_Boolean (cb_CDECL *Destroy)(struct cb_s_wTab_*,HWND,cb_Integer);
  cb_Integer (cb_CDECL *Events)(struct cb_s_wTab_*,HWND,cb_UInteger,WPARAM,LPARAM,cb_Integer,cb_Integer*);
  void (cb_CDECL *Terminate)(struct cb_s_wTab_*);
} wTab, *PwTab;


typedef struct cb_s_wTimer_ {
  cb_UInteger Interval;
  cb_cHRTimer clsHRT;
  cb_Integer Enabled;
  cb_Integer flag1_;
  cb_Integer UserData;
  void* ctlParent;
  void* ctlMain;
  void* clsModule;
  cb_Integer iCnt_;
  void (cb_CDECL *OnTimer)(struct cb_s_wTimer_*);
  void (cb_CDECL *OnHRTimer)(struct cb_s_wTimer_*,cb_UInteger);
} wTimer, *PwTimer;


typedef struct cb_s_wVidCapBox_ {
  char sFile[MAX_FILE_NAME];
  HWND hWnd;
  HWND hWndCap;
  HWND hWndPanel;
  HWND hToolTip;
  HCURSOR hCursor;
  cb_Boolean bAudio;
  struct cb_s_wButton_ btnRecord;
  struct cb_s_wButton_ btnStop;
  cb_Integer bUsePanel;
  cb_Integer bScale;
  cb_Integer fps;
  cb_Integer bOpen_;
  cb_Integer bPaused_;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  cb_Boolean (cb_CDECL *OnRecord)(struct cb_s_wVidCapBox_*,cb_Boolean);
  cb_Boolean (cb_CDECL *OnPause)(struct cb_s_wVidCapBox_*);
  cb_Boolean (cb_CDECL *OnStop)(struct cb_s_wVidCapBox_*);
  void (cb_CDECL *Resize)(struct cb_s_wVidCapBox_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wVidCapBox_*);
  void (cb_CDECL *Terminate)(struct cb_s_wVidCapBox_*);
  void (cb_CDECL *OnFrame)(struct cb_s_wVidCapBox_*,VIDEOHDR*);
  void (cb_CDECL *OnStatus)(struct cb_s_wVidCapBox_*,cb_Integer,const cb_String);
  void (cb_CDECL *OnVideoStream)(struct cb_s_wVidCapBox_*,VIDEOHDR*);
  void (cb_CDECL *OnError)(struct cb_s_wVidCapBox_*,cb_Integer,const cb_String);
} wVidCapBox, *PwVidCapBox;


typedef struct cb_s_wWMPlayer_ {
  wchar_t sFile[MAX_FILE_NAME];
  cb_comObject comWMP;
#ifdef __cplusplus
  wEventSink* pEventSink;
#else
  wEventSink TEventSink;
#endif
  HWND hWnd;
  HWND hWndParent;
  HWND hWMP;
  HCURSOR hCursor;
  cb_UInteger mInterval;
  cb_UInteger mTimer;
  cb_Integer bOpen_;
  cb_Boolean bStretch_;
  cb_Integer lVolume;
  void* ctlParent;
  void* ctlMain;
  void* clsParent;
  cb_Integer UserData;
  cb_Integer flag1_;
  cb_Boolean (cb_CDECL *OnPlay)(struct cb_s_wWMPlayer_*,cb_Boolean);
  cb_Boolean (cb_CDECL *OnPause)(struct cb_s_wWMPlayer_*);
  cb_Boolean (cb_CDECL *OnStop)(struct cb_s_wWMPlayer_*);
  cb_Boolean (cb_CDECL *OnUpdate)(struct cb_s_wWMPlayer_*);
  void (cb_CDECL *DropFiles)(struct cb_s_wWMPlayer_*,const cb_String,cb_Integer);
  void (cb_CDECL *Resize)(struct cb_s_wWMPlayer_*,cb_Integer,cb_Integer);
  void (cb_CDECL *Destroy)(struct cb_s_wWMPlayer_*);
  void (cb_CDECL *Terminate)(struct cb_s_wWMPlayer_*);
} wWMPlayer, *PwWMPlayer;



/*((((((((((((((  Global Classes  ))))))))))))))*/

#ifdef __cplusplus
class wEventSink : public IDispatch
{
  private:
    cb_UInteger m_cRefs;
    REFIID m_iid;
    wCOMEventSink m_Sub;
    DWORD m_dwCookie;
    const void* m_Ptr;
  public:
     wEventSink (REFIID,const void* =NULL);
    cb_Integer SetEvents (const void*,wCOMEventSink =NULL);
  private:
    STDMETHODIMP_(ULONG) Release (void);
    STDMETHODIMP_(ULONG) AddRef (void);
    STDMETHODIMP QueryInterface (REFIID,void**);
    STDMETHODIMP GetIDsOfNames (REFIID,OLECHAR**,unsigned int,LCID,DISPID*);
    STDMETHODIMP GetTypeInfo (unsigned int,LCID,ITypeInfo**);
    STDMETHODIMP GetTypeInfoCount (unsigned int*);
    STDMETHODIMP Invoke (DISPID,REFIID,LCID,WORD,DISPPARAMS*,VARIANT*,EXCEPINFO*,unsigned int*);
};
#endif








/*((((((((((((((  Global Variables  ))))))))))))))*/







EXTERN_C HWND modSocket_hWnd;
EXTERN_C const cb_PString modSocket_Description;






























/*((((((((((((((  Global Prototypes  ))))))))))))))*/

cb_BeginExternC
cb_PString FixBackSlash (const cb_String,cb_String);
cb_PString ChkFixBackSlash (cb_String);
cb_PStringW FixBackSlashW (const cb_StringW,cb_StringW);
cb_PStringW ChkFixBackSlashW (cb_StringW);
cb_PString FixForeSlash (const cb_String,cb_String);
cb_PString ChkFixForeSlash (cb_String);
cb_PStringW FixForeSlashW (const cb_StringW,cb_StringW);
cb_PStringW ChkFixForeSlashW (cb_StringW);
cb_PString FixTextStream (const cb_String,void* =NULL);
cb_UInteger Base64Encode_CalcSize (cb_UInteger,cb_UInteger =0);
cb_PString Base64_Encode (const void*,void* =NULL,void* =NULL,cb_UInteger =0,cb_UInteger =-1);
char* Base64_EncodeFile (const cb_String,void* =NULL,void* =NULL,cb_UInteger =0,const cb_String =NULL);
cb_PString Base64_Decode (const cb_String,void* =NULL,void* =NULL,cb_UInteger =-1);
char* Base64_DecodeFile (const cb_String,void* =NULL,void* =NULL,cb_Integer =FALSE);
cb_PString BytesToAscii (const void*,void* =NULL,void* =NULL,cb_Integer =-1);
BYTE* AsciiToBytes (const cb_String,void* =NULL,void* =NULL);
void XorByteArray (void*,const cb_String,cb_Integer =-1,BYTE =0);
cb_PString Encrypt1 (const void*,const cb_String =NULL,void* =NULL,void* =NULL,cb_Integer =-1,cb_Boolean =FALSE);
cb_PString EncryptToAscii1 (const void*,const cb_String =NULL,void* =NULL,cb_Integer =-1);
BYTE* Decrypt1 (const void*,const cb_String =NULL,void* =NULL,void* =NULL,cb_Integer =-1,cb_Boolean =FALSE);
BYTE* DecryptFromAscii1 (const cb_String,const cb_String =NULL,void* =NULL,void* =NULL);
cb_PString Encrypt2 (const void*,void* =NULL,void* =NULL,cb_Integer =-1,cb_Boolean =FALSE);
cb_PString EncryptToAscii2 (const void*,void* =NULL,cb_Integer =-1);
BYTE* Decrypt2 (const void*,void* =NULL,void* =NULL,cb_Integer =-1,cb_Boolean =FALSE);
BYTE* DecryptFromAscii2 (const cb_String,void* =NULL,void* =NULL);
cb_Integer GetWindowsVersion (void);
cb_PString GetShortPath (const cb_String,void* =NULL);
cb_PString GenerateTmpDir (void* =NULL);
cb_PString GenerateTmpFileName (const cb_String,const cb_String =cb_EMPTYSTR,cb_Integer =0,void* =NULL);
cb_PString GetWindowsPath (void);
cb_PString GetSystem32Path (void);
cb_PString GetNameOfComputer (void);
cb_PString GetNameOfUser (void);
cb_File* vbCreateFile (const cb_String,cb_Integer =1);
cb_File* vbCreateFileW (const cb_StringW,cb_Integer =1);
cb_File* vbOpenFile (const cb_String);
cb_File* vbOpenFileW (const cb_StringW);
HANDLE apiCreateOpenFile (const cb_String,cb_Integer =FILE_GENERIC_READ | FILE_GENERIC_WRITE,cb_Integer =CREATE_ALWAYS,cb_Integer =0);
HANDLE apiCreateOpenFileW (const cb_StringW,cb_Integer =FILE_GENERIC_READ | FILE_GENERIC_WRITE,cb_Integer =CREATE_ALWAYS,cb_Integer =0);
HANDLE apiCreateFile (const cb_String);
HANDLE apiCreateFileW (const cb_StringW);
HANDLE apiOpenFile (const cb_String,cb_Integer =FILE_SHARE_READ);
HANDLE apiOpenFileW (const cb_StringW,cb_Integer =FILE_SHARE_READ);
cb_Integer apiSetFilePos (HANDLE,cb_Integer =0,cb_Integer =FILE_BEGIN);
cb_Integer apiGetFilePos (HANDLE);
HANDLE apiOpenFileAppend (const cb_String,cb_Integer =FILE_SHARE_READ);
HANDLE apiOpenFileAppendW (const cb_StringW,cb_Integer =FILE_SHARE_READ);
cb_Integer apiWriteFile (HANDLE,BYTE*,cb_Integer,cb_Integer =0,cb_Integer =0,cb_Integer =FILE_BEGIN);
void apiWriteFileStr (HANDLE,const cb_String,cb_Integer =0,cb_Integer =FILE_BEGIN);
BYTE* apiReadFile (HANDLE,BYTE*,void* =NULL,cb_Integer =-1,cb_Integer =0,cb_Integer =0,cb_Integer =FILE_BEGIN);
cb_PString apiReadFileStr (HANDLE,void* =NULL,cb_Integer* =NULL,cb_Integer =-1,cb_Integer =0,cb_Integer =FILE_BEGIN);
void RenameKillEx (const cb_String,cb_Integer =-1,const cb_String =NULL);
void RenameKillExW (const cb_StringW,cb_Integer =-1,const cb_StringW =NULL);
void ReplaceFileAfterReboot (const cb_String,const cb_String);
void ReplaceFileAfterRebootW (const cb_StringW,const cb_StringW);
HANDLE modPipe_CreateProcessW (const cb_StringW =NULL,const cb_StringW =NULL,const cb_StringW =NULL,cb_Integer =FALSE,cb_Integer* =NULL,PROCESS_INFORMATION* =NULL,HANDLE* =NULL,HANDLE =NULL);
HANDLE modPipe_CreateProcess (const cb_String =NULL,const cb_String =NULL,const cb_String =NULL,cb_Integer =FALSE,cb_Integer* =NULL,PROCESS_INFORMATION* =NULL,HANDLE* =NULL,HANDLE =NULL);
cb_PString modCmdLine_GetNextArg (void* =NULL,const void* =NULL,cb_Integer =0);
void modCmdLine_Initialize (const cb_String =NULL);
cb_PString GenerateSettingFileName (const cb_String =".ini",const cb_String =NULL,void* =NULL);
cb_Integer cb_DEFCALL GUI_SendMessage (HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer =0);
cb_Integer cb_DEFCALL GUI_PostMessage (HWND,cb_UInteger,cb_UInteger =0,cb_UInteger =0);
cb_PString cb_DEFCALL GUI_GetWindowText (HWND,void* =NULL);
cb_PString cb_DEFCALL GUI_GetWindowClass (HWND,void* =NULL);
void GUI_RemoveFrame (HWND);
void GUI_SetFrame (HWND);
void GUI_SetWinTransparency (HWND,cb_Integer);
cb_Integer cb_DEFCALL GUI_TransparentWin (HWND =NULL,cb_Integer =255,cb_Integer =80,const cb_String =NULL);
void cb_DEFCALL GUI_SetOpaque (HWND);
cb_Integer cb_DEFCALL GUI_SetWinOnTop (HWND,cb_Integer =-1,cb_Integer =-1);
HWND cb_DEFCALL GUI_SetParentOf (HWND,HWND =NULL,HWND =NULL);
HWND cb_DEFCALL GUI_SetChildOfDesktop (HWND,HWND =NULL);
cb_Integer cb_DEFCALL GUI_SetTray (HWND,HICON =NULL,const cb_String =cb_EMPTYSTR,cb_Integer =TRUE,cb_Integer =-1,cb_Integer =WM_MOUSEMOVE);
HBITMAP cb_DEFCALL GUI_CreateGradientBitmap (HWND,COLORREF,COLORREF,cb_Integer =FALSE,HDC =NULL);
HBRUSH cb_DEFCALL GUI_CreateGradientBrush (HWND,COLORREF,COLORREF,cb_Integer =FALSE,HDC =NULL);
cb_Boolean cb_DEFCALL GUI_MoveForm (HWND,cb_Integer,cb_Boolean =FALSE);
HICON modShell_GetIcon (cb_Integer,const cb_String,HDC =NULL);
cb_Integer modShell_ShowProperties (const cb_String,HWND =(HWND)-1);
cb_PString modShell_GetFolderPath (cb_Integer,cb_String =NULL,HWND =NULL);
cb_PString modShell_GetSpecialFolder (cb_Integer,void* =NULL,HWND =NULL);
cb_Integer modShell_MoveFile (const cb_String,const cb_String);
cb_Integer modShell_DeleteFile (const cb_String);
void clsSharedMemory_Close (clsSharedMemory*);
LPVOID clsSharedMemory_Open (clsSharedMemory*,cb_Integer,const cb_String =NULL);
LPVOID clsSharedMemory_Create (clsSharedMemory*,cb_Integer,const cb_String =NULL);
clsSharedMemory* clsSharedMemory_Initialize (clsSharedMemory*);
void clsSharedMemory_Terminate (clsSharedMemory*);
cb_Integer cb_DEFCALL modGIF2BMPW (const wchar_t*,const wchar_t*,cb_Integer* =NULL,cb_Integer* =NULL,COLORREF* =NULL,cb_Boolean (cb_CDECL *)(const void*,BITMAPFILEHEADER*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,WORD,COLORREF,COLORREF,cb_Integer,cb_Integer) =NULL,const void* =NULL,WORD* =NULL,cb_Integer =0);
cb_Integer cb_DEFCALL modGIF2BMP (const char*,const char*,cb_Integer* =NULL,cb_Integer* =NULL,COLORREF* =NULL,cb_Boolean (cb_CDECL *)(const void*,BITMAPFILEHEADER*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,WORD,COLORREF,COLORREF,cb_Integer,cb_Integer) =NULL,const void* =NULL,WORD* =NULL,cb_Integer =0);
modAVI_HAVI modAVI_CreateW (const cb_StringW,cb_Integer =10,WAVEFORMATEX* =NULL,cb_Integer =-1);
modAVI_HAVI modAVI_Create (const cb_String,cb_Integer =10,WAVEFORMATEX* =NULL,cb_Integer =-1);
modAVI_HAVI modAVI_OpenW (const cb_StringW,WAVEFORMATEX* =NULL,cb_Integer =-1);
modAVI_HAVI modAVI_Open (const cb_String,WAVEFORMATEX* =NULL,cb_Integer =-1);
HRESULT modAVI_Close (modAVI_HAVI);
modAVI_HAVI modAVI_OpenStreamW (const cb_StringW);
modAVI_HAVI modAVI_OpenStream (const cb_String);
cb_Integer modAVI_GetFirstFrame (modAVI_HAVI);
cb_Integer modAVI_GetStreamLength (modAVI_HAVI);
cb_Integer modAVI_GetLastFrame (modAVI_HAVI);
cb_Integer modAVI_GetTime (modAVI_HAVI,cb_Integer =-1);
cb_Integer modAVI_GetInterval (modAVI_HAVI,cb_Integer =-1);
cb_Integer modAVI_GetFileInfo (modAVI_HAVI,AVIFILEINFO*);
cb_Integer modAVI_GetStreamInfo (modAVI_HAVI,AVISTREAMINFO*);
cb_Integer modAVI_GetFPS (modAVI_HAVI);
PGETFRAME modAVI_GetFrameOpen (modAVI_HAVI,LPBITMAPINFOHEADER =(LPBITMAPINFOHEADER)-1);
HRESULT modAVI_SetVideoCompression (modAVI_HAVI,HBITMAP,AVICOMPRESSOPTIONS* =NULL,HWND =NULL);
HRESULT modAVI_AddFrame (modAVI_HAVI,HBITMAP);
HRESULT modAVI_AddAudio (modAVI_HAVI,void*,DWORD);
HRESULT modAVI_AddWavW (modAVI_HAVI,const cb_StringW,DWORD);
HRESULT modAVI_AddWav (modAVI_HAVI,const cb_String,DWORD);
cb_PString modAVI_FormatMessage (HRESULT,void* =NULL);
cb_Boolean modAVI2BMP_SaveDIBW (BITMAPINFOHEADER*,const cb_StringW);
cb_Boolean modAVI2BMP_SaveDIB (BITMAPINFOHEADER*,const cb_String);
cb_Integer modAVI2BMPW (const cb_StringW,const cb_StringW =NULL,cb_Boolean (cb_CDECL *)(const void*,BITMAPINFOHEADER*,const cb_StringW,cb_Integer,cb_Integer) =NULL,const void* =NULL,const cb_StringW =NULL,modAVI2BMPType* =NULL);
cb_Integer modAVI2BMP (const cb_String,const cb_String =NULL,cb_Boolean (cb_CDECL *)(const void*,BITMAPINFOHEADER*,const cb_String,cb_Integer,cb_Integer) =NULL,const void* =NULL,const cb_String =NULL,modAVI2BMPType* =NULL);
void clsANI_SetFileW (clsANI*,const cb_StringW);
void clsANI_SetFile (clsANI*,const cb_String);
void clsANI_Clear (clsANI*);
void clsANI_Close (clsANI*);
cb_Integer clsANI_Load (clsANI*);
cb_Integer clsANI_IsOpen (clsANI*);
cb_Integer clsANI_OpenW (clsANI*,const cb_StringW =NULL,cb_Boolean =FALSE,HWND =NULL,cb_Integer =0);
cb_Integer clsANI_Open (clsANI*,const cb_String =NULL,cb_Boolean =FALSE,HWND =NULL,cb_Integer =0);
cb_Integer clsANI_OpenFromMemory (clsANI*,void*,cb_Integer,cb_Boolean =FALSE,HWND =NULL,cb_Integer =0);
cb_UInteger clsANI_GetDuration (clsANI*,cb_UInteger =-1);
cb_UInteger clsANI_SetDuration (clsANI*,cb_UInteger,cb_UInteger =-1);
cb_Integer clsANI_SetEngine (clsANI*,cb_Integer);
HBITMAP clsANI_GetBMP (clsANI*,cb_Integer =-1);
void clsANI_SetIndex (clsANI*,cb_Integer);
cb_Integer clsANI_Seek (clsANI*,cb_Integer);
void clsANI_SetBackColor (clsANI*,COLORREF,COLORREF =CLR_INVALID,cb_Integer =FALSE);
void clsANI_SetTransColor (clsANI*,COLORREF);
HBITMAP clsANI_GetCurrentBMP (clsANI*);
void clsANI_Shutdown (clsANI*);
EXTERN_C clsANI* clsANI_Initialize (clsANI* =NULL,void* =NULL,void* =NULL);
EXTERN_C void clsANI_Terminate (clsANI*);
HBITMAP wGradientButton_CreateBitmap (HWND,COLORREF,COLORREF,COLORREF,const void*,HDC,HFONT =NULL,RECT* =NULL,HDC* =NULL,cb_Integer =FALSE,cb_Integer =0,float =0.65f,COLORREF =cbWhite,cb_Integer =FALSE,COLORREF =CLR_INVALID,cb_Integer =0,cb_Integer =0,cb_Integer =0);
void wButton_CreateBitmaps (wButton*);
void wButton_Reset (wButton*);
void wButton_Refresh (wButton*);
void wButton_SetAngle (wButton*,float,float =0.0,cb_Integer =FALSE);
cb_PString wButton_GetCaption (wButton*);
void wButton_ChangeCaption (wButton*,const cb_String,cb_Integer =FALSE);
void wButton_SetCaption (wButton*,const cb_String);
void wButton_SetCaptionW (wButton*,const cb_StringW);
cb_Integer wButton_GetCaptionLen (wButton*);
void wButton_SetCaptionRect (wButton*,RECT*,cb_Integer =FALSE);
cb_Integer wButton_GetChecked (wButton*);
void wButton_SetChecked (wButton*,cb_Integer);
cb_Integer wButton_GetEnabled (wButton*);
void wButton_SetEnabled (wButton*,cb_Integer);
cb_Integer wButton_GetLocked (wButton*);
void wButton_SetLocked (wButton*,cb_Integer);
void wButton_EnableFocus (wButton*);
void wButton_DisableFocus (wButton*);
cb_Boolean wButton_GetUnicode (wButton*);
void wButton_SetUnicode (wButton*,cb_Boolean);
void wButton_SetStyle (wButton*,cb_UInteger,cb_Integer =FALSE);
void wButton_SetAutosize (wButton*,cb_Integer,cb_Integer =FALSE);
void wButton_SetDBLClick (wButton*,cb_Integer);
void wButton_Destroy (wButton*);
wButton* wButton_Create (wButton*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE | cb_MIN_INTEGER32 | 0x700,const cb_String =NULL,HFONT =NULL,cb_Integer =-1,cb_Integer =-1);
void wAnimation_Pause (wAnimation*,cb_Integer =FALSE);
void wAnimation_Stop (wAnimation*);
void wAnimation_Close (wAnimation*);
cb_Integer wAnimation_GetInterval (wAnimation*);
void wAnimation_SetInterval (wAnimation*,cb_Integer);
cb_Integer wAnimation_OpenW (wAnimation*,const cb_StringW =NULL,cb_Boolean =FALSE);
cb_Integer wAnimation_Open (wAnimation*,const cb_String =NULL,cb_Boolean =FALSE);
cb_Integer wAnimation_PlayW (wAnimation*,const cb_StringW =NULL,HBITMAP (cb_CDECL *)(wAnimation*,cb_Integer*) =NULL,cb_Integer =FALSE);
cb_Integer wAnimation_Play (wAnimation*,const cb_String =NULL,HBITMAP (cb_CDECL *)(wAnimation*,cb_Integer*) =NULL,cb_Integer =FALSE);
cb_Integer wAnimation_Resume (wAnimation*,cb_Integer =FALSE);
cb_Integer wAnimation_GetRepeat (wAnimation*);
void wAnimation_SetRepeat (wAnimation*,cb_Boolean =TRUE);
cb_Integer wAnimation_GetStretch (wAnimation*);
void wAnimation_SetStretch (wAnimation*,cb_Boolean =TRUE);
cb_Boolean wAnimation_IsPlaying (wAnimation*);
cb_UInteger wAnimation_GetPosition (wAnimation*);
cb_Integer wAnimation_SetPosition (wAnimation*,cb_UInteger);
float wAnimation_GetRate (wAnimation*);
cb_Boolean wAnimation_SetRate (wAnimation*,float);
void wAnimation_SetBackColor (wAnimation*,COLORREF,COLORREF =CLR_INVALID,cb_Integer =FALSE);
HBITMAP wAnimation_GetCurrentBMP (wAnimation*);
cb_Integer wAnimation_GetCurrentFrameIndex (wAnimation*);
void wAnimation_SetCurrentFrame (wAnimation*,cb_Integer);
void wAnimation_Resize_ (wAnimation*,cb_Integer,cb_Integer);
void wAnimation_Resize (wAnimation*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
void wAnimation_SetDragAccecptFiles (wAnimation*,cb_Boolean);
void wAnimation_Shutdown (wAnimation*);
cb_Integer wAnimation_DoEvents (wAnimation*,HWND,cb_UInteger,WPARAM,LPARAM);
wAnimation* wAnimation_Create (wAnimation*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE | 2 | 4);
void wPushButton_CreateBitmaps (wPushButton*);
void wPushButton_Reset (wPushButton*);
void wPushButton_Refresh (wPushButton*);
void wPushButton_SetAngle (wPushButton*,float,float =0.0,cb_Integer =FALSE);
cb_PString wPushButton_GetCaption (wPushButton*);
void wPushButton_ChangeCaption (wPushButton*,const cb_String,cb_Integer =FALSE);
void wPushButton_SetCaption (wPushButton*,const cb_String);
void wPushButton_SetCaptionW (wPushButton*,const cb_StringW);
cb_Integer wPushButton_GetCaptionLen (wPushButton*);
void wPushButton_SetCaptionRect (wPushButton*,RECT*,cb_Integer =FALSE);
cb_Integer wPushButton_GetEnabled (wPushButton*);
void wPushButton_SetEnabled (wPushButton*,cb_Integer);
cb_Integer wPushButton_GetLocked (wPushButton*);
void wPushButton_SetLocked (wPushButton*,cb_Integer);
void wPushButton_EnableFocus (wPushButton*);
void wPushButton_DisableFocus (wPushButton*);
cb_Boolean wPushButton_GetUnicode (wPushButton*);
void wPushButton_SetUnicode (wPushButton*,cb_Boolean);
void wPushButton_SetStyle (wPushButton*,cb_Integer =FALSE);
void wPushButton_SetAutosize (wPushButton*,cb_Integer,cb_Integer =FALSE);
void wPushButton_SetDBLClick (wPushButton*,cb_Integer);
void wPushButton_Destroy (wPushButton*);
wPushButton* wPushButton_Create (wPushButton*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE | cb_MIN_INTEGER32 | 0x700,const cb_String =NULL,HFONT =NULL,cb_Integer =-1,cb_Integer =-1);
void wSlider_Resize (wSlider*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wSlider_Refresh (wSlider*,cb_Integer =FALSE);
void wSlider_SetPosition (wSlider*,cb_Integer,cb_Integer =cb_MIN_INTEGER32,cb_Integer =FALSE);
double wSlider_GetMin (wSlider*);
void wSlider_SetMin (wSlider*,double,cb_Integer =FALSE);
double wSlider_GetMax (wSlider*,double* =NULL);
void wSlider_SetMax (wSlider*,double,cb_Integer =FALSE);
void wSlider_SetRange (wSlider*,double,double,cb_Integer =FALSE);
double wSlider_GetValue (wSlider*);
void wSlider_SetValue (wSlider*,double,cb_Integer =-1);
double wSlider_GetInterval (wSlider*);
void wSlider_SetInterval (wSlider*,double,cb_Integer =FALSE);
void wSlider_SetBackColor (wSlider*,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Integer =FALSE);
void wSlider_SetType (wSlider*,cb_Integer);
cb_Integer wSlider_GetHeight (wSlider*);
cb_Integer wSlider_DoEvents (wSlider*,HWND,cb_UInteger,WPARAM,LPARAM);
wSlider* wSlider_Create (wSlider*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE,double =0,double =0,double =100,double =1);
cb_Integer wScrollBar_GetAutoDisable (wScrollBar*);
void wScrollBar_SetAutoDisable (wScrollBar*,cb_Integer =FALSE);
void wScrollBar_SetPosition (wScrollBar*,cb_Integer,cb_Integer =cb_MIN_INTEGER32,cb_Integer =FALSE);
double wScrollBar_GetMin (wScrollBar*);
void wScrollBar_SetMin (wScrollBar*,double,cb_Integer =FALSE);
double wScrollBar_GetMax (wScrollBar*);
void wScrollBar_SetMax (wScrollBar*,double,cb_Integer =FALSE);
double wScrollBar_GetValue (wScrollBar*);
void wScrollBar_SetValue (wScrollBar*,double,cb_Integer =-1);
double wScrollBar_GetInterval (wScrollBar*);
void wScrollBar_SetInterval (wScrollBar*,double,cb_Integer =FALSE);
void wScrollBar_SetBackColor (wScrollBar*,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Integer =FALSE);
void wScrollBar_SetEnabled (wScrollBar*,cb_Integer =FALSE);
void wScrollBar_Refresh (wScrollBar*,cb_Integer =FALSE);
void wScrollBar_SetType (wScrollBar*,cb_Integer);
void wScrollBar_Resize (wScrollBar*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wScrollBar_SetAutosize (wScrollBar*,cb_Integer,cb_Integer =FALSE);
cb_Integer wScrollBar_DoEvents (wScrollBar*,HWND,cb_UInteger,WPARAM,LPARAM);
void wScrollBar_SetAddress (wScrollBar*);
wScrollBar* wScrollBar_Create (wScrollBar*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE | wScrollBar_SUBCLASS_BIT,double =0,double =0,double =100,double =1);
void wBox_SetBackColor (wBox*,COLORREF,COLORREF =CLR_INVALID,cb_Integer =FALSE);
void wBox_ResizeView (wBox*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wBox_Resize (wBox*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wBox_SetAutosize (wBox*,cb_Integer,cb_Integer =FALSE);
cb_Integer wBox_DoEvents (wBox*,HWND,cb_UInteger,WPARAM,LPARAM);
wBox* wBox_Create (wBox*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE | 4 | 8,const cb_String =NULL,cb_Integer =-1,cb_Integer =-1,double =0,double =100,double =1);
cb_PString Strings_RemoveQuotes (cb_String,cb_Integer* =NULL,cb_Integer* =NULL);
cb_PStringW Strings_RemoveQuotesW (cb_StringW,cb_Integer* =NULL,cb_Integer* =NULL);
cb_Integer Strings_StrInStr (const cb_String,const cb_String);
cb_Integer Strings_StrInStrW (const cb_StringW,const cb_StringW);
cb_PString Strings_FixFilePathName (const cb_String,void* =NULL,const cb_String =NULL);
cb_PStringW Strings_FixFilePathNameW (const cb_StringW,void* =NULL,const cb_StringW =NULL);
cb_PString Strings_GetFilefromPath (const cb_String,void* =NULL);
cb_PStringW Strings_GetFilefromPathW (const cb_StringW,void* =NULL);
cb_PString Strings_GetPathfromFile (const cb_String,void* =NULL);
cb_PStringW Strings_GetPathfromFileW (const cb_StringW,void* =NULL);
cb_Boolean Strings_ChkFileExtension (const cb_String,const cb_String);
cb_Boolean Strings_ChkFileExtensionW (const cb_StringW,const cb_StringW);
cb_PString Strings_GetDirUp (const cb_String,cb_Integer =1,void* =NULL);
cb_PStringW Strings_GetDirUpW (const cb_StringW,cb_Integer =1,void* =NULL);
cb_PString Strings_ChkSetBackSlashFast (cb_String);
cb_PStringW Strings_ChkSetBackSlashFastW (cb_StringW);
cb_Integer modInet_GetIPByNameAlias (const cb_String);
const cb_PString modInet_GetAscIP (IN_ADDR*);
const cb_PString modInet_ResolveIP (const cb_String);
cb_PString modInet_GetError (cb_Integer);
BOOL modFTP_MkDir (HINTERNET,const cb_String);
BOOL modFTP_RmDir (HINTERNET,const cb_String);
char* modFTP_GetDir (HINTERNET,void* =NULL);
BOOL modFTP_SetDir (HINTERNET,const cb_String);
BOOL modFTP_Rename (HINTERNET,const cb_String,const cb_String);
BOOL modFTP_Delete (HINTERNET,const cb_String);
BOOL modFTP_Command (HINTERNET,const cb_String,cb_Integer =-1);
cb_Boolean modFTP_IsFile (HINTERNET,const cb_String);
cb_Boolean modFTP_IsExist (HINTERNET,const cb_String);
HINTERNET modFTP_FindFirst (HINTERNET,const cb_String,WIN32_FIND_DATA*);
HINTERNET modFTP_FindNext (HINTERNET,WIN32_FIND_DATA*);
unsigned long long modFTP_GetFileSize (HINTERNET,const cb_String);
BOOL modFTP_GetFile (HINTERNET,const cb_String,const cb_String,const void* =NULL,cb_Integer =FALSE,DWORD =0,cb_Integer =-1);
BOOL modFTP_PutFile (HINTERNET,const cb_String,const cb_String,const void* =NULL,cb_Integer =-1);
cb_PString clsFTP_GetURL (clsFTP*,void* =NULL);
void clsFTP_SetURL (clsFTP*,const cb_String);
void clsFTP_SetPort (clsFTP*,cb_UInteger);
void clsFTP_SetUserName (clsFTP*,const cb_String);
void clsFTP_SetPassword (clsFTP*,const cb_String);
void clsFTP_SetProxy (clsFTP*,const cb_String);
void clsFTP_Disconnect (clsFTP*);
void clsFTP_Close (clsFTP*);
HINTERNET clsFTP_Open (clsFTP*,const cb_String =NULL,cb_Integer =0);
HINTERNET clsFTP_Connect (clsFTP*,const cb_String =NULL,const cb_String =NULL,const cb_String =NULL,const cb_String =NULL,cb_UInteger =0,cb_Integer =0);
HINTERNET clsFTP_ConnectSync (clsFTP*,const cb_String =NULL,cb_Integer =0);
cb_Integer clsFTP_MkDir (clsFTP*,const cb_String);
cb_Integer clsFTP_RmDir (clsFTP*,const cb_String);
char* clsFTP_GetDir (clsFTP*,void* =NULL);
cb_Integer clsFTP_SetDir (clsFTP*,const cb_String);
cb_Integer clsFTP_Rename (clsFTP*,const cb_String,const cb_String);
cb_Integer clsFTP_Delete (clsFTP*,const cb_String);
cb_Integer clsFTP_Command (clsFTP*,const cb_String,cb_Integer =-1);
cb_Integer clsFTP_IsFile (clsFTP*,const cb_String,HINTERNET =NULL);
cb_Integer clsFTP_IsExist (clsFTP*,const cb_String,HINTERNET =NULL);
cb_PString clsFTP_FindFirst (clsFTP*,const cb_String,void* =NULL,WIN32_FIND_DATA* =NULL);
cb_PString clsFTP_FindNext (clsFTP*,void* =NULL,WIN32_FIND_DATA* =NULL);
cb_PString clsFTP_List (clsFTP*,const cb_String =NULL,void* =NULL);
cb_Integer clsFTP_ListCount (clsFTP*,const cb_String =NULL,const cb_String =NULL);
cb_PString clsFTP_TempFileName (clsFTP*,const cb_String =NULL,const cb_String =NULL,void* =NULL);
unsigned long long clsFTP_GetFileSize (clsFTP*,const cb_String);
cb_Integer clsFTP_GetFile (clsFTP*,const cb_String,const cb_String =NULL,cb_Integer =FALSE,DWORD_PTR =0,cb_Integer =-1);
cb_Integer clsFTP_PutFile (clsFTP*,const cb_String,const cb_String =NULL,cb_Integer =FALSE,cb_Integer =-1);
EXTERN_C clsFTP* clsFTP_Initialize (clsFTP* =NULL,void* =NULL,void* =NULL);
EXTERN_C void clsFTP_Terminate (clsFTP*);
cb_PString watchDir_GetChanges (watchDir*,void* =NULL,void* =NULL,void* =NULL);
cb_Integer watchDir_HasChange (watchDir*,cb_Integer =0);
void watchDir_Enable (watchDir*,cb_Integer =TRUE);
void watchDir_Close (watchDir*);
watchDir* watchDir_Create (watchDir*,const cb_String =NULL);
cb_Integer watchDir_StartWatch (watchDir*,const cb_String =NULL,cb_Boolean =FALSE,DWORD_PTR =0,HWND =NULL,cb_UInteger =WM_USER+1,cb_Integer =FALSE);
void watchDir_Suspend (watchDir*);
cb_Integer watchDir_Resume (watchDir*);
HANDLE modShellExec_LaunchFile (const cb_String,const cb_String =NULL,const cb_String =NULL,HWND =(HWND)-1,cb_Integer =SW_SHOW);
cb_Integer wScrollBtn_GetInterval (wScrollBtn*);
void wScrollBtn_SetInterval (wScrollBtn*,cb_Integer);
void wScrollBtn_SetBackColor (wScrollBtn*,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Integer =FALSE);
void wScrollBtn_Refresh (wScrollBtn*,cb_Integer =FALSE);
void wScrollBtn_SetType (wScrollBtn*,cb_Integer);
void wScrollBtn_Resize (wScrollBtn*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
wScrollBtn* wScrollBtn_Create (wScrollBtn*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE,cb_Integer =1);
void ucCoolSB_Pause (ucCoolSB*);
void ucCoolSB_Resume (ucCoolSB*);
cb_Boolean ucCoolSB_IsOn (ucCoolSB*);
void ucCoolSB_Refresh (ucCoolSB*);
EXTERN_C ucCoolSB* ucCoolSB_Create (ucCoolSB*,HWND,void* =NULL,void* =NULL,cb_Integer =cb_MIN_INTEGER32,cb_Integer =cb_MIN_INTEGER32,cb_Integer =-1,cb_Integer =-1,cb_Integer =0,const cb_String =NULL,HFONT =NULL,cb_Integer =-1,cb_Integer =-1);
EXTERN_C void ucCoolSB_Destroy (ucCoolSB*);
cb_Boolean wListBox_GetColumnHeader (wListBox*);
void wListBox_SetColumnHeader (wListBox*,cb_Boolean =TRUE);
cb_Boolean wListBox_GetColumnHeaderSort (wListBox*);
void wListBox_SetColumnHeaderSort (wListBox*,cb_Boolean =TRUE);
cb_Integer wListBox_GetColumnLeft (wListBox*,cb_UInteger);
cb_Integer wListBox_GetColumnHeaderHeight (wListBox*);
void wListBox_SetColumnHeaderHeight (wListBox*,cb_Integer,cb_Integer =FALSE);
cb_PString wListBox_GetColumnTextA (wListBox*,cb_Integer,void* =NULL);
cb_PStringW wListBox_GetColumnTextW (wListBox*,cb_Integer,void* =NULL);
void wListBox_SetColumnTextA (wListBox*,cb_Integer,const cb_String);
void wListBox_SetColumnTextW (wListBox*,cb_Integer,const cb_StringW);
cb_Integer wListBox_GetColumnIndex (wListBox*,cb_Integer);
cb_Integer wListBox_GetColumnWidth (wListBox*,cb_Integer);
void wListBox_SetColumnWidth (wListBox*,cb_Integer,cb_Integer,cb_Integer =-1);
cb_Integer wListBox_ColumnAdd (wListBox*,const cb_String,cb_Integer =-1,cb_Integer =-1);
cb_Integer wListBox_ColumnAddW (wListBox*,const cb_StringW,cb_Integer =-1,cb_Integer =-1);
cb_Boolean wListBox_ColumnRemove (wListBox*,cb_Integer,cb_Integer =1);
void wListBox_ColumnClear (wListBox*);
cb_Boolean wListBox_GetAutoLabelEdit (wListBox*);
void wListBox_SetAutoLabelEdit (wListBox*,cb_Boolean =TRUE);
cb_Boolean wListBox_GetMultiSelect (wListBox*);
void wListBox_SetMultiSelect (wListBox*,cb_Boolean);
void wListBox_SetDropFiles (wListBox*,cb_Boolean =TRUE);
void wListBox_SetAutoDrag (wListBox*,cb_Boolean =TRUE);
void wListBox_SetRedraw (wListBox*,cb_Integer);
HWND wListBox_GetColumnHeaderhWnd (wListBox*);
cb_Integer wListBox_GetColumnCount (wListBox*);
cb_Integer wListBox_GetVisibleItems (wListBox*);
void* wListBox_GetText (wListBox*,cb_Integer =-1,cb_Integer =0,void* =NULL,cb_Integer =1,cb_UInteger =(cb_UInteger)-1);
cb_Integer wListBox_GetTextLen (wListBox*,cb_Integer =-1,cb_Integer =0,cb_Integer =1);
char* wListBox_GetTextA (wListBox*,cb_Integer =-1,cb_Integer =0,void* =NULL,cb_Integer =1,cb_UInteger =(cb_UInteger)-1);
cb_Integer wListBox_GetTextLenA (wListBox*,cb_Integer =-1,cb_Integer =0,cb_Integer =1);
wchar_t* wListBox_GetTextW (wListBox*,cb_Integer =-1,cb_Integer =0,void* =NULL,cb_Integer =1,cb_UInteger =(cb_UInteger)-1);
cb_Integer wListBox_GetTextLenW (wListBox*,cb_Integer =-1,cb_Integer =0,cb_Integer =1);
cb_Integer wListBox_InsertText (wListBox*,const void*,cb_Integer =-2);
cb_Integer wListBox_InsertTextA (wListBox*,const void*,cb_Integer =-2);
cb_Integer wListBox_InsertTextW (wListBox*,const void*,cb_Integer =-2);
cb_Integer wListBox_SetText (wListBox*,const void*,cb_Integer =-1,cb_Integer =0,cb_Integer =FALSE);
cb_Integer wListBox_SetTextA (wListBox*,const void*,cb_Integer =-1,cb_Integer =0,cb_Integer =FALSE);
cb_Integer wListBox_SetTextW (wListBox*,const void*,cb_Integer =-1,cb_Integer =0,cb_Integer =FALSE);
void wListBox_SetTag (wListBox*,cb_Boolean =TRUE);
char* wListBox_GetTagText (wListBox*,cb_Integer =-1,void* =NULL);
char* wListBox_GetTagTextA (wListBox*,cb_Integer =-1,void* =NULL);
wchar_t* wListBox_GetTagTextW (wListBox*,cb_Integer =-1,void* =NULL);
cb_Integer wListBox_SetTagText (wListBox*,const void*,cb_Integer =-1,cb_Integer =FALSE);
cb_Integer wListBox_SetTagTextA (wListBox*,const void*,cb_Integer =-1,cb_Integer =FALSE);
cb_Integer wListBox_SetTagTextW (wListBox*,const void*,cb_Integer =-1,cb_Integer =FALSE);
cb_Integer wListBox_GetItemData (wListBox*,cb_Integer =-1);
cb_Integer wListBox_SetItemData (wListBox*,cb_Integer,cb_Integer =-1);
cb_Integer wListBox_FindItemData (wListBox*,cb_Integer,cb_Integer =0);
cb_Integer wListBox_GetItemUserData (wListBox*,cb_Integer =-1);
cb_Integer wListBox_SetItemUserData (wListBox*,cb_Integer,cb_Integer =-1);
cb_Integer wListBox_FindItemUserData (wListBox*,cb_Integer,cb_Integer =0);
cb_Integer wListBox_FindItemA (wListBox*,const cb_String,cb_Integer =FALSE,cb_Integer =0,cb_Integer =0,cb_Integer =1);
cb_Integer wListBox_FindItemW (wListBox*,const cb_StringW,cb_Integer =FALSE,cb_Integer =0,cb_Integer =0,cb_Integer =1);
cb_Integer wListBox_FindItem (wListBox*,const void*,cb_Integer =FALSE,cb_Integer =0,cb_Integer =0,cb_Integer =1);
cb_Integer wListBox_GetIndex (wListBox*,const cb_String =NULL,cb_Integer =FALSE);
cb_Integer wListBox_GetIndexW (wListBox*,const cb_StringW =NULL,cb_Integer =FALSE);
cb_Boolean wListBox_GetChecked (wListBox*,cb_Integer =-1);
void wListBox_SetChecked (wListBox*,cb_Boolean,cb_Integer =-1);
cb_Integer wListBox_GetNextChecked (wListBox*,cb_Integer =0,cb_Integer =-1);
cb_Integer wListBox_GetPrevChecked (wListBox*,cb_Integer =0,cb_Integer =-1);
void wListBox_RemoveChecked (wListBox*,cb_Integer =-1,cb_Integer =-1);
void wListBox_Check (wListBox*,cb_Integer =0,cb_Integer =-1);
void wListBox_UnCheck (wListBox*,cb_Integer =0,cb_Integer =-1);
cb_Boolean wListBox_GetEnabled (wListBox*,cb_Integer =-1);
void wListBox_SetEnabled (wListBox*,cb_Boolean,cb_Integer =-1);
cb_Boolean wListBox_GetSelected (wListBox*,cb_Integer =-1);
void wListBox_SetSelected (wListBox*,cb_Boolean,cb_Integer =-1);
cb_Integer wListBox_GetSelectedIndex (wListBox*);
void wListBox_SetSelectedIndex (wListBox*,cb_Integer =-2);
cb_Integer wListBox_GetSelectedItem (wListBox*);
cb_Integer wListBox_GetCurrentItem (wListBox*);
cb_Integer wListBox_SetCurrentItem (wListBox*,cb_Integer =-2,cb_Boolean =TRUE);
cb_Integer wListBox_UnSetCurrentItem (wListBox*,cb_Integer);
cb_Integer wListBox_Remove (wListBox*,cb_Integer =-1);
cb_Integer wListBox_GetNextSelected (wListBox*,cb_Integer =0,cb_Integer =-1);
cb_Integer wListBox_GetPrevSelected (wListBox*,cb_Integer =-1,cb_Integer =0);
void wListBox_RemoveSelected (wListBox*,cb_Integer =-1,cb_Integer =-1);
void wListBox_Select (wListBox*,cb_Integer =0,cb_Integer =-1);
void wListBox_UnSelect (wListBox*,cb_Integer =0,cb_Integer =-1);
void wListBox_SortItems (wListBox*,cb_Integer =-1,cb_Integer =-1);
cb_Boolean wListBox_GetSorted (wListBox*);
void wListBox_SetSorted (wListBox*,cb_Boolean =TRUE);
HIMAGELIST wListBox_GetSmallIcons (wListBox*);
HIMAGELIST wListBox_CreateImageList (wListBox*,cb_Integer =-1);
void wListBox_Clear (wListBox*);
cb_Integer wListBox_GetItemImage (wListBox*,cb_Integer =-1);
void wListBox_SetItemImage (wListBox*,cb_Integer,cb_Integer =-1);
HBITMAP wListBox_GetImage (wListBox*,cb_Integer =-1);
HBITMAP wListBox_SetImage (wListBox*,HBITMAP,cb_Integer =-1);
HWND wListBox_GethWndLabelEdit (wListBox*);
void* wListBox_GetLabelEditText (wListBox*,void* =NULL);
void wListBox_SetLabelEditText (wListBox*,const void*);
cb_Integer wListBox_GetTopIndex (wListBox*);
void wListBox_SetTopIndex (wListBox*,cb_Integer);
cb_Integer wListBox_GetBottomIndex (wListBox*);
void wListBox_SetBottomIndex (wListBox*,cb_Integer);
cb_Integer wListBox_GetItemLeft_ (wListBox*);
cb_Integer wListBox_GetItemTop (wListBox*,cb_Integer =-1);
cb_Integer wListBox_GetItemWidth (wListBox*,cb_Integer =-1);
cb_Integer wListBox_GetItemHeight (wListBox*,cb_Integer =0);
void wListBox_EnsureVisible (wListBox*,cb_Integer =-1);
cb_Integer wListBox_BackupItemSelected (wListBox*,cb_Integer);
cb_Integer wListBox_RestoreItemSelected (wListBox*,cb_Integer);
cb_Integer wListBox_HitTest (wListBox*,cb_Integer* =NULL);
cb_Integer wListBox_SubItemHitTest (wListBox*);
cb_Boolean wListBox_GetItemRect (wListBox*,RECT*,cb_Integer =-1,cb_Integer =0);
cb_Boolean wListBox_GetColumnPos (wListBox*,cb_Integer);
cb_Boolean wListBox_GetFullRowSelect (wListBox*);
void wListBox_SetFullRowSelect (wListBox*,cb_Boolean =TRUE);
cb_Integer wListBox_GetGridLines (wListBox*);
void wListBox_SetGridLines (wListBox*,cb_Integer =-1,cb_Boolean =FALSE);
void wListBox_SetBackColor (wListBox*,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Boolean =FALSE,cb_Boolean =FALSE);
void wListBox_SetForeColor (wListBox*,COLORREF =CLR_INVALID,cb_Boolean =FALSE);
void wListBox_SetColumnBackColor (wListBox*,cb_Integer =-1,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Boolean =FALSE,cb_Boolean =FALSE);
void wListBox_SetColumnForeColor (wListBox*,COLORREF =CLR_INVALID,cb_Integer =-1,cb_Boolean =FALSE);
void wListBox_SetItemBackColor (wListBox*,cb_Integer =-1,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Boolean =FALSE,cb_Boolean =FALSE);
void wListBox_SetItemForeColor (wListBox*,COLORREF =CLR_INVALID,cb_Integer =-1,cb_Boolean =FALSE);
void wListBox_Resize (wListBox*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wListBox_Reset (wListBox*);
void wListBox_Refresh (wListBox*);
cb_Integer wListBox_GetCheckBoxes (wListBox*);
void wListBox_SetCheckBoxes (wListBox*,cb_Integer =1,cb_Boolean =FALSE);
cb_Boolean wListBox_GetUnicode (wListBox*);
void wListBox_SetUnicode (wListBox*,cb_Boolean);
void wListBox_EndLabelEdit (wListBox*,cb_Integer);
void wListBox_SetFocus (wListBox*);
void wListBox_Destroy (wListBox*);
void wListBox_StartLabelEdit (wListBox*,cb_Integer =-1,cb_Integer =-1);
void wListBox_SetAutoHScrollBar (wListBox*,cb_Integer);
void wListBox_SetAutoVScrollBar (wListBox*,cb_Integer);
cb_Integer wListBox_GetLeft (wListBox*);
void wListBox_SetLeft (wListBox*,cb_Integer);
cb_Integer wListBox_GetTop (wListBox*);
void wListBox_SetTop (wListBox*,cb_Integer);
cb_Integer wListBox_GetWidth (wListBox*);
void wListBox_SetWidth (wListBox*,cb_Integer);
cb_Integer wListBox_GetHeight (wListBox*);
void wListBox_SetHeight (wListBox*,cb_Integer);
wListBox* wListBox_Create (wListBox*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =cb_MIN_INTEGER32 | TRUE);
cb_LOGFONT* modEDIT_GetFont (HWND,cb_LOGFONT* =NULL,HFONT =NULL);
cb_LOGFONT* modEDIT_SetFont (HWND,cb_LOGFONT* =NULL,HFONT =NULL,cb_Boolean =FALSE);
cb_Integer modEDIT_GetTextLen (HWND);
cb_Integer modEDIT_GetMaxLen (HWND);
void modEDIT_SetMaxLen (HWND,cb_Integer =0x800000);
cb_Integer modEDIT_GetSelection (HWND,cb_Integer* =NULL);
void modEDIT_SetSelection (HWND,cb_Integer =0,cb_Integer =-1);
cb_Integer modEDIT_GetSelStart (HWND,cb_Integer* =NULL);
void modEDIT_SetSelStart (HWND,cb_Integer =-1,cb_Integer =0);
cb_Integer modEDIT_GetSelEnd (HWND);
cb_Integer modEDIT_GetSelLen (HWND,cb_Integer* =NULL);
void modEDIT_SetSelLen (HWND,cb_Integer,cb_Integer =-1);
cb_Integer modEDIT_LineFromChar (HWND,cb_Integer);
cb_Integer modEDIT_GetCurrentLine (HWND);
cb_Integer modEDIT_CharFromLine (HWND,cb_Integer);
cb_Integer modEDIT_GetCurrentCol (HWND,cb_Integer* =NULL);
cb_Integer modEDIT_GetLastLine (HWND);
cb_Integer modEDIT_GetLineLen (HWND,cb_Integer =-1);
cb_Integer modEDIT_CanUndo (HWND);
cb_Integer modEDIT_Undo (HWND);
cb_Integer modEDIT_SelectLine (HWND,cb_Integer =-1,cb_Integer* =NULL,cb_Boolean =TRUE);
cb_PString modEDIT_GetLine (HWND,cb_Integer =-1,void* =NULL,cb_Integer* =NULL);
cb_Integer modEDIT_SetLine (HWND,const cb_String,cb_Integer =-1);
void modEDIT_Delete (HWND);
void modEDIT_EnsureVisible (HWND);
void modEDIT_SetModify (HWND,cb_Integer =FALSE);
cb_Integer modEDIT_GetScrollBarH (HWND);
void modEDIT_SetScrollBarH (HWND,cb_Integer);
cb_Integer modEDIT_GetScrollBarV (HWND);
void modEDIT_SetScrollBarV (HWND,cb_Integer);
cb_Integer modEDIT_GoToLine (HWND,cb_Integer =0,cb_Integer =0);
cb_Integer modEDIT_FindText (HWND,const cb_String,cb_Integer =-1,cb_Integer =-1,cb_Integer =FR_DOWN,cb_Boolean =TRUE);
cb_PString modEval_Parse (cb_String,double*,cb_Integer* =NULL,cb_Integer =FALSE);
void wTextBox_SetBackColor (wTextBox*,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Integer =FALSE);
void wTextBox_SetForeColor (wTextBox*,COLORREF);
cb_LOGFONT* wTextBox_GetFont (wTextBox*,cb_LOGFONT* =NULL,HFONT =NULL);
cb_LOGFONT* wTextBox_SetFont (wTextBox*,HFONT,cb_LOGFONT* =NULL,cb_Boolean =FALSE);
cb_Integer wTextBox_GetSelection (wTextBox*,cb_Integer* =NULL);
void wTextBox_SetSelection (wTextBox*,cb_Integer =0,cb_Integer =-1);
cb_Integer wTextBox_AddText (wTextBox*,const void*);
cb_Integer wTextBox_AddTextA (wTextBox*,const cb_String);
cb_Integer wTextBox_ReplaceText (wTextBox*,const void*);
cb_Integer wTextBox_ReplaceTextA (wTextBox*,const cb_String);
void* wTextBox_GetText_ (wTextBox*,cb_Integer =FALSE,void* =NULL,cb_Integer* =NULL);
cb_PString wTextBox_GetTextA_ (wTextBox*,cb_Integer =FALSE,void* =NULL,cb_Integer* =NULL);
cb_Integer wTextBox_SetText (wTextBox*,const void*);
cb_Integer wTextBox_SetTextA (wTextBox*,const cb_String);
cb_Integer wTextBox_GetSelStart (wTextBox*,cb_Integer* =NULL);
void wTextBox_SetSelStart (wTextBox*,cb_Integer =-1,cb_Integer =0);
cb_Integer wTextBox_GetSelEnd (wTextBox*);
cb_Integer wTextBox_GetSelLen (wTextBox*,cb_Integer* =NULL);
void wTextBox_SetSelLen (wTextBox*,cb_Integer,cb_Integer =-1);
cb_Integer wTextBox_LineFromChar (wTextBox*,cb_Integer);
cb_Integer wTextBox_GetCurrentLine (wTextBox*);
cb_Integer wTextBox_CharFromLine (wTextBox*,cb_Integer);
cb_Integer wTextBox_GetCurrentCol (wTextBox*,cb_Integer* =NULL);
cb_Integer wTextBox_GetLastLine (wTextBox*);
cb_Integer wTextBox_GetLineLen (wTextBox*,cb_Integer =-1);
cb_Integer wTextBox_CanUndo (wTextBox*);
cb_Integer wTextBox_Undo (wTextBox*);
cb_Integer wTextBox_SelectLine (wTextBox*,cb_Integer =-1,cb_Integer* =NULL,cb_Boolean =TRUE);
cb_PString wTextBox_GetLine (wTextBox*,cb_Integer =-1,void* =NULL,cb_Integer* =NULL);
cb_Integer wTextBox_SetLine (wTextBox*,const cb_String,cb_Integer =-1);
cb_Integer wTextBox_GetMaxLen (wTextBox*);
void wTextBox_SetMaxLen (wTextBox*,cb_Integer =wTextBox_MAXLEN);
void wTextBox_Delete (wTextBox*);
void wTextBox_EnsureVisible (wTextBox*);
cb_Integer wTextBox_GetModify (wTextBox*);
void wTextBox_SetModify (wTextBox*,cb_Integer =FALSE);
cb_Integer wTextBox_GoToLine (wTextBox*,cb_Integer =0,cb_Integer =0);
cb_Integer wTextBox_FindText (wTextBox*,const cb_String,cb_Integer =-1,cb_Integer =-1,cb_Integer =FR_DOWN,cb_Boolean =TRUE);
void wTextBox_SetDropFiles (wTextBox*,cb_Boolean);
cb_Boolean wTextBox_GetFocus (wTextBox*);
cb_Integer wTextBox_GetScrollBarH (wTextBox*);
void wTextBox_SetScrollBarH (wTextBox*,cb_Integer);
cb_Integer wTextBox_GetScrollBarV (wTextBox*);
void wTextBox_SetScrollBarV (wTextBox*,cb_Integer);
void wTextBox_SetScrollBars (wTextBox*,cb_Integer);
void wTextBox_Resize (wTextBox*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
double wTextBox_GetValue (wTextBox*);
cb_Integer wTextBox_GetResult (wTextBox*,double*);
wTextBox* wTextBox_Create (wTextBox*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =cb_MIN_INTEGER32 | 1 | 4,const cb_StringW =NULL,HFONT =NULL,cb_Integer =-1);
cb_Integer wComboBox_Refresh (wComboBox*,cb_Integer =-1);
void wComboBox_SetForeColor (wComboBox*,COLORREF);
void wComboBox_SetBackColor (wComboBox*,COLORREF,COLORREF =CLR_INVALID,cb_Integer =FALSE);
cb_Integer wComboBox_GetCount (wComboBox*);
cb_Integer wComboBox_GetIndex (wComboBox*,const cb_String =NULL,cb_Integer =FALSE);
cb_Integer wComboBox_GetCurrentItem (wComboBox*);
cb_Integer wComboBoxGetHeight (wComboBox*);
cb_Integer wComboBoxGetListHeight (wComboBox*);
void wComboBox_SetListHeight (wComboBox*,cb_Integer =wComboBox_List_HEIGHT_);
cb_Integer wComboBox_SetCurrentItem (wComboBox*,cb_Integer =-2,const void* =NULL);
cb_Integer wComboBox_InsertText (wComboBox*,const void*,cb_Integer =-2,cb_Integer =FALSE);
cb_Integer wComboBox_Add (wComboBox*,const cb_String,cb_Integer =FALSE);
cb_Integer wComboBox_Remove (wComboBox*,cb_Integer =-1);
cb_Integer wComboBox_GetItemData (wComboBox*,cb_Integer =-1);
cb_Integer wComboBox_SetItemData (wComboBox*,cb_Integer,cb_Integer =-1);
void wComboBox_SetText (wComboBox*,const void*,cb_Integer =-1);
void wComboBox_SetTag (wComboBox*,cb_Boolean);
void wComboBox_SetTagText (wComboBox*,const void*,cb_Integer =-1);
void wComboBox_SetFocus (wComboBox*);
cb_Integer wComboBox_FindItemData (wComboBox*,cb_Integer,cb_Integer =0);
cb_Integer wComboBox_FindItem (wComboBox*,const void*,cb_Integer =FALSE,cb_Integer =0,cb_Integer =0);
void wComboBox_Resize (wComboBox*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
wComboBox* wComboBox_Create (wComboBox*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =cb_MIN_INTEGER32 | TRUE);
cb_Boolean wTreeView_GetAutoLabelEdit (wTreeView*);
void wTreeView_SetAutoLabelEdit (wTreeView*,cb_Boolean);
cb_Integer wTreeView_GetCount (wTreeView*);
HTREEITEM wTreeView_GetLast (wTreeView*,cb_Integer =-1);
cb_Integer wTreeView_GetNodeCount (wTreeView*,HTREEITEM =NULL,cb_Integer =-1);
HWND wTreeView_GethWnd (wTreeView*);
HTREEITEM wTreeView_GetIndex (wTreeView*);
void wTreeView_Remove (wTreeView*,HTREEITEM =NULL);
void wTreeView_Clear (wTreeView*,cb_Integer =0);
void wTreeView_EnsureVisible (wTreeView*,HTREEITEM =NULL);
void wTreeView_Add (wTreeView*,const cb_String,HTREEITEM =(HTREEITEM)-1,HTREEITEM =NULL);
cb_PString wTreeView_GetText (wTreeView*,HTREEITEM =NULL,void* =NULL,HTREEITEM =NULL);
void wTreeView_SetText (wTreeView*,const cb_String,HTREEITEM =NULL,HTREEITEM =NULL);
cb_Integer wTreeView_GetItemData (wTreeView*,HTREEITEM =NULL);
void wTreeView_SetItemData (wTreeView*,cb_Integer,HTREEITEM =NULL);
cb_Boolean wTreeView_GetItemFocus (wTreeView*,HTREEITEM =NULL);
HTREEITEM wTreeView_SetItemFocus (wTreeView*,cb_Boolean,HTREEITEM =NULL);
cb_Boolean wTreeView_GetSelected (wTreeView*,HTREEITEM =NULL);
void wTreeView_SetSelected (wTreeView*,cb_Boolean,HTREEITEM =NULL);
cb_Boolean wTreeView_GetChecked (wTreeView*,HTREEITEM =NULL);
void wTreeView_SetChecked (wTreeView*,cb_Boolean,HTREEITEM =NULL);
HTREEITEM wTreeView_GetSelectedItem (wTreeView*);
HTREEITEM wTreeView_SetSelectedItem (wTreeView*,HTREEITEM,cb_Boolean =FALSE);
HWND wTreeView_GethWndLabelEdit (wTreeView*);
cb_PString wTreeView_GetLabelEditText (wTreeView*,void* =NULL);
void wTreeView_SetLabelEditText (wTreeView*,cb_String);
HTREEITEM wTreeView_HitTest (wTreeView*,cb_Integer =-1,cb_Integer =-1);
cb_Integer wTreeView_GetItemHeight (wTreeView*,HTREEITEM =NULL);
cb_Boolean wTreeView_GetItemRect (wTreeView*,RECT*,HTREEITEM =NULL,cb_Integer =TRUE);
cb_Boolean wTreeView_GetItemPos (wTreeView*,POINT*,HTREEITEM =NULL);
cb_Boolean wTreeView_GetItemWindowRect (wTreeView*,RECT*,HTREEITEM =NULL,cb_Integer =TRUE);
void wTreeView_SetBackColor (wTreeView*,COLORREF);
void wTreeView_SetForeColor (wTreeView*,COLORREF);
void wTreeView_Resize (wTreeView*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wTreeView_EndLabelEdit (wTreeView*,cb_Integer);
void wTreeView_StartLabelEdit (wTreeView*,HTREEITEM,HTREEITEM =NULL);
cb_Integer wTreeView_GetLeft (wTreeView*);
void wTreeView_SetLeft (wTreeView*,cb_Integer);
cb_Integer wTreeView_GetTop (wTreeView*);
void wTreeView_SetTop (wTreeView*,cb_Integer);
cb_Integer wTreeView_GetWidth (wTreeView*);
void wTreeView_SetWidth (wTreeView*,cb_Integer);
cb_Integer wTreeView_GetHeight (wTreeView*);
void wTreeView_SetHeight (wTreeView*,cb_Integer);
void wTreeView_SetFocus (wTreeView*);
void wTreeView_Destroy (wTreeView*);
wTreeView* wTreeView_Create (wTreeView*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =cb_MIN_INTEGER32 | TRUE);
cb_Boolean wCommander_FTPIsReady (wCommander*);
cb_Boolean wCommander_FTPIsConnected (wCommander*);
cb_Integer wCommander_FTPIsFile (wCommander*,const cb_String,HINTERNET =NULL);
cb_Integer wCommander_FTPIsExist (wCommander*,const cb_String,HINTERNET =NULL);
cb_Integer wCommander_FTPIsFolder (wCommander*,const cb_String,HINTERNET =NULL);
char* wCommander_FTPFindFirst (wCommander*,const cb_String,void* =NULL);
char* wCommander_FTPFindNext (wCommander*,void* =NULL);
char* wCommander_FTPList (wCommander*,const cb_String,void* =NULL);
char* wCommander_TempFileName (wCommander*,const cb_String =NULL,const cb_String =NULL,void* =NULL);
cb_Integer wCommander_FTPMkDir (wCommander*,const cb_String);
cb_Integer wCommander_FTPRmDir (wCommander*,const cb_String =NULL);
char* wCommander_FTPGetDir (wCommander*,void* =NULL);
cb_Integer wCommander_FTPSetDir (wCommander*,const cb_String =NULL);
cb_Integer wCommander_FTPRename (wCommander*,const cb_String,const cb_String);
cb_Integer wCommander_FTPDelete (wCommander*,const cb_String);
cb_Integer wCommander_FTPGetFile (wCommander*,const cb_String =NULL,const cb_String =NULL,cb_Integer =FALSE,DWORD =0,cb_Integer =-1);
cb_Integer wCommander_FTPPutFile (wCommander*,const cb_String,const cb_String =NULL,cb_Integer =FALSE,cb_Integer =-1);
cb_Integer wCommander_Connect (wCommander*,const cb_String,const cb_String =NULL,cb_String =NULL,const cb_String =NULL,cb_UInteger =0,cb_Integer =FALSE);
cb_Integer wCommander_StopWatch (wCommander*);
cb_Integer wCommander_StartWatch (wCommander*,cb_Integer =-1,DWORD =(DWORD)-1);
cb_Integer wCommander_GetWatchChilds (wCommander*);
void wCommander_SetWatchChilds (wCommander*,cb_Integer =FALSE);
DWORD wCommander_GetWatchMask (wCommander*);
void wCommander_SetWatchMask (wCommander*,DWORD =0);
cb_Boolean wCommander_GetWatchAll (wCommander*);
void wCommander_SetWatchAll (wCommander*,cb_Integer =FALSE);
cb_Boolean wCommander_GetAutoWatch (wCommander*);
void wCommander_SetAutoWatch (wCommander*,cb_Integer =FALSE);
cb_Boolean wCommander_GetAutoLabelEdit (wCommander*);
void wCommander_SetAutoLabelEdit (wCommander*,cb_Boolean =TRUE);
cb_Boolean wCommander_GetAutoDelete (wCommander*);
void wCommander_SetAutoDelete (wCommander*,cb_Integer =FALSE);
cb_Boolean wCommander_GetAutoExec (wCommander*);
void wCommander_SetAutoExec (wCommander*,cb_Integer =FALSE);
cb_Boolean wCommander_GetAutoRename (wCommander*);
void wCommander_SetAutoRename (wCommander*,cb_Integer =FALSE);
cb_Integer wCommander_GetGridLines (wCommander*);
void wCommander_SetGridLines (wCommander*,cb_Integer =-1,cb_Boolean =FALSE);
cb_Boolean wCommander_GetColumnHeader (wCommander*);
void wCommander_SetColumnHeader (wCommander*,cb_Boolean =TRUE);
cb_Boolean wCommander_GetColumnHeaderSort (wCommander*);
void wCommander_SetColumnHeaderSort (wCommander*,cb_Boolean =TRUE);
cb_Boolean wCommander_GetBackSlash (wCommander*);
void wCommander_SetBackSlash (wCommander*,cb_Boolean =TRUE);
void wCommander_StartLabelEdit (wCommander*,cb_Integer =-1,cb_Integer =-1,cb_Boolean =FALSE);
cb_PString wCommander_GetFileName (wCommander*,cb_Integer =-1,void* =NULL,cb_Integer =TRUE);
cb_PString wCommander_GetDirName (wCommander*,cb_Integer =-1,void* =NULL,cb_Integer =FALSE);
void wCommander_FillDrives (wCommander*);
cb_Int64 wCommander_FillFiles (wCommander*,const cb_String =NULL,cb_Integer =FALSE);
void wCommander_SetSmallIcons (wCommander*,cb_Integer);
cb_Int64 wCommander_Fill (wCommander*,const cb_String =NULL,cb_Integer =-1);
cb_PString wCommander_GetMask (wCommander*);
void wCommander_SetMask (wCommander*,const cb_String);
void wCommander_SetBackColor (wCommander*,COLORREF);
void wCommander_SetForeColor (wCommander*,COLORREF);
cb_Boolean wCommander_GetMultiSelect (wCommander*,cb_Integer =FALSE);
void wCommander_SetMultiSelect (wCommander*,cb_Boolean,cb_Integer =-1);
void wCommander_SetCheckBoxes (wCommander*,cb_Integer =FALSE,cb_Integer =FALSE,cb_Boolean =FALSE);
cb_Boolean wCommander_IsDir (wCommander*,const cb_String,cb_Integer =TRUE);
cb_PString wCommander_GetPath (wCommander*,void* =NULL);
cb_Boolean wCommander_ChangeDir (wCommander*,const cb_String =NULL,cb_Integer =FALSE);
cb_Integer wCommander_FindFolder (wCommander*,const cb_String,cb_Integer =0);
cb_Integer wCommander_FindFile (wCommander*,const cb_String,cb_Integer =0);
void wCommander_Resize (wCommander*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wCommander_Destroy (wCommander*);
wCommander* wCommander_Create (wCommander*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,const cb_String =NULL,cb_Integer =cb_MIN_INTEGER32 | 0x1F7);
cb_Integer clsSCI_GetScrollWidth (clsSCI*);
void clsSCI_SetScrollWidth (clsSCI*,cb_Integer);
cb_Integer clsSCI_LinesOnScreen (clsSCI*);
cb_Integer clsSCI_GetXOffset (clsSCI*);
void clsSCI_SetXOffset (clsSCI*,cb_Integer);
void clsSCI_LineScroll (clsSCI*,cb_Integer,cb_Integer =0);
cb_Integer clsSCI_GetZoom (clsSCI*);
void clsSCI_SetZoom (clsSCI*,cb_Integer =0);
void clsSCI_ZoomIn (clsSCI*);
void clsSCI_ZoomOut (clsSCI*);
void clsSCI_SetForeColor (clsSCI*,COLORREF,cb_Integer =-1);
void clsSCI_SetBackColor (clsSCI*,COLORREF,cb_Integer =-1);
void clsSCI_SetSelBackColor (clsSCI*,COLORREF);
void clsSCI_SetSelForeColor (clsSCI*,COLORREF);
void clsSCI_SetCallTipBackColor (clsSCI*,COLORREF);
void clsSCI_SetCallTipForeColor (clsSCI*,COLORREF);
void clsSCI_SetCallTipHighLightColor (clsSCI*,COLORREF);
cb_Integer clsSCI_GetFolderWidth (clsSCI*);
void clsSCI_SetFolderWidth (clsSCI*,cb_Integer =0);
cb_Integer clsSCI_GetMarginWidth (clsSCI*);
void clsSCI_SetMarginWidth (clsSCI*,cb_Integer =0);
cb_Integer clsSCI_GetLineNumberWidth (clsSCI*);
void clsSCI_SetLineNumberWidth (clsSCI*,cb_Integer =0);
void clsSCI_SetWordChars (clsSCI*,const cb_String);
void clsSCI_SetWhitespaceChars (clsSCI*,const cb_String);
cb_Integer clsSCI_GetWhitespaceMode (clsSCI*);
void clsSCI_SetWhitespaceMode (clsSCI*,cb_Integer);
void clsSCI_SetWhitespaceBackColor (clsSCI*,COLORREF =-1);
void clsSCI_SetWhitespaceForeColor (clsSCI*,COLORREF =-1);
COLORREF clsSCI_GetCaretColor (clsSCI*);
void clsSCI_SetCaretColor (clsSCI*,COLORREF);
cb_Integer clsSCI_GetCaretWidth (clsSCI*);
void clsSCI_SetCaretWidth (clsSCI*,cb_Integer);
COLORREF clsSCI_GetCaretLineBack (clsSCI*);
void clsSCI_SetCaretLineBack (clsSCI*,COLORREF =-1);
void clsSCI_SetFoldMarginBackColor (clsSCI*,COLORREF =-1);
void clsSCI_SetFoldMarginForeColor (clsSCI*,COLORREF =-1);
cb_Integer clsSCI_GetOvertype (clsSCI*);
void clsSCI_SetOvertype (clsSCI*,cb_Integer);
void clsSCI_EditToggleOvertype (clsSCI*);
void clsSCI_Cancel (clsSCI*);
cb_Integer clsSCI_GetTabWidth (clsSCI*);
void clsSCI_SetTabWidth (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetIndentSize (clsSCI*);
void clsSCI_SetIndentSize (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetWrapMode (clsSCI*);
void clsSCI_SetWrapMode (clsSCI*,cb_Integer);
cb_Boolean clsSCI_GetIndentationGuides (clsSCI*);
void clsSCI_SetIndentationGuides (clsSCI*,cb_Boolean);
cb_Integer clsSCI_GetHighlightGuide (clsSCI*);
void clsSCI_SetHighlightGuide (clsSCI*,cb_Integer);
cb_LOGFONT* clsSCI_GetFont (clsSCI*,cb_LOGFONT* =NULL);
void clsSCI_SetFontName (clsSCI*,const cb_String,cb_Integer =-1);
void clsSCI_SetFontSize (clsSCI*,cb_Integer,cb_Integer =-1);
void clsSCI_SetFontBold (clsSCI*,cb_Integer,cb_Integer =-1);
void clsSCI_SetFontItalic (clsSCI*,cb_Integer,cb_Integer =-1);
void clsSCI_SetFontUnderline (clsSCI*,cb_Integer,cb_Integer =-1);
void clsSCI_SetFontCharacterSet (clsSCI*,cb_Integer,cb_Integer =-1);
void clsSCI_SetFontStrikeOut (clsSCI*,cb_Integer =0);
cb_LOGFONT* clsSCI_SetFont (clsSCI*,cb_LOGFONT* =NULL);
cb_Integer clsSCI_GetTextLen (clsSCI*);
cb_Integer clsSCI_LineCount (clsSCI*);
cb_Integer clsSCI_GetFirstVisibleLine (clsSCI*);
cb_Integer clsSCI_LineFromChar (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetCurrentLine (clsSCI*);
cb_Integer clsSCI_CharFromLine (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetCurrentPos (clsSCI*);
cb_Integer clsSCI_GetCharOfPos (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetCurrentChar (clsSCI*);
cb_Integer clsSCI_GetEOLMode (clsSCI*);
void clsSCI_SetEOLMode (clsSCI*,cb_Integer);
void clsSCI_ConvertEOL (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetCaretInterval (clsSCI*);
void clsSCI_SetCaretInterval (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetViewCaretLine (clsSCI*);
void clsSCI_SetViewCaretLine (clsSCI*,cb_Integer);
cb_Integer clsSCI_LineDown (clsSCI*);
cb_Integer clsSCI_LineDownExtend (clsSCI*);
cb_Integer clsSCI_LineUp (clsSCI*);
cb_Integer clsSCI_LineUpExtend (clsSCI*);
cb_Integer clsSCI_CharLeft (clsSCI*);
cb_Integer clsSCI_CharLeftExtend (clsSCI*);
cb_Integer clsSCI_CharRight (clsSCI*);
cb_Integer clsSCI_CharRightExtend (clsSCI*);
cb_Integer clsSCI_WordLeft (clsSCI*);
cb_Integer clsSCI_WordLeftExtend (clsSCI*);
cb_Integer clsSCI_WordRight (clsSCI*);
cb_Integer clsSCI_WordRightExtend (clsSCI*);
cb_Integer clsSCI_Home (clsSCI*);
cb_Integer clsSCI_HomeExtend (clsSCI*);
cb_Integer clsSCI_LineEnd (clsSCI*);
cb_Integer clsSCI_LineEndExtend (clsSCI*);
cb_Integer clsSCI_HomeDisplay (clsSCI*);
cb_Integer clsSCI_HomeDisplayExtend (clsSCI*);
cb_Integer clsSCI_LineEndDisplay (clsSCI*);
cb_Integer clsSCI_LineEndDisplayExtend (clsSCI*);
cb_Integer clsSCI_DocumentStart (clsSCI*);
cb_Integer clsSCI_DocumentStartExtend (clsSCI*);
cb_Integer clsSCI_DocumentEnd (clsSCI*);
cb_Integer clsSCI_DocumentEndExtend (clsSCI*);
cb_Integer clsSCI_PageUp (clsSCI*);
cb_Integer clsSCI_PageUpExtend (clsSCI*);
cb_Integer clsSCI_PageDown (clsSCI*);
cb_Integer clsSCI_PageDownExtend (clsSCI*);
cb_Integer clsSCI_VCHome (clsSCI*);
cb_Integer clsSCI_VCHomeExtend (clsSCI*);
cb_Boolean clsSCI_GetViewEOL (clsSCI*);
void clsSCI_SetViewEOL (clsSCI*,cb_Boolean);
void clsSCI_EmptyUndoBuffer (clsSCI*);
cb_Integer clsSCI_GetModify (clsSCI*);
void clsSCI_SetModify (clsSCI*);
void clsSCI_ResetModify (clsSCI*);
cb_Boolean clsSCI_GetReadOnly (clsSCI*);
void clsSCI_SetReadOnly (clsSCI*,cb_Boolean);
cb_Integer clsSCI_GetScrollBarH (clsSCI*);
void clsSCI_SetScrollBarH (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetScrollBarV (clsSCI*);
void clsSCI_SetScrollBarV (clsSCI*,cb_Integer);
void clsSCI_SetScrollBars (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetLastLine (clsSCI*);
cb_Integer clsSCI_GetLineLen (clsSCI*,cb_Integer =-1,cb_Integer =FALSE);
void clsSCI_Clear (clsSCI*);
void clsSCI_Allocate (clsSCI*,cb_Integer);
void clsSCI_AddText (clsSCI*,const cb_String,cb_Boolean =FALSE);
void clsSCI_AddStyledText (clsSCI*,const cb_String,cb_Boolean =FALSE);
void clsSCI_AppendText (clsSCI*,const cb_String,cb_Boolean =FALSE);
void clsSCI_InsertText (clsSCI*,const cb_String,cb_Integer =-1);
cb_Integer clsSCI_GetSelection (clsSCI*,cb_Integer* =NULL);
void clsSCI_SetSelection (clsSCI*,cb_Integer =0,cb_Integer =-1);
cb_Integer clsSCI_GetSelStart (clsSCI*,cb_Integer* =NULL);
void clsSCI_SetSelStart (clsSCI*,cb_Integer =-1,cb_Integer =0);
cb_Integer clsSCI_GetSelLen (clsSCI*,cb_Integer* =NULL);
void clsSCI_SetSelLen (clsSCI*,cb_Integer,cb_Integer =-1);
cb_Integer clsSCI_GetCurrentCol (clsSCI*,cb_Integer* =NULL);
void clsSCI_Delete (clsSCI*);
void clsSCI_ClearSel (clsSCI*,cb_Integer =-1,cb_Integer =-1);
cb_PString clsSCI_GetText_ (clsSCI*,cb_Integer =FALSE,void* =NULL,cb_Integer* =NULL);
cb_PString clsSCI_GetTextRange (clsSCI*,cb_Integer =0,cb_Integer =0,void* =NULL);
cb_Integer clsSCI_ReplaceText (clsSCI*,const cb_String);
cb_Integer clsSCI_SetText (clsSCI*,const cb_String,cb_Integer =FALSE);
cb_PString clsSCI_GetWord (clsSCI*,cb_Integer,void* =NULL,cb_Integer =-1,cb_Integer =-1);
cb_Integer clsSCI_SelectLine (clsSCI*,cb_Integer =-1,cb_Integer* =NULL,cb_Boolean =TRUE);
cb_PString clsSCI_GetLine (clsSCI*,cb_Integer =-1,void* =NULL,cb_Integer* =NULL);
cb_Integer clsSCI_SetLine (clsSCI*,const cb_String,cb_Integer =-1);
cb_Integer clsSCI_EnsureVisible (clsSCI*);
cb_Integer clsSCI_GoToPos (clsSCI*,cb_Integer);
cb_Integer clsSCI_GoToLine (clsSCI*,cb_Integer =0,cb_Integer =0);
cb_Integer clsSCI_CanUndo (clsSCI*);
cb_Integer clsSCI_CanRedo (clsSCI*);
cb_Integer clsSCI_Undo (clsSCI*);
cb_Integer clsSCI_Redo (clsSCI*);
cb_Integer clsSCI_LoadFile (clsSCI*,const cb_String,cb_Integer =FALSE);
cb_Integer clsSCI_SaveFile (clsSCI*,const cb_String,cb_Integer =FALSE);
cb_Boolean clsSCI_GetFocus (clsSCI*);
void clsSCI_SetFocus (clsSCI*,cb_Integer =TRUE);
cb_Integer clsSCI_FindText (clsSCI*,const cb_String,cb_Integer =-1,cb_Integer =-1,cb_Integer =1,cb_Boolean =TRUE);
void clsSCI_SetStyleLineNumber (clsSCI*,cb_Integer =40,COLORREF =cbBlack,COLORREF =cbLightSilver);
void clsSCI_SetStyleMargin (clsSCI*,cb_Integer =15);
void clsSCI_SetStyleFolder (clsSCI*,cb_Integer =15);
void clsSCI_DefineMarker (clsSCI*,cb_Integer,cb_Integer,COLORREF =-1,COLORREF =-1);
void* clsSCI_CreateDoc (clsSCI*);
void clsSCI_AddRefDoc (clsSCI*,void*);
void clsSCI_ReleaseDoc (clsSCI*,void*);
void* clsSCI_GetDoc (clsSCI*);
void clsSCI_SetDoc (clsSCI*,void*);
void clsSCI_ClearDocStyle (clsSCI*);
void clsSCI_SetProperty (clsSCI*,cb_Integer,cb_Integer);
cb_Integer clsSCI_GetLexer (clsSCI*);
#ifdef clsSCI_USE_LEXILLA
cb_Integer clsSCI_SetLexerName (clsSCI*,const cb_String);
#endif
cb_Integer clsSCI_SetLexer (clsSCI*,cb_Integer =-1);
void clsSCI_SetKeywords (clsSCI*,const void*,cb_Integer =0);
void clsSCI_UsePopUp (clsSCI*,cb_Integer);
cb_Integer clsSCI_GetFoldLevel (clsSCI*,cb_Integer);
void clsSCI_SetFoldLevel (clsSCI*,cb_Integer,cb_Integer);
cb_Integer clsSCI_GetFoldExpanded (clsSCI*,cb_Integer);
void clsSCI_SetFoldExpanded (clsSCI*,cb_Integer,cb_Integer);
void clsSCI_ToggleFold (clsSCI*,cb_Integer);
void clsSCI_Expand (clsSCI*,cb_Integer,cb_Boolean,cb_Boolean,cb_Integer,cb_Integer);
HWND clsSCI_Create (clsSCI*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,HFONT =NULL,HMODULE* =NULL,cb_Integer =-1);
clsSCI* clsSCI_Initialize (clsSCI*);
void clsSCI_Terminate (clsSCI*);
void clsSCI_Destroy (clsSCI*);
char* modShellPipe_ReadData (HANDLE,cb_Integer*);
cb_Integer modShellPipe_WriteData (HANDLE,cb_cString*);
cb_Integer clsShellPipe_IsActive (clsShellPipe*,cb_Integer =0);
cb_Boolean clsShellPipe_HasStdInRunning (clsShellPipe*);
cb_Boolean clsShellPipe_IsOpen (clsShellPipe*);
cb_Boolean clsShellPipe_HasChildrens (clsShellPipe*);
cb_Integer clsShellPipe_KillProcess (clsShellPipe*,cb_Integer =TRUE,cb_Integer =0);
cb_Integer clsShellPipe_Close (clsShellPipe*,cb_Integer =cb_MAX_INTEGER32,cb_Integer =FALSE,cb_Integer =(ONE_SECOND/2));
void clsShellPipe_Open (clsShellPipe*);
char* clsShellPipe_GetData (clsShellPipe*,cb_Integer* =NULL,cb_Boolean =FALSE);
char* clsShellPipe_GetLine (clsShellPipe*,cb_Integer* =NULL,cb_Boolean =FALSE);
cb_Integer clsShellPipe_HasLine (clsShellPipe*);
cb_Integer clsShellPipe_Break (clsShellPipe*,cb_Boolean =FALSE);
cb_Integer clsShellPipe_Length (clsShellPipe*);
HWND clsShellPipe_GethWnd (clsShellPipe*);
void clsShellPipe_SetSTDHandles (clsShellPipe*,HANDLE =cb_INVALID,HANDLE =cb_INVALID);
clsShellPipe_RESULTS clsShellPipe_RunW (clsShellPipe*,const cb_StringW =NULL,const cb_StringW =NULL,const cb_StringW =NULL,cb_Integer =FALSE,cb_File* =NULL,cb_File* =NULL);
clsShellPipe_RESULTS clsShellPipe_Run (clsShellPipe*,const cb_String =NULL,const cb_String =NULL,const cb_String =NULL,cb_Integer =FALSE,cb_File* =NULL,cb_File* =NULL);
cb_Integer clsShellPipe_SendData (clsShellPipe*,const void*,cb_Integer =-1);
void clsShellPipe_SendLine (clsShellPipe*,const cb_String,cb_Boolean =TRUE);
void clsShellPipe_SendLineW (clsShellPipe*,const cb_StringW,cb_Boolean =TRUE);
cb_Integer clsShellPipe_Update (clsShellPipe*);
void clsShellPipe_SetTimer (clsShellPipe*,HWND,cb_Integer =-1);
void clsShellPipe_SetAddress (clsShellPipe*,HWND =NULL);
clsShellPipe* clsShellPipe_Initialize (clsShellPipe*);
void clsShellPipe_Terminate (clsShellPipe*,cb_Integer =cb_MAX_INTEGER32,cb_Integer =FALSE);
const char* clsBatch_SetPath (clsBatch*,const cb_String =NULL);
cb_Integer clsBatch_SetPause (clsBatch*,cb_Integer =FALSE);
const char* clsBatch_GetCurrentDir (clsBatch*,cb_String =NULL);
cb_Integer clsBatch_Stop (void*);
cb_Integer clsBatch_Close (void*,cb_Integer =cb_MAX_INTEGER32);
cb_Integer clsBatch_Terminate (void*);
void* clsBatch_Initialize (void* =NULL,void* =NULL);
cb_Integer clsBatch_Parse (void*,const cb_String);
cb_Integer clsBatch_KillProcess (clsBatch*,cb_Integer =TRUE,cb_Integer =0);
cb_Integer clsBatch_ParseText (clsBatch*,const cb_String,const cb_String =NULL,cb_File* =NULL,cb_File* =NULL);
cb_Integer clsBatch_Run (clsBatch*,const cb_String,cb_Integer =-1,cb_File* =NULL,cb_File* =NULL);
void clsBatch_StopScript (clsBatch*);
cb_Integer clsBatch_IsWorking (clsBatch*);
void clsBatch_SetStdIn (clsBatch*,cb_Integer =TRUE);
cb_Integer clsBatch_HasStdIn (clsBatch*);
cb_Integer clsBatch_HasStdInRunning (clsBatch*);
cb_Boolean clsBatch_HasScript (clsBatch*);
cb_Boolean clsBatch_HasThreadScript (clsBatch*);
cb_Boolean clsBatch_HasAnyScript (clsBatch*);
cb_Boolean clsBatch_GetEcho (clsBatch*);
void clsBatch_SetEcho (clsBatch*,cb_Integer =FALSE);
void* clsBatch_GetParent (clsBatch*);
void clsBatch_SetParent (clsBatch*,void*);
cb_Boolean clsBatch_GetBreak (clsBatch*);
void clsBatch_SetBreak (clsBatch*,cb_Boolean);
void wConsole_SetOutBackColor (wConsole*,COLORREF,COLORREF =CLR_INVALID,cb_Integer =FALSE);
void wConsole_SetOutForeColor (wConsole*,COLORREF);
void wConsole_SetInBackColor (wConsole*,COLORREF,COLORREF =CLR_INVALID,cb_Integer =FALSE);
void wConsole_SetInForeColor (wConsole*,COLORREF);
cb_Boolean wConsole_GetWrapMode (wConsole*);
void wConsole_SetWrapMode (wConsole*,cb_Boolean);
void wConsole_Cls (wConsole*,cb_Integer =FALSE);
void wConsole_CopyToClipboard (wConsole*);
void wConsole_TextOutput (wConsole*,const cb_String,cb_Integer =TRUE);
void wConsole_SetInterval (wConsole*,cb_Integer);
void wConsole_Close (wConsole*,cb_Integer =cb_MAX_INTEGER32,cb_Integer =FALSE);
void wConsole_SetFocus (wConsole*);
cb_Integer wConsole_Run (wConsole*,const cb_String =NULL,const cb_String =NULL,const cb_String =NULL,cb_File* =NULL,cb_File* =NULL);
void wConsole_Restart (wConsole*,cb_Integer =FALSE,cb_Integer =0);
void wConsole_SetEngine (wConsole*,cb_Integer =0,cb_Integer =FALSE);
cb_Integer wConsole_IsActive (wConsole*);
cb_Integer wConsole_IsBreak (wConsole*);
void wConsole_SetBreak (wConsole*,cb_Integer =FALSE);
cb_Integer wConsole_IsESCBreak (wConsole*);
void wConsole_SetESCBreak (wConsole*,cb_Integer =FALSE);
cb_Integer wConsole_IsWorking (wConsole*);
cb_Integer wConsole_HasChildrens (wConsole*);
cb_Boolean wConsole_IsBusy (wConsole*);
cb_Boolean wConsole_IsPause (wConsole*);
cb_Boolean wConsole_HasStdIn (wConsole*);
cb_Boolean wConsole_HasStdInRunning (wConsole*);
void wConsole_Stop (wConsole*,cb_Integer =FALSE,cb_Integer =0);
void wConsole_SetHandles (wConsole*,cb_File* =cb_INVALID,cb_File* =cb_INVALID);
void wConsole_Break (wConsole*,cb_Integer =FALSE,cb_Integer =0);
void wConsole_AddItem (wConsole*,const cb_String);
cb_Integer wConsole_SendText (wConsole*,const cb_String);
cb_Integer wConsole_SendLine (wConsole*,const cb_String,cb_Boolean =FALSE);
cb_Integer wConsole_SetLine (wConsole*,const cb_String,cb_Boolean =FALSE);
cb_Integer wConsole_SetDir (wConsole*,const cb_String);
cb_Integer wConsole_FindText (wConsole*,const cb_String);
void wConsole_SetEditEngine (wConsole*,cb_Integer =0);
void wConsole_SetSTDHandles (wConsole*,HANDLE,HANDLE);
cb_Integer wConsole_GetScrollBars (wConsole*);
void wConsole_Resize (wConsole*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
wConsole* wConsole_Create (wConsole*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE);
void clsFormShadow_Refresh (clsFormShadow*,cb_Boolean =-1);
COLORREF clsFormShadow_GetColor (clsFormShadow*);
void clsFormShadow_SetColor (clsFormShadow*,COLORREF,cb_Boolean =FALSE);
cb_Integer clsFormShadow_GetDepth (clsFormShadow*);
void clsFormShadow_SetDepth (clsFormShadow*,cb_Integer =cb_MIN_INTEGER32,cb_Boolean =FALSE);
cb_Boolean clsFormShadow_GetRight (clsFormShadow*);
void clsFormShadow_SetRight (clsFormShadow*,cb_Boolean =TRUE,cb_Boolean =FALSE);
BYTE clsFormShadow_GetTransparency (clsFormShadow*);
void clsFormShadow_SetTransparency (clsFormShadow*,cb_Integer,cb_Boolean =FALSE);
void clsFormShadow_SetEnabled (clsFormShadow*,cb_Boolean,cb_Boolean =FALSE);
void clsFormShadow_Terminate (clsFormShadow*);
void clsFormShadow_DoEvents (clsFormShadow*,HWND,cb_UInteger,cb_Integer,cb_Integer);
void clsFormShadow_SetAddress (clsFormShadow*,HWND =NULL);
PclsFormShadow clsFormShadow_Initialize (clsFormShadow* =NULL);
void clsFormShadow_Set (clsFormShadow*,HWND,cb_Integer =0,cb_Integer =-1,COLORREF =-1,cb_Boolean =TRUE,cb_Integer =TRUE);
cb_Integer wPopupMenu_DoEvents (wPopupMenu*,HWND,cb_UInteger,WPARAM,LPARAM);
void wPopupMenu_Delete (wPopupMenu*,HMENU,cb_Integer =-1,cb_Integer =-1);
cb_PString wPopupMenu_GetCaptionA (wPopupMenu*,HMENU,cb_Integer,cb_Integer =-1,cb_String =NULL);
cb_PStringW wPopupMenu_GetCaptionW (wPopupMenu*,HMENU,cb_Integer,cb_Integer =-1,cb_StringW =NULL);
void* wPopupMenu_GetCaption (wPopupMenu*,HMENU,cb_Integer,cb_Integer =-1,void* =NULL);
void wPopupMenu_SetCaption (wPopupMenu*,HMENU,const cb_String,cb_Integer,cb_Integer =-1);
cb_PString wPopupMenu_GetTagA (wPopupMenu*,HMENU,cb_Integer,cb_Integer =-1,cb_String =NULL);
cb_PStringW wPopupMenu_GetTagW (wPopupMenu*,HMENU,cb_Integer,cb_Integer =-1,cb_StringW =NULL);
void* wPopupMenu_GetTag (wPopupMenu*,HMENU,cb_Integer,cb_Integer =-1,void* =NULL);
void wPopupMenu_SetTagA (wPopupMenu*,HMENU,const cb_String,cb_Integer,cb_Integer =-1);
void wPopupMenu_SetTagW (wPopupMenu*,HMENU,const cb_StringW,cb_Integer,cb_Integer =-1);
void wPopupMenu_SetTag (wPopupMenu*,HMENU,const void*,cb_Integer,cb_Integer =-1);
HBITMAP wPopupMenu_GetBitmap (wPopupMenu*,HMENU,cb_Integer,cb_Integer =-1);
void wPopupMenu_SetBitmap (wPopupMenu*,HMENU,HBITMAP,cb_Integer,cb_Integer =-1);
DWORD wPopupMenu_GetData (wPopupMenu*,HMENU,cb_Integer,cb_Integer =-1);
void wPopupMenu_SetData (wPopupMenu*,HMENU,DWORD,cb_Integer,cb_Integer =-1);
void wPopupMenu_Insert (wPopupMenu*,HMENU,const cb_String,cb_Integer,cb_Integer =-1,HBITMAP =NULL);
cb_Integer wPopupMenu_GetTransparency (wPopupMenu*);
void wPopupMenu_SetTransparency (wPopupMenu*,cb_Integer =-1);
cb_Integer wPopupMenu_GetShadow (wPopupMenu*);
void wPopupMenu_SetShadow (wPopupMenu*,cb_Integer =cb_MIN_INTEGER32,cb_Integer =-1,COLORREF =-1,cb_Boolean =TRUE);
cb_Integer wPopupMenu_GetUnicode (wPopupMenu*);
void wPopupMenu_SetUnicode (wPopupMenu*,cb_Boolean);
void wPopupMenu_ConvertItems (wPopupMenu*,HMENU,cb_Boolean =FALSE);
cb_Integer wPopupMenu_TrackPopupMenu (wPopupMenu*,HMENU,cb_Integer,cb_Integer,cb_Integer,HWND,RECT*);
cb_Integer wPopupMenu_Open (wPopupMenu*,HMENU,HWND,cb_Integer =-1,cb_Integer =-1,cb_Integer =-1);
void wPopupMenu_Refresh (wPopupMenu*);
void wPopupMenu_Destroy_ (wPopupMenu*,cb_Integer);
wPopupMenu* wPopupMenu_Initialize (wPopupMenu* =NULL);
void wPopupMenu_SetAddress (wPopupMenu*,HWND =NULL,wPopupMenu* =NULL);
void wPopupMenu_Set (wPopupMenu*,HWND =NULL,HMENU =NULL,cb_Integer =-1);
cb_Integer wMenuBar_Count (wMenuBar*);
cb_Integer wMenuBar_GetSelected (wMenuBar*);
void wMenuBar_SetSelected (wMenuBar*,cb_Integer =-1,cb_Integer =FALSE);
HBITMAP wMenuBar_GetBitmap (wMenuBar*,HMENU,cb_Integer,cb_Integer =-1);
void wMenuBar_SetBitmap (wMenuBar*,HMENU,HBITMAP,cb_Integer,cb_Integer =-1);
cb_Integer wMenuBar_GetData (wMenuBar*,cb_Integer =-1);
void wMenuBar_SetData (wMenuBar*,cb_Integer,cb_Integer =-1);
cb_Integer wMenuBar_GetUnicode (wMenuBar*);
void wMenuBar_SetUnicode (wMenuBar*,cb_Boolean);
cb_Integer wMenuBar_EnumMenuItems (wMenuBar*,HWND);
void wMenuBar_Insert (wMenuBar*,HMENU,const cb_String,cb_Integer =-1,HBITMAP =NULL,cb_Integer =FALSE);
void wMenuBar_Add (wMenuBar*,HMENU,const cb_String,HBITMAP =NULL,cb_Integer =FALSE);
void wMenuBar_Remove (wMenuBar*,cb_Integer =-1,cb_Integer =FALSE);
void wMenuBar_RemoveAll (wMenuBar*);
void wMenuBar_Release (wMenuBar*);
void wMenuBar_Destroy_ (wMenuBar*,cb_Integer);
cb_Integer wMenuBar_DoEvents (wMenuBar*,HWND,cb_UInteger,WPARAM,LPARAM);
void wMenuBar_Refresh (wMenuBar*);
wMenuBar* wMenuBar_Initialize (wMenuBar* =NULL);
void wMenuBar_SetAddress (wMenuBar*,HWND =NULL);
void wMenuBar_Set (wMenuBar*,HWND,cb_Integer =FALSE);
wMenuBar* wMenuBar_Dup (wMenuBar*,wMenuBar*,HWND =NULL,cb_Boolean =TRUE);
void wForm_Destroy (wForm*);
cb_Boolean modIE_IsNothing (cb_comObject*);
cb_Integer modIE_Open (cb_comObject*,const cb_String =NULL,HWND =NULL,const cb_String =NULL);
cb_PString modIE_GetURL (cb_comObject*,void* =NULL);
cb_PString modIE_SetURL (cb_comObject*,const cb_String,void* =NULL);
cb_Integer modIE_IsOpen (cb_comObject*);
cb_Integer modIE_ReadyState (cb_comObject*);
cb_Integer modIE_IsReady (cb_comObject*);
cb_Integer modIE_Busy (cb_comObject*);
cb_Integer modIE_GetRegisterAsBrowser (cb_comObject*);
cb_Integer modIE_SetRegisterAsBrowser (cb_comObject*,cb_Boolean);
cb_Integer modIE_GetRegisterAsDropTarget (cb_comObject*);
cb_Integer modIE_SetRegisterAsDropTarget (cb_comObject*,cb_Boolean);
cb_Integer modIE_GetResizable (cb_comObject*);
cb_Integer modIE_SetResizable (cb_comObject*,cb_Boolean);
cb_Integer modIE_GetVisible (cb_comObject*);
cb_Integer modIE_SetVisible (cb_comObject*,cb_Boolean);
HWND modIE_hWnd (cb_comObject*);
cb_PString modIE_LocationName (cb_comObject*,void* =NULL);
cb_PString modIE_Type (cb_comObject*,void* =NULL);
cb_PString modIE_Path (cb_comObject*,void* =NULL);
cb_Integer modIE_Quit (cb_comObject*);
cb_Integer modIE_Stop (cb_comObject*);
cb_Integer modIE_Close (cb_comObject*);
void modIE_SetNothing (cb_comObject*);
void modIE_Shutdown (cb_comObject*);
IUnknown* modIE_GetUnknownObject (VARIANT*);
void modIE_ReleaseUnknownObject (VARIANT*);
#ifdef __cplusplus
#else
cb_Integer wEventSink_SetEvents (wEventSink*,const void*,wCOMEventSink =NULL);
void wEventSink_Terminate (wEventSink*);
wEventSink* wEventSink_Initialize (wEventSink*,REFIID,const void* =NULL);
#endif




cb_Integer wIE_IsNothing (wIE*);
cb_PString wIE_GetURL (wIE*,void* =NULL);
cb_PString wIE_SetURL (wIE*,const cb_String,void* =NULL);
cb_Integer wIE_GetResizable (wIE*);
void wIE_SetResizable (wIE*,cb_Boolean =TRUE);
void wIE_SetTimerEnabled (wIE*,cb_Boolean =FALSE,cb_Integer =-1);
void wIE_Quit (wIE*);
void wIE_Stop (wIE*);
void wIE_Close (wIE*);
cb_Integer wIE_Open (wIE*,const cb_String =NULL);
cb_Integer wIE_IsReady (wIE*);
void wIE_Resize (wIE*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
void wIE_SetNothing (wIE*);
void wIE_Shutdown (wIE*);
wIE* wIE_Create (wIE*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE);


void wIExplorer_Refresh2 (wIExplorer*,cb_Integer =0);
void wIExplorer_GoForward (wIExplorer*);
void wIExplorer_GoBack (wIExplorer*);
void wIExplorer_GoHome (wIExplorer*);
void wIExplorer_GoSearch (wIExplorer*);
cb_PString wIExplorer_LocationURL (wIExplorer*,void* =NULL);
cb_PString wIExplorer_LocationName (wIExplorer*,void* =NULL);
void wIExplorer_SetAsDropTarget (wIExplorer*,VARIANT_BOOL);
cb_Boolean wIExplorer_GetAsDropTarget (wIExplorer*);
void wIExplorer_SetAsTheaterMode (wIExplorer*,VARIANT_BOOL);
cb_Boolean wIExplorer_GetAsTheaterMode (wIExplorer*);
void wIExplorer_StopDownload (wIExplorer*);
cb_Integer wIExplorer_Navigate (wIExplorer*,LPSTR);
void wIExplorer_Resize (wIExplorer*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
HRESULT wIExplorer_Open (wIExplorer*);
cb_Integer wIExplorer_Close (wIExplorer*);
wIExplorer* wIExplorer_Create (wIExplorer*,HWND =NULL,cb_Integer =0,cb_Integer =0,cb_Integer =0,cb_Integer =0,cb_Integer =TRUE);
HINTERNET wInet_Handle (wInet*);
cb_PString wInet_GetRemoteHost (wInet*);
void wInet_SetRemoteHost (wInet*,cb_String);
cb_PString wInet_GetRemoteHostIP (wInet*);
void wInet_SetRemoteHostIP (wInet*,cb_String);
cb_UInteger wInet_GetRemotePort (wInet*);
void wInet_SetRemotePort (wInet*,cb_UInteger);
cb_PString wInet_GetUserName (wInet*);
void wInet_SetUserName (wInet*,cb_String);
cb_PString wInet_GetPassword (wInet*);
void wInet_SetPassword (wInet*,cb_String);
cb_Integer wInet_RecvBufferLen (wInet*);
cb_Integer wInet_SendBufferLen (wInet*);
cb_Integer wInet_GetState (wInet*);
cb_Boolean wInet_IsReady (wInet*);
cb_Boolean wInet_IsBusy (wInet*);
cb_Integer wInet_GetOptions (wInet*,cb_Integer,cb_Integer =-1);
cb_Integer wInet_SetOptions (wInet*,cb_Integer,cb_Integer,cb_Integer =-1);
cb_Integer wInet_GetRecvTimeout (wInet*);
cb_Integer wInet_SetRecvTimeout (wInet*,cb_Integer);
cb_Integer wInet_GetSendTimeout (wInet*);
cb_Integer wInet_SetSendTimeout (wInet*,cb_Integer);
cb_Integer wInet_LastError (wInet*);
cb_PString wInet_LastErrorMsg (wInet*);
cb_Boolean wInet_GetTimerEnabled (wInet*);
void wInet_SetTimerEnabled (wInet*,cb_Boolean =FALSE,cb_Integer =-1);
cb_Integer wInet_GetTimerInterval (wInet*,cb_Boolean =FALSE);
void wInet_SetTimerInterval (wInet*,cb_Boolean =FALSE,cb_Integer =0);
void wInet_CloseURL (wInet*);
cb_Boolean wInet_Get (wInet*);
void* wInet_GetChunk (wInet*,cb_UInteger,void* =NULL);
char* wInet_GetHeader (wInet*,const cb_String =NULL,LPVOID =NULL,cb_Integer =-1);
void wInet_ResetBuffers (wInet*);
void wInet_Close (wInet*);
HINTERNET wInet_Open (wInet*,const cb_String =NULL,cb_Integer =0);
HINTERNET wInet_OpenURL (wInet*,const cb_String =NULL,const cb_String =NULL,void* =NULL,cb_Integer =0);
cb_Boolean wInet_GetURL (wInet*,const cb_String,const cb_String =NULL,const cb_String =NULL);
HINTERNET wInet_OpenServer (wInet*,const cb_String =NULL,const cb_String =NULL,const cb_String =NULL,const cb_String =NULL,cb_UInteger =0,cb_Integer =0);
HINTERNET wInet_OpenFTPServer (wInet*,const cb_String,const cb_String =NULL,const cb_String =NULL,const cb_String =NULL,cb_UInteger =0,cb_Integer =0);
HINTERNET wInet_OpenFTPServerSync (wInet*,const cb_String =NULL,cb_Integer =0);
cb_Integer wInet_MkDir (wInet*,const cb_String);
cb_Integer wInet_RmDir (wInet*,const cb_String);
char* wInet_GetDir (wInet*,void* =NULL);
cb_Integer wInet_SetDir (wInet*,const cb_String);
cb_Integer wInet_Rename (wInet*,const cb_String,const cb_String);
cb_Integer wInet_Delete (wInet*,const cb_String);
cb_Integer wInet_Command (wInet*,const cb_String,cb_Integer =-1);
cb_Integer wInet_IsExist (wInet*,const cb_String,HINTERNET =NULL);
cb_Integer wInet_IsFile (wInet*,const cb_String,HINTERNET =NULL);
cb_PString wInet_FindFirst (wInet*,const cb_String,void* =NULL,WIN32_FIND_DATA* =NULL);
cb_PString wInet_FindNext (wInet*,void* =NULL,WIN32_FIND_DATA* =NULL);
cb_PString wInet_List (wInet*,const cb_String =NULL,void* =NULL);
cb_PString wInet_TempFileName (wInet*,const cb_String =NULL,const cb_String =NULL,void* =NULL);
unsigned long long wInet_GetFileSize (wInet*,const cb_String);
cb_Integer wInet_GetFile (wInet*,const cb_String,const cb_String =NULL,cb_Integer =FALSE,DWORD =0,cb_Integer =-1);
cb_Integer wInet_PutFile (wInet*,const cb_String,const cb_String =NULL,cb_Integer =FALSE,cb_Integer =-1);
HINTERNET wInet_OpenRequest (wInet*,cb_Integer =FALSE,const cb_String =NULL);
cb_Boolean wInet_Execute (wInet*,cb_Integer =FALSE,const cb_String =NULL);
cb_Boolean wInet_Exec (wInet*,const cb_String =NULL,const cb_String =NULL);
cb_Boolean wInet_StillExecuting (wInet*);
LPBYTE wInet_GetData (wInet*,BYTE** =NULL,cb_Integer =0,cb_Boolean =TRUE);
LPBYTE wInet_PeekNext (wInet*,BYTE** =NULL,cb_Integer =0);
void wInet_SendData (wInet*,void*,cb_Integer =-1);
wInet* wInet_Initialize (wInet*);
void wInet_Terminate (wInet*);
cb_PString wInet_GetErrorDescription (wInet*,cb_Integer =0);
cb_Boolean wListView_GetHeader (wListView*);
void wListView_SetHeader (wListView*,cb_Boolean =TRUE);
cb_Boolean wListView_GetHeaderSort (wListView*);
void wListView_SetHeaderSort (wListView*,cb_Boolean =TRUE);
cb_Boolean wListView_GetAutoLabelEdit (wListView*);
void wListView_SetAutoLabelEdit (wListView*,cb_Boolean =TRUE);
cb_Boolean wListView_GetMultiSelect (wListView*);
void wListView_SetMultiSelect (wListView*,cb_Boolean =TRUE);
void wListView_SetRedraw (wListView*,cb_Integer);
HWND wListView_GethWndCol (wListView*);
cb_Integer wListView_GetColCount (wListView*);
cb_Integer wListView_ColAdd (wListView*,cb_String,cb_Integer =LVSCW_AUTOSIZE_USEHEADER,cb_Integer =LVCFMT_LEFT,cb_Integer =-1);
cb_Boolean wListView_ColRemove (wListView*,cb_Integer);
void wListView_ColClear (wListView*);
cb_PString wListView_GetColText (wListView*,cb_Integer,void* =NULL);
void wListView_SetColText (wListView*,cb_Integer,cb_String);
cb_Integer wListView_GetColIndex (wListView*,cb_Integer);
cb_Integer wListView_GetColWidth (wListView*,cb_Integer);
void wListView_SetColWidth (wListView*,cb_Integer,cb_Integer);
void wListView_SortItems (wListView*,cb_Integer =-1,cb_Integer =-1);
cb_Boolean wListView_GetSorted (wListView*);
void wListView_SetSorted (wListView*,cb_Boolean =TRUE);
cb_Integer wListView_GetCount (wListView*);
HWND wListView_GethWnd (wListView*);
cb_Integer wListView_GetIndex (wListView*);
void wListView_EnsureVisible (wListView*,cb_Integer =wListView_BASE-1);
cb_Integer wListView_FindItem (wListView*,const cb_String,cb_Integer =FALSE,cb_Integer =wListView_BASE,cb_Integer =0,cb_Integer =0);
cb_Integer wListView_Add (wListView*,const cb_String,cb_Integer =wListView_BASE-2);
char* wListView_GetText (wListView*,cb_Integer =wListView_BASE-1,cb_Integer =0,void* =NULL,cb_Integer =1,cb_UInteger =(cb_UInteger)-1);
cb_Integer wListView_SetText (wListView*,const cb_String,cb_Integer =wListView_BASE-1,cb_Integer =0,cb_Integer =1);
cb_Boolean wListView_GetTag (wListView*);
void wListView_SetTag (wListView*,cb_Boolean =TRUE);
char* wListView_GetTagText (wListView*,cb_Integer =wListView_BASE-1,void* =NULL);
cb_Integer wListView_SetTagText (wListView*,const cb_String,cb_Integer =wListView_BASE-1);
cb_Integer wListView_GetItemData (wListView*,cb_Integer =wListView_BASE-1);
void wListView_SetItemData (wListView*,cb_Integer,cb_Integer =wListView_BASE-1);
cb_Integer wListView_FindItemData (wListView*,cb_Integer,cb_Integer =wListView_BASE);
cb_Integer wListView_GetItemImage (wListView*,cb_Integer =wListView_BASE-1);
void wListView_SetItemImage (wListView*,cb_Integer,cb_Integer =wListView_BASE-1);
void wListView_SetCheckBoxes (wListView*,cb_Boolean =TRUE);
cb_Boolean wListView_GetCheckBoxes (wListView*);
cb_Boolean wListView_GetChecked (wListView*,cb_Integer =wListView_BASE-1);
void wListView_SetChecked (wListView*,cb_Boolean,cb_Integer =wListView_BASE-1);
cb_Boolean wListView_GetItemFocus (wListView*,cb_Integer =wListView_BASE-1);
cb_Integer wListView_SetItemFocus (wListView*,cb_Boolean,cb_Integer =wListView_BASE-1);
cb_Boolean wListView_GetSelected (wListView*,cb_Integer =wListView_BASE-1);
void wListView_SetSelected (wListView*,cb_Boolean,cb_Integer =wListView_BASE-1);
cb_Integer wListView_GetSelectedItem (wListView*);
cb_Integer wListView_GetCurrentItem (wListView*);
cb_Integer wListView_SetSelectedItem (wListView*,cb_Integer,cb_Boolean =FALSE,cb_Boolean =TRUE);
cb_Integer wListView_UnsetSelectedItem (wListView*,cb_Integer,cb_Boolean =FALSE);
void wListView_Remove (wListView*,cb_Integer =wListView_BASE-1);
void wListView_Clear (wListView*);
cb_Integer wListView_GetNextChecked (wListView*,cb_Integer =wListView_BASE,cb_Integer =-1);
cb_Integer wListView_GetPrevChecked (wListView*,cb_Integer =-1,cb_Integer =wListView_BASE);
void wListView_RemoveChecked (wListView*,cb_Integer =wListView_BASE,cb_Integer =-1);
void wListView_Check (wListView*,cb_Integer =wListView_BASE,cb_Integer =-2);
void wListView_UnCheck (wListView*,cb_Integer =wListView_BASE,cb_Integer =-1);
cb_Integer wListView_GetNextSelected (wListView*,cb_Integer =wListView_BASE,cb_Integer =-1);
cb_Integer wListView_GetPrevSelected (wListView*,cb_Integer =-1,cb_Integer =wListView_BASE);
void wListView_RemoveSelected (wListView*,cb_Integer =wListView_BASE,cb_Integer =-1);
void wListView_Select (wListView*,cb_Integer =wListView_BASE,cb_Integer =-2);
void wListView_UnSelect (wListView*,cb_Integer =wListView_BASE,cb_Integer =-1);
HIMAGELIST wListView_GetSmallIcons (wListView*);
HIMAGELIST wListView_SetSmallIcons (wListView*,HIMAGELIST);
HIMAGELIST wListView_CreateImageList (wListView*,cb_Integer =-1);
HWND wListView_GethWndLabelEdit (wListView*);
cb_PString wListView_GetLabelEditText (wListView*,void* =NULL);
void wListView_SetLabelEditText (wListView*,cb_String);
cb_Integer wListView_HitTest (wListView*,cb_Integer =-1,cb_Integer =-1);
cb_Integer wListView_SubItemHitTest (wListView*);
cb_Integer wListView_GetItemHeight (wListView*,cb_Integer =wListView_BASE-1);
cb_Boolean wListView_GetItemRect (wListView*,RECT*,cb_Integer =wListView_BASE-1,cb_Integer =0,cb_Integer =LVIR_LABEL);
cb_Boolean wListView_GetItemPos (wListView*,POINT*,cb_Integer =wListView_BASE-1,cb_Integer =0);
cb_Boolean wListView_GetItemWindowRect (wListView*,RECT*,cb_Integer =wListView_BASE-1,cb_Integer =0,cb_Integer =LVIR_LABEL);
void wListView_SetFullRowSelect (wListView*,cb_Boolean =TRUE);
cb_Boolean wListView_GetFullRowSelect (wListView*);
void wListView_SetGridLines (wListView*,cb_Boolean =TRUE);
cb_Boolean wListView_GetGridLines (wListView*);
void wListView_SetBackColor (wListView*,COLORREF =CLR_NONE,cb_Boolean =FALSE);
void wListView_SetForeColor (wListView*,COLORREF =CLR_NONE,cb_Boolean =FALSE);
void wListView_SetDropFiles (wListView*,cb_Boolean =TRUE);
void wListView_Resize (wListView*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wListView_EndLabelEdit (wListView*,cb_Integer);
void wListView_StartLabelEdit (wListView*,cb_Integer =wListView_BASE-1,cb_Integer =-1);
cb_Integer wListView_GetLeft (wListView*);
void wListView_SetLeft (wListView*,cb_Integer);
cb_Integer wListView_GetTop (wListView*);
void wListView_SetTop (wListView*,cb_Integer);
cb_Integer wListView_GetWidth (wListView*);
void wListView_SetWidth (wListView*,cb_Integer);
cb_Integer wListView_GetHeight (wListView*);
void wListView_SetHeight (wListView*,cb_Integer);
void wListView_SetFocus (wListView*);
void wListView_Destroy (wListView*);
wListView* wListView_Create (wListView*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =cb_MIN_INTEGER32 | TRUE);
cb_Integer modMediaType_GetByExtension (const cb_String);
cb_Integer modMediaType_GetByFileName (const cb_String);
cb_Integer modMediaType_GetByFileNameW (const cb_StringW);
cb_Integer modMediaType_GetByID (cb_UInteger);
cb_Integer modMediaType_GetByDeviceName (const cb_String);
void clsMixer_Initialize (clsMixer*);
void clsMixer_Terminate (clsMixer*);
cb_Integer clsMixer_GetVolumeCD (clsMixer*);
cb_Boolean clsMixer_SetVolumeCD (clsMixer*,cb_Integer);
cb_Integer clsMixer_GetVolumeCD_Max (clsMixer*);
cb_Integer clsMixer_GetVolumeCD_Min (clsMixer*);
cb_Integer clsMixer_GetVolumeMIDI (clsMixer*);
cb_Boolean clsMixer_SetVolumeMIDI (clsMixer*,cb_Integer);
cb_Integer clsMixer_GetVolumeMIDI_Max (clsMixer*);
cb_Integer clsMixer_GetVolumeMIDI_Min (clsMixer*);
cb_Integer clsMixer_GetVolumeSystem (clsMixer*);
cb_Boolean clsMixer_SetVolumeSystem (clsMixer*,cb_Integer);
cb_Integer clsMixer_GetVolumeSystem_Max (clsMixer*);
cb_Integer clsMixer_GetVolumeSystem_Min (clsMixer*);
cb_Integer clsMixer_GetVolumeWAVE (clsMixer*);
cb_Boolean clsMixer_SetVolumeWAVE (clsMixer*,cb_Integer);
cb_Integer clsMixer_GetVolumeWAVE_Max (clsMixer*);
cb_Integer clsMixer_GetVolumeWAVE_Min (clsMixer*);
cb_PString clsMCIStr_GetErrorMsg (cb_Integer =-123);
wchar_t* clsMCIStr_SendStringW (const cb_StringW,cb_Integer* =NULL,void* =NULL,HWND =NULL);
char* clsMCIStr_SendString (const cb_String,cb_Integer* =NULL,void* =NULL,HWND =NULL);
cb_Integer clsMCIStr_Resize (clsMCIStr*,HWND =NULL,cb_Integer =0,cb_Integer =0,cb_Boolean =FALSE);
cb_Integer clsMCIStr_ResizeToFit (clsMCIStr*,HWND =NULL,cb_Integer =0,cb_Integer =0);
cb_Integer clsMCIStr_SetStretch (clsMCIStr*,cb_Integer =TRUE,HWND =NULL);
cb_Integer clsMCIStr_SetTimeFormat (clsMCIStr*);
wchar_t* clsMCIStr_GetStatusW (clsMCIStr*,void* =NULL);
char* clsMCIStr_GetStatus (clsMCIStr*,void* =NULL);
cb_Integer clsMCIStr_IsPlaying (clsMCIStr*);
cb_Integer clsMCIStr_SetPosition (clsMCIStr*,cb_UInteger =0,cb_Integer =-1,HWND =NULL);
cb_Integer clsMCIStr_Stop (clsMCIStr*,cb_Boolean =FALSE);
cb_Integer clsMCIStr_Close (clsMCIStr*);
cb_Integer clsMCIStr_OpenW (clsMCIStr*,const cb_StringW =NULL,const cb_String =NULL,const cb_StringW =NULL,HWND =NULL,cb_Boolean =TRUE);
cb_Integer clsMCIStr_Open (clsMCIStr*,const cb_String =NULL,const cb_String =NULL,const cb_StringW =NULL,HWND =NULL,cb_Boolean =TRUE);
cb_Integer clsMCIStr_Play (clsMCIStr*,cb_Boolean =FALSE,cb_Integer =-1,HWND =NULL);
cb_Integer clsMCIStr_Record (clsMCIStr*,cb_Integer =2,cb_Integer =-1,cb_Integer =-1,HWND =NULL);
cb_Integer clsMCIStr_Pause (clsMCIStr*);
cb_Integer clsMCIStr_Resume (clsMCIStr*);
cb_Integer clsMCIStr_SetMute (clsMCIStr*,cb_Boolean =TRUE);
cb_Integer clsMCIStr_GetVolume (clsMCIStr*);
cb_Integer clsMCIStr_SetVolume (clsMCIStr*,cb_Integer,cb_Integer =-1);
cb_Integer clsMCIStr_SetBass (clsMCIStr*,cb_Integer);
cb_Integer clsMCIStr_SetTreble (clsMCIStr*,cb_Integer);
float clsMCIStr_GetRate (clsMCIStr*);
cb_Integer clsMCIStr_SetRate (clsMCIStr*,float);
cb_UInteger clsMCIStr_GetLength (clsMCIStr*);
cb_UInteger clsMCIStr_GetPosition (clsMCIStr*);
HWND clsMCIStr_GethWnd (clsMCIStr*);
cb_Integer clsMCIStr_SaveW (clsMCIStr*,const cb_StringW =NULL);
cb_Integer clsMCIStr_Save (clsMCIStr*,const cb_String =NULL);
void clsMCIStr_Terminate (clsMCIStr*);
clsMCIStr* clsMCIStr_Initialize (clsMCIStr* =NULL);
cb_Integer clsMCIStr_CloseAll (void);
cb_Integer clsMCIStr_Shutdown (clsMCIStr*);
cb_PString wMCIStr_GetErrorMsg (wMCIStr*,cb_Integer =-1);
cb_UInteger wMCIStr_SetTimeFormat (wMCIStr*);
cb_UInteger wMCIStr_OpenW (wMCIStr*,const cb_StringW =NULL,const cb_String =NULL,HWND =NULL,cb_Boolean =TRUE);
cb_UInteger wMCIStr_Open (wMCIStr*,const cb_String =NULL,const cb_String =NULL,HWND =NULL,cb_Boolean =TRUE);
wchar_t* wMCIStr_GetStatusW (wMCIStr*);
char* wMCIStr_GetStatus (wMCIStr*);
cb_Integer wMCIStr_IsPlaying (wMCIStr*);
cb_UInteger wMCIStr_Play (wMCIStr*,cb_UInteger =FALSE,cb_UInteger =-1,cb_UInteger =-1);
cb_UInteger wMCIStr_Record (wMCIStr*,cb_Integer =2,cb_UInteger =-1,cb_UInteger =-1);
cb_UInteger wMCIStr_Pause (wMCIStr*);
cb_UInteger wMCIStr_Resume (wMCIStr*);
cb_UInteger wMCIStr_SetMute (wMCIStr*,cb_Integer =TRUE);
cb_UInteger wMCIStr_GetVolume (wMCIStr*);
cb_UInteger wMCIStr_SetVolume (wMCIStr*,cb_UInteger,cb_UInteger =-1);
cb_UInteger wMCIStr_SetBalance (wMCIStr*,float,cb_UInteger =-1);
cb_UInteger wMCIStr_SetBass (wMCIStr*,cb_UInteger);
cb_UInteger wMCIStr_SetTreble (wMCIStr*,cb_UInteger);
float wMCIStr_GetRate (wMCIStr*);
cb_UInteger wMCIStr_SetRate (wMCIStr*,float);
cb_UInteger wMCIStr_GetLength (wMCIStr*);
cb_UInteger wMCIStr_GetPosition (wMCIStr*);
cb_UInteger wMCIStr_SetPosition (wMCIStr*,cb_UInteger =0,cb_Integer =-1);
cb_UInteger wMCIStr_Resize (wMCIStr*,HWND =NULL,cb_Integer =0,cb_Integer =0,cb_Boolean =FALSE);
cb_UInteger wMCIStr_ResizeToFit (wMCIStr*,HWND =NULL,cb_Integer =0,cb_Integer =0);
cb_UInteger wMCIStr_SetStretch (wMCIStr*,cb_Integer =TRUE,HWND =NULL);
cb_UInteger wMCIStr_Stop (wMCIStr*);
cb_UInteger wMCIStr_SaveW (wMCIStr*,const cb_StringW =NULL);
cb_UInteger wMCIStr_Save (wMCIStr*,const cb_String =NULL);
cb_UInteger wMCIStr_Close (wMCIStr*);
wMCIStr* wMCIStr_Initialize (wMCIStr*);
void wMCIStr_Terminate (wMCIStr*);
cb_UInteger wMCIStr_CloseAll (void);
cb_UInteger wMCIStr_Shutdown (wMCIStr*);
cb_PString modMCI_FormatError (cb_Integer,cb_String =NULL);
cb_UInteger clsMCI_Resize (clsMCI*,HWND =NULL,cb_Integer =0,cb_Integer =0,cb_Integer =FALSE);
cb_UInteger clsMCI_ResizeToFit (clsMCI*,HWND =NULL,cb_Integer =0,cb_Integer =0);
cb_UInteger clsMCI_SetWindowW (clsMCI*,HWND,cb_Integer =-1,cb_StringW =NULL,cb_Integer =-1,cb_Integer =-1);
cb_UInteger clsMCI_SetWindow (clsMCI*,HWND,cb_Integer =-1,cb_String =NULL,cb_Integer =-1,cb_Integer =-1);
cb_UInteger clsMCI_SetStretch (clsMCI*,cb_Integer =TRUE,HWND =NULL);
cb_UInteger clsMCI_GetStatus (clsMCI*);
cb_Integer clsMCI_IsPlaying (clsMCI*);
cb_UInteger clsMCI_SetPosition (clsMCI*,cb_UInteger =-1,HWND =NULL);
cb_UInteger clsMCI_Stop (clsMCI*,HWND =NULL);
cb_UInteger clsMCI_Close (clsMCI*,HWND =NULL);
cb_UInteger clsMCI_OpenW (clsMCI*,const cb_StringW =NULL,const cb_String =NULL,const cb_StringW =NULL,HWND =NULL,cb_Integer =3,cb_StringW =NULL,cb_UInteger =-1);
cb_UInteger clsMCI_Open (clsMCI*,cb_String =NULL,cb_String =NULL,cb_String =NULL,HWND =NULL,cb_Integer =3,cb_String =NULL,cb_UInteger =-1);
cb_UInteger clsMCI_Play (clsMCI*,cb_UInteger =0,cb_UInteger =0,HWND =NULL);
cb_UInteger clsMCI_Record (clsMCI*,cb_UInteger =0,cb_UInteger =0,HWND =NULL);
cb_UInteger clsMCI_Pause (clsMCI*,HWND =NULL);
cb_UInteger clsMCI_Resume (clsMCI*,HWND =NULL);
cb_UInteger clsMCI_GetTimeFormat (clsMCI*);
cb_UInteger clsMCI_SetTimeFormat (clsMCI*,cb_UInteger =0,HWND =NULL);
cb_UInteger clsMCI_GetLength (clsMCI*);
cb_UInteger clsMCI_GetPosition (clsMCI*);
HWND clsMCI_GethWndW (clsMCI*);
cb_UInteger clsMCI_GetVolume (clsMCI*);
cb_UInteger clsMCI_SetVolume (clsMCI*,cb_UInteger =0,cb_UInteger =-1,HWND =NULL);
cb_UInteger clsMCI_GetRate (clsMCI*);
cb_UInteger clsMCI_SetRate (clsMCI*,cb_UInteger =1000,HWND =NULL);
cb_UInteger clsMCI_GetBass (clsMCI*);
cb_UInteger clsMCI_SetBass (clsMCI*,cb_UInteger =0,HWND =NULL);
cb_UInteger clsMCI_GetTreble (clsMCI*);
cb_UInteger clsMCI_SetTreble (clsMCI*,cb_UInteger =0,HWND =NULL);
cb_UInteger clsMCI_SetAudio (clsMCI*,cb_Integer =-1);
cb_UInteger clsMCI_SetMute (clsMCI*,cb_Integer =-1);
cb_UInteger clsMCI_SaveW (clsMCI*,const cb_StringW,HWND =NULL);
cb_UInteger clsMCI_Save (clsMCI*,const cb_String,HWND =NULL);
void clsMCI_Terminate (clsMCI*);
clsMCI* clsMCI_Initialize (clsMCI* =NULL);
cb_UInteger clsMCI_CloseAll (HWND =NULL,cb_UInteger =MCI_ALL_DEVICE_ID);
cb_UInteger clsMCI_Shutdown (clsMCI*);
cb_PString wMCI_GetErrorMsg (wMCI*,cb_Integer =-1);
cb_UInteger wMCI_SetTimeFormat (wMCI*,cb_UInteger =0);
cb_UInteger wMCI_OpenW (wMCI*,const cb_StringW =NULL,const cb_String =NULL,HWND =NULL,cb_Boolean =TRUE);
cb_UInteger wMCI_Open (wMCI*,const cb_String =NULL,const cb_String =NULL,HWND =NULL,cb_Boolean =TRUE);
cb_UInteger wMCI_GetStatus (wMCI*);
cb_Integer wMCI_IsPlaying (wMCI*);
cb_UInteger wMCI_Play (wMCI*,cb_UInteger =FALSE,cb_UInteger =-1,cb_UInteger =-1);
cb_UInteger wMCI_Record (wMCI*,cb_Integer =2,cb_UInteger =-1,cb_UInteger =-1);
cb_UInteger wMCI_Pause (wMCI*);
cb_UInteger wMCI_Resume (wMCI*);
cb_UInteger wMCI_SetMute (wMCI*,cb_Integer =TRUE);
cb_UInteger wMCI_GetVolume (wMCI*);
cb_UInteger wMCI_SetVolume (wMCI*,cb_UInteger,cb_UInteger =-1);
cb_UInteger wMCI_SetBalance (wMCI*,float,cb_UInteger =-1);
cb_UInteger wMCI_SetBass (wMCI*,cb_UInteger);
cb_UInteger wMCI_SetTreble (wMCI*,cb_UInteger);
float wMCI_GetRate (wMCI*);
cb_UInteger wMCI_SetRate (wMCI*,float);
cb_UInteger wMCI_GetLength (wMCI*);
cb_UInteger wMCI_GetPosition (wMCI*);
cb_UInteger wMCI_SetPosition (wMCI*,cb_UInteger =0,cb_Integer =-1);
cb_UInteger wMCI_Resize (wMCI*,HWND =NULL,cb_Integer =0,cb_Integer =0,cb_Boolean =FALSE);
cb_UInteger wMCI_ResizeToFit (wMCI*,HWND =NULL,cb_Integer =0,cb_Integer =0);
cb_UInteger wMCI_SetStretch (wMCI*,cb_Integer =TRUE,HWND =NULL);
cb_UInteger wMCI_Stop (wMCI*);
cb_UInteger wMCI_SaveW (wMCI*,const cb_StringW =NULL);
cb_UInteger wMCI_Save (wMCI*,const cb_String =NULL);
cb_UInteger wMCI_Close (wMCI*);
wMCI* wMCI_Initialize (wMCI*);
void wMCI_Terminate (wMCI*);
cb_UInteger wMCI_CloseAll (void);
cb_UInteger wMCI_Shutdown (wMCI*);
cb_Boolean modWMP_IsNothing (cb_comObject*);
cb_PStringW modWMP_GetURLW (cb_comObject*,void* =NULL);
cb_PString modWMP_GetURL (cb_comObject*,void* =NULL);
cb_PStringW modWMP_SetURLW (cb_comObject*,const cb_StringW,void* =NULL);
char* modWMP_SetURL (cb_comObject*,const cb_String,void* =NULL);
cb_Boolean modWMP_GetStretch (cb_comObject*);
cb_Boolean modWMP_SetStretch (cb_comObject*,cb_Boolean =TRUE);
cb_Integer modWMP_OpenW (cb_comObject*,const cb_StringW,HWND =NULL,const cb_StringW =NULL);
cb_Integer modWMP_Open (cb_comObject*,const cb_String,HWND =NULL,const cb_String =NULL);
cb_Integer modWMP_IsOpen (cb_comObject*);
cb_Integer modWMP_IsPlaying (cb_comObject*);
cb_Integer modWMP_Play (cb_comObject*,cb_Integer =-1);
cb_Integer modWMP_Pause (cb_comObject*);
cb_Integer modWMP_Resume (cb_comObject*);
cb_Integer modWMP_SetMute (cb_comObject*,cb_Boolean);
cb_Integer modWMP_GetMute (cb_comObject*);
cb_Integer modWMP_GetVolume (cb_comObject*);
cb_Integer modWMP_SetVolume (cb_comObject*,cb_Integer);
cb_Integer modWMP_SetBalance (cb_comObject*,cb_Integer);
double modWMP_GetRate (cb_comObject*);
cb_Integer modWMP_SetRate (cb_comObject*,double);
double modWMP_GetLength (cb_comObject*,cb_String =NULL);
double modWMP_GetPosition (cb_comObject*,cb_String =NULL);
cb_Integer modWMP_SetPosition (cb_comObject*,double);
cb_PString modWMP_GetuiMode (cb_comObject*,void* =NULL);
cb_Integer modWMP_SetuiMode (cb_comObject*,cb_Integer =TRUE,const cb_String =NULL);
cb_Integer modWMP_Stop (cb_comObject*);
cb_Integer modWMP_Close (cb_comObject*);
void modWMP_SetNothing (cb_comObject*);
void modWMP_Shutdown (cb_comObject*);
IUnknown* modWMP_GetUnknownObject (VARIANT*);
void modWMP_ReleaseUnknownObject (VARIANT*);
cb_Boolean modSWF_IsNothing (cb_comObject*);
cb_PStringW modSWF_GetMovieW (cb_comObject*,void* =NULL);
cb_PString modSWF_GetMovie (cb_comObject*,void* =NULL);
cb_PStringW modSWF_SetMovieW (cb_comObject*,const cb_StringW,void* =NULL);
char* modSWF_SetMovie (cb_comObject*,const cb_String,void* =NULL);
cb_Boolean modSWF_GetStretch (cb_comObject*);
cb_Boolean modSWF_SetStretch (cb_comObject*,cb_Integer =FALSE);
cb_Boolean modSWF_LoadMovieW (cb_comObject*,const cb_StringW,cb_Integer =0);
cb_Boolean modSWF_LoadMovie (cb_comObject*,const cb_String,cb_Integer =0);
cb_Integer modSWF_OpenW (cb_comObject*,const cb_StringW,HWND =NULL,const cb_StringW =NULL,cb_Integer =0);
cb_Integer modSWF_Open (cb_comObject*,const cb_String,HWND =NULL,const cb_String =NULL,cb_Integer =0);
cb_Integer modSWF_IsOpen (cb_comObject*);
cb_Integer modSWF_IsPlaying (cb_comObject*);
cb_Boolean modSWF_Play (cb_comObject*,cb_Integer =-1);
cb_Boolean modSWF_Pause (cb_comObject*);
cb_Boolean modSWF_SetMute (cb_comObject*,cb_Boolean);
cb_Boolean modSWF_GetMute (cb_comObject*);
cb_Integer modSWF_GetVolume (cb_comObject*);
cb_Boolean modSWF_SetVolume (cb_comObject*,cb_Integer);
cb_Boolean modSWF_SetBalance (cb_comObject*,cb_Integer);
double modSWF_GetRate (cb_comObject*);
cb_Boolean modSWF_SetRate (cb_comObject*,double);
cb_Integer modSWF_TotalFrames (cb_comObject*);
cb_Integer modSWF_GetFrame (cb_comObject*);
cb_Boolean modSWF_SetFrame (cb_comObject*,cb_Integer);
cb_PStringW modSWF_GetWModeW (cb_comObject*,void* =NULL);
cb_PString modSWF_GetWMode (cb_comObject*,void* =NULL);
cb_Boolean modSWF_SetWModeW (cb_comObject*,cb_Integer =TRUE,const cb_StringW =NULL);
cb_Boolean modSWF_SetWMode (cb_comObject*,cb_Integer =TRUE,const cb_String =NULL);
cb_PStringW modSWF_GetVariableW (cb_comObject*,const cb_StringW,void* =NULL);
cb_PString modSWF_GetVariable (cb_comObject*,const cb_String,void* =NULL);
cb_Integer modSWF_SetVariableW (cb_comObject*,const cb_StringW,const cb_StringW);
cb_Integer modSWF_SetVariable (cb_comObject*,const cb_String,const cb_String);
cb_Boolean modSWF_Stop (cb_comObject*);
cb_Boolean modSWF_Close (cb_comObject*);
void modSWF_SetNothing (cb_comObject*);
void modSWF_Shutdown (cb_comObject*);
IUnknown* modSWF_GetUnknownObject (VARIANT*);
void modSWF_ReleaseUnknownObject (VARIANT*);
HBITMAP modBMPCapture_CaptureWindow (HWND =(HWND)-1,cb_Boolean =FALSE,cb_Integer =0,cb_Integer =0,cb_Integer =0,cb_Integer =0,HDC* =NULL,RECT* =NULL);
cb_PStringW wMPlayer_GetFile (wMPlayer*);
cb_PStringW wMPlayer_GetFileRecord (wMPlayer*);
void wMPlayer_SetFileW (wMPlayer*,const cb_StringW);
void wMPlayer_SetFile (wMPlayer*,const cb_String);
void wMPlayer_SetFileRecordW (wMPlayer*,const cb_StringW);
void wMPlayer_SetFileRecord (wMPlayer*,const cb_String);
cb_Boolean wMPlayer_SaveW (wMPlayer*,const cb_StringW =NULL);
cb_Boolean wMPlayer_Save (wMPlayer*,const cb_String =NULL);
void wMPlayer_SetTimerEnabled (wMPlayer*,cb_Boolean =TRUE,cb_UInteger =(cb_UInteger)-1);
void wMPlayer_Stop (wMPlayer*);
void wMPlayer_StopRecord (wMPlayer*,const cb_String =NULL,cb_Integer =TRUE);
void wMPlayer_Close (wMPlayer*,cb_Integer =0);
void wMPlayer_Shutdown (wMPlayer*);
cb_Boolean wMPlayer_GetMute (wMPlayer*);
cb_Boolean wMPlayer_SetMute (wMPlayer*,cb_Boolean);
HBITMAP wMPlayer_GetCurrentBMP (wMPlayer*);
cb_Boolean wMPlayer_PauseRecord (wMPlayer*,cb_Integer =FALSE);
cb_Boolean wMPlayer_Resume (wMPlayer*,cb_Integer =FALSE);
cb_Boolean wMPlayer_PlayW (wMPlayer*,const cb_StringW =NULL,cb_Integer =FALSE);
cb_Boolean wMPlayer_Play (wMPlayer*,const cb_String =NULL,cb_Integer =FALSE);
cb_Boolean wMPlayer_Pause (wMPlayer*,cb_Integer =FALSE);
cb_Boolean wMPlayer_ResumeRecord (wMPlayer*,cb_Integer =FALSE);
cb_Integer wMPlayer_GetRepeat (wMPlayer*);
void wMPlayer_SetRepeat (wMPlayer*,cb_Boolean =TRUE);
cb_Boolean wMPlayer_GetStretch (wMPlayer*);
void wMPlayer_SetStretch (wMPlayer*,cb_Integer =TRUE);
cb_Integer wMPlayer_OpenW (wMPlayer*,const cb_StringW =NULL,void* =NULL,cb_Integer =TRUE);
cb_Integer wMPlayer_Open (wMPlayer*,const cb_String =NULL,void* =NULL,cb_Integer =TRUE);
cb_Integer wMPlayer_IsPlaying (wMPlayer*);
cb_UInteger wMPlayer_GetPosition (wMPlayer*);
cb_Boolean wMPlayer_SetPosition (wMPlayer*,cb_UInteger);
float wMPlayer_GetRate (wMPlayer*);
cb_Boolean wMPlayer_SetRate (wMPlayer*,float);
cb_UInteger wMPlayer_GetLength (wMPlayer*);
cb_Integer wMPlayer_OpenRecordW (wMPlayer*,const cb_StringW =NULL);
cb_Integer wMPlayer_OpenRecord (wMPlayer*,const cb_String =NULL);
cb_Boolean wMPlayer_RecordW (wMPlayer*,const cb_StringW =NULL,cb_Integer =2,cb_Integer =FALSE,cb_Integer =FALSE);
cb_Boolean wMPlayer_Record (wMPlayer*,const cb_String =NULL,cb_Integer =2,cb_Integer =FALSE,cb_Integer =FALSE);
cb_Boolean wMPlayer_SetBalance (wMPlayer*,cb_Integer,cb_Integer =-1);
cb_Integer wMPlayer_GetVolume (wMPlayer*);
cb_Boolean wMPlayer_SetVolume (wMPlayer*,cb_Integer);
void wMPlayer_SetBackColor (wMPlayer*,COLORREF,COLORREF =CLR_INVALID,cb_Integer =FALSE);
void wMPlayer_Resize (wMPlayer*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wMPlayer_SetDragAccecptFiles (wMPlayer*,cb_Boolean);
wMPlayer* wMPlayer_Create (wMPlayer*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE | 2 | 4);
cb_Integer wMIDIKB_GetMaxWidth (wMIDIKB*);
cb_Integer wMIDIKB_GetMaxHeight (wMIDIKB*);
void wMIDIKB_Resize (wMIDIKB*,cb_Integer,cb_Integer,cb_Integer,cb_Integer =0);
void wMIDIKB_Paint (wMIDIKB*);
wMIDIKB* wMIDIKB_Create (wMIDIKB*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE);
cb_PString wRTF2HTML (const cb_String,void* =NULL);
void modRTF_SetProp (HWND,cb_Integer,cb_Boolean);
cb_Boolean modRTF_GetProp (HWND,cb_Integer);
COLORREF modRTF_SetBackColor (HWND,COLORREF,cb_Integer =FALSE);
cb_Integer modRTF_GetEventMask (HWND);
void modRTF_SetEventMask (HWND,cb_Integer);
cb_Integer modRTF_GetTextMode (HWND);
void modRTF_SetTextMode (HWND,cb_Integer =TM_PLAINTEXT);
void modRTF_EnableAutoURLDetection (HWND,cb_Integer =ENM_LINK);
cb_Integer modRTF_GetTextLen (HWND);
cb_Integer modRTF_GetMaxLen (HWND);
void modRTF_SetMaxLen (HWND,cb_Integer =0x800000);
cb_Integer modRTF_GetSelection (HWND,cb_Integer* =NULL);
void modRTF_SetSelection (HWND,cb_Integer =0,cb_Integer =-1);
cb_Integer modRTF_GetSelStart (HWND,cb_Integer* =NULL);
void modRTF_SetSelStart (HWND,cb_Integer =-1,cb_Integer =0);
cb_Integer modRTF_GetSelEnd (HWND);
cb_Integer modRTF_GetSelLen (HWND,cb_Integer* =NULL);
void modRTF_SetSelLen (HWND,cb_Integer,cb_Integer =-1);
cb_Integer modRTF_LineCount (HWND);
cb_Integer modRTF_GetFirstVisibleLine (HWND);
cb_Integer modRTF_LineFromChar (HWND,cb_Integer);
cb_Integer modRTF_GetCurrentLine (HWND);
cb_Integer modRTF_CharFromLine (HWND,cb_Integer);
cb_Integer modRTF_GetCurrentCol (HWND,cb_Integer* =NULL);
cb_Integer modRTF_GetLastLine (HWND);
cb_Integer modRTF_GetLineLen (HWND,cb_Integer =-1);
cb_Integer modRTF_SelectLine (HWND,cb_Integer =-1,cb_Integer* =NULL,cb_Boolean =TRUE);
cb_PString modRTF_GetTextRange (HWND,cb_Integer =0,cb_Integer =0,void* =NULL);
cb_PString modRTF_GetLine (HWND,cb_Integer =-1,void* =NULL,cb_Integer* =NULL,cb_Integer =SF_TEXT | SFF_SELECTION);
cb_Integer modRTF_SetLine (HWND,const cb_String,cb_Integer =-1,cb_Integer =SF_TEXT | SFF_SELECTION);
cb_PString modRTF_GetRTFLine (HWND,cb_Integer =-1,void* =NULL,cb_Integer* =NULL);
cb_Integer modRTF_SetRTFLine (HWND,const cb_String,cb_Integer =-1);
cb_Integer modRTF_CharFromPos (HWND,cb_Integer,cb_Integer);
cb_Integer modRTF_GetUndoName (HWND);
cb_Integer modRTF_GetRedoName (HWND);
cb_Integer modRTF_CanUndo (HWND);
cb_Integer modRTF_CanRedo (HWND);
cb_Integer modRTF_Undo (HWND);
cb_Integer modRTF_Redo (HWND);
void modRTF_Delete (HWND);
void modRTF_DeleteRTF (HWND);
COLORREF modRTF_GetColor (HWND,cb_Integer =SCF_SELECTION);
void modRTF_SetColor (HWND,COLORREF,cb_Integer =SCF_SELECTION);
cb_LOGFONT* modRTF_GetFont (HWND,cb_LOGFONT* =NULL,cb_Integer =SCF_SELECTION);
cb_LOGFONT* modRTF_SetFont (HWND,cb_LOGFONT* =NULL,cb_Integer =SCF_SELECTION);
void modRTF_EnsureVisible (HWND);
cb_Integer modRTF_GetScrollBarH (HWND);
void modRTF_SetScrollBarH (HWND,cb_Integer);
cb_Integer modRTF_GetScrollBarV (HWND);
void modRTF_SetScrollBarV (HWND,cb_Integer);
cb_Integer modRTF_GoToLine (HWND,cb_Integer =0,cb_Integer =0);
cb_Integer modRTF_FindText (HWND,const cb_String,cb_Integer =-1,cb_Integer =-1,cb_Integer =FR_DOWN);
HWND wRTFBox_hWnd (wRTFBox*);
HWND wRTFBox_hWndRTF (wRTFBox*);
void wRTFBox_SetTextRTF (wRTFBox*,const cb_String);
void wRTFBox_SetText (wRTFBox*,const cb_String);
void wRTFBox_SetSelRTF (wRTFBox*,const cb_String);
void wRTFBox_SetSelText (wRTFBox*,const cb_String);
cb_PString wRTFBox_Text2HTML (wRTFBox*,void* =NULL);
cb_PString wRTFBox_Sel2HTML (wRTFBox*,void* =NULL);
cb_Integer wRTFBox_GetSelection (wRTFBox*,cb_Integer* =NULL);
void wRTFBox_SetSelection (wRTFBox*,cb_Integer,cb_Integer);
cb_Integer wRTFBox_GetSelStart (wRTFBox*,cb_Integer* =NULL);
void wRTFBox_SetSelStart (wRTFBox*,cb_Integer,cb_Integer =0);
cb_Integer wRTFBox_GetSelLen (wRTFBox*,cb_Integer* =NULL);
void wRTFBox_SetSelLen (wRTFBox*,cb_Integer,cb_Integer =-1);
cb_Integer wRTFBox_GetTextLen (wRTFBox*);
cb_Integer wRTFBox_CharFromPos (wRTFBox*,cb_Integer,cb_Integer);
cb_Integer wRTFBox_SelCharOffset (wRTFBox*,cb_Integer,cb_Integer);
cb_PString wRTFBox_GetTextRange (wRTFBox*,cb_Integer =0,cb_Integer =0,void* =NULL);
cb_Integer wRTFBox_GetTextMode (wRTFBox*);
void wRTFBox_SetTextMode (wRTFBox*,cb_Integer =TM_PLAINTEXT);
cb_Boolean wRTFBox_GetProp (wRTFBox*,cb_Integer);
void wRTFBox_SetProp (wRTFBox*,cb_Integer,cb_Boolean);
cb_Integer wRTFBox_GetEventMask (wRTFBox*);
void wRTFBox_SetEventMask (wRTFBox*,cb_Integer,cb_Integer =-1);
cb_Boolean wRTFBox_GetHideSelection (wRTFBox*);
void wRTFBox_SetHideSelection (wRTFBox*,cb_Boolean);
cb_Boolean wRTFBox_GetMultiLine (wRTFBox*);
void wRTFBox_SetMultiLine (wRTFBox*,cb_Boolean);
cb_Boolean wRTFBox_GetReadOnly (wRTFBox*);
void wRTFBox_SetReadOnly (wRTFBox*,cb_Boolean);
cb_Boolean wRTFBox_GetLocked (wRTFBox*);
void wRTFBox_SetLocked (wRTFBox*,cb_Boolean);
cb_Boolean wRTFBox_GetDataChanged (wRTFBox*);
void wRTFBox_SetDataChanged (wRTFBox*,cb_Boolean);
cb_Boolean wRTFBox_GetAutoURLDetect (wRTFBox*);
void wRTFBox_SetAutoURLDetect (wRTFBox*,cb_Integer =ENM_LINK);
cb_Integer wRTFBox_LineCount (wRTFBox*);
cb_Integer wRTFBox_FirstVisibleLine (wRTFBox*);
cb_Integer wRTFBox_LineFromChar (wRTFBox*,cb_Integer);
cb_Integer wRTFBox_CharFromLine (wRTFBox*,cb_Integer);
cb_Integer wRTFBox_GetCurrentLine (wRTFBox*);
cb_Integer wRTFBox_GetCurrentCol (wRTFBox*,cb_Integer* =NULL);
cb_Integer wRTFBox_GetLastLine (wRTFBox*);
cb_Integer wRTFBox_GetLineLen (wRTFBox*,cb_Integer =-1);
void wRTFBox_EnsureVisible (wRTFBox*);
cb_Integer wRTFBox_SelectLine (wRTFBox*,cb_Integer =-1,cb_Integer* =NULL,cb_Boolean =TRUE);
cb_PString wRTFBox_GetLine (wRTFBox*,cb_Integer =-1,void* =NULL,cb_Integer* =NULL,cb_Integer =SF_TEXT | SFF_SELECTION);
void wRTFBox_SetLine (wRTFBox*,const cb_String,cb_Integer =-1,cb_Integer =SF_TEXT | SFF_SELECTION);
cb_PString wRTFBox_GetRTFLine (wRTFBox*,cb_Integer =-1,void* =NULL,cb_Integer* =NULL);
void wRTFBox_SetRTFLine (wRTFBox*,const cb_String,cb_Integer =-1);
cb_Integer wRTFBox_GetMaxLen (wRTFBox*);
void wRTFBox_SetMaxLen (wRTFBox*,cb_Integer =wRTFBox_MAXLEN);
void wRTFBox_GetParagraphOffsets (wRTFBox*,cb_Integer*,cb_Integer*,cb_Integer*);
void wRTFBox_SetParagraphOffsets (wRTFBox*,cb_Integer,cb_Integer,cb_Integer);
cb_Integer wRTFBox_GetSelIndent (wRTFBox*);
void wRTFBox_SetSelIndent (wRTFBox*,cb_Integer);
cb_Integer wRTFBox_GetSelAlignment (wRTFBox*);
void wRTFBox_SetSelAlignment (wRTFBox*,cb_Integer);
cb_Integer wRTFBox_GetUndoName (wRTFBox*);
cb_Integer wRTFBox_GetRedoName (wRTFBox*);
cb_Boolean wRTFBox_CanUndo (wRTFBox*);
cb_Boolean wRTFBox_CanRedo (wRTFBox*);
void wRTFBox_Undo (wRTFBox*);
void wRTFBox_Redo (wRTFBox*);
COLORREF wRTFBox_GetForeColor (wRTFBox*,cb_Integer =SCF_SELECTION);
void wRTFBox_SetForeColor (wRTFBox*,COLORREF,cb_Integer =SCF_SELECTION);
COLORREF wRTFBox_SetBackColor (wRTFBox*,COLORREF);
void wRTFBox_SetDropFiles (wRTFBox*,cb_Boolean);
cb_Integer wRTFBox_GoToLine (wRTFBox*,cb_Integer =0,cb_Integer =0);
cb_Integer wRTFBox_Find (wRTFBox*,const cb_String,cb_Integer =-1,cb_Integer =-1,cb_Integer =FR_DOWN);
cb_Integer wRTFBox_LoadFile (wRTFBox*,const cb_String,cb_Integer =SF_RTF);
cb_Integer wRTFBox_SaveFile (wRTFBox*,const cb_String,cb_Integer =SF_RTF);
void wRTFBox_PrintDocDC (wRTFBox*,HDC,cb_String =NULL,cb_Integer =0,cb_Integer =0);
void wRTFBox_PrintDoc (wRTFBox*,cb_String);
cb_Integer wRTFBox_GetScrollBarH (wRTFBox*);
void wRTFBox_SetScrollBarH (wRTFBox*,cb_Integer);
cb_Integer wRTFBox_GetScrollBarV (wRTFBox*);
void wRTFBox_SetScrollBarV (wRTFBox*,cb_Integer);
void wRTFBox_SetScrollBars (wRTFBox*,cb_Integer);
void wRTFBox_Resize (wRTFBox*,cb_Integer =cb_MIN_INTEGER32,cb_Integer =cb_MIN_INTEGER32,cb_Integer =-1,cb_Integer =-1);
cb_Integer wRTFBox_GetLeft (wRTFBox*);
void wRTFBox_SetLeft (wRTFBox*,cb_Integer);
cb_Integer wRTFBox_GetTop (wRTFBox*);
void wRTFBox_SetTop (wRTFBox*,cb_Integer);
cb_Integer wRTFBox_GetWidth (wRTFBox*);
void wRTFBox_SetWidth (wRTFBox*,cb_Integer);
cb_Integer wRTFBox_GetHeight (wRTFBox*);
void wRTFBox_SetHeight (wRTFBox*,cb_Integer);
wRTFBox* wRTFBox_Create (wRTFBox*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =cb_MIN_INTEGER32 | 1,cb_Integer =-1);
cb_Boolean wRTFBox_GetFocus (wRTFBox*);
void wRTFBox_SetFocus (wRTFBox*);
void wRTFBox_Destroy (wRTFBox*);
void wSCIBox_SetBackColor (wSCIBox*,COLORREF,cb_Integer =-1);
void wSCIBox_SetForeColor (wSCIBox*,COLORREF,cb_Integer =-1);
void wSCIBox_SetSelBackColor (wSCIBox*,COLORREF =-1);
void wSCIBox_SetSelForeColor (wSCIBox*,COLORREF =-1);
void wSCIBox_SetCallTipBackColor (wSCIBox*,COLORREF);
void wSCIBox_SetCallTipForeColor (wSCIBox*,COLORREF);
void wSCIBox_SetCallTipHighLightColor (wSCIBox*,COLORREF);
cb_Integer wSCIBox_GetEOLMode (wSCIBox*);
void wSCIBox_SetEOLMode (wSCIBox*,cb_Integer);
void wSCIBox_ConvertEOL (wSCIBox*,cb_Integer);
cb_Boolean wSCIBox_GetViewCaretLine (wSCIBox*);
void wSCIBox_SetViewCaretLine (wSCIBox*,cb_Boolean);
cb_Boolean wSCIBox_GetViewEOL (wSCIBox*);
void wSCIBox_SetViewEOL (wSCIBox*,cb_Boolean);
cb_LOGFONT* wSCIBox_GetFont (wSCIBox*,cb_LOGFONT* =NULL);
cb_LOGFONT* wSCIBox_SetFont (wSCIBox*,cb_LOGFONT* =NULL);
void wSCIBox_UsePopUp (wSCIBox*,cb_Integer);
void wSCIBox_SetLang (wSCIBox*,cb_UInteger =0);
void wSCIBox_SetDropFiles (wSCIBox*,cb_Boolean);
void wSCIBox_Clear (wSCIBox*);
void wSCIBox_Delete (wSCIBox*);
void wSCIBox_Allocate (wSCIBox*,cb_Integer);
void wSCIBox_AddText (wSCIBox*,const cb_String,cb_Boolean =FALSE);
void wSCIBox_AddStyledText (wSCIBox*,const cb_String,cb_Boolean =FALSE);
void wSCIBox_AppendText (wSCIBox*,const cb_String,cb_Boolean =FALSE);
void wSCIBox_InsertText (wSCIBox*,const cb_String,cb_Integer =-1);
cb_Integer wSCIBox_GetTextLen (wSCIBox*);
cb_PString wSCIBox_GetText_ (wSCIBox*,cb_Integer =FALSE,void* =NULL,cb_Integer* =NULL);
void wSCIBox_SetText (wSCIBox*,const cb_String,cb_Integer =FALSE);
void wSCIBox_ReplaceText (wSCIBox*,const cb_String);
cb_Integer wSCIBox_LineCount (wSCIBox*);
cb_Integer wSCIBox_GetFirstVisibleLine (wSCIBox*);
cb_Integer wSCIBox_LineFromChar (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_CharFromLine (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_GetCurrentLine (wSCIBox*);
cb_Integer wSCIBox_GetCurrentCol (wSCIBox*,cb_Integer* =NULL);
cb_Integer wSCIBox_GetLastLine (wSCIBox*);
cb_Integer wSCIBox_GetLineLen (wSCIBox*,cb_Integer =-1,cb_Boolean =FALSE);
cb_Integer wSCIBox_SelectLine (wSCIBox*,cb_Integer =-1,cb_Integer* =NULL,cb_Boolean =TRUE);
cb_PString wSCIBox_GetLine (wSCIBox*,cb_Integer =-1,void* =NULL,cb_Integer* =NULL);
cb_Integer wSCIBox_SetLine (wSCIBox*,const cb_String,cb_Integer =-1);
cb_Integer wSCIBox_GoToPos (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_GoToLine (wSCIBox*,cb_Integer =0,cb_Integer =0);
cb_PString wSCIBox_GetFile (wSCIBox*,void* =(void*)-2);
void wSCIBox_SetFile (wSCIBox*,const cb_String);
void wSCIBox_EmptyUndoBuffer (wSCIBox*);
cb_Boolean wSCIBox_GetModify (wSCIBox*);
void wSCIBox_SetModify (wSCIBox*);
void wSCIBox_ResetModify (wSCIBox*);
cb_Boolean wSCIBox_CanUndo (wSCIBox*);
cb_Boolean wSCIBox_CanRedo (wSCIBox*);
cb_Integer wSCIBox_Undo (wSCIBox*);
cb_Integer wSCIBox_Redo (wSCIBox*);
cb_Boolean wSCIBox_GetReadOnly (wSCIBox*);
void wSCIBox_SetReadOnly (wSCIBox*,cb_Boolean);
cb_Integer wSCIBox_GetZoom (wSCIBox*);
void wSCIBox_SetZoom (wSCIBox*,cb_Integer =0);
void wSCIBox_ZoomIn (wSCIBox*);
void wSCIBox_ZoomOut (wSCIBox*);
cb_Integer wSCIBox_GetFolderWidth (wSCIBox*);
void wSCIBox_SetFolderWidth (wSCIBox*,cb_Integer =0);
cb_Integer wSCIBox_GetMarginWidth (wSCIBox*);
void wSCIBox_SetMarginWidth (wSCIBox*,cb_Integer =0);
cb_Integer wSCIBox_GetLineNumberWidth (wSCIBox*);
void wSCIBox_SetLineNumberWidth (wSCIBox*,cb_Integer =0);
void wSCIBox_SetWordChars (wSCIBox*,const cb_String);
void wSCIBox_SetWhitespaceChars (wSCIBox*,const cb_String);
cb_Integer wSCIBox_GetWhitespaceMode (wSCIBox*);
void wSCIBox_SetWhitespaceMode (wSCIBox*,cb_Integer);
void wSCIBox_SetWhitespaceBackColor (wSCIBox*,COLORREF =-1);
void wSCIBox_SetWhitespaceForeColor (wSCIBox*,COLORREF =-1);
COLORREF wSCIBox_GetCaretColor (wSCIBox*);
void wSCIBox_SetCaretColor (wSCIBox*,COLORREF);
cb_Integer wSCIBox_GetCaretWidth (wSCIBox*);
void wSCIBox_SetCaretWidth (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_GetCaretLineVisible (wSCIBox*);
void wSCIBox_SetCaretLineVisible (wSCIBox*,cb_Integer);
COLORREF wSCIBox_GetCaretLineBack (wSCIBox*);
void wSCIBox_SetCaretLineBack (wSCIBox*,COLORREF =-1);
void wSCIBox_SetFoldMarginBackColor (wSCIBox*,COLORREF =-1);
void wSCIBox_SetFoldMarginForeColor (wSCIBox*,COLORREF =-1);
cb_Integer wSCIBox_GetTabWidth (wSCIBox*);
void wSCIBox_SetTabWidth (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_GetIndentSize (wSCIBox*);
void wSCIBox_SetIndentSize (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_GetWrapMode (wSCIBox*);
void wSCIBox_SetWrapMode (wSCIBox*,cb_Integer);
cb_Boolean wSCIBox_GetIndentationGuides (wSCIBox*);
void wSCIBox_SetIndentationGuides (wSCIBox*,cb_Boolean);
cb_Integer wSCIBox_GetHighlightGuide (wSCIBox*);
void wSCIBox_SetHighlightGuide (wSCIBox*,cb_Integer);
void wSCIBox_ResetOptions (wSCIBox*);
void wSCIBox_SetOptions (wSCIBox*,cb_Integer =-1);
void wSCIBox_SetFoldMarker (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_LoadFile (wSCIBox*,const cb_String =NULL);
cb_Integer wSCIBox_SaveFile (wSCIBox*,const cb_String =NULL,cb_Boolean =FALSE);
cb_Integer wSCIBox_FindText (wSCIBox*,const cb_String,cb_Integer =-1,cb_Integer =-1,cb_Integer =1,cb_Boolean =TRUE);
void wSCIBox_SetStyleLineNumber (wSCIBox*,cb_Integer =40,COLORREF =cbBlack,COLORREF =cbLightSilver);
void wSCIBox_SetStyleMargin (wSCIBox*,cb_Integer =15);
void wSCIBox_SetStyleFolder (wSCIBox*,cb_Integer =15,cb_Integer =3);
void* wSCIBox_CreateDoc (wSCIBox*);
void wSCIBox_AddRefDoc (wSCIBox*,void*);
void wSCIBox_ReleaseDoc (wSCIBox*,void*);
void* wSCIBox_GetDoc (wSCIBox*);
void wSCIBox_SetDoc (wSCIBox*,void*);
cb_Integer wSCIBox_GetLexer (wSCIBox*);
void wSCIBox_SetLexer (wSCIBox*,cb_Integer =-1);
void wSCIBox_SetKeywords (wSCIBox*,const void*,cb_Integer =0);
void wSCIBox_SetKeywordsFromFile (wSCIBox*,const cb_String,cb_Integer =0);
cb_Boolean wSCIBox_GetFocus (wSCIBox*);
void wSCIBox_SetFocus (wSCIBox*);
void wSCIBox_KillFocus (wSCIBox*);
cb_Integer wSCIBox_GetUserData (wSCIBox*);
void wSCIBox_SetUserData (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_GetScrollWidth (wSCIBox*);
void wSCIBox_SetScrollWidth (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_LinesOnScreen (wSCIBox*);
cb_Boolean wSCIBox_GetwScrollBarH (wSCIBox*);
void wSCIBox_SetwScrollBarH (wSCIBox*,cb_Integer);
cb_Boolean wSCIBox_GetwScrollBarV (wSCIBox*);
void wSCIBox_SetwScrollBarV (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_GetScrollBarH (wSCIBox*);
void wSCIBox_SetScrollBarH (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_GetScrollBarV (wSCIBox*);
void wSCIBox_SetScrollBarV (wSCIBox*,cb_Integer);
void wSCIBox_SetScrollBars (wSCIBox*,cb_Integer);
cb_Integer wSCIBox_DocCount (wSCIBox*);
cb_Integer wSCIBox_GetDocIndex (wSCIBox*,HWND);
HWND wSCIBox_GetDochWnd (wSCIBox*,cb_Integer =-1);
cb_Integer wSCIBox_GetCurrentDoc (wSCIBox*);
cb_Integer wSCIBox_SetCurrentDoc (wSCIBox*,cb_Integer =-2,cb_Integer =FALSE);
cb_Integer wSCIBox_IsRefDoc (wSCIBox*,cb_Integer =-2);
cb_Integer wSCIBox_RemoveDoc (wSCIBox*,cb_Integer =-2);
cb_Boolean wSCIBox_GetMultiLine (wSCIBox*,cb_Integer =-1);
void wSCIBox_SetMultiLine (wSCIBox*,cb_Integer,cb_Integer =-1);
cb_Integer wSCIBox_GetVerticalSplit (wSCIBox*);
void wSCIBox_SetVerticalSplit (wSCIBox*,cb_Integer =FALSE);
void wSCIBox_Resize (wSCIBox*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
void wSCIBox_Destroy (wSCIBox*);
cb_Integer wSCIBox_AddDoc (wSCIBox*);
cb_Integer wSCIBox_DupDoc (wSCIBox*,cb_Integer =-2);
cb_Integer wSCIBox_Clone (wSCIBox*,wSCIBox*,void (cb_CDECL *)(wSCIBox*,cb_Integer,wSCIBox*,cb_Integer),cb_Integer =FALSE);
LRESULT CALLBACK wSCIBox_SCI_Events_ (HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK wSCIBox_Events_ (HWND,UINT,WPARAM,LPARAM);
wSCIBox* wSCIBox_Create (wSCIBox*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE | cb_MIN_INTEGER32,HFONT =NULL);
cb_Integer wShell_Delete (wShell*,const cb_String,cb_Integer =-1);
cb_Integer wShell_Copy (wShell*,const cb_String,const cb_String,cb_Integer =-1);
cb_Integer wShell_Move (wShell*,const cb_String,const cb_String,cb_Integer =-1);
cb_Integer wShell_Rename (wShell*,const cb_String,const cb_String,cb_Integer =-1);
cb_PString wShell_BrowseForFile (wShell*,DWORD,void* =NULL);
cb_PString wShell_BrowseForFolder (wShell*,DWORD,void* =NULL);
wShell* wShell_Initialize (wShell*);
void wShell_Terminate (wShell*);
cb_PString wCrypt_Encrypt (wCrypt*,const cb_String,void* =NULL);
cb_PString wCrypt_Decrypt (wCrypt*,const cb_String,void* =NULL,void* =NULL);
cb_PString wCrypt_Hash (wCrypt*,const cb_String,void* =NULL);
cb_PString wCrypt_RandomBytes (wCrypt*,cb_UInteger,void* =NULL,void* =NULL);
cb_PString wCrypt_ExportKeyBlob (wCrypt*,const cb_String,cb_PString*,cb_PString*,const cb_String,const cb_String,const cb_String,cb_Integer =128,void* =NULL);
wCrypt* wCrypt_Initialize (wCrypt*);
void wCrypt_Terminate (wCrypt*);
void wSSL_Terminate (wSSL*);
char* wSSL_Encrypt (wSSL*,const cb_String,void* =NULL);
char* wSSL_SendClientHello (wSSL*,void* =NULL);
char* wSSL_DataArrival (wSSL*,const cb_String,cb_Integer,void (cb_CDECL *)(const void*,const cb_String),const void* =NULL,void* =NULL,cb_Integer =FALSE);
cb_Integer modSocket_Register (modSocket*,cb_Integer =modSocket_EVENTS_BITS);
cb_Integer modSocket_UnRegister (modSocket*);
cb_Integer modSocket_GetDetails (modSocket*,cb_Integer =3);
cb_Integer modSocket_Bind (modSocket*);
cb_Integer modSocket_Connect (modSocket*,cb_Integer =-1);
cb_Integer modSocket_Listen (modSocket*);
cb_Integer modSocket_RecvData (modSocket*);
void modSocket_StopSSL (modSocket*);
void modSocket_Disconnect (modSocket*,cb_Integer =FALSE);
void modSocket_Close (modSocket*,cb_Integer =FALSE);
void modSocket_Open (modSocket*,cb_Integer,cb_Integer);
SOCKET modSocket_Accept (modSocket*);
cb_Integer modSocket_GetData (modSocket*,BYTE**,cb_Integer,cb_Boolean);
cb_Integer modSocket_GetLine (modSocket*,BYTE**,cb_Boolean =FALSE);
cb_Integer modSocket_SendAllocatedData (modSocket*);
cb_Integer modSocket_AllocData (modSocket*,const void*,cb_Integer);
void modSocket_AllocSSLData (modSocket*,const cb_String,cb_Integer);
cb_Integer modSocket_SetOptions (modSocket*,cb_Integer,int,cb_Integer =SOL_SOCKET);
cb_Integer modSocket_SetSynch (modSocket*,cb_Integer =-1,cb_Integer =-1);
cb_Integer modSocket_DoEvents (void);
cb_Integer modSocket_Initialize (WNDPROC);
void modSocket_Terminate (void);
SOCKET wSocket_SocketHandle (wSocket*);
cb_PString wSocket_GetRemoteHost (wSocket*);
void wSocket_SetRemoteHost (wSocket*,const cb_String);
cb_PString wSocket_GetRemoteHostIP (wSocket*);
void wSocket_SetRemoteHostIP (wSocket*,const cb_String);
cb_UInteger wSocket_GetRemotePort (wSocket*);
void wSocket_SetRemotePort (wSocket*,cb_UInteger);
cb_PString wSocket_GetLocalHostName (wSocket*);
void wSocket_SetLocalHostName (wSocket*,const cb_String);
cb_PString wSocket_GetLocalIP (wSocket*);
void wSocket_SetLocalIP (wSocket*,const cb_String);
cb_UInteger wSocket_GetLocalPort (wSocket*);
void wSocket_SetLocalPort (wSocket*,cb_UInteger);
cb_Integer wSocket_RecvBufferSize (wSocket*);
cb_Integer wSocket_SendBufferSize (wSocket*);
cb_Integer wSocket_RecvBufferLen (wSocket*);
cb_Integer wSocket_SendBufferLen (wSocket*);
cb_Integer wSocket_GetState (wSocket*);
cb_Integer wSocket_GetOptions (wSocket*,cb_Integer,cb_Integer =SOL_SOCKET);
cb_Integer wSocket_SetOptions (wSocket*,cb_Integer,cb_Integer,cb_Integer =SOL_SOCKET);
cb_Integer wSocket_GetRecvTimeout (wSocket*);
cb_Integer wSocket_SetRecvTimeout (wSocket*,cb_Integer);
cb_Integer wSocket_GetSendTimeout (wSocket*);
cb_Integer wSocket_SetSendTimeout (wSocket*,cb_Integer);
void wSocket_SetSynch (wSocket*,cb_Integer =-1,cb_Integer =-1);
cb_Integer wSocket_LastError (wSocket*);
cb_PString wSocket_GetErrorDescription (wSocket*,cb_Integer =0,cb_String =NULL);
cb_PString wSocket_LastErrorMsg (wSocket*,cb_String =NULL);
cb_Integer wSocket_GetProtocol (wSocket*);
void wSocket_SetProtocol (wSocket*,cb_Integer);
void wSocket_ResetBuffers (wSocket*);
void wSocket_Close (wSocket*,cb_Boolean =FALSE);
cb_Integer wSocket_Accept (wSocket*,SOCKET);
cb_Integer wSocket_Connect (wSocket*,cb_String =NULL,cb_UInteger =-1,cb_Integer =-1,cb_Integer =-1,cb_Integer =-1);
cb_Integer wSocket_Listen (wSocket*,cb_UInteger =-1,cb_String =NULL,cb_Integer =-1,cb_Integer =-1);
cb_Integer wSocket_Bind (wSocket*,cb_UInteger,cb_String =NULL,cb_Integer =-1);
cb_Integer wSocket_RecvData (wSocket*);
LPBYTE wSocket_GetData (wSocket*,BYTE** =NULL,void* =0,cb_Boolean =FALSE);
LPBYTE wSocket_PeekData (wSocket*,BYTE** =NULL,void* =0);
cb_PString wSocket_GetLine (wSocket*,BYTE** =NULL,void* =0,cb_Boolean =FALSE);
cb_PString wSocket_PeekLine (wSocket*,BYTE** =NULL,void* =0);
cb_Integer wSocket_SendData (wSocket*,const void*,cb_Integer =-1,cb_Integer =0);
#ifdef __cplusplus
#else
cb_Integer wSocket_Send (wSocket*,const void*,cb_Integer =-1);
#endif
cb_Boolean wSocket_GetTimerEnabled (wSocket*);
void wSocket_SetTimerEnabled (wSocket*,cb_Boolean =FALSE,cb_Integer =-1);
cb_Integer wSocket_GetTimerInterval (wSocket*);
void wSocket_SetTimerInterval (wSocket*,cb_Boolean =FALSE,cb_Integer =0);
void wSocket_StartSSL (wSocket*);
wSocket* wSocket_Initialize (wSocket*);
void wSocket_Terminate (wSocket*);
cb_Integer wTab_Count (wTab*);
void wTab_SetBackColor (wTab*,cb_Integer =-1,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Integer =FALSE);
cb_Integer wTab_SetTabSpace (wTab*,cb_Integer);
cb_Integer wTab_GetTabLeft (wTab*,cb_Integer);
cb_Integer wTab_GetTabTop (wTab*,cb_Integer);
cb_Integer wTab_DrawBar (wTab*,cb_Integer =-1,cb_Integer =-1,cb_Integer =-1,cb_Integer =-1);
cb_Integer wTab_EnsureVisible (wTab*,cb_Integer =-1,cb_Integer =FALSE);
cb_Integer wTab_GetSelected (wTab*);
cb_Integer wTab_SetSelected (wTab*,cb_Integer =-1,cb_Integer =FALSE);
void wTab_RefreshBar (wTab*);
void wTab_Refresh (wTab*);
void wTab_SetAutosize (wTab*,cb_Integer =FALSE);
cb_Integer wTab_InsertTab (wTab*,cb_Integer,const cb_String,HWND =NULL,cb_Integer =cb_MIN_INTEGER32);
cb_Integer wTab_Add (wTab*,const cb_String,HWND =NULL,cb_Integer =cb_MIN_INTEGER32);
HWND wTab_TabhWnd (wTab*,cb_Integer =-1);
HWND wTab_TabChildhWnd (wTab*,cb_Integer =-1,cb_Integer =FALSE);
cb_Integer wTab_GetTabData (wTab*,cb_Integer =-1);
void wTab_SetTabData (wTab*,cb_Integer,cb_Integer =-1);
char* wTab_GetTabCaption (wTab*,cb_Integer =-1,void* =NULL);
void wTab_SetTabCaption (wTab*,const cb_String,cb_Integer =-1,cb_Integer =FALSE);
void wTab_SetTabToolTip (wTab*,const cb_String,cb_Integer =-1,HWND =NULL);
void wTab_ShowTab (wTab*,cb_Integer,cb_Integer =-1);
void wTab_MoveTab (wTab*,cb_Integer,cb_Integer =-1);
void wTab_Remove (wTab*,cb_Integer =-1,cb_Integer =-1);
void wTab_RemoveAll (wTab*);
HWND wTab_Release (wTab*,cb_Integer =-1);
void wTab_SetCloseButton (wTab*,cb_Integer,cb_Integer =-1);
void wTab_SetAddButton (wTab*,cb_Integer,cb_Integer =-1);
void wTab_Resize (wTab*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
cb_Integer wTab_GetTabWidth (wTab*);
cb_Integer wTab_SetTabWidth (wTab*,cb_Integer,cb_Integer =FALSE);
cb_Integer wTab_GetTabHeight (wTab*);
cb_Integer wTab_SetTabHeight (wTab*,cb_Integer,cb_Integer =FALSE);
HBITMAP wTab_GetBMP (wTab*);
void wTab_SetBMP (wTab*,HBITMAP =NULL,cb_Integer =0);
HBITMAP wTab_GetTabBMP (wTab*,cb_Integer =-1);
void wTab_SetTabBMP (wTab*,HBITMAP =NULL,cb_Integer =-1,cb_Integer =0);
wTab* wTab_Create (wTab*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE);
void wTimer_SetEnabled (wTimer*,cb_Integer =TRUE,cb_UInteger =-1);
cb_Integer wTimer_GetEnabled (wTimer*);
void wTimer_SetInterval (wTimer*,cb_UInteger =0);
cb_UInteger wTimer_GetInterval (wTimer*);
void wTimer_SetHREnabled (wTimer*,cb_Integer =TRUE,cb_UInteger =-1);
cb_Boolean wTimer_GetHREnabled (wTimer*);
cb_UInteger wTimer_GetHRInterval (wTimer*);
void wTimer_SetHRInterval (wTimer*,cb_UInteger =0);
wTimer* wTimer_Create (wTimer*,cb_Integer =-1,cb_UInteger =-1);
void wTimer_Kill (wTimer*);
void wTimer_Destroy (wTimer*);
BOOL modVidCap_SaveFrame (HWND,const cb_String);
HBITMAP modVidCap_GetBMP (HWND,const cb_String =NULL);
cb_PString modVidCap_GetCaptureFile (HWND,void* =NULL);
BOOL modVidCap_SetCaptureFile (HWND,const cb_String =NULL);
cb_Integer modVidCap_InitCapture (HWND,CAPTUREPARMS*,cb_Boolean =TRUE,cb_Boolean =TRUE);
BOOL modVidCap_Capture (HWND,const cb_String =NULL);
BOOL modVidCap_Close (HWND);
HWND modVidCap_Create (HWND =NULL,cb_Integer =0,cb_Integer =0,cb_Integer =0,cb_Integer =0,const cb_String ="modVidCap",cb_Integer =WS_CHILD | WS_VISIBLE);
BOOL modVidCap_SetPreview (HWND,cb_Integer,cb_Boolean =FALSE,cb_Integer =66);
cb_Integer modVidCap_SetImageSize (HWND,cb_Integer =320,cb_Integer =240,cb_Integer =32);
cb_Integer modVidCap_ResizeToFit (HWND,HWND =NULL);
cb_PString wVidCapBox_GetCaptureFile (wVidCapBox*);
void wVidCapBox_SetCaptureFile (wVidCapBox*,const cb_String =NULL);
cb_Integer wVidCapBox_SaveFrame (wVidCapBox*,const cb_String);
HBITMAP wVidCapBox_GetBMP (wVidCapBox*,const cb_String);
cb_Integer wVidCapBox_Save (wVidCapBox*,const cb_String =NULL);
void wVidCapBox_Stop (wVidCapBox*);
void wVidCapBox_Close (wVidCapBox*);
cb_Integer wVidCapBox_Open (wVidCapBox*,cb_Integer =0,cb_Integer =0);
cb_Integer wVidCapBox_SetPreview (wVidCapBox*,cb_Integer,cb_Integer =-1,cb_Integer =0);
cb_Integer wVidCapBox_SetVideoFormat (wVidCapBox*);
cb_Integer wVidCapBox_SetImageSize (wVidCapBox*,cb_Integer =0,cb_Integer =0,cb_Integer =32);
void wVidCapBox_ResizeToFit (wVidCapBox*);
cb_Integer wVidCapBox_Pause (wVidCapBox*,cb_Integer =FALSE);
cb_Integer wVidCapBox_Resume (wVidCapBox*,cb_Integer =FALSE);
cb_Integer wVidCapBox_Capture (wVidCapBox*,const cb_String =NULL,cb_Integer =FALSE);
void wVidCapBox_EnableAudio (wVidCapBox*,cb_Boolean =TRUE);
void wVidCapBox_SetBackColor (wVidCapBox*,COLORREF);
void wVidCapBox_Resize (wVidCapBox*,cb_Integer,cb_Integer,cb_Integer =-1,cb_Integer =-1);
wVidCapBox* wVidCapBox_Create (wVidCapBox*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE | 2);


cb_Integer wWMPlayer_IsNothing (wWMPlayer*);
cb_PString wWMPlayer_GetURL (wWMPlayer*,void* =NULL);
cb_PString wWMPlayer_SetURL (wWMPlayer*,const cb_String,void* =NULL);
cb_PStringW wWMPlayer_GetFileW (wWMPlayer*);
void wWMPlayer_SetFileW (wWMPlayer*,const cb_StringW);
void wWMPlayer_SetTimerEnabled (wWMPlayer*,cb_Boolean =TRUE,cb_Integer =-1);
void wWMPlayer_Stop (wWMPlayer*);
void wWMPlayer_Close (wWMPlayer*);
void wWMPlayer_SetVolume (wWMPlayer*,cb_Integer =-123);
cb_Integer wWMPlayer_SetMute (wWMPlayer*,cb_Integer,cb_Integer =FALSE);
cb_Boolean wWMPlayer_GetMute (wWMPlayer*,cb_Integer =FALSE);
void wWMPlayer_SetStretch (wWMPlayer*,cb_Boolean =TRUE);
cb_Integer wWMPlayer_OpenW (wWMPlayer*,const cb_StringW =NULL);
cb_Integer wWMPlayer_Open (wWMPlayer*,const cb_String =NULL);
cb_Integer wWMPlayer_IsPlaying (wWMPlayer*);
double wWMPlayer_GetLength (wWMPlayer*,cb_String =NULL);
double wWMPlayer_GetPosition (wWMPlayer*,cb_String =NULL);
void wWMPlayer_SetPosition (wWMPlayer*,double);
cb_PString wWMPlayer_GetuiMode (wWMPlayer*,void* =NULL);
cb_Integer wWMPlayer_SetuiMode (wWMPlayer*,cb_Integer,const cb_String =NULL);
void wWMPlayer_Play (wWMPlayer*,cb_Integer =0,const cb_String =NULL);
void wWMPlayer_Pause (wWMPlayer*);
void wWMPlayer_Resume (wWMPlayer*);
void wWMPlayer_SetBalance (wWMPlayer*,cb_Integer);
float wWMPlayer_GetRate (wWMPlayer*);
void wWMPlayer_SetRate (wWMPlayer*,float);
void wWMPlayer_Resize (wWMPlayer*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
void wWMPlayer_SetNothing (wWMPlayer*);
void wWMPlayer_Shutdown (wWMPlayer*);
wWMPlayer* wWMPlayer_Create (wWMPlayer*,HWND,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE);
HBITMAP cb_DEFCALL cb_CreateGradientBitmap (HDC,cb_Integer,cb_Integer,cb_Integer,cb_Integer,COLORREF,COLORREF,cb_Integer =FALSE);
HBRUSH cb_DEFCALL cb_CreateGradientBrush (HDC,cb_Integer,cb_Integer,cb_Integer,cb_Integer,COLORREF,COLORREF,cb_Integer =FALSE);
void cb_DEFCALL cb_GradientFillEx (HDC,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,COLORREF,COLORREF,COLORREF,COLORREF,cb_Integer =GRADIENT_FILL_RECT_V);







cb_EndExternC

/*((((((((((((((  Public Macros  ))))))))))))))*/

#define XorBytes XorByteArray
#define modShell_GetSmallIcon(...) modShell_GetIcon(FALSE,__VA_ARGS__)
#define modShell_GetLargeIcon(...) modShell_GetIcon(TRUE,__VA_ARGS__)
#define clsANI_Reset clsANI_Clear
#define clsANI_Rewind clsANI_Clear
#define clsANI_Stop clsANI_Clear
#define clsANI_GetEngine(x) (x)->iEngine_
#define clsANI_GetIndex(x) (x)->BmpNdx_
#define clsANI_GetCurrentFrame clsANI_GetCurrentBMP
#define clsANI_GetMax(x) (x)->BmpMax_
#define wButton_GetCaptionW (cb_PStringW)wButton_GetCaption
#define wButton_IsEnabled wButton_GetEnabled
#define wButton_IsLocked wButton_GetLocked
#define wButton_SetAddress(x) cb_SetWndData((x)->hWnd,x)
#define wAnimation_GetCurrentFrame wAnimation_GetCurrentBMP
#define wPushButton_GetCaptionW (cb_PStringW)wPushButton_GetCaption
#define wPushButton_IsEnabled wPushButton_GetEnabled
#define wPushButton_IsLocked wPushButton_GetLocked
#define wPushButton_SetAddress(x) cb_SetWndData((x)->hWnd,x)
#define wSlider_SetAddress(x) cb_SetWndData((x)->hWnd,x)
#define wSlider_GetRange wSlider_GetMax
#define wScrollBar_Disable wScrollBar_SetEnabled
#define wScrollBar_Enable(x) wScrollBar_SetEnabled(x,TRUE)
#define wBox_GethWnd(x) (x)->hWnd
#define wBox_GetView(x) (x)->hWndView
#define modFTP_ChDir modFTP_SetDir
#define modFTP_IsFolder(x,y) (modFTP_IsExist(x,y) & FILE_ATTRIBUTE_DIRECTORY)
#define modFTP_IsDir modFTP_IsFolder
#define watchDir_Disable(x) watchDir_Enable(x,FALSE)
#define watchDir_Terminate watchDir_Close
#define watchDir_Initialize watchDir_Create
#define wListBox_GetHeader wListBox_GetColumnHeader
#define wListBox_GetColHeader wListBox_GetColumnHeader
#define wListBox_SetHeader wListBox_SetColumnHeader
#define wListBox_SetColHeader wListBox_SetColumnHeader
#define wListBox_GetHeaderSort wListBox_GetColumnHeaderSort
#define wListBox_GetColHeaderSort wListBox_GetColumnHeaderSort
#define wListBox_SetHeaderSort wListBox_SetColumnHeaderSort
#define wListBox_SetColHeaderSort wListBox_SetColumnHeaderSort
#define wListBox_GetColLeft wListBox_GetColumnLeft
#define wListBox_GetColTextA wListBox_GetColumnTextA
#define wListBox_GetColTextW wListBox_GetColumnTextW
#define wListBox_SetColTextA wListBox_SetColumnTextA
#define wListBox_SetColTextW wListBox_SetColumnTextW
#define wListBox_GetColIndex wListBox_GetColumnIndex
#define wListBox_GetColWidth wListBox_GetColumnWidth
#define wListBox_SetColWidth wListBox_SetColumnWidth
#define wListBox_AddCol wListBox_ColumnAdd
#define wListBox_AddColumn wListBox_ColumnAdd
#define wListBox_ColAdd wListBox_ColumnAdd
#define wListBox_AddColW wListBox_ColumnAddW
#define wListBox_AddColumnW wListBox_ColumnAddW
#define wListBox_ColAddW wListBox_ColumnAddW
#define wListBox_RemoveCol wListBox_ColumnRemove
#define wListBox_RemoveColumn wListBox_Column_Remove
#define wListBox_ColRemoveAll(x) wListBox_ColumnRemove(x,0,-1)
#define wListBox_ColumnRemoveAll(x) wListBox_ColumnRemove(x,0,-1)
#define wListBox_ColRemove wListBox_ColumnRemove
#define wListBox_ColClear wListBox_ColumnClear
#define wListBox_SetDragAcceptFiles wListBox_SetDropFiles
#define wListBox_ColCount wListBox_GetColumnCount
#define wListBox_ColumnCount wListBox_GetColumnCount
#define wListBox_GetColCount wListBox_GetColumnCount
#define wListBox_GetListWidth(x) ((cb_Integer)(x)->m_lstWidth_)
#define wListBox_GetListHeight(x) ((cb_Integer)(x)->m_lstHeight_)
#define wListBox_GetCount(T) (T)->ItemsCnt
#define wListBox_Count wListBox_GetCount
#define wListBox_GetListhWnd(x) (x)->hWndLB
#define wListBox_GetListBox wListBox_GetListhWnd
#define wListBox_Insert wListBox_InsertText
#define wListBox_InsertA wListBox_InsertTextA
#define wListBox_InsertW wListBox_InsertTextW
#define wListBox_Add wListBox_Insert
#define wListBox_AddA wListBox_InsertA
#define wListBox_AddW wListBox_InsertW
#define wListBox_AddText wListBox_InsertText
#define wListBox_AddTextA wListBox_InsertTextA
#define wListBox_AddTextW wListBox_InsertTextW
#define wListBox_GetFirstChecked wListBox_GetNextChecked
#define wListBox_GetLastChecked wListBox_GetPrevChecked
#define wListBox_CheckAll wListBox_Check
#define wListBox_UnCheckAll wListBox_UnCheck
#define wListBox_SetSelectedItem(x,y) wListBox_SetCurrentItem(x,y,TRUE+1)
#define wListBox_UnSetSelectedItem wListBox_UnSetCurrentItem
#define wListBox_Delete wListBox_Remove
#define wListBox_GetFirstSelected wListBox_GetNextSelected
#define wListBox_GetLastSelected wListBox_GetPrevSelected
#define wListBox_SelectAll wListBox_Select
#define wListBox_UnSelectAll wListBox_UnSelect
#define wListBox_ClearImageList(x) wListBox_CreateImageList(x,0)
#define wListBox_SmallIcons_Destroy wListBox_ClearImageList
#define wListBox_GetItemLeft(x,y) wListBox_GetItemLeft_(x)
#define wListBox_GetColPos wListBox_GetColumnPos
#define wListBox_GetItemWindowRect wListBox_GetItemRect
#define wListBox_SetColBackColor wListBox_SetColumnBackColor
#define wListBox_SetColForeColor wListBox_SetColumnForeColor
#define wListBox_CancelLabelEdit(x) wListBox_EndLabelEdit(x,FALSE)
#define wListBoxSetAutoHScrollBar(x,y) wListBox_SetAutoHScrollBar(&(x)->wListBox1,y)
#define wListBoxSetAutoVScrollBar(x,y) wListBox_SetAutoVScrollBar(&(x)->wListBox1,y)
#define wListBoxGetListBox(x) &(x)->wListBox1
#define modEDIT_GetMaxLength modEDIT_GetMaxLen
#define modEDIT_SetMaxLength modEDIT_SetMaxLen
#define modEDIT_GetSel modEDIT_GetSelection
#define modEDIT_SelectAll(x) modEDIT_SetSelection(x,0,-2)
#define modEDIT_SelectNone(x) modEDIT_SetSelection(x,0,0)
#define modEDIT_SetSel modEDIT_SetSelection
#define modEDIT_GetCurrentPos modEDIT_GetSelStart
#define modEDIT_LineOfChar modEDIT_LineFromChar
#define modEDIT_GetCurrentColumn modEDIT_GetCurrentCol
#define modEDIT_GetModify(h) ((cb_Integer)Edit_GetModify(h))
#define modEDIT_SetCurrentLine modEDIT_GoToLine
#define modEDIT_GoToStart modEDIT_GoToLine
#define modEDIT_GoToEnd(x) modEDIT_GoToLine(x,0,-2)
#define modEDIT_GoToEOL(x,y) modEDIT_GoToLine(x,y,-1)
#define wTextBox_GetSel wTextBox_GetSelection
#define wTextBox_SelectNone(x) wTextBox_SetSelection(x,0,0)
#define wTextBox_SelectAll(x) wTextBox_SetSelection(x,0,-2)
#define wTextBox_SetSel wTextBox_SetSelection
#define wTextBox_Add wTextBox_AddText
#define wTextBox_Replace wTextBox_ReplaceText
#define wTextBox_GetText(x,...) wTextBox_GetText_(x,FALSE,__VA_ARGS__)
#define wTextBox_GetSelText(x,...) wTextBox_GetText_(x,TRUE,__VA_ARGS__)
#define wTextBox_Get wTextBox_GetText
#define wTextBox_Set wTextBox_SetText
#define wTextBox_GetCurrentPos wTextBox_GetSelStart
#define wTextBox_LineOfChar wTextBox_LineFromChar
#define wTextBox_GetCurrentColumn wTextBox_GetCurrentCol
#define wTextBox_GetMaxLength wTextBox_GetMaxLen
#define wTextBox_SetMaxLength wTextBox_SetMaxLen
#define wTextBox_ResetModify(x) wTextBox_SetModify(x)
#define wTextBox_SetCurrentLine wTextBox_GoToLine
#define wTextBox_SetCurrentColumn wTextBox_SetCurrentCol
#define wTextBox_SetCurrentCol(x,y) wTextBox_GoToLine(x,-1,y)
#define wTextBox_GoToStart wTextBox_GoToLine
#define wTextBox_GoToEnd(x) wTextBox_GoToLine(x,0,-2)
#define wTextBox_GoToEOL(x,y) wTextBox_GoToLine(x,y,-1)
#define wTextBox_Destroy(x) \
 if ((x)->hWnd) { \
   DestroyWindow((x)->hWnd); \
 }
#define wComboBox_Count wComboBox_GetCount
#define wComboBox_ListCount wComboBox_GetCount
#define wComboBox_GetSelectedItem wComboBox_GetCurrentItem
#define wComboBox_SetSelectedItem wComboBox_SetCurrentItem
#define wComboBox_GetListBox(x) &(x)->wListBox1
#define wComboBox_SetAutoHScrollBar(x,y) wListBox_SetAutoHScrollBar(&(x)->wListBox1,y)
#define wComboBox_SetAutoVScrollBar(x,y) wListBox_SetAutoVScrollBar(&(x)->wListBox1,y)
#define wTreeView_Count wTreeView_GetCount
#define wCommander_FTPIsDir wCommander_FTPIsFolder
#define wCommander_FTPCurDir wCommander_FTPGetDir
#define wCommander_FTPGetCurrentDir wCommander_FTPGetDir
#define wCommander_FTPChDir wCommander_FTPSetDir
#define wCommander_GetHeader wCommander_GetColumnHeader
#define wCommander_GetColHeader wCommander_GetColumnHeader
#define wCommander_SetHeader wCommander_SetColumnHeader
#define wCommander_SetColHeader wCommander_SetColumnHeader
#define wCommander_GetHeaderSort wCommander_GetColumnHeaderSort
#define wCommander_GetColHeaderSort wCommander_GetColumnHeaderSort
#define wCommander_SetHeaderSort wCommander_SetColumnHeaderSort
#define wCommander_SetColHeaderSort wCommander_SetColumnHeaderSort
#define wCommander_ResetBackSlash(x) wCommander_SetBackSlash(x,FALSE)
#define wCommander_GetFile wCommander_GetFileName
#define wCommander_GetDir wCommander_GetDirName
#define wCommander_GetFolderName wCommander_GetDirName
#define wCommander_GetFolder wCommander_GetDirName
#define wCommander_Reset(x) wCommander_Fill(x,(const cb_String)-1)
#define wCommander_Refresh wCommander_Fill
#define wCommander_IsFolder wCommander_IsDir
#define wCommander_SetPath wCommander_ChangeDir
#define wCommander_ChDir wCommander_ChangeDir
#define wCommander_SetFolder wCommander_ChangeDir
#define wCommander_ChangeFolder wCommander_ChangeDir
#define wCommander_FindDir wCommander_FindFolder
#define clsSCI_StyleClearAll(x) SCIM_StyleClearAll(x)
#define clsSCI_SetSelFore(x,...) SCIM_SetSelFore(x,__VA_ARGS__)
#define clsSCI_SetSelBack(x,...) SCIM_SetSelBack(x,__VA_ARGS__)
#define clsSCI_CallTipSetFore(x,...) SCIM_CallTipSetBack(x,__VA_ARGS__)
#define clsSCI_CallTipSetBack(x,...) SCIM_CallTipSetBack(x,__VA_ARGS__)
#define clsSCI_ResetZoom clsSCI_SetZoom
#define clsSCI_GetViewWS clsSCI_GetWhitespaceMode
#define clsSCI_SetViewWS clsSCI_SetWhitespaceMode
#define clsSCI_GetCaretLineBackColor clsSCI_GetCaretLineBack
#define clsSCI_SetCaretLineBackColor clsSCI_SetCaretLineBack
#define clsSCI_GetInsertMode(x) !(p._GetOvertype(x))
#define clsSCI_SetInsertMode(x,y) clsSCI_SetOvertype(x,!(y))
#define clsSCI_ToggleInsertMode clsSCI_EditToggleOvertype
#define clsSCI_GetWrapStyle clsSCI_GetWrapMode
#define clsSCI_SetWrapStyle clsSCI_SetWrapMode
#define clsSCI_LineOfChar clsSCI_LineFromChar
#define clsSCI_LineFromPosition clsSCI_LineFromChar
#define clsSCI_CharOfLine clsSCI_CharFromLine
#define clsSCI_PositionFromLine clsSCI_CharFromLine
#define clsSCI_GetCaretLineVisible clsSCI_GetViewCaretLine
#define clsSCI_SetCaretLineVisible clsSCI_SetViewCaretLine
#define clsSCI_LineStart clsSCI_Home
#define clsSCI_LineStartExtend clsSCI_HomeExtend
#define clsSCI_LineStartDisplay clsSCI_HomeDisplay
#define clsSCI_LineStartDisplayExtend clsSCI_HomeDisplayExtend
#define clsSCI_LineVisibleStart clsSCI_VCHome
#define clsSCI_LineStartExtend clsSCI_VCHomeExtend
#define clsSCI_GetSel clsSCI_GetSelection
#define clsSCI_SelectAll(x) clsSCI_SetSelection(x,0,-2)
#define clsSCI_SelectNone(x) clsSCI_SetSelection(x,0,0)
#define clsSCI_SetSel clsSCI_SetSelection
#define clsSCI_GetCurrentColumn clsSCI_GetCurrentCol
#define clsSCI_GetSelText(x,...) clsSCI_GetText_(x,TRUE,__VA_ARGS__)
#define clsSCI_GetText(x,...) clsSCI_GetText_(x,FALSE,__VA_ARGS__)
#define clsSCI_SetCurrentLine clsSCI_GoToLine
#define clsSCI_GoToStart clsSCI_GoToLine
#define clsSCI_GoToEnd(x) clsSCI_GoToLine(x,0,-2)
#define clsSCI_GoToEOL(x,y) clsSCI_GoToLine(x,y,-1)
#define clsSCI_KillFocus(x) clsSCI_SetFocus(x,FALSE)
#define clsShellPipe_IsRunning(...) (clsShellPipe_IsActive(__VA_ARGS__)>0)
#define clsShellPipe_HasStdIn(x) ((cb_UInteger)((cb_UInteger)((x)->hStdIn_)-2)<(cb_UInteger)(-2-2))
#define clsShellPipe_GetLastError(x) (x)->LastResult
#define clsShellPipe_LastError clsShellPipe_GetLastError
#define clsShellPipe_GetLastResult(x) (x)->LastResult
#define clsShellPipe_LastResult clsShellPipe_GetLastResult
#define clsShellPipe_SetLastError(x,y) (x)->LastResult = y
#define clsShellPipe_SetLastResult(x,y) (x)->LastResult = y
#define clsShellPipe_PeekData(x,y) clsShellPipe_GetData(x,y,TRUE)
#define clsShellPipe_PeekLine(x,y) clsShellPipe_GetLine(x,y,TRUE)
#define clsShellPipe_Destroy clsShellPipe_Terminate
#define clsBatch_IsActive(x) clsShellPipe_IsActive(&((x)->m_ShellPipe))
#define clsBatch_IsRunning(x) clsShellPipe_IsRunning(&((x)->m_ShellPipe))
#define clsBatch_GetShellPipe(x) &((x)->m_ShellPipe)
#define clsBatch_HasChildrens(x) clsShellPipe_HasChildrens(&((x)->m_ShellPipe))
#define clsBatch_SetSTDHandles(x,...) clsShellPipe_SetSTDHandles(&((x)->m_ShellPipe),__VA_ARGS__)
#define clsBatch_ResetPath clsBatch_SetPath
#define clsBatch_HasThread (x)->m_hThread
#define clsBatch_IsBreak clsBatch_GetBreak
#define clsBatch_BreakOff clsBatch_SetBreak
#define clsBatch_BreakOn(x) clsBatch_SetBreak(x,TRUE)
#define clsBatch_IsEcho clsBatch_GetEcho
#define clsBatch_IsEchoON clsBatch_GetEcho
#define clsBatch_EchoOff clsBatch_SetEcho
#define clsBatch_EchoOn(x) clsBatch_SetEcho(x,TRUE)
#define clsBatch_HasAsyncScript clsBatch_HasThreadScript
#define clsBatch_Pause(x) clsBatch_SetPause(x,TRUE)
#define clsBatch_Resume clsBatch_SetPause
#define clsBatch_LastResult(x) (x)->m_Result_
#define clsBatch_LastError(x) clsShellPipe_LastError(&((x)->m_ShellPipe))
#define wConsole_GetEngine(x) (x)->iEngine
#define wConsole_GetSCI(x) (&(x)->clsSCI1)
#define wConsole_IsRunning(x) wConsole_IsActive(x)>0
#define wConsole_SetPath(x,y) clsBatch_SetPath(&(x)->b1,y)
#define wConsole_ResetPath(x) clsBatch_ResetPath(&(x)->b1)
#define wConsole_SetStdIn(x,y) clsBatch_SetStdIn(&(x)->b1,y)
#define wConsole_Start(x) wConsole_Run(x,(const cb_String)-1)
#define wConsole_HasScript(x) clsBatch_HasScript(&(x)->b1)
#define wConsole_GetCurrentDir(x,y) clsBatch_GetCurrentDir(&((x)->b1),y)
#define wConsole_GetBreak wConsole_IsBreak
#define wConsole_BreakOn(x) wConsole_SetBreak(x,TRUE)
#define wConsole_BreakOff(x) wConsole_SetBreak(x)
#define wConsole_GetESCBreak wConsole_IsESCBreak
#define wConsole_ESCBreakOn(x) wConsole_SetESCBreak(x,TRUE)
#define wConsole_ESCBreakOff(x) wConsole_SetESCBreak(x)
#define wConsole_IsEcho(x) clsBatch_IsEcho(&((x)->b1))
#define wConsole_IsEchoON(x) clsBatch_IsEchoON(&((x)->b1))
#define wConsole_SetEcho(x,y) clsBatch_SetEcho(&((x)->b1),y)
#define wConsole_EchoOn(x) clsBatch_EchoOn(&((x)->b1))
#define wConsole_EchoOff(x) clsBatch_EchoOff(&((x)->b1))
#define wConsole_IsSCI(x) ((x)->flag1_ & wConsole_SCI_BIT_)
#define wConsole_IsTEXT ((x)->flag1_ & wConsole_TEXT_BIT_)
#define wConsole_GetEditEngine(x) ((x)->flag1_ & (wConsole_SCI_BIT_ | wConsole_TEXT_BIT_))
#define wConsole_Destroy_ wConsole_Close
#define wConsole_Restart_(x) wConsole_Close(x,cb_MAX_INTEGER32,-1)
#define wConsole_SetBackColor wConsole_SetOutBackColor
#define wConsole_LoadList(x,...) wComboBox_LoadList(&(x)->wComboBox1,__VA_ARGS__)
#define wConsole_InsertList(x,...) wComboBox_InsertList(&(x)->wComboBox1,__VA_ARGS__)
#define wConsole_SaveList(x,...) \
 if (wComboBox_ListCount(&(x)->wComboBox1)>0) { \
   wComboBox_SaveList(&(x)->wComboBox1,__VA_ARGS__); \
 }
#define wConsole_SetForeColor wConsole_SetOutForeColor
#define wConsole_Copy wConsole_CopyToClipboard
#define wConsole_Display wConsole_TextOutput
#define wConsole_SetUpdateInterval wConsole_SetInterval
#define clsFormShadow_Disable(x) clsFormShadow_SetEnabled(x,FALSE)
#define clsFormShadow_Enable(x) clsFormShadow_SetEnabled(x,TRUE)
#define clsFormShadow_Reset clsFormShadow_Terminate
#define wPopupMenu_Add wPopupMenu_Insert
#define wPopupMenu_Append wPopupMenu_Add
#define wPopupMenu_GetShadowDepth wPopupMenu_GetShadow
#define wPopupMenu_SetShadowDepth wPopupMenu_SetShadow
#define wPopupMenu_ResetShadow(x) wPopupMenu_SetShadow(x,0)
#define wPopupMenu_PopupMenu wPopupMenu_Open
#define wPopupMenu_ShowPopup wPopupMenu_Open
#define wPopupMenu_ShowPopupMenu wPopupMenu_Open
#define wPopupMenu_Show wPopupMenu_Open
#define wPopupMenu_Reset(x) wPopupMenu_Destroy_(x,FALSE)
#define wPopupMenu_Destroy(x) wPopupMenu_Destroy_(x,TRUE)
#define wPopupMenu_Terminate wPopupMenu_Destroy
#define wPopupMenu_Create wPopupMenu_Initialize
#define wMenuBar_GetCount wMenuBar_Count
#define wMenuBar_DrawBar(x) DrawMenuBar(x->hWndParent)
#define wMenuBar_DrawMenuBar wMenuBar_DrawBar
#define wMenuBar_Append wMenuBar_Add
#define wMenuBar_Delete wMenuBar_Remove
#define wMenuBar_Reset(x) wMenuBar_Destroy_(x,FALSE)
#define wMenuBar_Destroy(x) wMenuBar_Destroy_(x,TRUE)
#define wMenuBar_Create wMenuBar_Initialize
#define wFTP clsFTP
#define wFTP_Disconnect clsFTP_Disconnect
#define wFTP_Connect clsFTP_Connect
#define wFTP_GetURL clsFTP_GetURL
#define wFTP_SetURL clsFTP_SetURL
#define wFTP_FindFirst clsFTP_FindFirst
#define wFTP_FindNext clsFTP_FindNext
#define wFTP_MkDir clsFTP_MkDir
#define wFTP_RmDir clsFTP_RmDir
#define wFTP_GetDir clsFTP_GetDir
#define wFTP_SetDir clsFTP_SetDir
#define wFTP_ChDir clsFTP_ChDir
#define wFTP_Rename clsFTP_Rename
#define wFTP_Delete clsFTP_Delete
#define wFTP_Command clsFTP_Command
#define wFTP_IsExist clsFTP_IsExist
#define wFTP_GetFileSize clsFTP_GetFileSize
#define wFTP_GetFile clsFTP_GetFile
#define wFTP_SetFile clsFTP_SetFile
#define wFTP_PutFile clsFTP_PutFile
#define wFTP_Close clsFTP_Close
#define wFTP_Terminate clsFTP_Terminate
#define wFTP_Initialize clsFTP_Initialize




#define wIE_KillTimer wIE_SetTimerEnabled
#define wIE_SetTimer wIE_SetTimerEnabled


#define wIExplorer_Refresh wIExplorer_Refresh2
#define wInet_IsOpen(x) ((x)->cFTP_.m_State>=wInet_Open)
#define wInet_IsConnected(x) ((x)->cFTP_.m_State>=wInet_Connected)
#define wInet_GetBytesReceived wInet_RecvBufferLen
#define wInet_ChDir wInet_SetDir
#define wInet_IsFolder(x,...) (wInet_IsExist(x,__VA_ARGS__) & (cb_MIN_INTEGER32 | FILE_ATTRIBUTE_DIRECTORY))
#define wInet_IsDir wInet_IsFolder
#define wInet_SetFile wInet_PutFile
#define wInet_Connect wInet_OpenURL
#define wInet_ConnectURL wInet_OpenURL
#define wInet_ConnectHTTP wInet_OpenURL
#define wInet_ConnectServer wInet_OpenServer
#define wInet_ConnectFTPServer wInet_OpenFTPServer
#define wInet_ConnectFTP wInet_OpenFTPServer
#define wInet_ConnectFTPSync wInet_OpenFTPServerSync
#define wInet_AddConnectFTP(x) wInet_OpenFTPServerSync(x,(const cb_String)-1,2)
#define wInet_Cancel wInet_CloseURL
#define wInet_Disconnect wInet_CloseURL
#define wInet_DownloadFile wInet_GetURL
#define wInet_Create wInet_Initialize
#define wInet_Destroy wInet_Terminate
#define wListView_ColCount wListView_GetColCount
#define wListView_AddCol wListView_ColAdd
#define wListView_Count wListView_GetCount
#define wListView_SetCurrentItem wListView_SetSelectedItem
#define wListView_GetFirstChecked wListView_GetNextChecked
#define wListView_GetLastChecked wListView_GetPrevChecked
#define wListView_CheckAll wListView_Check
#define wListView_UnCheckAll wListView_UnCheck
#define wListView_GetFirstSelected wListView_GetNextSelected
#define wListView_GetLastSelected wListView_GetPrevSelected
#define wListView_SelectAll wListView_Select
#define wListView_UnSelectAll wListView_UnSelect
#define wListView_SmallIcons_Destroy(x) wListView_SetSmallIcons(x,NULL)
#define wListView_SetDragAcceptFiles wListView_SetDropFiles
#define clsMCIStr_Rewind clsMCIStr_SetPosition
#define clsMCIStr_Seek clsMCIStr_SetPosition
#define clsMCIStr_hWnd clsMCIStr_GethWnd
#define wMCIStr_Rewind wMCIStr_SetPosition
#define wMCIStr_Seek wMCIStr_SetPosition
#define clsMCI_Rewind clsMCI_SetPosition
#define clsMCI_Seek clsMCI_SetPosition
#define clsMCI_hWnd clsMCI_GethWnd
#define wMCI_Rewind wMCI_SetPosition
#define wMCI_Seek wMCI_SetPosition
#define modSWF_Resume modSWF_Play
#define modSWF_GetLength modSWF_TotalFrames
#define modSWF_GetPosition modSWF_GetFrame
#define modSWF_SetPosition modSWF_SetFrame
#define modSWF_GetuiModeW modSWF_GetWModeW
#define modSWF_GetuiMode modSWF_GetWMode
#define modSWF_SetuiModeW modSWF_SetWModeW
#define modSWF_SetuiMode modSWF_SetWMode
#define modBMPCapture_CaptureScreen modBMPCapture_CaptureWindow
#define wMPlayer_KillTimer(x) wMPlayer_SetTimerEnabled(x,FALSE)
#define wMPlayer_SetTimer wMPlayer_SetTimerEnabled
#define wMPlayer_GetCurrentFrame wMPlayer_GetCurrentBMP
#define modRTF_GetMaxLength modRTF_GetMaxLen
#define modRTF_SetMaxLength modRTF_SetMaxLen
#define modRTF_GetSel modRTF_GetSelection
#define modRTF_SelectAll(x) modRTF_SetSelection(x,0,-2)
#define modRTF_SelectNone(x) modRTF_SetSelection(x,0,0)
#define modRTF_SetSel modRTF_SetSelection
#define modRTF_GetCurrentPos modRTF_GetSelStart
#define modRTF_LineOfChar modRTF_LineFromChar
#define modRTF_GetCurrentColumn modRTF_GetCurrentCol
#define modRTF_GetUndoType modRTF_GetUndoName
#define modRTF_GetRedoType modRTF_GetRedoName
#define modRTF_SetCurrentLine modRTF_GoToLine
#define modRTF_GoToStart modRTF_GoToLine
#define modRTF_GoToEnd(x) modRTF_GoToLine(x,0,-2)
#define modRTF_GoToEOL(x,y) modRTF_GoToLine(x,y,-1)
#define wRTFBox_GethWnd wRTFBox_hWnd
#define wRTFBox_GetRTFhWnd wRTFBox_hWndRTF
#define wRTFBox_GetRTF(x,...) modRTF_GetRTF((x)->hWndRTF,__VA_ARGS__)
#define wRTFBox_GetTextRTF wRTFBox_GetRTF
#define wRTFBox_GetRTFText wRTFBox_GetRTF
#define wRTFBox_GetText(x,...) modRTF_GetText((x)->hWndRTF,__VA_ARGS__)
#define wRTFBox_GetSelRTF(x,...) modRTF_GetSelRTF((x)->hWndRTF,__VA_ARGS__)
#define wRTFBox_GetSelText(x,...) modRTF_GetSelText((x)->hWndRTF,__VA_ARGS__)
#define wRTFBox_GetSel wRTFBox_GetSelection
#define wRTFBox_SetSel wRTFBox_SetSelection
#define wRTFBox_SelectAll(x) wRTFBox_SetSelection(x,0,-1)
#define SelectNone(x) wRTFBox_SetSelection(x,0,0)
#define wRTFBox_LineOfChar wRTFBox_LineFromChar
#define wRTFBox_GetCurrentColumn wRTFBox_GetCurrentCol
#define wRTFBox_GetMaxLength wRTFBox_GetMaxLen
#define wRTFBox_SetMaxLength wRTFBox_SetMaxLen
#define wRTFBox_GetFont(x,...) modRTF_GetFont((x)->hWndRTF,__VA_ARGS__)
#define wRTFBox_SetFont(x,...) modRTF_SetFont((x)->hWndRTF,__VA_ARGS__)
#define wRTFBox_SetCurrentLine wRTFBox_GoToLine
#define wRTFBox_SetCurrentCol(x,y) wRTFBox_GoToLine(x,-1,y)
#define wRTFBox_SetCurrentColumn wRTFBox_SetCurrentCol
#define wRTFBox_GoToStart wRTFBox_GoToLine
#define wRTFBox_GoToEnd(x) wRTFBox_GoToLine(x,0,-2)
#define wRTFBox_GoToEOL(x,y) wRTFBox_GoToLine(x,y,-1)
#define wSCIBox_GetLang(x) (x)->iLang
#define wSCIBox_GetText(x,...) wSCIBox_GetText_(x,FALSE,__VA_ARGS__)
#define wSCIBox_GetSelText(x,...) wSCIBox_GetText_(x,TRUE,__VA_ARGS__)
#define wSCIBox_LineOfChar wSCIBox_LineFromChar
#define wSCIBox_GetCurrentColumn wSCIBox_GetCurrentCol
#define wSCIBox_SetCurrentLine wSCIBox_GoToLine
#define wSCIBox_SetCurrentColumn wSCIBox_SetCurrentCol
#define wSCIBox_SetCurrentCol(x,y) wSCIBox_GoToLine(x,-1,y)
#define wSCIBox_GoToStart wSCIBox_GoToLine
#define wSCIBox_GoToEnd(x) wSCIBox_GoToLine(x,0,-2)
#define wSCIBox_GoToEOL(x,y) wSCIBox_GoToLine(x,y,-1)
#define wSCIBox_GetFileName wSCIBox_GetFile
#define wSCIBox_SetFileName wSCIBox_SetFile
#define wSCIBox_ResetZoom wSCIBox_SetZoom
#define wSCIBox_GetViewWS wSCIBox_GetWhitespaceMode
#define wSCIBox_SetViewWS wSCIBox_SetWhitespaceMode
#define wSCIBox_GetCaretLineBackColor wSCIBox_GetCaretLineBack
#define wSCIBox_SetCaretLineBackColor wSCIBox_SetCaretLineBack
#define wSCIBox_GetWrapStyle wSCIBox_GetWrapMode
#define wSCIBox_SetWrapStyle wSCIBox_SetWrapMode
#define wSCIBox_GetDocCount wSCIBox_DocCount
#define wSCIBox_GetSplitV wSCIBox_GetVerticalSplit
#define wSCIBox_SetSplitV wSCIBox_SetVerticalSplit
#define wShell_Create wShell_Initialize
#define wShell_Destroy wShell_Terminate
#define wCrypt_RC4_Encrypt wCrypt_Encrypt
#define wCrypt_RC4_Decrypt wCrypt_Decrypt
#define wCrypt_MD5_Hash wCrypt_Hash
#define wCrypt_GenerateRandomBytes wCrypt_RandomBytes
#define wSSL_Close wSSL_Terminate
#define wSSL_Open wSSL_SendClientHello
#define modSocket_IsASynch(x) ((x)->iFlag & modSocket_REGISTER_BIT_)
#define modSocket_IsSynch(x) !((x)->iFlag & modSocket_REGISTER_BIT_)
#define modSocket_Assign(x,y) \
 (x)->SocketHandle = y

#define modSocket_GetHandle(x) (x)->SocketHandle
#define modSocket_SetHandle modSocket_Assign
#define modSocket_WasConnect(x) ((x)->iFlag & modSocket_CONNECT_BIT_)
#define modSocket_IsOn(x) ((x)->iFlag & modSocket_ON_BIT_)
#define wSocket_StopSSL(x) modSocket_StopSSL(&(x)->Buf)
#ifdef __cplusplus
#define wSocket_Send wSocket_SendData
#endif
#define wSocket_Disconnect(x) wSocket_Close(x,TRUE)
#define wSocket_Get wSocket_GetData
#define wSocket_Peek wSocket_PeekData
#define wSocket_KillTimer wSocket_SetTimerEnabled
#define wSocket_SetTimer wSocket_SetTimerEnabled
#define wSocket_GetBytesReceived wSocket_RecvBufferLen
#define wSocket_DoEvents modSocket_DoEvents
#define wSocket_Create wSocket_Initialize
#define wSocket_Destroy wSocket_Terminate
#define wTab_GetCount wTab_Count
#define wTab_TabSpace(x) (x)->TabSpace
#define wTab_GetTabSpace wTab_TabSpace
#define wTab_GetTabhWnd wTab_TabhWnd
#define wTab_GetTabChildhWnd wTab_TabChildhWnd
#define wTab_GetTabChild wTab_TabChildhWnd
#define wTab_HideTab(x,y) wTab_ShowTab(x,y,2)
#define wTimer_Pause(x) wTimer_SetEnabled(x,FALSE)
#define wTimer_Resume(x) wTimer_SetEnabled(x,TRUE)
#define wTimer_HRPause(x) wTimer_SetHREnabled(x,-1)
#define wTimer_HRResume(x) wTimer_SetHREnabled(x,TRUE)
#define wTimer_HRKill(x) wTimer_SetEnabled(x,FALSE)
#define wTimer_Initialize wTimer_Create
#define wTimer_Terminate wTimer_Destroy
#define modVidCap_CopyFrame(hWin) capEditCopy(hWin)
#define modVidCap_SetData(hWin,i) capSetUserData(hWin,i)
#define modVidCap_GetData(hWin) capGetUserData(hWin)
#define modVidCap_Stop(hWin) capCaptureStop(hWin)
#define modVidCap_Open(hWin,Index) capDriverConnect(hWin,Index)
#define modVidCap_Destroy(hWin) DestroyWindow(hWin)
#define modVidCap_Pause(x) modVidCap_Stop(x)
#define modVidCap_Resume(x) modVidCap_Capture(x)
#define modVidCap_SaveFile(x,y) capFileSaveAs(x,y)
#define modVidCap_SetVideoFormat(x) capDlgVideoFormat(x)
#define modVidCap_SetCallbackOnError(x,y) capSetCallbackOnError(x,y)
#define modVidCap_SetCallbackOnFrame(x,y) capSetCallbackOnFrame(x,y)
#define modVidCap_SetCallbackOnStatus(x,y) capSetCallbackOnStatus(x,y)
#define modVidCap_SetCallbackOnVideoStream(x,y) capSetCallbackOnVideoStream(x,y)


#define wWMPlayer_KillTimer(x) wWMPlayer_SetTimerEnabled(x,FALSE)
#define wWMPlayer_SetTimer wWMPlayer_SetTimerEnabled

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Declarations -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


#endif  // wControls_h_
