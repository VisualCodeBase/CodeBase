
#include "../Source/Lib/Classes/All/Stack/Stack1.h"
