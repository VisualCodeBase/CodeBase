
#ifndef _pvf_vst_h_
#define _pvf_vst_h_
#if ((defined(__GNUC__) && (defined(__APPLE_CPP__) || defined(__APPLE_CC__))) || (defined (__MWERKS__) && defined (__MACH__)))
#ifndef TARGET_API_MAC_CARBON
#define TARGET_API_MAC_CARBON 1
#endif
#if __ppc__
#ifndef VST_FORCE_DEPRECATED
#define VST_FORCE_DEPRECATED 0
#endif
#endif
#endif
#if TARGET_API_MAC_CARBON
#ifdef __LP64__
#pragma options align=power
#else
#pragma options align=mac68k
#endif
#define VSTCALLBACK
#elif defined __BORLANDC__
#pragma -a8
#elif defined(__GNUC__)
#pragma pack(push,8)
#define VSTCALLBACK __cdecl
#elif defined(WIN32) || defined(__FLAT__) || defined CBUILDER
#pragma pack(push)
#pragma pack(8)
#define VSTCALLBACK __cdecl
#else
#define VSTCALLBACK
#endif
#include <string.h>
#define VST_2_1_EXTENSIONS 1
#define VST_2_2_EXTENSIONS 1
#define VST_2_3_EXTENSIONS 1
#ifndef VST_2_4_EXTENSIONS
#define VST_2_4_EXTENSIONS 1
#endif
#if VST_2_4_EXTENSIONS
#define kVstVersion 2400
#elif VST_2_3_EXTENSIONS
#define kVstVersion 2300
#elif VST_2_2_EXTENSIONS
#define kVstVersion 2200
#elif VST_2_1_EXTENSIONS
#define kVstVersion 2100
#else
#define kVstVersion 2
#endif
#ifndef VST_FORCE_DEPRECATED
#define VST_FORCE_DEPRECATED VST_2_4_EXTENSIONS
#endif
#if VST_FORCE_DEPRECATED
#define DECLARE_VST_DEPRECATED(identifier) __##identifier##Deprecated
#else
#define DECLARE_VST_DEPRECATED(identifier) identifier
#endif
#ifndef VST_64BIT_PLATFORM
#define VST_64BIT_PLATFORM _WIN64 || __LP64__
#endif
#ifdef WIN32
typedef short VstInt16;
typedef int VstInt32;
typedef __int64 VstInt64;
#else
#include <stdint.h>
typedef int16_t VstInt16;
typedef int32_t VstInt32;
typedef int64_t VstInt64;
#endif
#if VST_64BIT_PLATFORM
typedef VstInt64 VstIntPtr;
#else
typedef VstInt32 VstIntPtr;
#endif
struct AEffect;
typedef  VstIntPtr (VSTCALLBACK *audioMasterCallback) (AEffect* effect, VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt);
typedef VstIntPtr (VSTCALLBACK *AEffectDispatcherProc) (AEffect* effect, VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt);
typedef void (VSTCALLBACK *AEffectProcessProc) (AEffect* effect, float** inputs, float** outputs, VstInt32 sampleFrames);
typedef void (VSTCALLBACK *AEffectProcessDoubleProc) (AEffect* effect, double** inputs, double** outputs, VstInt32 sampleFrames);
typedef void (VSTCALLBACK *AEffectSetParameterProc) (AEffect* effect, VstInt32 index, float parameter);
typedef float (VSTCALLBACK *AEffectGetParameterProc) (AEffect* effect, VstInt32 index);
#define CCONST(a, b, c, d) ((((VstInt32)a) << 24) | (((VstInt32)b) << 16) | (((VstInt32)c) << 8) | (((VstInt32)d) << 0))
#define kEffectMagic CCONST ('V', 's', 't', 'P')
struct AEffect {
  VstInt32 magic;
  AEffectDispatcherProc dispatcher;
  AEffectProcessProc DECLARE_VST_DEPRECATED (process);
  AEffectSetParameterProc setParameter;
  AEffectGetParameterProc getParameter;
  VstInt32 numPrograms;
  VstInt32 numParams;
  VstInt32 numInputs;
  VstInt32 numOutputs;
  VstInt32 flags;
  VstIntPtr resvd1;
  VstIntPtr resvd2;
  VstInt32 initialDelay;
  VstInt32 DECLARE_VST_DEPRECATED (realQualities);
  VstInt32 DECLARE_VST_DEPRECATED (offQualities);
  float    DECLARE_VST_DEPRECATED (ioRatio);
  void* object;
  void* user;
  VstInt32 uniqueID;
  VstInt32 version;
  AEffectProcessProc processReplacing;
#if VST_2_4_EXTENSIONS
  AEffectProcessDoubleProc processDoubleReplacing;
  char future[56];
#else
  char future[60];
#endif
};
enum VstAEffectFlags {
  effFlagsHasEditor     = 1 << 0,
  effFlagsCanReplacing  = 1 << 4,
  effFlagsProgramChunks = 1 << 5,
  effFlagsIsSynth       = 1 << 8,
  effFlagsNoSoundInStop = 1 << 9,
#if VST_2_4_EXTENSIONS
  effFlagsCanDoubleReplacing = 1 << 12,
#endif
  DECLARE_VST_DEPRECATED (effFlagsHasClip) = 1 << 1,
  DECLARE_VST_DEPRECATED (effFlagsHasVu)   = 1 << 2,
  DECLARE_VST_DEPRECATED (effFlagsCanMono) = 1 << 3,
  DECLARE_VST_DEPRECATED (effFlagsExtIsAsync)   = 1 << 10,
  DECLARE_VST_DEPRECATED (effFlagsExtHasBuffer) = 1 << 11
};
enum AEffectOpcodes {
  effOpen = 0,
  effClose,
  effSetProgram,
  effGetProgram,
  effSetProgramName,
  effGetProgramName,
  effGetParamLabel,
  effGetParamDisplay,
  effGetParamName,
  DECLARE_VST_DEPRECATED (effGetVu),
  effSetSampleRate,
  effSetBlockSize,
  effMainsChanged,
  effEditGetRect,
  effEditOpen,
  effEditClose,
  DECLARE_VST_DEPRECATED (effEditDraw),
  DECLARE_VST_DEPRECATED (effEditMouse),
  DECLARE_VST_DEPRECATED (effEditKey),
  effEditIdle,
  DECLARE_VST_DEPRECATED (effEditTop),
  DECLARE_VST_DEPRECATED (effEditSleep),
  DECLARE_VST_DEPRECATED (effIdentify),
  effGetChunk,
  effSetChunk,
  effNumOpcodes
};
enum AudioMasterOpcodes {
  audioMasterAutomate = 0,
  audioMasterVersion,
  audioMasterCurrentId,
  audioMasterIdle,
  DECLARE_VST_DEPRECATED (audioMasterPinConnected)
};
enum VstStringConstants {
  kVstMaxProgNameLen   = 24,
  kVstMaxParamStrLen   = 8,
  kVstMaxVendorStrLen  = 64,
  kVstMaxProductStrLen = 64,
  kVstMaxEffectNameLen = 32
};
inline char* vst_strncpy (char* dst, const char* src, size_t maxLen) {
  char* result = strncpy (dst, src, maxLen);
  dst[maxLen] = 0;
  return result;
}
inline char* vst_strncat (char* dst, const char* src, size_t maxLen) {
  char* result = strncat (dst, src, maxLen);
  dst[maxLen] = 0;
  return result;
}
template <class T> inline T* FromVstPtr (VstIntPtr& arg) {
  T** address = (T**)&arg;
  return *address;
}
template <class T> inline VstIntPtr ToVstPtr (T* ptr) {
  VstIntPtr* address = (VstIntPtr*)&ptr;
  return *address;
}
struct ERect {
  VstInt16 top;
  VstInt16 left;
  VstInt16 bottom;
  VstInt16 right;
};
#if TARGET_API_MAC_CARBON
#pragma options align=reset
#elif defined(WIN32) || defined(__FLAT__) || defined(__GNUC__)
#pragma pack(pop)
#elif defined __BORLANDC__
#pragma -a-
#endif
#if TARGET_API_MAC_CARBON
#ifdef __LP64__
#pragma options align=power
#else
#pragma options align=mac68k
#endif
#elif defined __BORLANDC__
#pragma -a8
#elif defined(__GNUC__)
#pragma pack(push,8)
#elif defined(WIN32) || defined(__FLAT__)
#pragma pack(push)
#pragma pack(8)
#endif
enum Vst2StringConstants {
  kVstMaxNameLen       = 64,
  kVstMaxLabelLen      = 64,
  kVstMaxShortLabelLen = 8,
  kVstMaxCategLabelLen = 24,
  kVstMaxFileNameLen   = 100
};
struct VstEvent {
  VstInt32 type;
  VstInt32 byteSize;
  VstInt32 deltaFrames;
  VstInt32 flags;
  char data[16];
};
enum VstEventTypes {
  kVstMidiType = 1,
  DECLARE_VST_DEPRECATED (kVstAudioType),
  DECLARE_VST_DEPRECATED (kVstVideoType),
  DECLARE_VST_DEPRECATED (kVstParameterType),
  DECLARE_VST_DEPRECATED (kVstTriggerType),
  kVstSysExType
};
struct VstEvents {
  VstInt32 numEvents;
  VstIntPtr reserved;
  VstEvent* events[2];
};
struct VstMidiEvent {
  VstInt32 type;
  VstInt32 byteSize;
  VstInt32 deltaFrames;
  VstInt32 flags;
  VstInt32 noteLength;
  VstInt32 noteOffset;
  char midiData[4];
  char detune;
  char noteOffVelocity;
  char reserved1;
  char reserved2;
};
enum VstMidiEventFlags {
  kVstMidiEventIsRealtime = 1 << 0
};
struct VstMidiSysexEvent {
  VstInt32 type;
  VstInt32 byteSize;
  VstInt32 deltaFrames;
  VstInt32 flags;
  VstInt32 dumpBytes;
  VstIntPtr resvd1;
  char* sysexDump;
  VstIntPtr resvd2;
};
struct VstTimeInfo {
  double samplePos;
  double sampleRate;
  double nanoSeconds;
  double ppqPos;
  double tempo;
  double barStartPos;
  double cycleStartPos;
  double cycleEndPos;
  VstInt32 timeSigNumerator;
  VstInt32 timeSigDenominator;
  VstInt32 smpteOffset;
  VstInt32 smpteFrameRate;
  VstInt32 samplesToNextClock;
  VstInt32 flags;
};
enum VstTimeInfoFlags {
  kVstTransportChanged     = 1,
  kVstTransportPlaying     = 1 << 1,
  kVstTransportCycleActive = 1 << 2,
  kVstTransportRecording   = 1 << 3,
  kVstAutomationWriting    = 1 << 6,
  kVstAutomationReading    = 1 << 7,
  kVstNanosValid           = 1 << 8,
  kVstPpqPosValid          = 1 << 9,
  kVstTempoValid           = 1 << 10,
  kVstBarsValid            = 1 << 11,
  kVstCyclePosValid        = 1 << 12,
  kVstTimeSigValid         = 1 << 13,
  kVstSmpteValid           = 1 << 14,
  kVstClockValid           = 1 << 15
};
enum VstSmpteFrameRate {
  kVstSmpte24fps    = 0,
  kVstSmpte25fps    = 1,
  kVstSmpte2997fps  = 2,
  kVstSmpte30fps    = 3,
  kVstSmpte2997dfps = 4,
  kVstSmpte30dfps   = 5,
  kVstSmpteFilm16mm = 6,
  kVstSmpteFilm35mm = 7,
  kVstSmpte239fps   = 10,
  kVstSmpte249fps   = 11,
  kVstSmpte599fps   = 12,
  kVstSmpte60fps    = 13
};
struct VstVariableIo {
  float** inputs;
  float** outputs;
  VstInt32 numSamplesInput;
  VstInt32 numSamplesOutput;
  VstInt32* numSamplesInputProcessed;
  VstInt32* numSamplesOutputProcessed;
};
enum VstHostLanguage {
  kVstLangEnglish = 1,
  kVstLangGerman,
  kVstLangFrench,
  kVstLangItalian,
  kVstLangSpanish,
  kVstLangJapanese
};
enum AudioMasterOpcodesX {
  DECLARE_VST_DEPRECATED (audioMasterWantMidi) = DECLARE_VST_DEPRECATED (audioMasterPinConnected) + 2,
  audioMasterGetTime,
  audioMasterProcessEvents,
  DECLARE_VST_DEPRECATED (audioMasterSetTime),
  DECLARE_VST_DEPRECATED (audioMasterTempoAt),
  DECLARE_VST_DEPRECATED (audioMasterGetNumAutomatableParameters),
  DECLARE_VST_DEPRECATED (audioMasterGetParameterQuantization),
  audioMasterIOChanged,
  DECLARE_VST_DEPRECATED (audioMasterNeedIdle),
  audioMasterSizeWindow,
  audioMasterGetSampleRate,
  audioMasterGetBlockSize,
  audioMasterGetInputLatency,
  audioMasterGetOutputLatency,
  DECLARE_VST_DEPRECATED (audioMasterGetPreviousPlug),
  DECLARE_VST_DEPRECATED (audioMasterGetNextPlug),
  DECLARE_VST_DEPRECATED (audioMasterWillReplaceOrAccumulate),
  audioMasterGetCurrentProcessLevel,
  audioMasterGetAutomationState,
  audioMasterOfflineStart,
  audioMasterOfflineRead,
  audioMasterOfflineWrite,
  audioMasterOfflineGetCurrentPass,
  audioMasterOfflineGetCurrentMetaPass,
  DECLARE_VST_DEPRECATED (audioMasterSetOutputSampleRate),
  DECLARE_VST_DEPRECATED (audioMasterGetOutputSpeakerArrangement),
  audioMasterGetVendorString,
  audioMasterGetProductString,
  audioMasterGetVendorVersion,
  audioMasterVendorSpecific,
  DECLARE_VST_DEPRECATED (audioMasterSetIcon),
  audioMasterCanDo,
  audioMasterGetLanguage,
  DECLARE_VST_DEPRECATED (audioMasterOpenWindow),
  DECLARE_VST_DEPRECATED (audioMasterCloseWindow),
  audioMasterGetDirectory,
  audioMasterUpdateDisplay,
  audioMasterBeginEdit,
  audioMasterEndEdit,
  audioMasterOpenFileSelector,
  audioMasterCloseFileSelector,
  DECLARE_VST_DEPRECATED (audioMasterEditFile),
  DECLARE_VST_DEPRECATED (audioMasterGetChunkFile),
  DECLARE_VST_DEPRECATED (audioMasterGetInputSpeakerArrangement)
};
enum AEffectXOpcodes {
  effProcessEvents = effSetChunk + 1
  , effCanBeAutomated
  , effString2Parameter
  , DECLARE_VST_DEPRECATED (effGetNumProgramCategories)
  , effGetProgramNameIndexed
  , DECLARE_VST_DEPRECATED (effCopyProgram)
  , DECLARE_VST_DEPRECATED (effConnectInput)
  , DECLARE_VST_DEPRECATED (effConnectOutput)
  , effGetInputProperties
  , effGetOutputProperties
  , effGetPlugCategory
  , DECLARE_VST_DEPRECATED (effGetCurrentPosition)
  , DECLARE_VST_DEPRECATED (effGetDestinationBuffer)
  , effOfflineNotify
  , effOfflinePrepare
  , effOfflineRun
  , effProcessVarIo
  , effSetSpeakerArrangement
  , DECLARE_VST_DEPRECATED (effSetBlockSizeAndSampleRate)
  , effSetBypass
  , effGetEffectName
  , DECLARE_VST_DEPRECATED (effGetErrorText)
  , effGetVendorString
  , effGetProductString
  , effGetVendorVersion
  , effVendorSpecific
  , effCanDo
  , effGetTailSize
  , DECLARE_VST_DEPRECATED (effIdle)
  , DECLARE_VST_DEPRECATED (effGetIcon)
  , DECLARE_VST_DEPRECATED (effSetViewPosition)
  , effGetParameterProperties
  , DECLARE_VST_DEPRECATED (effKeysRequired)
  , effGetVstVersion
#if VST_2_1_EXTENSIONS
  , effEditKeyDown
  , effEditKeyUp
  , effSetEditKnobMode
  , effGetMidiProgramName
  , effGetCurrentMidiProgram
  , effGetMidiProgramCategory
  , effHasMidiProgramsChanged
  , effGetMidiKeyName
  , effBeginSetProgram
  , effEndSetProgram
#endif
#if VST_2_3_EXTENSIONS
  , effGetSpeakerArrangement
  , effShellGetNextPlugin
  , effStartProcess
  , effStopProcess
  , effSetTotalSampleToProcess
  , effSetPanLaw
  , effBeginLoadBank
  , effBeginLoadProgram
#endif
#if VST_2_4_EXTENSIONS
  , effSetProcessPrecision
  , effGetNumMidiInputChannels
  , effGetNumMidiOutputChannels
#endif
};
enum VstProcessPrecision {
  kVstProcessPrecision32 = 0,
  kVstProcessPrecision64
};
struct VstParameterProperties {
  float stepFloat;
  float smallStepFloat;
  float largeStepFloat;
  char label[kVstMaxLabelLen];
  VstInt32 flags;
  VstInt32 minInteger;
  VstInt32 maxInteger;
  VstInt32 stepInteger;
  VstInt32 largeStepInteger;
  char shortLabel[kVstMaxShortLabelLen];
  VstInt16 displayIndex;
  VstInt16 category;
  VstInt16 numParametersInCategory;
  VstInt16 reserved;
  char categoryLabel[kVstMaxCategLabelLen];
  char future[16];
};
enum VstParameterFlags {
  kVstParameterIsSwitch         = 1 << 0,
  kVstParameterUsesIntegerMinMax     = 1 << 1,
  kVstParameterUsesFloatStep       = 1 << 2,
  kVstParameterUsesIntStep       = 1 << 3,
  kVstParameterSupportsDisplayIndex    = 1 << 4,
  kVstParameterSupportsDisplayCategory = 1 << 5,
  kVstParameterCanRamp         = 1 << 6
};
struct VstPinProperties {
  char label[kVstMaxLabelLen];
  VstInt32 flags;
  VstInt32 arrangementType;
  char shortLabel[kVstMaxShortLabelLen];
  char future[48];
};
enum VstPinPropertiesFlags {
  kVstPinIsActive   = 1 << 0,
  kVstPinIsStereo   = 1 << 1,
  kVstPinUseSpeaker = 1 << 2
};
enum VstPlugCategory {
    kPlugCategUnknown = 0,
    kPlugCategEffect,
    kPlugCategSynth,
    kPlugCategAnalysis,
    kPlugCategMastering,
  kPlugCategSpacializer,
  kPlugCategRoomFx,
  kPlugSurroundFx,
  kPlugCategRestoration,
  kPlugCategOfflineProcess,
  kPlugCategShell,
  kPlugCategGenerator,
  kPlugCategMaxCount
};
struct MidiProgramName {
  VstInt32 thisProgramIndex;
  char name[kVstMaxNameLen];
  char midiProgram;
  char midiBankMsb;
  char midiBankLsb;
  char reserved;
  VstInt32 parentCategoryIndex;
  VstInt32 flags;
};
enum VstMidiProgramNameFlags {
  kMidiIsOmni = 1
};
struct MidiProgramCategory {
  VstInt32 thisCategoryIndex;
  char name[kVstMaxNameLen];
  VstInt32 parentCategoryIndex;
  VstInt32 flags;
};
struct MidiKeyName {
  VstInt32 thisProgramIndex;
  VstInt32 thisKeyNumber;
  char keyName[kVstMaxNameLen];
  VstInt32 reserved;
  VstInt32 flags;
};
struct VstSpeakerProperties {
  float azimuth;
  float elevation;
  float radius;
  float reserved;
  char name[kVstMaxNameLen];
  VstInt32 type;
  char future[28];
};
struct VstSpeakerArrangement {
  VstInt32 type;
  VstInt32 numChannels;
  VstSpeakerProperties speakers[8];
};
enum VstSpeakerType {
  kSpeakerUndefined = 0x7fffffff,
  kSpeakerM = 0,
  kSpeakerL,
  kSpeakerR,
  kSpeakerC,
  kSpeakerLfe,
  kSpeakerLs,
  kSpeakerRs,
  kSpeakerLc,
  kSpeakerRc,
  kSpeakerS,
  kSpeakerCs = kSpeakerS,
  kSpeakerSl,
  kSpeakerSr,
  kSpeakerTm,
  kSpeakerTfl,
  kSpeakerTfc,
  kSpeakerTfr,
  kSpeakerTrl,
  kSpeakerTrc,
  kSpeakerTrr,
  kSpeakerLfe2
};
enum VstUserSpeakerType {
  kSpeakerU32 = -32,
  kSpeakerU31,
  kSpeakerU30,
  kSpeakerU29,
  kSpeakerU28,
  kSpeakerU27,
  kSpeakerU26,
  kSpeakerU25,
  kSpeakerU24,
  kSpeakerU23,
  kSpeakerU22,
  kSpeakerU21,
  kSpeakerU20,
  kSpeakerU19,
  kSpeakerU18,
  kSpeakerU17,
  kSpeakerU16,
  kSpeakerU15,
  kSpeakerU14,
  kSpeakerU13,
  kSpeakerU12,
  kSpeakerU11,
  kSpeakerU10,
  kSpeakerU9,
  kSpeakerU8,
  kSpeakerU7,
  kSpeakerU6,
  kSpeakerU5,
  kSpeakerU4,
  kSpeakerU3,
  kSpeakerU2,
  kSpeakerU1
};
enum VstSpeakerArrangementType {
  kSpeakerArrUserDefined = -2,
  kSpeakerArrEmpty = -1,
  kSpeakerArrMono  =  0,
  kSpeakerArrStereo,
  kSpeakerArrStereoSurround,
  kSpeakerArrStereoCenter,
  kSpeakerArrStereoSide,
  kSpeakerArrStereoCLfe,
  kSpeakerArr30Cine,
  kSpeakerArr30Music,
  kSpeakerArr31Cine,
  kSpeakerArr31Music,
  kSpeakerArr40Cine,
  kSpeakerArr40Music,
  kSpeakerArr41Cine,
  kSpeakerArr41Music,
  kSpeakerArr50,
  kSpeakerArr51,
  kSpeakerArr60Cine,
  kSpeakerArr60Music,
  kSpeakerArr61Cine,
  kSpeakerArr61Music,
  kSpeakerArr70Cine,
  kSpeakerArr70Music,
  kSpeakerArr71Cine,
  kSpeakerArr71Music,
  kSpeakerArr80Cine,
  kSpeakerArr80Music,
  kSpeakerArr81Cine,
  kSpeakerArr81Music,
  kSpeakerArr102,
  kNumSpeakerArr
};
struct VstOfflineTask {
  char processName[96];
  double readPosition;
  double writePosition;
  VstInt32 readCount;
  VstInt32 writeCount;
  VstInt32 sizeInputBuffer;
  VstInt32 sizeOutputBuffer;
  void* inputBuffer;
  void* outputBuffer;
  double positionToProcessFrom;
  double numFramesToProcess;
  double maxFramesToWrite;
  void* extraBuffer;
  VstInt32 value;
  VstInt32 index;
  double numFramesInSourceFile;
  double sourceSampleRate;
  double destinationSampleRate;
  VstInt32 numSourceChannels;
  VstInt32 numDestinationChannels;
  VstInt32 sourceFormat;
  VstInt32 destinationFormat;
  char outputText[512];
  double progress;
  VstInt32 progressMode;
  char progressText[100];
  VstInt32 flags;
  VstInt32 returnValue;
  void* hostOwned;
  void* plugOwned;
  char future[1024];
};
enum VstOfflineTaskFlags {
  kVstOfflineUnvalidParameter  = 1 << 0,
  kVstOfflineNewFile      = 1 << 1,
  kVstOfflinePlugError    = 1 << 10,
  kVstOfflineInterleavedAudio  = 1 << 11,
  kVstOfflineTempOutputFile  = 1 << 12,
  kVstOfflineFloatOutputFile  = 1 << 13,
  kVstOfflineRandomWrite    = 1 << 14,
  kVstOfflineStretch      = 1 << 15,
  kVstOfflineNoThread      = 1 << 16
};
enum VstOfflineOption {
   kVstOfflineAudio,
   kVstOfflinePeaks,
   kVstOfflineParameter,
   kVstOfflineMarker,
   kVstOfflineCursor,
   kVstOfflineSelection,
   kVstOfflineQueryFiles
};
struct VstAudioFile {
  VstInt32 flags;
  void* hostOwned;
  void* plugOwned;
  char name[kVstMaxFileNameLen];
  VstInt32 uniqueId;
  double sampleRate;
  VstInt32 numChannels;
  double numFrames;
  VstInt32 format;
  double editCursorPosition;
  double selectionStart;
  double selectionSize;
  VstInt32 selectedChannelsMask;
  VstInt32 numMarkers;
  VstInt32 timeRulerUnit;
  double timeRulerOffset;
  double tempo;
  VstInt32 timeSigNumerator;
  VstInt32 timeSigDenominator;
  VstInt32 ticksPerBlackNote;
  VstInt32 smpteFrameRate;
  char future[64];
};
enum VstAudioFileFlags {
  kVstOfflineReadOnly        = 1 << 0,
  kVstOfflineNoRateConversion    = 1 << 1,
  kVstOfflineNoChannelChange    = 1 << 2,
  kVstOfflineCanProcessSelection  = 1 << 10,
  kVstOfflineNoCrossfade      = 1 << 11,
  kVstOfflineWantRead        = 1 << 12,
  kVstOfflineWantWrite      = 1 << 13,
  kVstOfflineWantWriteMarker    = 1 << 14,
  kVstOfflineWantMoveCursor    = 1 << 15,
  kVstOfflineWantSelect      = 1 << 16
};
struct VstAudioFileMarker {
  double position;
  char name[32];
  VstInt32 type;
  VstInt32 id;
  VstInt32 reserved;
};
struct DECLARE_VST_DEPRECATED (VstWindow) {
  char title[128];
  VstInt16 xPos;
  VstInt16 yPos;
  VstInt16 width;
  VstInt16 height;
  VstInt32 style;
  void* parent;
  void* userHandle;
  void* winHandle;
  char future[104];
};
struct VstKeyCode {
  VstInt32 character;
  unsigned char virt;
  unsigned char modifier;
};
enum VstVirtualKey {
  VKEY_BACK = 1,
  VKEY_TAB,
  VKEY_CLEAR,
  VKEY_RETURN,
  VKEY_PAUSE,
  VKEY_ESCAPE,
  VKEY_SPACE,
  VKEY_NEXT,
  VKEY_END,
  VKEY_HOME,
  VKEY_LEFT,
  VKEY_UP,
  VKEY_RIGHT,
  VKEY_DOWN,
  VKEY_PAGEUP,
  VKEY_PAGEDOWN,
  VKEY_SELECT,
  VKEY_PRINT,
  VKEY_ENTER,
  VKEY_SNAPSHOT,
  VKEY_INSERT,
  VKEY_DELETE,
  VKEY_HELP,
  VKEY_NUMPAD0,
  VKEY_NUMPAD1,
  VKEY_NUMPAD2,
  VKEY_NUMPAD3,
  VKEY_NUMPAD4,
  VKEY_NUMPAD5,
  VKEY_NUMPAD6,
  VKEY_NUMPAD7,
  VKEY_NUMPAD8,
  VKEY_NUMPAD9,
  VKEY_MULTIPLY,
  VKEY_ADD,
  VKEY_SEPARATOR,
  VKEY_SUBTRACT,
  VKEY_DECIMAL,
  VKEY_DIVIDE,
  VKEY_F1,
  VKEY_F2,
  VKEY_F3,
  VKEY_F4,
  VKEY_F5,
  VKEY_F6,
  VKEY_F7,
  VKEY_F8,
  VKEY_F9,
  VKEY_F10,
  VKEY_F11,
  VKEY_F12,
  VKEY_NUMLOCK,
  VKEY_SCROLL,
  VKEY_SHIFT,
  VKEY_CONTROL,
  VKEY_ALT,
  VKEY_EQUALS
};
enum VstModifierKey {
  MODIFIER_SHIFT     = 1<<0,
  MODIFIER_ALTERNATE = 1<<1,
  MODIFIER_COMMAND   = 1<<2,
  MODIFIER_CONTROL   = 1<<3
};
struct VstFileType {
  char name[128];
  char macType[8];
  char dosType[8];
  char unixType[8];
  char mimeType1[128];
  char mimeType2[128];
  VstFileType (const char* _name = 0, const char* _macType = 0, const char* _dosType = 0,
         const char* _unixType = 0, const char* _mimeType1 = 0, const char* _mimeType2 = 0) {
    vst_strncpy (name, _name ? _name : "", 127);
    vst_strncpy (macType, _macType ? _macType : "", 7);
    vst_strncpy (dosType, _dosType ? _dosType : "", 7);
    vst_strncpy (unixType, _unixType ? _unixType : "", 7);
    vst_strncpy (mimeType1, _mimeType1 ? _mimeType1 : "", 127);
    vst_strncpy (mimeType2, _mimeType2 ? _mimeType2 : "", 127);
  }
};
struct VstFileSelect {
  VstInt32 command;
  VstInt32 type;
  VstInt32 macCreator;
  VstInt32 nbFileTypes;
  VstFileType* fileTypes;
  char title[1024];
  char* initialPath;
  char* returnPath;
  VstInt32 sizeReturnPath;
  char** returnMultiplePaths;
  VstInt32 nbReturnPath;
  VstIntPtr reserved;
  char future[116];
};
enum VstFileSelectCommand {
  kVstFileLoad = 0,
  kVstFileSave,
  kVstMultipleFilesLoad,
  kVstDirectorySelect
};
enum VstFileSelectType {
  kVstFileType = 0
};
struct VstPatchChunkInfo {
  VstInt32 version;
  VstInt32 pluginUniqueID;
  VstInt32 pluginVersion;
  VstInt32 numElements;
  char future[48];
};
enum VstPanLawType {
  kLinearPanLaw = 0,
  kEqualPowerPanLaw
};
enum VstProcessLevels {
  kVstProcessLevelUnknown = 0,
  kVstProcessLevelUser,
  kVstProcessLevelRealtime,
  kVstProcessLevelPrefetch,
  kVstProcessLevelOffline
};
enum VstAutomationStates {
  kVstAutomationUnsupported = 0,
  kVstAutomationOff,
  kVstAutomationRead,
  kVstAutomationWrite,
  kVstAutomationReadWrite
};
#if TARGET_API_MAC_CARBON
#pragma options align=reset
#elif defined(WIN32) || defined(__FLAT__) || defined(__GNUC__)
#pragma pack(pop)
#elif defined __BORLANDC__
#pragma -a-
#endif
#define getInitialDelay() cEffect.initialDelay
class AEffEditor;
class AudioEffect {
public:
  AudioEffect (audioMasterCallback audioMaster, VstInt32 numPrograms, VstInt32 numParams);
  virtual ~AudioEffect ();
  virtual VstIntPtr dispatcher (VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt);
  virtual void open () {}
  virtual void close () {}
  virtual void suspend () {}
  virtual void resume () {}
  virtual void setSampleRate (float sampleRate)  { this->sampleRate = sampleRate; }
  virtual void setBlockSize (VstInt32 blockSize) { this->blockSize = blockSize; }
  virtual void processReplacing (float** inputs, float** outputs, VstInt32 sampleFrames) = 0;
#if VST_2_4_EXTENSIONS
  virtual void processDoubleReplacing (double** inputs, double** outputs, VstInt32 sampleFrames) {}
#endif
  virtual void setParameter (VstInt32 index, float value) {}
  virtual float getParameter (VstInt32 index) { return 0; }
  virtual void setParameterAutomated (VstInt32 index, float value);
  virtual VstInt32 getProgram () { return curProgram; }
  virtual void setProgram (VstInt32 program) { curProgram = program; }
  virtual void setProgramName (char* name) {}
  virtual void getProgramName (char* name) { *name = 0; }
  virtual void getParameterLabel (VstInt32 index, char* label)  { *label = 0; }
  virtual void getParameterDisplay (VstInt32 index, char* text) { *text = 0; }
  virtual void getParameterName (VstInt32 index, char* text)    { *text = 0; }
  virtual VstInt32 getChunk (void** data, bool isPreset = false) { return 0; }
  virtual VstInt32 setChunk (void* data, VstInt32 byteSize, bool isPreset = false) { return 0; }
  virtual void setUniqueID (VstInt32 iD)        { cEffect.uniqueID = iD; }
  virtual void setNumInputs (VstInt32 inputs)   { cEffect.numInputs = inputs; }
  virtual void setNumOutputs (VstInt32 outputs) { cEffect.numOutputs = outputs; }
  virtual void canProcessReplacing (bool state = true);
#if VST_2_4_EXTENSIONS
  virtual void canDoubleReplacing (bool state = true);
#endif
  virtual void programsAreChunks (bool state = true);
  virtual void setInitialDelay (VstInt32 delay);
  void setEditor (AEffEditor* editor);
  virtual AEffEditor* getEditor () { return beditor; }
  virtual AEffect* getAeffect ()   { return &cEffect; }
  virtual float getSampleRate ()   { return sampleRate; }
  virtual VstInt32 getBlockSize () { return blockSize; }
  virtual VstInt32 getMasterVersion ();
  virtual VstInt32 getCurrentUniqueId ();
  virtual void masterIdle ();
  virtual void dB2string (float value, char* text, VstInt32 maxLen);
  virtual void Hz2string (float samples, char* text, VstInt32 maxLen);
  virtual void ms2string (float samples, char* text, VstInt32 maxLen);
  virtual void float2string (float value, char* text, VstInt32 maxLen);
  virtual void int2string (VstInt32 value, char* text, VstInt32 maxLen);
  virtual void DECLARE_VST_DEPRECATED (process) (float** inputs, float** outputs, VstInt32 sampleFrames) {}
  virtual float DECLARE_VST_DEPRECATED (getVu) () { return 0; }
  virtual void DECLARE_VST_DEPRECATED (hasVu) (bool state = true);
  virtual void DECLARE_VST_DEPRECATED (hasClip) (bool state = true);
  virtual void DECLARE_VST_DEPRECATED (canMono) (bool state = true);
  virtual void DECLARE_VST_DEPRECATED (setRealtimeQualities) (VstInt32 qualities);
  virtual void DECLARE_VST_DEPRECATED (setOfflineQualities) (VstInt32 qualities);
  virtual bool DECLARE_VST_DEPRECATED (isInputConnected) (VstInt32 input);
  virtual bool DECLARE_VST_DEPRECATED (isOutputConnected) (VstInt32 output);
protected:
  audioMasterCallback audioMaster;
  AEffEditor* beditor;
  float sampleRate;
  VstInt32 blockSize;
  VstInt32 numPrograms;
  VstInt32 numParams;
  VstInt32 curProgram;
  AEffect  cEffect;
  static VstIntPtr VSTCALLBACK dispatchEffectClass (AEffect* e, VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt);
  static float VSTCALLBACK getParameterClass (AEffect* e, VstInt32 index);
  static void VSTCALLBACK setParameterClass (AEffect* e, VstInt32 index, float value);
  static void VSTCALLBACK DECLARE_VST_DEPRECATED (processClass) (AEffect* e, float** inputs, float** outputs, VstInt32 sampleFrames);
  static void VSTCALLBACK processClassReplacing (AEffect* e, float** inputs, float** outputs, VstInt32 sampleFrames);
#if VST_2_4_EXTENSIONS
  static void VSTCALLBACK processClassDoubleReplacing (AEffect* e, double** inputs, double** outputs, VstInt32 sampleFrames);
#endif
};
class AudioEffectX : public AudioEffect {
public:
  AudioEffectX (audioMasterCallback audioMaster, VstInt32 numPrograms, VstInt32 numParams);
  virtual bool canParameterBeAutomated (VstInt32 index) { return true; }
  virtual bool string2parameter (VstInt32 index, char* text) { return false; }
  virtual bool getParameterProperties (VstInt32 index, VstParameterProperties* p) { return false; }
#if VST_2_1_EXTENSIONS
  virtual bool beginEdit (VstInt32 index);
  virtual bool endEdit (VstInt32 index);
#endif
  virtual bool getProgramNameIndexed (VstInt32 category, VstInt32 index, char* text) { return false; }
#if VST_2_1_EXTENSIONS
  virtual bool beginSetProgram () { return false; }
  virtual bool endSetProgram () { return false; }
#endif
#if VST_2_3_EXTENSIONS
  virtual VstInt32 beginLoadBank (VstPatchChunkInfo* ptr) { return 0; }
  virtual VstInt32 beginLoadProgram (VstPatchChunkInfo* ptr) { return 0; }
#endif
  virtual bool ioChanged ();
  virtual double updateSampleRate ();
  virtual VstInt32 updateBlockSize ();
  virtual VstInt32 getInputLatency ();
  virtual VstInt32 getOutputLatency ();
  virtual bool getInputProperties (VstInt32 index, VstPinProperties* properties) { return false; }
  virtual bool getOutputProperties (VstInt32 index, VstPinProperties* properties) { return false; }
  virtual bool setSpeakerArrangement (VstSpeakerArrangement* pluginInput, VstSpeakerArrangement* pluginOutput) { return false; }
  virtual bool getSpeakerArrangement (VstSpeakerArrangement** pluginInput, VstSpeakerArrangement** pluginOutput) { *pluginInput = 0; *pluginOutput = 0; return false; }
  virtual bool setBypass (bool onOff) { return false; }
#if VST_2_3_EXTENSIONS
  virtual bool setPanLaw (VstInt32 type, float val) { return false; }
#endif
#if VST_2_4_EXTENSIONS
  virtual bool setProcessPrecision (VstInt32 precision) { return false; }
  virtual VstInt32 getNumMidiInputChannels ()  { return 0; }
  virtual VstInt32 getNumMidiOutputChannels () { return 0; }
#endif
  virtual VstTimeInfo* getTimeInfo (VstInt32 filter);
  virtual VstInt32 getCurrentProcessLevel ();
  virtual VstInt32 getAutomationState ();
  virtual VstInt32 processEvents (VstEvents* events) { return 0; }
  bool sendVstEventsToHost (VstEvents* events);
#if VST_2_3_EXTENSIONS
  virtual VstInt32 startProcess () { return 0; }
  virtual VstInt32 stopProcess () { return 0;}
#endif
  virtual bool processVariableIo (VstVariableIo* varIo) { return false; }
#if VST_2_3_EXTENSIONS
  virtual VstInt32 setTotalSampleToProcess (VstInt32 value) {  return value; }
#endif
  virtual bool getHostVendorString (char* text);
  virtual bool getHostProductString (char* text);
  virtual VstInt32 getHostVendorVersion ();
  virtual VstIntPtr hostVendorSpecific (VstInt32 lArg1, VstIntPtr lArg2, void* ptrArg, float floatArg);
  virtual VstInt32 canHostDo (char* text);
  virtual VstInt32 getHostLanguage ();
  virtual void isSynth (bool state = true);
  virtual void noTail (bool state = true);
  virtual VstInt32 getGetTailSize () { return 0; }
  virtual void* getDirectory ();
  virtual bool getEffectName (char* name) { return false; }
  virtual bool getVendorString (char* text) { return false; }
  virtual bool getProductString (char* text) { return false; }
  virtual VstInt32 getVendorVersion () { return 0; }
  virtual VstIntPtr vendorSpecific (VstInt32 lArg, VstIntPtr lArg2, void* ptrArg, float floatArg) { return 0; }
  virtual VstInt32 canDo (char* text) { return 0; }
  virtual VstInt32 getVstVersion () { return kVstVersion; }
  virtual VstPlugCategory getPlugCategory ();
#if VST_2_1_EXTENSIONS
  virtual VstInt32 getMidiProgramName (VstInt32 channel, MidiProgramName* midiProgramName) { return 0; }
  virtual VstInt32 getCurrentMidiProgram (VstInt32 channel, MidiProgramName* currentProgram) { return -1; }
  virtual VstInt32 getMidiProgramCategory (VstInt32 channel, MidiProgramCategory* category) { return 0; }
  virtual bool hasMidiProgramsChanged (VstInt32 channel) { return false; }
  virtual bool getMidiKeyName (VstInt32 channel, MidiKeyName* keyName) { return false; }
#endif
  virtual bool updateDisplay ();
  virtual bool sizeWindow (VstInt32 width, VstInt32 height);
#if VST_2_1_EXTENSIONS
  virtual bool openFileSelector (VstFileSelect* ptr);
#endif
#if VST_2_2_EXTENSIONS
  virtual bool closeFileSelector (VstFileSelect* ptr);
#endif
#if VST_2_3_EXTENSIONS
  virtual VstInt32 getNextShellPlugin (char* name) { return 0; }
#endif
#if VST_2_3_EXTENSIONS
  virtual bool allocateArrangement (VstSpeakerArrangement** arrangement, VstInt32 nbChannels);
  virtual bool deallocateArrangement (VstSpeakerArrangement** arrangement);
  virtual bool copySpeaker (VstSpeakerProperties* to, VstSpeakerProperties* from);
  virtual bool matchArrangement (VstSpeakerArrangement** to, VstSpeakerArrangement* from);
#endif
  virtual bool offlineRead (VstOfflineTask* offline, VstOfflineOption option, bool readSource = true);
  virtual bool offlineWrite (VstOfflineTask* offline, VstOfflineOption option);
  virtual bool offlineStart (VstAudioFile* ptr, VstInt32 numAudioFiles, VstInt32 numNewAudioFiles);
  virtual VstInt32 offlineGetCurrentPass ();
  virtual VstInt32 offlineGetCurrentMetaPass ();
  virtual bool offlineNotify (VstAudioFile* ptr, VstInt32 numAudioFiles, bool start) { return false; }
  virtual bool offlinePrepare (VstOfflineTask* offline, VstInt32 count) { return false; }
  virtual bool offlineRun (VstOfflineTask* offline, VstInt32 count) { return false; }
  virtual VstInt32 offlineGetNumPasses () { return 0; }
  virtual VstInt32 offlineGetNumMetaPasses () { return 0; }
  virtual VstIntPtr dispatcher (VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt);
  virtual void resume ();
  virtual void DECLARE_VST_DEPRECATED (wantEvents) (VstInt32 filter = 1);
  virtual VstInt32 DECLARE_VST_DEPRECATED (tempoAt) (VstInt32 pos);
  virtual VstInt32 DECLARE_VST_DEPRECATED (getNumAutomatableParameters) ();
  virtual VstInt32 DECLARE_VST_DEPRECATED (getParameterQuantization) ();
  virtual VstInt32 DECLARE_VST_DEPRECATED (getNumCategories) () { return 1L; }
  virtual bool DECLARE_VST_DEPRECATED (copyProgram) (VstInt32 destination) { return false; }
  virtual bool DECLARE_VST_DEPRECATED (needIdle) ();
  virtual AEffect* DECLARE_VST_DEPRECATED (getPreviousPlug) (VstInt32 input);
  virtual AEffect* DECLARE_VST_DEPRECATED (getNextPlug) (VstInt32 output);
  virtual void DECLARE_VST_DEPRECATED (inputConnected) (VstInt32 index, bool state) {}
  virtual void DECLARE_VST_DEPRECATED (outputConnected) (VstInt32 index, bool state) {}
  virtual VstInt32 DECLARE_VST_DEPRECATED (willProcessReplacing) ();
  virtual void DECLARE_VST_DEPRECATED (wantAsyncOperation) (bool state = true);
  virtual void DECLARE_VST_DEPRECATED (hasExternalBuffer) (bool state = true);
  virtual VstInt32 DECLARE_VST_DEPRECATED (reportCurrentPosition) () { return 0; }
  virtual float* DECLARE_VST_DEPRECATED (reportDestinationBuffer) () { return 0; }
  virtual void DECLARE_VST_DEPRECATED (setOutputSamplerate) (float samplerate);
  virtual VstSpeakerArrangement* DECLARE_VST_DEPRECATED (getInputSpeakerArrangement) ();
  virtual VstSpeakerArrangement* DECLARE_VST_DEPRECATED (getOutputSpeakerArrangement) ();
  virtual void* DECLARE_VST_DEPRECATED (openWindow) (DECLARE_VST_DEPRECATED (VstWindow)*);
  virtual bool DECLARE_VST_DEPRECATED (closeWindow) (DECLARE_VST_DEPRECATED (VstWindow)*);
  virtual void DECLARE_VST_DEPRECATED (setBlockSizeAndSampleRate) (VstInt32 _blockSize, float _sampleRate) { blockSize = _blockSize; sampleRate = _sampleRate; }
  virtual bool DECLARE_VST_DEPRECATED (getErrorText) (char* text) { return false; }
  virtual void* DECLARE_VST_DEPRECATED (getIcon) () { return 0; }
  virtual bool DECLARE_VST_DEPRECATED (setViewPosition) (VstInt32 x, VstInt32 y) { return false; }
  virtual VstInt32 DECLARE_VST_DEPRECATED (fxIdle) () { return 0; }
  virtual bool DECLARE_VST_DEPRECATED (keysRequired) () { return false; }
#if VST_2_2_EXTENSIONS
  virtual bool DECLARE_VST_DEPRECATED (getChunkFile) (void* nativePath);
#endif
};
#define __aeffeditor__
class AEffEditor {
public:
  AEffEditor (AudioEffectX* effect = 0)
  : beffect (effect)
  , systemWindow (0) {}
  virtual ~AEffEditor () {}
  virtual AudioEffectX* getEffect ()  { return beffect; }
  virtual VstInt32 getRect (ERect** rect)  { *rect = 0; return 0; }
  virtual VstInt32 open (void* ptr)    { systemWindow = ptr; return 0; }
  virtual void close ()        { systemWindow = 0; }
  virtual bool isOpen ()        { return systemWindow != 0; }
  virtual void idle ()        {}
#if TARGET_API_MAC_CARBON
  virtual void DECLARE_VST_DEPRECATED (draw) (ERect* rect) {}
  virtual VstInt32 DECLARE_VST_DEPRECATED (mouse) (VstInt32 x, VstInt32 y) { return 0; }
  virtual VstInt32 DECLARE_VST_DEPRECATED (key) (VstInt32 keyCode) { return 0; }
  virtual void DECLARE_VST_DEPRECATED (top) () {}
  virtual void DECLARE_VST_DEPRECATED (sleep) () {}
#endif
#if VST_2_1_EXTENSIONS
  virtual bool onKeyDown (VstKeyCode& keyCode)  { return false; }
  virtual bool onKeyUp (VstKeyCode& keyCode)    { return false; }
  virtual bool onWheel (float distance)      { return false; }
  virtual bool setKnobMode (VstInt32 val)      { return false; }
#endif
protected:
  AudioEffectX* beffect;
  void* systemWindow;
};
#define cMagic        'CcnK'
#define fMagic        'FxCk'
#define bankMagic      'FxBk'
#define chunkPresetMagic  'FPCh'
#define chunkBankMagic    'FBCh'
struct fxProgram {
 VstInt32 chunkMagic;
 VstInt32 byteSize;
 VstInt32 fxMagic;
 VstInt32 version;
 VstInt32 fxID;
 VstInt32 fxVersion;
 VstInt32 numParams;
 char prgName[28];
 union {
  float params[1];
  struct {
   VstInt32 size;
   char chunk[1];
  } data;
 } content;
};
struct fxBank {
 VstInt32 chunkMagic;
 VstInt32 byteSize;
 VstInt32 fxMagic;
 VstInt32 version;
 VstInt32 fxID;
 VstInt32 fxVersion;
 VstInt32 numPrograms;
#if VST_2_4_EXTENSIONS
 VstInt32 currentProgram;
 char future[124];
#else
 char future[128];
#endif
 union {
  fxProgram programs[1];
  struct {
   VstInt32 size;
   char chunk[1];
  } data;
 } content;
};
#endif
