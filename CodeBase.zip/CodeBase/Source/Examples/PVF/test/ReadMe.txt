this test demonstrates using pvf/neutron extented features, without breaking REAPER compatibility.

how to test
-------------
double click on one of the build scripts in the build folder.
then you will find a dll in the release folder.
copy the dll with the animation files to your vst folder, and load it in your host.