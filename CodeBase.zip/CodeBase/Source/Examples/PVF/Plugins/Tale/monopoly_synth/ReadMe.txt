
this is TALE+argee plugin written in EEL, converted to VST with neutron+pvf+codebase+gpp.

it includes imported nested libs and heavly uses psedu namespace code.

the original source (includes the libraries) didn't change at all !!!

(except of rename import file, that was NOT a requirment, only to be constant with the other lessGUI plug)

it compiles perfectly fine.
it works perfectly fine.

-------------------------------------------------------

in reaper the vst plug works fine (MIDI+AUDIO) but not perfect, some controls (ADSR) don't work properly.
^^^^ HISTORY ^^^^ adsr works!


* note:
  the plug produce invalid numbers (NAN). reaper handles them some how.

  ^^^ Wrong ^^^ - sorry it was bug in pvf. the abs function choosen was wrong. but yeah, reaper handles Invalid samples.


  fl studio 32 bits doesn't handle them.
  fl studio 64 bits handles them but there're some gfx problems, because of the 32 to 64 bridge.
  when codebase will produce 64 files, this problem will be solved.

  ^^^ Wrong ^^^ - sorry it was bug in pvf. the abs function choosen was wrong. it works perfectly in flstudio 32.