
this is argee arp which is a gui modification of whatsup & argee arp.

the gui of the other arp is also by argee.

we fixed the engine code according to the changes in the original arp.

the source file was divided for better read and test purpose.

we didn't tested yet. it may or may not require more changes.

the other arp tested and found to work as expected.

pvf/neutron compiles it to an optimized VST plugin, with ZERO modification to the original source.
