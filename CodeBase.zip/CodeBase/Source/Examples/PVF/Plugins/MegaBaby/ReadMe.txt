this plug belong to Cockos, it seems they forgot to licence it.
we cannot licence it because it's not our, we didn't touch the code at ALL!

pvf/neutron compiles it to an optimized VST plugin, with ZERO modification to the original source.
