
this is another excllent plug from saike.
it is compiled fine with zero changes to the source, it doesn't operate correctly yet.

Note:
  since this plug includes unusual source - '/*' (open comment block)
  it's required unusual parameter for building - '-e', meaning full compatiable eel mode.
  although pvf auto detect eel source, it doesn't allow unclosed comment block by default.

  this plug also rely on the fact that the compiler would do a nested folders scan when looking for imported libs.
  pvf support this but not by default. the '-e' argument command line is required for doing this.

  this plug use midi and audio so it needs a switch command line '-eff', to tell pvf that it is an effect and not a synth.
  this is require for daws like FL studio.