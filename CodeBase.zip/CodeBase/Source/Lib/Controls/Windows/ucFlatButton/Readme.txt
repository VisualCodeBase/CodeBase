
this control was found somewhere (probably on psc = planet source code)
it was almost totaly modified.
new modern features were added like: hovering, flickering less drawing, checked state, different colors and gradiant fill.

future - maybe different style drawing, taken from sources found on psc and converted to codebase.

licence - UN-licenced

a credit with a link (https://github.com/VisualCodeBase/CodeBase) would be appreciated.
