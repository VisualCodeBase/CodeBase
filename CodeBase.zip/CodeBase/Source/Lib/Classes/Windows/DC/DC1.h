
#ifndef cb_cDC1_H_
#define cb_cDC1_H_

typedef struct cb_s_cb_cDC_ {
  HWND hWnd;
  HDC hDC_;
  HBITMAP hBmp_;
  HBITMAP hOldBmp_;
  HFONT hFnt_;
  HFONT hOldFnt_;
  HFONT hOldFnt__;
  cb_Integer bkMode_;
  cb_Integer flg1_;
  cb_Integer X_;
  cb_Integer Y_;
  cb_Integer L_;
  cb_Integer T_;
  cb_Integer W_;
  cb_Integer H_;
  cb_Integer Top_;
  RECT rc_;
  void* bmp_;
  void* bmp__;
  void* bmp___;
  cb_Integer W__;
  cb_Integer H__;
  cb_Integer flag1__;
  HFONT oldfnt_;
  HFONT oldfnt__;
  void* fnt_;
  void* fnt__;
  void* hbmp__;
  cb_Integer iWeight;
  cb_UInteger A_;
  double Afp_;
  cb_Integer iMode_;
  cb_Integer iLICEMode_;
  cb_Integer iLICEMode__;
  COLORREF clrLice;
  cb_Integer TextH_;
  COLORREF clrFore1;
  COLORREF clrFore2;
  COLORREF clrBack1;
  COLORREF clrBack2;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cDC, *Pcb_cDC;

#endif