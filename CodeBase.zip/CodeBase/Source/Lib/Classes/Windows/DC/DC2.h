
#ifndef cb_cDC2_H_
#define cb_cDC2_H_

#define cb_cDC_LICEGetFont(x) (x)->fnt_
#define cb_cDC_LICEUnsetFont cb_cDC_LICESetFont
#define cb_cDC_GetFont(x) (x)->hFnt_
#define cb_cDC_UnsetFont cb_cDC_SetFont
#define cb_cDC_GetR cb_cDC_GetForeR
#define cb_cDC_SetR cb_cDC_SetForeR
#define cb_cDC_GetG cb_cDC_GetForeG
#define cb_cDC_SetG cb_cDC_SetForeG
#define cb_cDC_GetB cb_cDC_GetForeB
#define cb_cDC_SetB cb_cDC_SetForeB
#define cb_cDC_Clear cb_cDC_Set
#define cb_cDC_Free cb_cDC_Set
#define cb_cDC_ReStart(x) cb_cDC_Set(x,(HDC)-1)
#define cb_cDC_Invalidate cb_cDC_ReStart
#define cb_cDC_CreateMem(x) cb_cDC_Set(x,(HDC)-2)
#define cb_cDC_AssignBmp(x,y) cb_cDC_Set(x,(HDC)-2,y)
#define cb_cDC_ReleaseBmp(x) cb_cDC_Set(x,(HDC)-4)
#define cb_cDC_Get(x) (x)->hDC_
#define cb_cDC_GetDC cb_cDC_Get
#define cb_cDC_GetMode(x) (x)->iMode_
#define cb_cDC_LICEGetMode(x) (x)->iLICEMode_
#define cb_cDC_LICECreateMem(x) cb_cDC_Set(x,(HDC)-3)
#define cb_cDC_LICEAssignBmp(x,y) cb_cDC_Set(x,(HDC)-3,y)
#define cb_cDC_LICEReleaseBmp(x) cb_cDC_Set(x,(HDC)-4)
#define cb_cDC_LICESetImage cb_cDC_SetImage
#define cb_cDC_LICEGetDC cb_cDC_LICEGet
#define cb_cDC_Terminate(x) cb_cDC_Close(x)

cb_BeginExternC
HDC cb_cDC_LICEGet (cb_cDC*);
void* cb_cDC_LICEGetBmp (cb_cDC*);
cb_Integer cb_cDC_LICEClw (cb_cDC*,COLORREF =CLR_INVALID);
cb_Integer cb_cDC_LICEGetPixel (cb_cDC*,cb_Integer* =NULL,cb_Integer* =NULL,cb_Integer* =NULL);
cb_Integer cb_cDC_LICESetPixel (cb_cDC*,cb_Integer,cb_Integer,cb_Integer);
cb_Integer cb_cDC_LICEBlitExt (cb_cDC*,void*,cb_Integer*,double);
cb_Integer cb_cDC_LICEBlit (cb_cDC*,void*,double,double,cb_Integer =0,cb_Integer =0,cb_Integer =-1,cb_Integer =-1,cb_Integer =cb_MIN_INTEGER64,cb_Integer =cb_MIN_INTEGER64,cb_Integer =-1,cb_Integer =-1,double =0.0,double =0.0);
cb_Integer cb_cDC_LICEBlur (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
cb_Integer cb_cDC_LICEBlurTo (cb_cDC*,cb_Integer,cb_Integer);
cb_Integer cb_cDC_LICELine (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE);
cb_Integer cb_cDC_LICELineTo (cb_cDC*,cb_Integer,cb_Integer,cb_Integer =TRUE);
cb_Integer cb_cDC_LICERect (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE);
cb_Integer cb_cDC_LICERectTo (cb_cDC*,cb_Integer,cb_Integer);
cb_Integer cb_cDC_LICEGradRect (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,float,float,float,float,float,float,float,float,float,float,float,float);
cb_Integer cb_cDC_LICEGradRectTo (cb_cDC*,cb_Integer,cb_Integer,float,float,float,float,float,float,float,float,float,float,float,float);
cb_Integer cb_cDC_LICEArcFrom (cb_cDC*,double,double,double,double,double,cb_Integer =TRUE);
cb_Integer cb_cDC_LICEArc (cb_cDC*,double,double,double,cb_Integer =TRUE);
cb_Integer cb_cDC_LICECircleFrom (cb_cDC*,double,double,double,cb_Integer =FALSE,cb_Integer =TRUE);
cb_Integer cb_cDC_LICECircle (cb_cDC*,double,cb_Integer =FALSE,cb_Integer =TRUE);
cb_Integer cb_cDC_LICERoundRect (cb_cDC*,double,double,double,double,cb_Integer,cb_Integer =TRUE);
cb_Integer cb_cDC_LICERoundRectTo (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer =TRUE);
cb_Integer cb_cDC_LICETriangle (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
cb_Integer cb_cDC_LICETriangleTo (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
cb_Integer cb_cDC_LICEPolygonV (cb_cDC*,cb_Integer,int*);
cb_Integer cb_CDECL cb_cDC_LICEPolygon (cb_cDC*,cb_Integer,...);
void* cb_cDC_LICEGetDest (cb_cDC*,cb_Integer =FALSE);
void* cb_cDC_LICESetDest (cb_cDC*,void* =NULL);
cb_Integer cb_cDC_LICEDrawText (cb_cDC*,const cb_String,cb_Integer =0,cb_Integer =-1);
cb_Integer cb_cDC_LICEDrawChar (cb_cDC*,cb_UInteger,cb_Integer =-1);
cb_Integer cb_cDC_LICEDrawNumber (cb_cDC*,double,cb_Integer,cb_Integer =-1);
cb_Integer cb_cDC_LICEPrintFV (cb_cDC*,cb_String,const cb_String,void*);
cb_Integer cb_CDECL cb_cDC_LICEPrintF (cb_cDC*,cb_String,const cb_String,...);
cb_Integer cb_cDC_LICEMeasureText (cb_cDC*,const cb_String,cb_Integer* =NULL,cb_Integer =-1);
cb_Integer cb_cDC_LICEGetTextHeight (cb_cDC*,const cb_String =NULL);
void* cb_cDC_LICESetFont (cb_cDC*,void* =NULL);
void* cb_cDC_LICESetFromHFont (cb_cDC*,HFONT);
void* cb_cDC_GetBmp (cb_cDC*);
cb_Integer cb_cDC_Clw (cb_cDC*,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Integer =-1,cb_Integer =-1);
cb_Integer cb_cDC_GetPixel (cb_cDC*,cb_Integer* =NULL,cb_Integer* =NULL,cb_Integer* =NULL);
cb_Integer cb_cDC_SetPixel (cb_cDC*,cb_Integer,cb_Integer,cb_Integer);
cb_Integer cb_cDC_Blit (cb_cDC*,HBITMAP,double,double,cb_Integer =-1,cb_Integer =-1);
cb_Integer cb_cDC_BlitExt (cb_cDC*,HBITMAP,cb_Integer*,double);
cb_Integer cb_cDC_Line (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =-1);
cb_Integer cb_cDC_LineTo (cb_cDC*,cb_Integer,cb_Integer,cb_Integer =-1);
HBRUSH cb_cDC_CreateBrush (cb_cDC*,cb_Integer,cb_Integer);
cb_Integer cb_cDC_Rect (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_RectTo (cb_cDC*,cb_Integer,cb_Integer,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_GradRect (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
cb_Integer cb_cDC_GradRectTo (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
cb_Integer cb_cDC_ArcFrom (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,double,double,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_Arc (cb_cDC*,cb_Integer,double,double,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_CircleFrom (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_Circle (cb_cDC*,cb_Integer,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_RoundRect (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_RoundRectTo (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_Triangle (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_TriangleTo (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_cDC_PolygonV (cb_cDC*,cb_Integer,POINT*,cb_Integer =-1,COLORREF =CLR_INVALID,cb_Integer =PS_SOLID);
cb_Integer cb_CDECL cb_cDC_Polygon (cb_cDC*,cb_Integer,...);
cb_Integer cb_cDC_DrawText (cb_cDC*,const cb_String,cb_Integer =-1);
cb_Integer cb_cDC_DrawChar (cb_cDC*,cb_UInteger);
cb_Integer cb_cDC_DrawNumber (cb_cDC*,double,cb_Integer);
cb_Integer cb_cDC_PrintFV (cb_cDC*,cb_String,const cb_String,void*);
cb_Integer cb_CDECL cb_cDC_PrintF (cb_cDC*,cb_String,const cb_String,...);
cb_Integer cb_cDC_MeasureText (cb_cDC*,const cb_String,cb_Integer*);
cb_Integer cb_cDC_GetTextHeight (cb_cDC*,const cb_String =NULL);
HFONT cb_cDC_SetFont (cb_cDC*,HFONT =NULL,cb_Integer =FALSE);
void* cb_cDC_GetDest (cb_cDC*,cb_Integer =FALSE);
void* cb_cDC_SetDest (cb_cDC*,void* =NULL);
COLORREF cb_cDC_GetBackColor (cb_cDC*);
void cb_cDC_SetBackColor (cb_cDC*,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Integer =FALSE);
COLORREF cb_cDC_GetForeColor (cb_cDC*);
void cb_cDC_SetForeColor (cb_cDC*,COLORREF,COLORREF =CLR_INVALID);
BYTE cb_cDC_GetBackR (cb_cDC*);
void cb_cDC_SetBackR (cb_cDC*,BYTE);
BYTE cb_cDC_GetBackG (cb_cDC*);
void cb_cDC_SetBackG (cb_cDC*,BYTE);
BYTE cb_cDC_GetBackB (cb_cDC*);
void cb_cDC_SetBackB (cb_cDC*,BYTE);
BYTE cb_cDC_GetBackA (cb_cDC*);
void cb_cDC_SetBackA (cb_cDC*,BYTE);
BYTE cb_cDC_GetForeR (cb_cDC*);
void cb_cDC_SetForeR (cb_cDC*,BYTE);
BYTE cb_cDC_GetForeG (cb_cDC*);
void cb_cDC_SetForeG (cb_cDC*,BYTE);
BYTE cb_cDC_GetForeB (cb_cDC*);
void cb_cDC_SetForeB (cb_cDC*,BYTE);
BYTE cb_cDC_GetForeA (cb_cDC*);
void cb_cDC_SetForeA (cb_cDC*,BYTE);
COLORREF cb_cDC_GetBkColor (cb_cDC*);
void cb_cDC_SetBkColor (cb_cDC*,COLORREF);
COLORREF cb_cDC_GetTextColor (cb_cDC*);
void cb_cDC_SetTextColor (cb_cDC*,COLORREF);
RECT* cb_cDC_GetRect (cb_cDC*);
void cb_cDC_SetRect (cb_cDC*,RECT*);
cb_Integer cb_cDC_GetX (cb_cDC*);
void cb_cDC_SetX (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetY (cb_cDC*);
void cb_cDC_SetY (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetLeft (cb_cDC*);
void cb_cDC_SetLeft (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetTop (cb_cDC*);
void cb_cDC_SetTop (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetWidth (cb_cDC*);
void cb_cDC_SetWidth (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetHeight (cb_cDC*);
void cb_cDC_SetHeight (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetWeight (cb_cDC*);
void cb_cDC_SetWeight (cb_cDC*,cb_Integer =-1);
cb_Integer cb_cDC_GetTransparency (cb_cDC*);
void cb_cDC_SetTransparency (cb_cDC*,cb_UInteger =-1);
double cb_cDC_GetTransparencyEx (cb_cDC*);
void cb_cDC_SetTransparencyEx (cb_cDC*,double =1.0);
void cb_cDC_SetMode (cb_cDC*,cb_Integer =-1);
void cb_cDC_LICESetMode (cb_cDC*,cb_Integer =-1);
HWND cb_cDC_GethWnd (cb_cDC*);
HWND cb_cDC_SethWnd (cb_cDC*,HWND);
void cb_cDC_SetImage (cb_cDC*,HBITMAP);
void cb_cDC_Settings (cb_cDC*,cb_Integer =-1,cb_Integer =-1,cb_Integer =-1,cb_Integer =-1,cb_Integer =-1,cb_Integer =-1,cb_Integer =-1);
void* cb_cDC_Set (cb_cDC*,HDC =NULL,void* =NULL);
void cb_cDC_Flush (cb_cDC*,HDC =NULL);
void cb_cDC_Open (cb_cDC*,void*,cb_Integer =FALSE,RECT* =NULL);
void cb_cDC_Reset (cb_cDC*);
void cb_cDC_Close (cb_cDC*);
void cb_cDC_Initialize (cb_cDC*);
cb_EndExternC

#endif
