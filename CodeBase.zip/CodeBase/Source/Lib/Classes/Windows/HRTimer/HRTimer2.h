
#ifndef cb_cHRTimer2_H_
#define cb_cHRTimer2_H_

#define WM_HRTIMER_ WM_USER+1
#define cb_cHRTimer_GetEnabled(x) ((x)->iFlag_ & 1)
#define cb_cHRTimer_GethWnd(x) (x)->hWnd
#define cb_cHRTimer_SethWnd(x,y) (x)->hWnd = y
#define cb_cHRTimer_GetInterval(x) (x)->Interval
#define cb_cHRTimer_SetInterval(x,y) (x)->Interval = y
#define cb_cHRTimer_GetThreadId(x) (x)->idThread_
#define cb_cHRTimer_GetThreadHandle(x,y) (x)->hThread_
#define cb_cHRTimer_Kill cb_cHRTimer_End
#define cb_cHRTimer_Start cb_cHRTimer_SetEnabled
#define cb_cHRTimer_Pause(x) cb_cHRTimer_SetEnabled(x,-1)
#define cb_cHRTimer_Resume(x) cb_cHRTimer_SetEnabled(x,TRUE)
#define cb_cHRTimer_Create cb_cHRTimer_Initialize
#define cb_cHRTimer_Destroy cb_cHRTimer_Terminate

cb_BeginExternC
void cb_cHRTimer_Notify (cb_cHRTimer*);
void cb_cHRTimer_End (cb_cHRTimer*);
void cb_cHRTimer_SetEnabled (cb_cHRTimer*,cb_Integer =TRUE,cb_UInteger =-1);
EXTERN_C cb_cHRTimer* cb_cHRTimer_Initialize (cb_cHRTimer* =NULL,void* =NULL,void* =NULL);
EXTERN_C void cb_cHRTimer_Terminate (cb_cHRTimer*);
cb_EndExternC

#endif
