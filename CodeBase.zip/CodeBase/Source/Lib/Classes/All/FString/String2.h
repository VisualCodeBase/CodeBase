
#ifndef cb_cFString2_H_
#define cb_cFString2_H_

#define cb_cFString_DEFAULT_MAXLENGTH 2*0x400
#define cb_cFString_DEFAULT_ADDLENGTH 2*0x400
#define cb_cFString_GetBufferSize(x) (x)->m_Size-2
#define cb_cFString_GetSize cb_cFString_GetBufferSize
#define cb_cFString_SetSize cb_cFString_SetBufferSize
#define cb_cFString_Str cb_cFString_StrPtr
#define cb_cFString_GetLen cb_cFString_GetLength
#define cb_cFString_Len cb_cFString_GetLength
#define cb_cFString_Length cb_cFString_GetLength
#define cb_cFString_SetLen cb_cFString_SetLength
#define cb_cFString_ChangeLen cb_cFString_ChangeLength
#define cb_cFString_StrPut cb_cFString_StrPutAt
#define cb_cFString_StrCopyAt cb_cFString_StrPutAt
#define cb_cFString_StrCopy cb_cFString_StrPutAt
#define cb_cFString_Put cb_cFString_PutAt
#define cb_cFString_UserClassCopyAt cb_cFString_PutAt
#define cb_cFString_Copy cb_cFString_PutAt
#define cb_cFString_StrNPut cb_cFString_StrNPutAt
#define cb_cFString_StrNCopyAt cb_cFString_StrNPutAt
#define cb_cFString_StrNCopy cb_cFString_StrNPutAt
#define cb_cFString_NPut cb_cFString_NPutAt
#define cb_cFString_NCopyAt cb_cFString_NPutAt
#define cb_cFString_NCopy cb_cFString_NPutAt
#define cb_cFString_StrInsert cb_cFString_StrInsertAt
#define cb_cFString_Insert cb_cFString_InsertAt
#define cb_cFString_StrMid cb_cFString_StrGetMid
#define cb_cFString_substr cb_cFString_StrGetMid
#define cb_cFString_StrLeft cb_cFString_StrGetLeft
#define cb_cFString_StrRight cb_cFString_StrGetRight
#define cb_cFString_GetChar cb_cFString_Asc
#define cb_cFString_StrAdd cb_cFString_StrCat
#define cb_cFString_StrCat cb_cFString_StrAppend
#define cb_cFString_Cat cb_cFString_Append
#define cb_cFString_Add cb_cFString_Cat
#define cb_cFString_StrNCat cb_cFString_StrNAppend
#define cb_cFString_NCat cb_cFString_NAppend
#define cb_cFString_CharAdd cb_cFString_CharAppend
#define cb_cFString_DeleteChars cb_cFString_Delete
#define cb_cFString_GetData(w,x,y,z) cb_cFString_Get(w,x,0,y,0,z)
#define cb_cFString_PeekData(x,y,z) cb_cFString_Get(x,y,0,z,0,TRUE)
#define cb_cFString_EOF cb_cFString_EOS

cb_BeginExternC
void* cb_cFString_Initialize (cb_Integer =0,void* =NULL);
void cb_cFString_Terminate (void*);
void* cb_cFString_SetBufferSize (void*,cb_Integer,cb_Boolean =FALSE);
void* cb_cFString_New (cb_Integer =0);
void* cb_cFString_SetBuffer (void*,void*,cb_Integer =0);
const cb_PString cb_cFString_StrPtr (const void*);
cb_Integer cb_cFString_GetLength (const void*);
void* cb_cFString_SetLength (void*,cb_Integer);
void* cb_cFString_ChangeLength (void*,cb_Integer);
void cb_cFString_Clear (void*);
cb_PString cb_cFString_StrGetAt (void*,cb_Integer =0,cb_Integer =-1,void* =NULL);
void* cb_cFString_StrPutAt (void*,const void*,cb_Integer =0,cb_Integer =-1);
void* cb_cFString_PutAt (void*,const void*,cb_Integer =0,cb_Integer =-1);
void* cb_cFString_StrNPutAt (void*,const void*,cb_Integer =0,cb_Integer =-1,cb_Integer =-1);
void* cb_cFString_NPutAt (void*,const void*,cb_Integer =0,cb_Integer =-1,cb_Integer =-1);
void* cb_cFString_Dup (void*,void* =NULL);
void* cb_cFString_StrInsertAt (void*,const void*,cb_Integer =0,cb_Integer =-1,cb_Integer =0);
void* cb_cFString_InsertAt (void*,const void*,cb_Integer =0,cb_Integer =-1,cb_Integer =0);
cb_PString cb_cFString_StrGetMid (void*,cb_Integer =0,cb_Integer =-1,void* =NULL,cb_Integer* =NULL);
cb_PString cb_cFString_StrGetLeft (void*,cb_Integer =-1,void* =NULL);
cb_PString cb_cFString_StrGetRight (void*,cb_Integer =-1,void* =NULL);
void* cb_cFString_StrSetMid (void*,const void*,cb_Integer =0,cb_Integer =-1,cb_Integer =-1);
cb_Integer cb_cFString_Asc (void*,cb_UInteger =0);
void* cb_cFString_SetChar (void*,cb_UInteger,BYTE);
cb_Integer cb_cFString_InStr (void*,const cb_String,cb_Integer =0,cb_Integer =0);
cb_Integer cb_cFString_In (void*,const void*,cb_Integer =0,cb_Integer =0);
cb_Integer cb_cFString_StrFind (void*,const cb_String,cb_Integer =0,cb_Boolean =FALSE,cb_Integer =0);
cb_Integer cb_cFString_Find (void*,const void*,cb_Integer =0,cb_Boolean =FALSE,cb_Integer =0);
void* cb_cFString_UCase (void*);
void* cb_cFString_LCase (void*);
void* cb_cFString_Reverse (void*);
void* cb_cFString_StrAppend (void*,const void*,cb_Integer =-1);
void* cb_cFString_Append (void*,const void*,cb_Integer =-1);
void* cb_cFString_LineAppend (void*,const cb_String,cb_Integer =-1);
void* cb_cFString_StrNAppend (void*,const void*,cb_Integer =-1,cb_Integer =-1);
void* cb_cFString_NAppend (void*,const void*,cb_Integer =-1,cb_Integer =-1);
void* cb_cFString_CharAppend (void*,char);
void* cb_CDECL cb_cFString_StrJoin (void*,const cb_String,...);
void* cb_CDECL cb_cFString_Join (void*,const void*,...);
void* cb_CDECL cb_cFString_StrConCat (void*,const cb_String,...);
void* cb_CDECL cb_cFString_ConCat (void*,const void*,...);
void* cb_CDECL cb_cFString_SPrintF (void*,const cb_String,...);
cb_Integer cb_cFString_StrCompareCase (const void*,const cb_String);
cb_Integer cb_cFString_StrCompareNoCase (const void*,const cb_String);
cb_Integer cb_cFString_CompareCase (const void*,const void*);
cb_Integer cb_cFString_CompareNoCase (const void*,const void*);
const char* cb_cFString_CharToken (void*,cb_Integer,const cb_String =NULL,void* =(void*)-2);
const char* cb_cFString_StrToken (void*,const cb_String,const cb_String =NULL,void* =(void*)-2);
cb_Integer cb_cFString_Backspace (void*,cb_Integer =1);
void cb_cFString_Delete (void*,cb_Integer,cb_Integer =0);
char* cb_cFString_Get (void*,void* =NULL,cb_Integer =0,void* =NULL,cb_Integer =0,cb_Boolean =FALSE);
char* cb_cFString_Peek (void*,void* =NULL,cb_Integer =0,void* =NULL,cb_Integer =0);
char* cb_cFString_GetLine (void*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1,cb_Integer =FALSE);
char* cb_cFString_PeekLine (void*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1);
char* cb_cFString_ReadLine (void*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1);
wchar_t* cb_cFString_GetLineW (void*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1,cb_Integer =FALSE);
wchar_t* cb_cFString_PeekLineW (void*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1);
wchar_t* cb_cFString_ReadLineW (void*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1);
cb_Integer cb_cFString_HasLine (void*,cb_Integer =0);
cb_Integer cb_cFString_EOS (void*);
void cb_cFString_Rewind (void*);
void* cb_cFString_GetTag (void*);
void* cb_cFString_SetTag (void*,void*);
cb_Integer cb_cFString_WriteFile (void*,cb_File*);
cb_Integer cb_cFString_WriteFileName (void*,const cb_String);
void* cb_cFString_ReadFile (void*,cb_File*,cb_Integer =0);
void* cb_cFString_ReadFileName (void*,const cb_String,cb_Integer =0);
void* cb_cFString_ReadFileNameW (void*,const cb_StringW,cb_Integer =0);
cb_Integer cb_cFString_Seek (void*,cb_Integer =0,cb_Integer =SEEK_SET);
cb_Integer cb_cFString_Tell (void*);
char* cb_cFString_Read (void*,cb_Integer* =NULL,void* =NULL,cb_Integer =0);
void* cb_cFString_Write (void*,const void*,cb_Integer =-1);
cb_EndExternC

#endif
