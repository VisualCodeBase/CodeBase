
#ifndef cb_cFString1_H_
#define cb_cFString1_H_

#define cb_cFString void

#endif
