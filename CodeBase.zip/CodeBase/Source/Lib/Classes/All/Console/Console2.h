
#ifndef cb_cConsole2_H_
#define cb_cConsole2_H_

#define cb_cConsole_ReadLine cb_cConsole_Get

cb_BeginExternC
char* cb_cConsole_Get (cb_cConsole*,void* =NULL,cb_Integer =-1);
cb_Integer cb_cConsole_Put (cb_cConsole*,const cb_String,cb_Integer =-1);
cb_Integer cb_cConsole_WriteLine (cb_cConsole*,const cb_String,cb_Integer =-1);
cb_cConsole* cb_cConsole_Terminate (cb_cConsole*);
cb_cConsole* cb_cConsole_Initialize (cb_cConsole* =NULL);
cb_EndExternC

#endif
