
#ifndef cb_cConsole1_H_
#define cb_cConsole1_H_

typedef struct cb_s_cb_cConsole_ {
  HANDLE hIn;
  HANDLE hOut;
  char m_Buf[16*0x400];
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cConsole, *Pcb_cConsole;

#endif