
#ifndef cb_cTimer1_H_
#define cb_cTimer1_H_

typedef struct cb_s_cb_cTimer_ {
  cb_Integer iInterval;
  cb_Integer bEnabled;
  cb_UInteger idTimer_;
  cb_Integer Ndx_;
  void (cb_CDECL *OnTimer)(struct cb_s_cb_cTimer_*);
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cTimer, *Pcb_cTimer;

#endif
