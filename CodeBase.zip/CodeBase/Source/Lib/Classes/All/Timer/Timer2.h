
#ifndef cb_cTimer2_H_
#define cb_cTimer2_H_

#define cb_cTimer_GetEnabled(x) x->bEnabled
#define cb_cTimer_Pause(x) cb_cTimer_SetEnabled(x,FALSE)
#define cb_cTimer_Resume(x) cb_cTimer_SetEnabled(x,TRUE)
#define cb_cTimer_GetInterval(x) x->iInterval
#define cb_cTimer_SetInterval(x,y) x->iInterval = y
#define cb_cTimer_Create cb_cTimer_Initialize
#define cb_cTimer_Destroy cb_cTimer_Terminate

cb_BeginExternC
void cb_DEFCALL cb_cTimer_SetEnabled (cb_cTimer*,cb_Integer =TRUE,cb_UInteger =-1);
void cb_DEFCALL cb_cTimer_Kill (cb_cTimer*);
cb_cTimer* cb_cTimer_Initialize (cb_cTimer* =NULL,void* =NULL,void* =NULL);
void cb_cTimer_Terminate (cb_cTimer*);
cb_EndExternC

#endif
