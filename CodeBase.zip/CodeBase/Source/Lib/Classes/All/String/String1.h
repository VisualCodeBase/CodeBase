
#ifndef cb_cString1_H_
#define cb_cString1_H_

typedef struct cb_s_cb_cString_ {
  BYTE* m_Buffer;
  cb_Integer m_Size;
  cb_Integer m_Len;
  cb_Integer m_Pos;
  cb_Integer m_LastChar;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cString, *Pcb_cString;

#endif
