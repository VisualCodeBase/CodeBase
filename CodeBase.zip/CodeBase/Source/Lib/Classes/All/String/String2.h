
#ifndef cb_cString2_H_
#define cb_cString2_H_

#define cb_cString_DEFAULT_MAXLENGTH 2*0x400
#define cb_cString_DEFAULT_ADDLENGTH 2*0x400
#define cb_cString_GetBufferSize(x) ((x)->m_Size-2)
#define cb_cString_GetSize cb_cString_GetBufferSize
#define cb_cString_SetSize cb_cString_SetBufferSize
#define cb_cString_Str cb_cString_StrPtr
#define cb_cString_GetLength(x) (x)->m_Len
#define cb_cString_GetLen cb_cString_GetLength
#define cb_cString_Len cb_cString_GetLength
#define cb_cString_Length cb_cString_GetLength
#define cb_cString_SetLen cb_cString_SetLength
#define cb_cString_ChangeLen cb_cString_ChangeLength
#define cb_cString_StrGet cb_cString_StrGetAt
#define cb_cString_StrPut cb_cString_StrPutAt
#define cb_cString_StrCopyAt cb_cString_StrPutAt
#define cb_cString_StrCopy cb_cString_StrPutAt
#define cb_cString_Put cb_cString_PutAt
#define cb_cString_CopyAt cb_cString_PutAt
#define cb_cString_Copy cb_cString_PutAt
#define cb_cString_StrNPut cb_cString_StrNPutAt
#define cb_cString_StrNCopyAt cb_cString_StrNPut
#define cb_cString_StrNCopy cb_cString_StrNPutAt
#define cb_cString_NPut UserClassNPutAt
#define cb_cString_NCopyAt cb_cString_NPutAt
#define cb_cString_NCopy cb_cString_NPutAt
#define cb_cString_StrInsert cb_cString_StrInsertAt
#define cb_cString_Insert cb_cString_InsertAt
#define cb_cString_StrMid cb_cString_StrGetMid
#define cb_cString_substr cb_cString_StrGetMid
#define cb_cString_StrLeft cb_cString_StrGetLeft
#define cb_cString_StrRight cb_cString_StrGetRight
#define cb_cString_GetChar cb_cString_Asc
#define cb_cString_StrAdd cb_cString_StrCat
#define cb_cString_StrCat cb_cString_StrAppend
#define cb_cString_Cat cb_cString_Append
#define cb_cString_Add cb_cString_Cat
#define cb_cString_StrNCat cb_cString_StrNAppend
#define cb_cString_NCat cb_cString_NAppend
#define cb_cString_CharAdd cb_cString_CharAppend
#define cb_cString_DeleteChars cb_cString_Delete
#define cb_cString_GetData(w,x,y,z) cb_cString_Get(w,x,0,y,0,z)
#define cb_cString_PeekData(x,y,z) cb_cString_Get(x,y,0,z,0,TRUE)
#define cb_cString_EOF cb_cString_EOS

cb_BeginExternC
cb_cString* cb_cString_Initialize (cb_cString*);
void cb_cString_Terminate (cb_cString*);
cb_cString* cb_cString_SetBufferSize (cb_cString*,cb_Integer,cb_Boolean =FALSE);
cb_cString* cb_cString_New (cb_Integer =0);
cb_cString* cb_cString_SetBuffer (cb_cString*,void*,cb_Integer =-1);
cb_cString* cb_cString_Attatch (cb_cString*,void*,cb_Integer =-1,cb_Integer =FALSE);
cb_PString cb_cString_Release (cb_cString*,cb_Integer* =NULL);
const cb_PString cb_cString_StrPtr (const cb_cString*);
cb_cString* cb_cString_SetLength (cb_cString*,cb_Integer);
cb_cString* cb_cString_ChangeLength (cb_cString*,cb_Integer);
void cb_cString_Clear (cb_cString*);
cb_PString cb_cString_StrGetAt (cb_cString*,cb_Integer =0,cb_Integer =-1,void* =NULL);
cb_cString* cb_cString_StrPutAt (cb_cString*,const void*,cb_Integer =0,cb_Integer =-1);
cb_cString* cb_cString_PutAt (cb_cString*,const cb_cString*,cb_Integer =0,cb_Integer =-1);
cb_cString* cb_cString_StrNPutAt (cb_cString*,const void*,cb_Integer =0,cb_Integer =-1,cb_Integer =-1);
cb_cString* cb_cString_NPutAt (cb_cString*,const cb_cString*,cb_Integer =0,cb_Integer =-1,cb_Integer =-1);
cb_cString* cb_cString_Dup (cb_cString*,cb_cString* =NULL);
cb_cString* cb_cString_StrInsertAt (cb_cString*,const void*,cb_Integer =0,cb_Integer =-1,cb_Integer =0);
cb_cString* cb_cString_InsertAt (cb_cString*,const cb_cString*,cb_Integer =0,cb_Integer =-1,cb_Integer =0);
cb_PString cb_cString_StrGetMid (cb_cString*,cb_Integer =-1,cb_Integer =-1,void* =NULL,cb_Integer* =NULL);
cb_PString cb_cString_StrGetLeft (cb_cString*,cb_Integer =-1,void* =NULL);
cb_PString cb_cString_StrGetRight (cb_cString*,cb_Integer =-1,void* =NULL);
cb_cString* cb_cString_StrSetMid (cb_cString*,const void*,cb_Integer =0,cb_Integer =-1,cb_Integer =-1);
cb_Integer cb_cString_Asc (cb_cString*,cb_UInteger =0);
void cb_cString_SetChar (cb_cString*,cb_UInteger,BYTE);
cb_Integer cb_cString_InStr (cb_cString*,const cb_String,cb_Integer =0,cb_Integer =0);
cb_Integer cb_cString_In (cb_cString*,const cb_cString*,cb_Integer =0,cb_Integer =0);
cb_Integer cb_cString_StrFind (cb_cString*,const cb_String,cb_Integer =0,cb_Boolean =FALSE,cb_Integer =0);
cb_Integer cb_cString_Find (cb_cString*,const cb_cString*,cb_Integer =0,cb_Boolean =FALSE,cb_Integer =0);
cb_cString* cb_cString_UCase (cb_cString*);
cb_cString* cb_cString_LCase (cb_cString*);
cb_cString* cb_cString_ReverseStr (cb_cString*);
cb_cString* cb_cString_StrAppend (cb_cString*,const void*,cb_Integer =-1);
cb_cString* cb_cString_LineAppend (cb_cString*,const cb_String,cb_Integer =-1);
cb_cString* cb_cString_Append (cb_cString*,const cb_cString*,cb_Integer =-1);
cb_cString* cb_cString_StrNAppend (cb_cString*,const void*,cb_Integer =-1,cb_Integer =-1);
cb_cString* cb_cString_NAppend (cb_cString*,const cb_cString*,cb_Integer =-1,cb_Integer =-1);
cb_cString* cb_cString_CharAppend (cb_cString*,char);
cb_cString* cb_CDECL cb_cString_StrJoin (cb_cString*,const cb_String,...);
cb_cString* cb_CDECL cb_cString_Join (cb_cString*,const cb_cString*,...);
cb_cString* cb_CDECL cb_cString_StrConCat (cb_cString*,const cb_String,...);
cb_cString* cb_CDECL cb_cString_ConCat (cb_cString*,const cb_cString*,...);
cb_cString* cb_CDECL cb_cString_SPrintF (cb_cString*,const cb_String,...);
cb_Integer cb_cString_StrCompareCase (cb_cString*,const cb_String);
cb_Integer cb_cString_StrCompareNoCase (cb_cString*,const cb_String);
cb_Integer cb_cString_CompareCase (cb_cString*,const cb_cString*);
cb_Integer cb_cString_CompareNoCase (cb_cString*,const cb_cString*);
const char* cb_cString_CharToken (cb_cString*,cb_Integer,const cb_String =NULL,void* =(void*)-2);
const char* cb_cString_StrToken (cb_cString*,const cb_String,const cb_String =NULL,void* =(void*)-2);
cb_Integer cb_cString_Backspace (cb_cString*,cb_Integer =1);
void cb_cString_Delete (cb_cString*,cb_Integer,cb_Integer =0);
char* cb_cString_Get (cb_cString*,void* =NULL,cb_Integer =0,void* =NULL,cb_Integer =0,cb_Boolean =FALSE);
char* cb_cString_Peek (cb_cString*,void* =NULL,cb_Integer =0,void* =NULL,cb_Integer =0);
char* cb_cString_GetLine (cb_cString*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1,cb_Integer =FALSE);
char* cb_cString_PeekLine (cb_cString*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1);
char* cb_cString_ReadLine (cb_cString*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1);
wchar_t* cb_cString_GetLineW (cb_cString*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1,cb_Integer =FALSE);
wchar_t* cb_cString_PeekLineW (cb_cString*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1);
wchar_t* cb_cString_ReadLineW (cb_cString*,void* =NULL,void* =NULL,cb_Integer =0,cb_Integer =-1);
cb_Integer cb_cString_HasLine (cb_cString*,cb_Integer =0);
cb_Integer cb_cString_EOS (cb_cString*);
void cb_cString_Rewind (cb_cString*);
void* cb_cString_GetTag (cb_cString*);
void* cb_cString_SetTag (cb_cString*,void*);
cb_Integer cb_cString_WriteFile (cb_cString*,cb_File*);
cb_Integer cb_cString_WriteFileName (cb_cString*,const cb_String);
cb_cString* cb_cString_ReadFile (cb_cString*,cb_File*,cb_Integer =0);
cb_cString* cb_cString_ReadFileName (cb_cString*,const cb_String,cb_Integer =0);
cb_cString* cb_cString_ReadFileNameW (cb_cString*,const cb_StringW,cb_Integer =0);
cb_Integer cb_cString_Seek (cb_cString*,cb_Integer =0,cb_Integer =SEEK_SET);
cb_Integer cb_cString_Tell (cb_cString*);
char* cb_cString_Read (cb_cString*,cb_Integer* =NULL,void* =NULL,cb_Integer =0);
cb_cString* cb_cString_Write (cb_cString*,const void*,cb_Integer =-1);
cb_EndExternC

#endif
