
#ifndef cb_cCollection1_H_
#define cb_cCollection1_H_

typedef struct cb_s_cb_cCollection_ {
  cb_UInteger m_Cnt;
  BYTE* m_Items;
  cb_UInteger m_UBound;
  cb_Integer m_Vector;
  cb_Integer m_ElementSize;
  void (cb_CDECL *onStart)(struct cb_s_cb_cCollection_*,void**,cb_Integer);
  cb_Boolean (cb_CDECL *OnEnd)(struct cb_s_cb_cCollection_*,void**,cb_Integer);
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cCollection, *Pcb_cCollection;

#endif
