
#ifndef cb_cEachFile2_H_
#define cb_cEachFile2_H_

#define cb_cEachFile_RewindA(x) cb_cEachFile_OpenVA(x,NULL)
#define cb_cEachFile_RewindW(x) cb_cEachFile_OpenVW(x,NULL)
#define cb_cEachFile_Rewind cb_cEachFile_OpenA
#define cb_cEachFile_NextA cb_cEachFile_GetA
#define cb_cEachFile_NextW cb_cEachFile_GetW
#define cb_cEachFile_Next cb_cEachFile_Get
#define cb_cEachFile_NameA(x) (cb_PString)((x)->sFileName)
#define cb_cEachFile_NameLen(x) (x)->iFileName
#define cb_cEachFile_NameW(x) (x)->sFileName
#define cb_cEachFile_NameLenW cb_cEachFile_NameLen
#define cb_cEachFile_Name cb_cEachFile_NameA
#define cb_cEachFile_IsDir cb_cEachFile_IsFolder

cb_BeginExternC
cb_cEachFile* cb_cEachFile_Terminate (cb_cEachFile*);
cb_cEachFile* cb_cEachFile_Initialize (cb_cEachFile* =NULL);
cb_Integer cb_cEachFile_OpenVA (cb_cEachFile*,void**);
char* cb_cEachFile_GetA (cb_cEachFile*,void* =NULL,cb_Integer =cb_MIN_INTEGER64);
cb_Integer cb_CDECL cb_cEachFile_OpenA (cb_cEachFile*,...);
char* cb_CDECL cb_cEachFile_FirstA (cb_cEachFile*,...);
cb_Integer cb_cEachFile_OpenVW (cb_cEachFile*,void**);
wchar_t* cb_cEachFile_GetW (cb_cEachFile*,void* =NULL,cb_Integer =cb_MIN_INTEGER64);
cb_Integer cb_CDECL cb_cEachFile_OpenW (cb_cEachFile*,...);
wchar_t* cb_CDECL cb_cEachFile_FirstW (cb_cEachFile*,...);
cb_Boolean cb_cEachFile_IsFile (cb_cEachFile*);
cb_Boolean cb_cEachFile_IsFolder (cb_cEachFile*);
cb_Integer cb_cEachFile_OpenV (cb_cEachFile*,void**);
cb_Integer cb_CDECL cb_cEachFile_Open (cb_cEachFile*,...);
void* cb_cEachFile_Get (cb_cEachFile*,void* =NULL,cb_Integer =cb_MIN_INTEGER64);
void* cb_CDECL cb_cEachFile_First (cb_cEachFile*,...);
cb_EndExternC

#endif
