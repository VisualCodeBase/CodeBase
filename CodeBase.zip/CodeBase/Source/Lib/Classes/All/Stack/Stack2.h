
#ifndef cb_cStack2_H_
#define cb_cStack2_H_

#define cb_cStack_GetBuf cb_cStack_Buf
#define cb_cStack_Stack cb_cStack_Buf
#define cb_cStack_Create cb_cStack_Initialize
#define cb_cStack_Destroy cb_cStack_Terminate

cb_BeginExternC
void* cb_cStack_Pop (cb_cStack*,void*,cb_Integer =-1);
const void* cb_cStack_Push (cb_cStack*,const void*,cb_Integer =-1);
void* cb_cStack_XChange (cb_cStack*,void*,cb_Integer =-1);
void* cb_cStack_GetAt (cb_cStack*,cb_Integer,void*,cb_Integer =-1);
const void* cb_cStack_PutAt (cb_cStack*,cb_Integer,const void*,cb_Integer =-1);
cb_Integer cb_cStack_Size (cb_cStack*);
const void* cb_cStack_Buf (cb_cStack*);
EXTERN_C cb_cStack* cb_cStack_Initialize (cb_cStack* =NULL,void* =NULL,void* =NULL);
EXTERN_C void cb_cStack_Terminate (cb_cStack*);
cb_EndExternC

#endif
