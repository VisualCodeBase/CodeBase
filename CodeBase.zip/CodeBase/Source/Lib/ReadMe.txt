The files in this folder are used by codebase on compile time.
most of them are declarations.
few of them contained source that is compiled each time it's been in used.