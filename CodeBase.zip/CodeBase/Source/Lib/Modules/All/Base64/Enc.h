
char* cb_DEFCALL cb_Base64_Encode(const char*, char*, cb_Integer=-1, cb_Integer* =NULL);