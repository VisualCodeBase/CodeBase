
char* cb_DEFCALL cb_Base64_Decode(const char*, char*, cb_Integer=0, cb_Integer* =NULL);