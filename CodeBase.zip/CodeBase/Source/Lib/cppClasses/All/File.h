
#ifndef cb_cppFile_H_
#define cb_cppFile_H_

#include "String.h"

#ifndef cb_cppFileInt
#define cb_cppFileInt cb_Integer
#endif

#ifndef cb_cppFileLLong
#define cb_cppFileLLong long long
#endif

class cb_cppFile
{
  protected:
    void *h;
    cb_cppFileInt sze;
    cb_cppFileInt pos;
    cb_cppFileInt flg;
    const cb_cppString *s;

    static cb_cppFile* ios_in_;
    static cb_cppFile* ios_out_;
    static cb_cppFile* ios_err_;

    static cb_cppFile& ios_in;
    static cb_cppFile& ios_out;
    static cb_cppFile& ios_err;

  public:
    cb_cppFile& Open(const char*, const char *);
    cb_cppFile& open(const char* s, const char *f) { return Open(s,f); }
    inline cb_cppFile& open(cb_cppString& str, const char* m) { return open(str.c_str(),m); }
    cb_cppFile& Open(const char*, cb_cppFileInt);
    cb_cppFile& open(const char* s, cb_cppFileInt f) { return Open(s,f); }
    inline cb_cppFile& open(cb_cppString& str, cb_cppFileInt f) { return open(str.c_str(),f); }
    cb_cppFile& Open(void*, cb_cppFileInt=0);
    cb_cppFile& open(void* s, cb_cppFileInt f) { return Open(s,f); }

    cb_cppFile();
    cb_cppFile(const char* n, cb_cppFileInt f) { cb_cppFile(); open(n,f); }
    cb_cppFile(cb_cppString& str, cb_cppFileInt f) { cb_cppFile(); open(str,f); }
    cb_cppFile(const char* n, const char *m) { cb_cppFile(); open(n,m); }
    cb_cppFile(cb_cppString& str, const char *m) { cb_cppFile(); open(str,m); }
    cb_cppFile(void* o,cb_cppFileInt f=0) { cb_cppFile(); open(o,f); }

    inline void Close();
    inline void close() { Close(); }
    ~cb_cppFile();

    inline void* c_file() { return h; }
    inline cb_cppFileInt is_open() { return (cb_cppFileInt)h; }
    cb_cppFileInt seek(cb_cppFileInt, cb_cppFileInt);
    cb_cppFileInt fseek(cb_cppFileInt, cb_cppFileInt);
    inline cb_cppFileInt seekg(cb_cppFileInt p, cb_cppFileInt n) { return seek(p,n); }
    cb_cppFileInt tell();
    inline cb_cppFileInt tellg() { return tell(); }
    cb_cppFileInt len();
    cb_cppFileLLong seek64(cb_cppFileLLong, cb_cppFileInt);
    cb_cppFileLLong fseek64(cb_cppFileLLong, cb_cppFileInt);
    cb_cppFileLLong tell64();
    cb_cppFileLLong len64();
    inline cb_cppFileInt Read(void*, cb_cppFileInt);
    inline cb_cppFileInt Write(void*, cb_cppFileInt);
    inline cb_cppFileInt read(void* b, cb_cppFileInt n) { return Read(b,n); }
    inline cb_cppFileInt write(void* b, cb_cppFileInt n) { return Write(b,n); }

    enum { SeekBegin, SeekCurrent, SeekEnd };

    enum {
      modeRead
    };
};

#endif  //cb_cppFile_H_
