
#ifndef cb_cppMem_H_
#define cb_cppMem_H_

#ifndef cb_cppMemInt
#define cb_cppMemInt cb_Integer
#endif

class cb_cppMem
{
  protected:
    void *h;
    cb_cppMemInt sze;

  public:
    void free();

    cb_cppMem() { h=NULL; sze=0; };

    ~cb_cppMem() { free(); }

};
#endif  //cb_cppMem_H_
