
#ifndef __cb_cppStringArray_H__
#define __cb_cppStringArray_H__

#include "Collection.h"
#include "String.h"

#ifndef cb_cppStringArrayInt
#define cb_cppStringArrayInt cb_Integer
#endif

class cb_cppStringArray : public cb_cppCollection
{
public:
	cb_cppStringArray();
	cb_cppString& GetAt(cb_cppStringArrayInt);
};

#endif
