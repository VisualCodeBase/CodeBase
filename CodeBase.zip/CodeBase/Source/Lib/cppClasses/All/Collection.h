
#ifndef __cb_cppCollection_H__
#define __cb_cppCollection_H__

#ifndef cb_cppCollectionInt
#define cb_cppCollectionInt cb_Integer
#endif

#ifndef cb_cppCollectionUInt
#define cb_cppCollectionUInt cb_UInteger
#endif

class cb_cppCollection
{
public:
    cb_cppCollection();
    ~cb_cppCollection();
    cb_cppCollectionInt GetSize();
    const void * GetAt(cb_cppCollectionInt);
    const void * PutAt(const void*,cb_cppCollectionInt);
    cb_cppCollectionInt InsertAt(const void*,cb_cppCollectionInt);
    cb_cppCollectionInt Add(const void*);
    cb_cppCollectionInt GetUpperBound();
    void Remove(cb_cppCollectionInt);
    void RemoveAll();

protected:
    const void **Buf;
    cb_cppCollectionInt iCnt;
};

#endif
