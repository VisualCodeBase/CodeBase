
#ifndef cb_cppString_H_
#define cb_cppString_H_

#ifndef cb_cppStringInt
#define cb_cppStringInt cb_Integer
#endif

#ifndef cb_cppStringUInt
#define cb_cppStringUInt cb_UInteger
#endif

#ifndef cb_cppStringChar
#define cb_cppStringChar char // Don't change this!
#endif

#ifndef cb_cppString_MIN_INTEGER
#define cb_cppString_MIN_INTEGER cb_MIN_INTEGER
#endif

class cb_cppString
{
  protected:
    cb_cppStringChar *m_buf;
    cb_cppStringInt m_size;
    cb_cppStringInt m_len;

  //private:

  public:
    cb_cppString& append(const cb_cppStringChar*, cb_cppStringInt);
    inline cb_cppString& append(cb_cppString& str) { return append(str.m_buf,str.m_len); }
    inline cb_cppString& append(const cb_cppStringChar*);
    inline cb_cppString& append(const cb_cppStringChar);
    inline cb_cppString& append(cb_cppStringInt);
    inline cb_cppString& append(double);

    cb_cppString& assign(const cb_cppStringChar*, cb_cppStringInt);
    inline cb_cppString& assign(cb_cppString& str) { return assign(str.m_buf,str.m_len); }
    inline cb_cppString& assign(const cb_cppStringChar*);
    inline cb_cppString& assign(const cb_cppStringChar);
    inline cb_cppString& assign(cb_cppStringInt);
    inline cb_cppString& assign(double);

    cb_cppString(void) { m_buf=NULL; m_size=0; m_len=cb_cppString_MIN_INTEGER; }
    cb_cppString(const cb_cppStringChar* s, cb_cppStringInt n) { m_buf=NULL; m_size=0; assign(s,n); }
    cb_cppString(const cb_cppStringChar* s) { m_buf=NULL; m_size=0; assign(s); }
    cb_cppString(cb_cppString& str) { m_buf=NULL; m_size=0; assign(str); }
    cb_cppString(const cb_cppStringChar c) { m_buf=NULL; m_size=0; assign(c); }
    cb_cppString(cb_cppStringInt val) { m_buf=NULL; m_size=0; assign(val); }
    cb_cppString(double val) { m_buf=NULL; m_size=0; assign(val); }

    void clear(void);

    ~cb_cppString(void) { clear(); }

    inline const cb_cppStringChar* c_str(void) { return m_buf; }
    inline const cb_cppStringChar* strptr(void) { return m_buf; }

    inline cb_cppStringInt length(void) { return m_len; }
    inline cb_cppStringInt GetLength(void) { return m_len; }

    inline operator const cb_cppString*(void) const { return (const cb_cppString*)m_buf; }

    cb_cppString& operator = (cb_cppString& str) { return assign(str); }
    cb_cppString& operator = (const cb_cppStringChar* s) { return assign(s); }
    cb_cppString& operator = (const cb_cppStringChar c) { return assign(c); }
    cb_cppString& operator = (cb_cppStringInt val) { return assign(val); }
    cb_cppString& operator = (double val) { return assign(val); }

    cb_cppString& operator += (cb_cppString& str) { return append(str); }
    cb_cppString& operator += (const cb_cppStringChar* s) { return append(s); }
    cb_cppString& operator += (const cb_cppStringChar c) { return append(c); }
    cb_cppString& operator += (cb_cppStringInt val) { return append(val); }
    cb_cppString& operator += (double val) { return append(val); }

    inline cb_cppStringInt cmpcase(const cb_cppStringChar*);
    inline cb_cppStringInt cmpcase(cb_cppString&);
    cb_cppStringInt cmpcase(cb_cppStringChar);
    cb_cppStringInt cmpcase(cb_cppStringInt);
    cb_cppStringInt cmpcase(double);

    inline cb_cppStringInt cmpnocase(const cb_cppStringChar*);
    inline cb_cppStringInt cmpnocase(cb_cppString&);
    cb_cppStringInt cmpnocase(cb_cppStringChar);
    cb_cppStringInt cmpnocase(cb_cppStringInt);
    cb_cppStringInt cmpnocase(double);

    cb_cppStringInt FindAt(const cb_cppStringChar*,cb_cppStringInt);
    cb_cppStringInt FindAt(cb_cppStringInt,cb_cppStringInt);
    inline cb_cppStringInt Find(const cb_cppStringChar* s) { return FindAt(s,0); }
    inline cb_cppStringInt Find(cb_cppString& s) { return FindAt(s.m_buf,0); }
    inline cb_cppStringInt Find(cb_cppStringInt c) { return FindAt(c,0); }
    //inline cb_cppStringInt FindAt(cb_cppString& s,cb_cppStringInt n) { return FindAt(s.m_buf,n); }
    inline cb_cppStringInt Find(cb_cppString& s,cb_cppStringInt n) { return FindAt(s.m_buf,n); }
    cb_cppStringInt FindNoCaseAt(const cb_cppStringChar*,cb_cppStringInt);
    cb_cppStringInt FindNoCaseAt(cb_cppStringInt,cb_cppStringInt);
    inline cb_cppStringInt FindNoCase(const cb_cppStringChar* s) { return FindNoCaseAt(s,0); }
    inline cb_cppStringInt FindNoCase(cb_cppString& s) { return FindNoCaseAt(s.m_buf,0); }
    inline cb_cppStringInt FindNoCase(cb_cppStringInt c) { return FindNoCaseAt(c,0); }
    inline cb_cppStringInt FindNoCaseAt(cb_cppString& s,cb_cppStringInt n) { return FindNoCaseAt(s.m_buf,n); }

    inline cb_cppString& MakeLower(void);
    inline cb_cppString& MakeUpper(void);

    cb_cppStringChar& getat(cb_cppStringUInt);

    cb_cppStringChar& putat(cb_cppStringChar, cb_cppStringUInt, cb_cppStringUInt=-1);
    cb_cppString& putat(cb_cppStringChar*, cb_cppStringUInt, cb_cppStringUInt=-1);

    cb_cppStringInt getlineat(cb_cppStringChar*, cb_cppStringUInt=0);

    inline cb_cppStringChar& operator [] (cb_cppStringUInt n) { return getat(n); }

    cb_cppString& Mid(cb_cppStringUInt, cb_cppStringInt=-1);
    inline cb_cppString& Left(cb_cppStringInt n) { return Mid(0,n); }
    inline cb_cppString& Right(cb_cppStringInt);
    inline cb_cppString& substr(cb_cppStringUInt s, cb_cppStringInt n) { return Mid(s,n); }

    friend cb_cppString& operator + (cb_cppString&, cb_cppString&);
    friend cb_cppString& operator + (cb_cppString&, const cb_cppStringChar*);
    friend cb_cppString& operator + (cb_cppString&, cb_cppStringChar);
    friend cb_cppString& operator + (cb_cppString&, cb_cppStringInt);
    friend cb_cppString& operator + (cb_cppString&, double);
    friend cb_cppString& operator + (const cb_cppStringChar*, cb_cppString&);
    friend cb_cppString& operator + (cb_cppStringChar, cb_cppString&);
    friend cb_cppString& operator + (cb_cppStringInt, cb_cppString&);
    friend cb_cppString& operator + (double, cb_cppString&);
    friend cb_cppStringInt operator == (const cb_cppStringChar* s, cb_cppString& str) { return !str.cmpcase(s); }
    friend cb_cppStringInt operator == (cb_cppString& str, const cb_cppStringChar* s) { return !str.cmpcase(s); }
    friend cb_cppStringInt operator == (cb_cppString& str1, cb_cppString& str2) { return !str1.cmpcase(str2); }
    friend cb_cppStringInt operator != (const cb_cppStringChar* s, cb_cppString& str) { return str.cmpcase(s); }
    friend cb_cppStringInt operator != (cb_cppString& str, const cb_cppStringChar* s) { return str.cmpcase(s); }
    friend cb_cppStringInt operator != (cb_cppString& str1, cb_cppString& str2) { return str1.cmpcase(str2); }
    friend cb_cppStringInt operator == (const cb_cppStringChar c, cb_cppString& str) { return !str.cmpcase(c); }
    friend cb_cppStringInt operator == (cb_cppStringInt val, cb_cppString& str) { return !str.cmpcase(val); }
    friend cb_cppStringInt operator == (double val, cb_cppString& str) { return !str.cmpcase(val); }
    friend cb_cppStringInt operator == (cb_cppString& str, const cb_cppStringChar c) { return !str.cmpcase(c); }
    friend cb_cppStringInt operator == (cb_cppString& str, cb_cppStringInt val) { return !str.cmpcase(val); }
    friend cb_cppStringInt operator == (cb_cppString& str, double val) { return !str.cmpcase(val); }
    friend cb_cppStringInt operator != (const cb_cppStringChar c, cb_cppString& str) { return str.cmpcase(c); }
    friend cb_cppStringInt operator != (cb_cppStringInt val, cb_cppString& str) { return str.cmpcase(val); }
    friend cb_cppStringInt operator != (double val, cb_cppString& str) { return str.cmpcase(val); }
    friend cb_cppStringInt operator != (cb_cppString& str, const cb_cppStringChar c) { return str.cmpcase(c); }
    friend cb_cppStringInt operator != (cb_cppString& str, cb_cppStringInt val) { return str.cmpcase(val); }
    friend cb_cppStringInt operator != (cb_cppString& str, double val) { return str.cmpcase(val); }
};

EXTERN_C cb_cppString& cb_cppString_NewTmp(const cb_cppStringChar* =(const cb_cppStringChar*)1); // this is for garbage collection. the operator +, and Left/Mid/Right use it.
EXTERN_C void cb_cppString_Terminate(void); // this should be called only after all the instances of the class were deleted. on app close all memory is anyway freed by the OS.

#ifdef cb_cppString_StrPtr
#define cb_cppString_StrPtr(x) (x).strptr()
#define cb_cppString_StrLen(x) (x).length()
#define cb_cppString_NewTmpStr(x) cb_cppString_NewTmp(x)
#endif

#endif  //cb_cppString_H_
