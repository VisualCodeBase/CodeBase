
#ifndef _eel_match_c_
#define _eel_match_c_

static int eel_string_match(void *opaque, const char *fmt, const char *msg, int match_fmt_pos, int ignorecase, const char *fmt_endptr, const char *msg_endptr, int num_fmt_parms, EEL_F **fmt_parms)
{
  // check for match, updating EEL_STRING_GETFMTVAR(*) as necessary
  // %d=12345
  // %f=12345[.678]
  // %c=any nonzero char, ascii value
  // %x=12354ab
  // %*, %?, %+, %% literals
  // * ? +  match minimal groups of 0+,1, or 1+ chars
  for (;;)
  {
    if (fmt>=fmt_endptr)
    {
      if (msg>=msg_endptr) return 1;
      return 0; // format ends before matching string
    }

    // if string ends and format is not on a wildcard, early-out to 0
    if (msg>=msg_endptr && *fmt != '*' && *fmt != '%') return 0;

    switch (*fmt)
    {
      case '*':
      case '+':
        // if last char of search pattern, we're done!
        if (fmt+1>=fmt_endptr || (fmt[1] == '?' && fmt+2>=fmt_endptr)) return *fmt == '*' || msg<msg_endptr;

        if (fmt[0] == '+')  msg++; // skip a character for + . Note that in this case msg[1] is valid, because of the !*msg && *fmt != '*' check above

        fmt++;
        if (*fmt == '?')
        {
          // *? or +? are lazy matches
          fmt++;

          while (msg<msg_endptr && !eel_string_match(opaque,fmt,msg,match_fmt_pos,ignorecase,fmt_endptr,msg_endptr,num_fmt_parms,fmt_parms)) msg++;
          return msg<msg_endptr;
        }
        else
        {
          // greedy match
          int len = (int) (msg_endptr-msg);
          while (len >= 0 && !eel_string_match(opaque,fmt,msg+len,match_fmt_pos,ignorecase,fmt_endptr,msg_endptr,num_fmt_parms,fmt_parms)) len--;
          return len >= 0;
        }
      break;
      case '?':
        fmt++;
        msg++;
      break;
      case '%':
        {
          fmt++;
          unsigned short fmt_minlen = 1, fmt_maxlen = 0;
          if (*fmt >= '0' && *fmt <= '9')
          {
            fmt_minlen = *fmt++ - '0';
            while (*fmt >= '0' && *fmt <= '9') fmt_minlen = fmt_minlen * 10 + (*fmt++ - '0');
            fmt_maxlen = fmt_minlen;
          }
          if (*fmt == '-')
          {
            fmt++;
            fmt_maxlen = 0;
            while (*fmt >= '0' && *fmt <= '9') fmt_maxlen = fmt_maxlen * 10 + (*fmt++ - '0');
          }
          const char *dest_varname=NULL;
          if (*fmt == '{')
          {
            dest_varname=++fmt;
            while (*fmt && fmt < fmt_endptr && *fmt != '}') fmt++;
            if (fmt >= fmt_endptr-1 || *fmt != '}') return 0; // malformed %{var}s
            fmt++; // skip '}'
          }

          char fmt_char = *fmt++;
          if (!fmt_char) return 0; // malformed

          if (fmt_char == '*' ||
              fmt_char == '?' ||
              fmt_char == '+' ||
              fmt_char == '%')
          {
            if (*msg++ != fmt_char) return 0;
          }
          else if (fmt_char == 'c')
          {
            EEL_F *varOut = NULL;
            EEL_F vv=0.0;
            if (!dest_varname)
            {
              if (match_fmt_pos < num_fmt_parms) varOut = fmt_parms[match_fmt_pos];
#ifdef EEL_STRING_GETFMTVAR
              if (!varOut) varOut = EEL_STRING_GETFMTVAR(match_fmt_pos);
#endif
              match_fmt_pos++;
            }
            else
            {
#ifdef EEL_STRING_GETNAMEDVAR
              char tmp[128];
              int idx=0;
              while (dest_varname < fmt_endptr && *dest_varname && *dest_varname != '}' && idx<(int)sizeof(tmp)-1) tmp[idx++] = *dest_varname++;
              tmp[idx]=0;
              if (idx>0) varOut = EEL_STRING_GETNAMEDVAR(tmp,1,&vv);
#endif
            }
            if (msg >= msg_endptr) return 0; // out of chars

            if (varOut)
            {
              #if 0
              if (varOut == &vv) // %{#foo}c
              {
                EEL_STRING_STORAGECLASS *wr=NULL;
                EEL_STRING_GET_FOR_WRITE(vv, &wr);
                if (wr) wr->Set(msg,1);
              }
              else
              #endif
              {
                *varOut = (EEL_F)*(unsigned char *)msg;
              }
            }
            msg++;
          }
          else
          {
            int len=0;
            int lazy=0;
            if (fmt_char>='A'&&fmt_char<='Z') { lazy=1; fmt_char += 'a' - 'A'; }

            if (fmt_char == 's')
            {
              len = (int) (msg_endptr-msg);
            }
            else if (fmt_char == 'x')
            {
              while ((msg[len] >= '0' && msg[len] <= '9') ||
                     (msg[len] >= 'A' && msg[len] <= 'F') ||
                     (msg[len] >= 'a' && msg[len] <= 'f')) len++;
            }
            else if (fmt_char == 'f')
            {
              if (msg[len] == '-') len++;
              while (msg[len] >= '0' && msg[len] <= '9') len++;
              if (msg[len] == '.')
              {
                len++;
                while (msg[len] >= '0' && msg[len] <= '9') len++;
              }
            }
            else if (fmt_char == 'd' || fmt_char == 'u' || fmt_char == 'i')
            {
              if (fmt_char != 'u' && msg[len] == '-') len++;
              while (msg[len] >= '0' && msg[len] <= '9') len++;
            }
            else
            {
              // bad format
              return 0;
            }

            if (fmt_maxlen>0 && len > fmt_maxlen) len = fmt_maxlen;

            if (!dest_varname) match_fmt_pos++;

            if (lazy)
            {
              if (fmt_maxlen<1 || fmt_maxlen>len) fmt_maxlen=len;
              len=fmt_minlen;
              while (len <= fmt_maxlen && !eel_string_match(opaque,fmt,msg+len,match_fmt_pos,ignorecase,fmt_endptr,msg_endptr,num_fmt_parms,fmt_parms)) len++;
              if (len > fmt_maxlen) return 0;
            }
            else
            {
              while (len >= fmt_minlen && !eel_string_match(opaque,fmt,msg+len,match_fmt_pos,ignorecase,fmt_endptr,msg_endptr,num_fmt_parms,fmt_parms)) len--;
              if (len < fmt_minlen) return 0;
            }

            EEL_F vv=0.0;
            EEL_F *varOut = NULL;
            if (!dest_varname)
            {
              if (match_fmt_pos>0 && match_fmt_pos/*-1*/ <= num_fmt_parms) varOut = fmt_parms[match_fmt_pos-1]; ////-1
#ifdef EEL_STRING_GETFMTVAR
              if (!varOut) varOut = EEL_STRING_GETFMTVAR(match_fmt_pos-1);
#endif
            }
            else
            {
#ifdef EEL_STRING_GETNAMEDVAR
              char tmp[128];
              int idx=0;
              while (dest_varname < fmt_endptr && *dest_varname  && *dest_varname != '}' && idx<(int)sizeof(tmp)-1) tmp[idx++] = *dest_varname++;
              tmp[idx]=0;
              if (idx>0) varOut = EEL_STRING_GETNAMEDVAR(tmp,1,&vv);
#endif
            }
            if (varOut)
            {
              if (fmt_char == 's')
              {
                EEL_STRING_STORAGECLASS wr_, *wr/*=NULL*/;
                wr = EEL_STRING_GET_FOR_WRITE(*varOut, &wr_);
                if (wr)
                {
                  if (msg_endptr >= wr->Get() && msg_endptr <= wr->Get() + wr->GetLength())
                  {
#ifdef EEL_STRING_DEBUGOUT
                    EEL_STRING_DEBUGOUT("match: destination specifier passed is also haystack, will not update");
#endif
                  }
                  else if (fmt_endptr >= wr->Get() && fmt_endptr <= wr->Get() + wr->GetLength())
                  {
#ifdef EEL_STRING_DEBUGOUT
                    EEL_STRING_DEBUGOUT("match: destination specifier passed is also format, will not update");
#endif
                  }
                  else
                  {
                    wr->SetRaw(msg,len);
                  }
                }
                else
                {
#ifdef EEL_STRING_DEBUGOUT
                   EEL_STRING_DEBUGOUT("match: bad destination specifier passed as %d: %f",match_fmt_pos,*varOut);
#endif
                }
              }
              else
              {
                char tmp[128];
                lstrcpyn_safe(tmp,msg,wdl_min(len+1,(int)sizeof(tmp)));
#if 0
                if (varOut == &vv)
                {
                  EEL_STRING_STORAGECLASS *wr=NULL;
                  EEL_STRING_GET_FOR_WRITE(vv, &wr);
                  if (wr) wr->Set(tmp);
                }
                else
#endif
                {
                  char *bl=(char*)msg;
                  if (fmt_char == 'u')
                    *varOut = (EEL_F)strtoul(tmp,&bl,10);
                  else if (fmt_char == 'x')
                    *varOut = (EEL_F)strtoul(msg,&bl,16);
                  else
                    *varOut = (EEL_F)atof(tmp);
                }
              }
            }
            return 1;
          }
        }
      break;
      default:
        if (ignorecase ? (toupper(*fmt) != toupper(*msg)) : (*fmt!= *msg)) return 0;
        fmt++;
        msg++;
      break;
    }
  }
}


#if 0
static EEL_F NSEEL_CGEN_CALL _eel_match(void *opaque, INT_PTR num_parms, EEL_F **parms)
{
  if (opaque && num_parms >= 2)
  {
    EEL_STRING_MUTEXLOCK_SCOPE
    EEL_STRING_STORAGECLASS *fmt_wr=NULL, *msg_wr=NULL;
    const char *fmt = EEL_STRING_GET_FOR_INDEX(*(parms[0]),&fmt_wr);
    const char *msg = EEL_STRING_GET_FOR_INDEX(*(parms[1]),&msg_wr);

    if (fmt && msg) return eel_string_match(opaque,fmt,msg,0,0, fmt + (fmt_wr?fmt_wr->GetLength():strlen(fmt)), msg + (msg_wr?msg_wr->GetLength():strlen(msg)),(int)num_parms-2,parms+2) ? 1.0 : 0.0;
  }
  return 0.0;
}
static EEL_F NSEEL_CGEN_CALL _eel_matchi(void *opaque, INT_PTR num_parms, EEL_F **parms)
{
  if (opaque && num_parms >= 2)
  {
    EEL_STRING_MUTEXLOCK_SCOPE
    EEL_STRING_STORAGECLASS *fmt_wr=NULL, *msg_wr=NULL;
    const char *fmt = EEL_STRING_GET_FOR_INDEX(*(parms[0]),&fmt_wr);
    const char *msg = EEL_STRING_GET_FOR_INDEX(*(parms[1]),&msg_wr);

    if (fmt && msg) return eel_string_match(opaque,fmt,msg,0,1, fmt + (fmt_wr?fmt_wr->GetLength():strlen(fmt)), msg + (msg_wr?msg_wr->GetLength():strlen(msg)),(int)num_parms-2,parms+2) ? 1.0 : 0.0;
  }
  return 0.0;
}
#endif

#endif
