
#ifndef _eel_getsetchar_h_
#define _eel_getsetchar_h_

#define EEL_GETCHAR_FLAG_ENDIANSWAP 0x10
#define EEL_GETCHAR_FLAG_UNSIGNED 0x20
#define EEL_GETCHAR_FLAG_FLOAT 0x40
static int eel_getchar_flag(int type)
{
#ifdef __ppc__
  int ret=EEL_GETCHAR_FLAG_ENDIANSWAP; // default to LE
#else
  int ret=0;
#endif

  if (toupper((type>>8)&0xff) == 'U') ret|=EEL_GETCHAR_FLAG_UNSIGNED;
  else if (type>255 && toupper(type&0xff) == 'U') { ret|=EEL_GETCHAR_FLAG_UNSIGNED; type>>=8; }
  type&=0xff;

  if (isupper(type)) ret^=EEL_GETCHAR_FLAG_ENDIANSWAP;
  else type += 'A'-'a';

  switch (type)
  {
    case 'F': return ret|4|EEL_GETCHAR_FLAG_FLOAT;
    case 'D': return ret|8|EEL_GETCHAR_FLAG_FLOAT;
    case 'S': return ret|2;
    case 'I': return ret|4;
  }

  return ret|1;
}

static void eel_setchar_do(int flag, char *dest, EEL_F val)
{
  union
  {
    char buf[8];
    float asFloat;
    double asDouble;
    int asInt;
    short asShort;
    char asChar;
    unsigned int asUInt;
    unsigned short asUShort;
    unsigned char asUChar;
  } a;
  const int type_sz=flag&0xf;

  if (flag & EEL_GETCHAR_FLAG_FLOAT)
  {
    if (type_sz==8) a.asDouble=val;
    else a.asFloat=(float)val;
  }
  else if (flag & EEL_GETCHAR_FLAG_UNSIGNED)
  {
    if (type_sz==4) a.asUInt=(unsigned int)val;
    else if (type_sz==2) a.asUShort=(unsigned short)val;
    else a.asUChar=(unsigned char)val;
  }
  else if (type_sz==4) a.asInt=(int)val;
  else if (type_sz==2) a.asShort=(short)val;
  else a.asChar=(char)val;

  if (flag & EEL_GETCHAR_FLAG_ENDIANSWAP)
  {
    dest += type_sz;
    int x;
    for(x=0;x<type_sz;x++) *--dest=a.buf[x];
  }
  else
    memcpy(dest,a.buf,type_sz);

}


static EEL_F eel_getchar_do(int flag, const char *src)
{
  union
  {
    char buf[8];
    float asFloat;
    double asDouble;
    int asInt;
    short asShort;
    char asChar;
    unsigned int asUInt;
    unsigned short asUShort;
    unsigned char asUChar;
  } a;
  const int type_sz=flag&0xf;

  memset(&a, 0, sizeof(a));
  if (flag & EEL_GETCHAR_FLAG_ENDIANSWAP)
  {
    src += type_sz;
    int x;
    for(x=0;x<type_sz;x++) a.buf[x]=*--src;
  }
  else
    memcpy(a.buf,src,type_sz);

  if (flag & EEL_GETCHAR_FLAG_FLOAT)
  {
    if (type_sz==8) return a.asDouble;
    return a.asFloat;
  }
  if (flag & EEL_GETCHAR_FLAG_UNSIGNED)
  {
    if (type_sz==4) return a.asUInt;
    if (type_sz==2) return a.asUShort;
    return a.asUChar;
  }
  if (type_sz==4) return a.asInt;
  if (type_sz==2) return a.asShort;
  return a.asChar;
}

#endif
