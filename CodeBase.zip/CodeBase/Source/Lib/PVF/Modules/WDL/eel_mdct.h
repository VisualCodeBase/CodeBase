#ifndef EEL_MDCT_H_
#define EEL_MDCT_H_

#ifdef _WIN64
#define int long long
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern EEL_F *mdct_func(int,EEL_F *,int);

#ifdef __cplusplus
};
#endif

#ifdef pvf_LIBRARY
#include "mdct.c"
#else
#include "eel_mdct.c"
#endif

#ifdef _WIN64
#undef int
#endif

#endif
