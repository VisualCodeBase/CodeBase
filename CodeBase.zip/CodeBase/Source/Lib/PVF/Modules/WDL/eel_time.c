#ifndef _EEL_TIME_C_
#define _EEL_TIME_C_


#ifndef _WIN32
#include <sys/time.h>
#endif
#include <time.h>
// some generic EEL functions for things like time

static EEL_F/* * NSEEL_CGEN_CALL*/ _eel_time(/*void *opaque, */EEL_F *v)
{
  EEL_F f = (EEL_F) time(NULL);
  if (v) *v = f;
  return f;
}

static EEL_F/* * NSEEL_CGEN_CALL*/ _eel_time_precise(/*void *opaque, */EEL_F *v)
{
  EEL_F f;
#ifdef _WIN32
  LARGE_INTEGER freq,now;
  QueryPerformanceFrequency(&freq);
  QueryPerformanceCounter(&now);
  f = (double)now.QuadPart / (double)freq.QuadPart;
  // *v = (EEL_F)timeGetTime() * 0.001;
#else
  struct timeval tm={0,};
  gettimeofday(&tm,NULL);
  f = tm.tv_sec + tm.tv_usec*0.000001;
#endif
  if (v) *v = f;
  return f;
}


#ifdef EEL_WANT_DOCUMENTATION
static const char *eel_misc_function_reference =
#ifndef EEL_MISC_NO_SLEEP
  "sleep\tms\tYields the CPU for the millisecond count specified, calling Sleep() on Windows or usleep() on other platforms.\0"
#endif
  "time\t[&val]\tSets the parameter (or a temporary buffer if omitted) to the number of seconds since January 1, 1970, and returns a reference to that value. "
  "The granularity of the value returned is 1 second.\0"
  "time_precise\t[&val]\tSets the parameter (or a temporary buffer if omitted) to a system-local timestamp in seconds, and returns a reference to that value. "
  "The granularity of the value returned is system defined (but generally significantly smaller than one second).\0"
;
#endif


#endif
