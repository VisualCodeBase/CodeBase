
/*static */EEL_F * /*NSEEL_CGEN_CALL  */eel_mdct(/*EEL_F **blocks, */EEL_F *start, /*EEL_F **/int length)
{
  return mdct_func(0/*, blocks*/, start, length);
}

/*static */EEL_F * /*NSEEL_CGEN_CALL  */eel_imdct(/*EEL_F **blocks, */EEL_F *start, /*EEL_F **/int length)
{
  return mdct_func(-1/*, blocks*/, start, length);
}
