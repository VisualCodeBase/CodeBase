
#ifndef EEL_FFT_H_
#define EEL_FFT_H_

#ifdef _WIN64
#define int long long
#endif

/*#ifdef __cplusplus
extern "C" {
#endif

extern EEL_F *eel_fft(EEL_F *start, int length);
extern EEL_F *eel_ifft(EEL_F *start, int length);
extern EEL_F *eel_fft_real(EEL_F *start, int length);
extern EEL_F *eel_ifft_real(EEL_F *start, int length);
extern EEL_F *eel_fft_permute(EEL_F *start, int length);
extern EEL_F *eel_ifft_permute(EEL_F *start, int length);
extern EEL_F *eel_convolve_c(EEL_F *dest, EEL_F *src, int length);
extern void EEL_fft_register(void);

#ifdef __cplusplus
};
#endif*/

#define WDL_FFT_REALSIZE EEL_F_SIZE

#ifdef pvf_LIBRARY
#include "fft.c"
#else
#include "fft.h"
#include "eel_fft.c"
#endif

#ifdef _WIN64
#undef int
#endif

#endif
