
#pragma pack(1)
// The format chunk of a wave file
typedef struct {
  char chunkID[4];        // String: must be "fmt " (0x666D7420).
  unsigned cbDataSize;      // Unsigned 4-byte little endian int: Byte count for the remainder of the chunk: 16 + extraFormatbytes.
  unsigned short FormatTag;    // Unsigned 2-byte little endian int
  unsigned short nChannels;    // Unsigned 2-byte little endian int
  unsigned sampleRate;        // Unsigned 4-byte little endian int
  unsigned avgBytesPerSecond;  // Unsigned 4-byte little endian int: This value indicates how many bytes of wave data must be streamed to a D/A converter per second in order to play the wave file. This information is useful when determining if data can be streamed from the source fast enough to keep up with playback. = SampleRate * BlockAlign.
  unsigned short blockAlign;        // Unsigned 2-byte little endian int: The number of bytes per sample slice. This value is not affected by the number of channels and can be calculated with the formula: blockAlign = BitsPerSample / 8 * nChannels
  unsigned short BitsPerSample;// Unsigned 2-byte little endian int
} WaveFormatChunk;
#pragma pack()
