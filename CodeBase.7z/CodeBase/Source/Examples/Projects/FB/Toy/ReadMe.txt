
we created container (vb module), wrote few settings and included the original toy.

this way the required manual changes to the original source close to zero,
and we'll try to reduce them even more.

the original file (Modules/Toy.bas) modified a little, by adding one byref,
instead of using default byref for all functions arguments (option byref).

as you see it compiles with no error at all.

Unfortunately this project still doesn't run correctly under codebase compiling. we'll investigate and fix.
