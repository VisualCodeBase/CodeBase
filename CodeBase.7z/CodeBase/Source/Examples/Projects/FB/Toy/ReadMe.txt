
the original file (Modules/Toy.bas) was not modified at all!
we created containter (vb module), wrote few settings and included the original toy.

as you see it compiles without any error except two, which will be fixed soon.

except of this all boolean + string expressions should work correct.
