/*    CodeBase - Compiler Frontend To C++ - (Version 1.00)    */
/*    Copyright � SoftBase Labs.  MIT    */

//CommandLine:
//-c Toy

#define __CODEBASE__
#if defined(__GNUC__) || defined(__GNUG__)
#define _NO_OLDNAMES
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0502
#endif
#ifndef _WIN32_IE
#define _WIN32_IE 0x0502
#endif
#ifndef WINVER
#define WINVER 0x0502
#endif
#else

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif
#ifndef _WIN32_IE
#define _WIN32_IE 0x0600
#endif
#ifndef WINVER
#define WINVER 0x0600
#endif
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ctype.h>
#include <fcntl.h>
#ifdef _MSC_VER
#define _USE_MATH_DEFINES
#endif
#include <math.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <wctype.h>
#include <sys/stat.h>
#include <conio.h>
#include <direct.h>
#include <io.h>
#ifdef cb_USE_COM
#include <shellapi.h>
#include <objbase.h>
#include <oaidl.h>
#include <shlobj.h>
#endif
#include <wchar.h>
#if defined(__GNUC__) || defined(__GNUG__) || defined(__clang__)
#endif

/*-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-*/
#include <CodeBase.h>
/*-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-*/

#define cb_End exit
#define cb_OnEnd atexit
#define cb_IsAlpha isalpha
#define cb_IsAlphaW iswalpha
#define cb_IsDigit isdigit
#define cb_IsDigitW iswdigit
#define cb_IsAlphaDigit isalnum
#define cb_IsAlphaDigitW iswalnum
#define cb_IsSpace isspace
#define cb_IsSpaceW iswspace
#define cb_IsLower islower
#define cb_IsLowerW iswlower
#define cb_IsUpper isupper
#define cb_IsUpperW iswupper
#define cb_IsSpace isspace
#define cb_IsSpaceW iswspace
#define cb_MemComp memcmp
#define cb_MemChr memchr
#define cb_MemChrW wmemchr
#define cb_MemSet memset
#define cb_MemSetW wmemset
#define cb_MemCopy memcpy
#define cb_MemCopyW wmemcpy
#define cb_MemMove memmove
#define cb_MemMoveW wmemmove
#define cb_StrLen strlen
#define cb_StrLenW wcslen
#define cb_AtoL atol
#define cb_AtoF(x,y) strtof(x,y)
#define cb_AtoD(x,y) strtod(x,y)
#define cb_AtoLD(x,y) strtold(x,y)
#define cb_Ceil ceil
#define cb_Ceilf ceilf
#define cb_Ceill ceill
#define cb_Floor floor
#define cb_Floorf floorf
#define cb_Floorl floorl
#define cb_FMod fmod
#define cb_FModf fmodf
#define cb_FModl fmodl
#define cb_ModF modf
#define cb_ModFf modff
#define cb_ModFl modfl
#define cb_Pow pow
#define cb_Powf powf
#define cb_Powl powl
#define cb_Trunc trunc
#define cb_Truncf truncf
#define cb_Truncl truncl
#define cb_SQR(x,y) pow(x,(double)1.0/(double)(y))
#define cb_SQRF(x,y) powf(x,(float)1.0/(float)(y))
#define cb_SQRLD(x,y) powl(x,(long double)1.0/(long double)(y))
#define cb_Rand rand
#define cb_Randomize srand
#define cb_ChDir _chdir
#define cb_ChDrive _chdrive
#define cb_ChMod _chmod
#define cb_GetDrive _getdrive
#define cb_MkDir _mkdir
#define cb_RmDir _rmdir
#define cb_Remove remove
#define cb_RemoveW wremove
#define cb_Rename !rename
#define cb_RenameW !wrename
#define cb_FilePrintF cb_fprintf
#define cb_SPrintFW cb_snwprintf
#define cb_INT(x) ((cb_Integer)cb_Floor(x))
#define cb_CLEAR1(x) cb_MemSet(&(x),0,sizeof(x))
cb_BeginExternC
EXTERN_C cb_Integer  cbApp_Argc;
EXTERN_C char**  cbApp_Argv;
EXTERN_C structcbApp_Error  cbApp_Error;
EXTERN_C char  *cb_TmpDynStrPtrBuf_ [cb_MAX_TMPDYNSTR_CYCLES_];
EXTERN_C cb_Integer  cb_TmpDynStrCyclesMax_;
EXTERN_C cb_Integer  cb_TmpDynStrCyclesFlag;
EXTERN_C cb_Integer  cb_TmpDynStrCyclesCnt_;
EXTERN_C char  cb_PrintBoxBuffer[64 * 0x400];
EXTERN_C char  *cb_CommandLinePtr;
EXTERN_C cb_FIND_DATA  cbApp_FindData;
EXTERN_C cb_File*  cb_StdIn;
EXTERN_C cb_File*  cb_StdErr;
EXTERN_C cb_File*  cb_StdOut;
cb_EndExternC
cb_BeginExternC
char*  cb_DEFCALL  cb_StrMove (void*,const void*);
cb_Integer  cb_CDECL  cb_StrComp (const void*, const void*);
char*  cb_CDECL  cb_StrJoin (void*, ...);
char*  cb_DEFCALL  cb_UCaseX (const char*,void* =NULL,cb_Integer=-1,cb_Integer=-1);
char*  cb_DEFCALL  cb_UCase (const char*,void* =NULL);
char*  cb_DEFCALL  cb_RTrimX (const void*,void* =NULL,cb_Integer=32,cb_Integer=-1,cb_Integer=-1);
char*  cb_DEFCALL  cb_RTrim (const void*,void* =NULL);
char*  cb_DEFCALL  cb_Chr (cb_Integer,void* =NULL);
char*  cb_DEFCALL  cb_CStrDbl (double, void* =NULL, cb_Integer=-1);
cb_Integer  cb_DEFCALL  cb_FileClose (cb_File*);
void  cb_FileInitialize (void);
cb_Integer  cb_DEFCALL  cb_FileFlush (cb_File*);
cb_Integer  cb_DEFCALL  cb_FileEOF (cb_File*);
cb_Integer  cb_DEFCALL  cb_FileError (cb_File*);
cb_Integer  cb_DEFCALL  cb_FileClearError (cb_File*);
cb_File*  cb_DEFCALL  cb_TempFile (const char* =NULL,const char* =cb_EMPTYSTR,const char* =NULL,cb_Integer=-1^_O_APPEND);
cb_File*  cb_DEFCALL  cb_FileOpen (const void* =NULL, cb_Integer=-1, cb_Integer=0);
cb_File*  cb_DEFCALL  cb_FOpen (const void* =NULL, const char* =NULL, cb_Integer=0);
cb_UInteger  cb_DEFCALL  cb_FileTell (cb_File*);
cb_UInteger  cb_DEFCALL  cb_FileRead (cb_File*, void*, cb_UInteger);
cb_UInteger  cb_DEFCALL  cb_FileWrite (cb_File*, const void*, cb_UInteger);
cb_Integer  cb_DEFCALL  cb_FilePutS (cb_File*, const char*);
void*  cb_DEFCALL  cb_FileHandle (cb_File*);
cb_Integer  cb_DEFCALL  cb_FileGetS (cb_File*, char*, cb_Integer);
char*  cb_DEFCALL  cb_FGetS (cb_File*, char*, cb_Integer);
cb_UInteger  cb_DEFCALL  cb_FileSeek (cb_File*, cb_UInteger=0, cb_Integer=SEEK_SET);
cb_Integer  cb_DEFCALL  cb_FSeek (cb_File*, cb_UInteger=0, cb_Integer=SEEK_SET);
char *  cb_DEFCALL  cb_FStrGet (cb_File* =(cb_File*)-1,void* =NULL,void* =NULL,cb_Integer=cb_STRING_SIZE);
void  cb_DEFCALL  cb_Wait (const char* =NULL);
char*  cb_DEFCALL  cb_Command (cb_Integer=-1,void* =NULL,cb_Integer=0);
char*  cb_DEFCALL  cb_TempFileName (const char* =NULL,const char* ="tmp",const char* =NULL,void* =NULL);
char*  cb_DEFCALL  cb_GenErrorMsg (const char*,cb_Integer=0,void* =NULL);
char **  cb_DEFCALL  cb_CommandLineToArgvA (cb_Integer* =NULL,void* =NULL,void* =NULL);
cb_Integer  cb_DEFCALL  cb_vsnprintf (char*,cb_UInteger,const char*,void*,void* =NULL);
cb_Integer  cb_CDECL  cb_snprintf (char*,cb_UInteger,const char*,...);
cb_Integer  cb_DEFCALL  cb_vsprintf (char*,const char*,void*,void* =NULL);
cb_Integer  cb_CDECL  cb_SPrintF (char*,const char*,...);
cb_Integer  cb_DEFCALL  cb_vsscanf (const char*,const char*,void*);
cb_Integer  cb_CDECL  cb_SScanF (const char*,const char*,...);
cb_Integer  cb_DEFCALL  cb_PutS (const char*);
void  cb_DEFCALL  cb_Abort (cb_Integer=cb_ABORT_EXIT_CODE,const char* =NULL);
cb_EndExternC
#include "C:/Programs/Win32/CodeBase/Include/vb_Def.h"
#include <cEachFile.h>
#include "C:/Programs/Win32/CodeBase/Source/Lib/Classes/All/EachFile/cEachFile.h"
#include <cString.h>
#include "C:/Programs/Win32/CodeBase/Source/Lib/Classes/All/String/cString.h"

enum {
 id_Module1 = 1
};

static cb_File* cb_Handle1;
EXTERN_C cb_Integer cb_vfprintf (cb_File*,const char *,void*);
EXTERN_C cb_Integer cb_CDECL cb_fprintf (cb_File*,const char *,...);
EXTERN_C cb_Integer cb_CDECL cb_PrintF (const char *,...);
EXTERN_C cb_Integer cb_vfscanf (cb_File*,const char *,void*);
EXTERN_C cb_Integer cb_CDECL cb_fscanf (cb_File*,const char *,...);
EXTERN_C cb_Integer cb_CDECL cb_ScanF (const char *,...);
EXTERN_C char cb_PrintFBuf_[(64*0x400<<1)];
char* cur_line;
char* cur_ch;
short sym;
char* token;
short cur_col;
short cur_line_num;
short error_line;
short error_col;
short sym_tab_used;
long data_index;
long code_index;
long data_size;
Key_words key_words_tab[1 + MAX_KEYWORDS];
Symbol_table sym_tab[1 + MAX_SYMTAB];
long code_arr[1 + MAX_CODE];
static void Module1_Initialize (void);
static void Module1_Terminate (void);
#define Module1_Create Module1_Initialize
#define Module1_Destroy Module1_Terminate
void cbApp_Terminate (void);
void cbApp_Initialize (void);

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Declarations -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */

/*((((((((((((((  Implementation  ))))))))))))))*/
cb_Integer cb_DEFCALL cb_FilePutS (cb_File* T, const char *b)
{
  register cb_Integer i = cb_StrLen(b);
  if (i>0) if (cb_FileWrite(T,b,i)!=i) i = -1;
  return i;
}
/* MODULE::cb_vfprintf */


cb_Integer cb_vfprintf (cb_File* f,const char * Str1,void* arg)
{
 #define Buf cb_PrintFBuf_
 register cb_Integer i; i = cb_vsnprintf(Buf,sizeof(Buf),Str1,arg,NULL);
 return cb_FileWrite(f,Buf,i);
 #undef Buf
}


__declspec(noinline) cb_Integer cb_CDECL cb_fprintf (cb_File* f,const char * Str1,...)
{
 return cb_vfprintf(f,Str1,cb_CAST(void*,&Str1+1));
}


__declspec(noinline) cb_Integer cb_CDECL cb_PrintF (const char * Str1,...)
{
 cb_Integer cb_retVar_;
 cb_retVar_ = cb_vfprintf(cb_StdOut,Str1,cb_CAST(void*,&Str1+1));
 cb_FileFlush(cb_StdOut);
 return cb_retVar_;
}
/* END MODULE */
/* MODULE::cb_vfscanf */


cb_Integer cb_vfscanf (cb_File* f,const char * Str1,void* arg)
{
 return vfscanf((FILE*)cb_FileHandle(f),Str1,(va_list)arg);
}


__declspec(noinline) cb_Integer cb_CDECL cb_fscanf (cb_File* f,const char * Str1,...)
{
 return cb_vfscanf(f,Str1,&Str1+1);
}


__declspec(noinline) cb_Integer cb_CDECL cb_ScanF (const char * Str1,...)
{
 return cb_vfscanf(cb_StdIn,Str1,&Str1+1);
}
/* END MODULE */

/*((((((((((((((  Code  ))))))))))))))*/
#define cb_vbCBOOL(x) ((x)?-1:0)
/* MODULE::cb_vbByCopy */
static cb_Integer cb_vbByCopyBuf_[1*0x400];
static cb_Integer cb_vbByCopyCnt_;
#ifdef __cplusplus


static void* cb_vbByCopy (void*);

static void* cb_vbByCopy (void* p)
{
 void* cb_retVar_;
 cb_retVar_ = &(cb_vbByCopyBuf_[cb_vbByCopyCnt_]);
 *(void**)cb_retVar_ = p;
 cb_vbByCopyCnt_++;
 cb_vbByCopyCnt_ &= sizeof(cb_vbByCopyBuf_)-1;
 return cb_retVar_;
}
#endif


static cb_Integer* cb_vbByCopy (cb_Integer);

static cb_Integer* cb_vbByCopy (cb_Integer p)
{
 cb_Integer* cb_retVar_;
 cb_retVar_ = &(cb_vbByCopyBuf_[cb_vbByCopyCnt_]);
 *cb_retVar_ = p;
 cb_vbByCopyCnt_++;
 cb_vbByCopyCnt_ &= sizeof(cb_vbByCopyBuf_)-1;
 return cb_retVar_;
}
/* END MODULE */
#define cbGUI_CreateAndSet(x,y) \
 y = x()

#define cbGUI_DestroyAndReset(x,y) \
 xy; \
 y = NULL

#define cbGUI_DestroyWindowAndReset(x) \
 DestroyWindow(x)->hWnd; \
 x = NULL

#define cbGUI_vbDiv(x,y) cb_CAST(double,x)/cb_CAST(double,y)
#define cbGUI_vbMul(x,y) cb_CAST(double,x)*cb_CAST(double,y)
#define Module1_true -1
#define Module1_false 0

typedef struct cb_s_Module1_Key_words_ {
 char keyword[10];
 short sym;
} Module1_Key_words;

#define Module1_MAX_KEYWORDS 13
#define Module1_MAX_SYMTAB 100
#define Module1_MAX_CODE 1000
#define Module1_MAX_STACK 1000

typedef struct cb_s_Module1_Symbol_table_ {
 char ident[80];
 long data_index;
} Module1_Symbol_table;

#define Module1_sym_unknown 0
#define Module1_sym_eoi 1
#define Module1_sym_string_const 2
#define Module1_sym_lparen 3
#define Module1_sym_rparen 4
#define Module1_sym_multiply 5
#define Module1_sym_plus 6
#define Module1_sym_comma 7
#define Module1_sym_minus 8
#define Module1_sym_divide 9
#define Module1_sym_integer_const 10
#define Module1_sym_ident 11
#define Module1_sym_print 12
#define Module1_sym_while 13
#define Module1_sym_do 14
#define Module1_sym_end 15
#define Module1_sym_halt 16
#define Module1_sym_if 17
#define Module1_sym_then 18
#define Module1_sym_else 19
#define Module1_sym_integer_var 20
#define Module1_sym_equal 21
#define Module1_sym_mod 22
#define Module1_sym_or 23
#define Module1_sym_and 24
#define Module1_sym_neq 25
#define Module1_sym_lss 26
#define Module1_sym_leq 27
#define Module1_sym_gtr 28
#define Module1_sym_geq 29
#define Module1_sym_neg 30
#define Module1_sym_not 31
#define Module1_sym_whtspc 32
#define Module1_left_assoc 1
#define Module1_right_assoc 0
#define Module1_op_halt 0
#define Module1_op_push_int 1
#define Module1_op_add 2
#define Module1_op_sub 3
#define Module1_op_mul 4
#define Module1_op_div 5
#define Module1_op_prt_str 6
#define Module1_op_prt_int 7
#define Module1_op_prt_nl 8
#define Module1_op_jmp 9
#define Module1_op_jz 10
#define Module1_op_push_int_var 11
#define Module1_op_stor 12
#define Module1_op_mod 13
#define Module1_op_or 14
#define Module1_op_and 15
#define Module1_op_neq 16
#define Module1_op_equal 17
#define Module1_op_lss 18
#define Module1_op_leq 19
#define Module1_op_gtr 20
#define Module1_op_geq 21
#define Module1_op_neg 22
#define Module1_op_not 23


void Module1_assign_stmt (void);


void Module1_do_string (void);


void Module1_emit (long*);


void Module1_emit_at (long*,long*);


void Module1_emit_op (short*);


void Module1_error_msg (char *);


void Module1_expect (short*);


void Module1_expr (short*);


void Module1_get_digits (void);


void Module1_get_ident (void);


void Module1_get_string (void);


void Module1_halt_stmt (void);


void Module1_if_stmt (void);


void Module1_init_code (void);


void Module1_init_lex (char *);


void Module1_init_sym_tab (void);


void Module1_insert_sym_tab (char *);


void Module1_interpret (void);


void Module1_list_code (void);


void Module1_main (void);


void Module1_next_char (void);


void Module1_next_line (void);


void Module1_next_sym (void);


void Module1_parse (void);


void Module1_patch_jmp_to_current (long*);


void Module1_press_a_key (void);


void Module1_primary (void);


void Module1_print_stmt (void);


void Module1_set_data_size (long*);


void Module1_skip_white_space (void);


void Module1_stmt_seq (void);


void Module1_variable_decl (void);


void Module1_while_stmt (void);


cb_Integer Module1_associativity (short*);


cb_Integer Module1_binary_prec (short*);


cb_Integer Module1_emit2 (long*,long*);


cb_Integer Module1_find_sym_tab (char *);


cb_Integer Module1_get_cur_loc (void);


cb_Integer Module1_get_data_size (void);


cb_Integer Module1_is_alpha (char *);


cb_Integer Module1_is_binary_operator (short*);


cb_Integer Module1_is_in_sym_tab (char *,long*);


cb_Integer Module1_is_numeric (char *);


cb_Integer Module1_is_print (char *);


cb_Integer Module1_is_relational_operator (short*);


cb_Integer Module1_search_key_words (char *);


cb_Integer Module1_unary_prec (short*);


void Module1_main (void)
{
 char filename[cb_STRING_SIZE];
 cb_StrMove(filename, cb_Command());
 if (cb_vbCBOOL(filename[0]==0)) {
  cb_PutS("enter filename: ");
  cb_ScanF("%s", filename);
 }
 if (cb_vbCBOOL(filename[0]==0)) {
  system();
 }
 Module1_init_sym_tab();
 Module1_init_code();
 Module1_init_lex(filename);
 Module1_parse();
 if (cb_Handle1!=NULL) {
  if (cb_FileClose(cb_Handle1)==-1) {
   cb_GenErrorMsg("Close File Failed on: 'cb_Handle1'");
cb_AbortLabel_0:
   cb_Abort(cbApp_Error.Number, cbApp_Error.Description);
  }
  cb_Handle1 = NULL;
 }
 Module1_list_code();
 Module1_interpret();
 Module1_press_a_key();
}


void Module1_init_lex (char * filename)
{
 if ((cb_Handle1 = cb_FOpen(filename,"rb"))==NULL) {
  cb_GenErrorMsg(cb_StrJoin(cb_PrintBoxBuffer,"Can't Open: ",filename,NULL));
cb_AbortLabel_0:
  cb_Abort(cbApp_Error.Number, cbApp_Error.Description);
 }
 cur_line_num = 0;
 key_words_tab(1).sym = Module1_sym_and;
 key_words_tab(2).sym = Module1_sym_do;
 key_words_tab(3).sym = Module1_sym_else;
 key_words_tab(4).sym = Module1_sym_end;
 key_words_tab(5).sym = Module1_sym_halt;
 key_words_tab(6).sym = Module1_sym_if;
 key_words_tab(7).sym = Module1_sym_integer_var;
 key_words_tab(8).sym = Module1_sym_mod;
 key_words_tab(9).sym = Module1_sym_not;
 key_words_tab(10).sym = Module1_sym_or;
 key_words_tab(11).sym = Module1_sym_print;
 key_words_tab(12).sym = Module1_sym_then;
 key_words_tab(13).sym = Module1_sym_while;
 key_words_tab(1).keyword = "and";
 key_words_tab(2).keyword = "do";
 key_words_tab(3).keyword = "else";
 key_words_tab(4).keyword = "end";
 key_words_tab(5).keyword = "halt";
 key_words_tab(6).keyword = "if";
 key_words_tab(7).keyword = "integer";
 key_words_tab(8).keyword = "mod";
 key_words_tab(9).keyword = "not";
 key_words_tab(10).keyword = "or";
 key_words_tab(11).keyword = "print";
 key_words_tab(12).keyword = "then";
 key_words_tab(13).keyword = "while";
 Module1_next_char();
}


void Module1_next_line (void)
{
 cur_line = cb_EMPTYSTR;
 cur_ch = cb_EMPTYSTR;
 if (cb_FileEOF(cb_Handle1)) {
  return;
 }
 if ((cb_FStrGet(cb_Handle1, cur_line, NULL, (sizeof(cur_line)==sizeof(void*)) ? cb_STRING_SIZE : sizeof(cur_line)))==NULL) {
  cb_GenErrorMsg("Line Input/Peek From: 'cb_Handle1', has Failed");
cb_AbortLabel_0:
  cb_Abort(cbApp_Error.Number, cbApp_Error.Description);
 }
 cur_line = cb_StrJoin(NULL, cur_line, "\012",NULL);
 cur_line_num++;
 cb_PrintF("%s\n", (const char*)(cur_line));
 cur_col = 1;
}


void Module1_next_char (void)
{
 cur_ch = cb_EMPTYSTR;
 cur_col++;
 if (cb_vbCBOOL(cur_col>cb_StrLen(cur_line))) {
  Module1_next_line();
 }
 if (cb_vbCBOOL(cur_col<=cb_StrLen(cur_line))) {
  cur_ch = cb_vbStrMid(cur_line,cur_col,1);
 }
}


void Module1_skip_white_space (void)
{
 do {
  if (cb_vbCBOOL(cur_ch[0]==0)) {
   break;
  }
  if (cb_vbCBOOL(cb_MemComp(cur_ch," ",1+1)!=0) & cb_vbCBOOL(cb_ASC1(cur_ch)!=9) & cb_vbCBOOL(cb_ASC1(cur_ch)!=10)) {
   break;
  }
  Module1_next_char();
 } while(1);
}


void Module1_next_sym (void)
{
 token = cb_EMPTYSTR;
 Module1_skip_white_space();
 error_line = cur_line_num;
 error_col = cur_col;
 {  /* Select Case cur_ch */
  if (cur_ch[0]==0) {
   sym = Module1_sym_eoi;
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"+",1+1)==0) {
   sym = Module1_sym_plus;
   Module1_next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"-",1+1)==0) {
   sym = Module1_sym_minus;
   Module1_next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"*",1+1)==0) {
   sym = Module1_sym_multiply;
   Module1_next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"/",1+1)==0) {
   sym = Module1_sym_divide;
   Module1_next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,",",1+1)==0) {
   sym = Module1_sym_comma;
   Module1_next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"(",1+1)==0) {
   sym = Module1_sym_lparen;
   Module1_next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,")",1+1)==0) {
   sym = Module1_sym_rparen;
   Module1_next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"=",1+1)==0) {
   sym = Module1_sym_equal;
   Module1_next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"<",1+1)==0) {
   sym = Module1_sym_lss;
   Module1_next_char();
   if (cb_vbCBOOL(cb_MemComp(cur_ch,">",1+1)==0)) {
    sym = Module1_sym_neq;
    Module1_next_char();
   }
   else if (cb_vbCBOOL(cb_MemComp(cur_ch,"=",1+1)==0)) {
    sym = Module1_sym_leq;
    Module1_next_char();
   }
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,">",1+1)==0) {
   sym = Module1_sym_gtr;
   Module1_next_char();
   if (cb_vbCBOOL(cb_MemComp(cur_ch,"=",1+1)==0)) {
    sym = Module1_sym_geq;
    Module1_next_char();
   }
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"\042",1+1)==0) {
   Module1_get_string();
   goto EndSelect_0;
  }
  {
   if (Module1_is_numeric(cur_ch)) {
    Module1_get_digits();
   }
   else if (Module1_is_alpha(cur_ch)) {
    Module1_get_ident();
   }
   else {
    Module1_error_msg(cb_StrJoin(NULL,"unrecognized character: ",cur_ch,NULL));
   }
  }
 }  /* End Select: cur_ch */
 EndSelect_0:;
}


void Module1_get_string (void)
{
 short start_line;
 sym = Module1_sym_string_const;
 token = cb_EMPTYSTR;
 start_line = error_line;
 Module1_next_char();
 while(cb_vbCBOOL(cb_MemComp(cur_ch,"\042",1+1)!=0)) {
  if (cb_vbCBOOL(cur_ch[0]==0)) {
   sym = Module1_sym_eoi;
   Module1_error_msg("eof found in string");
   break;
  }
  if (cb_vbCBOOL(error_line>start_line)) {
   Module1_error_msg("string must be on one line");
   break;
  }
  token = cb_StrJoin(NULL, token, cur_ch,NULL);
  Module1_next_char();
 }
 if (cb_vbCBOOL(cb_MemComp(cur_ch,"\042",1+1)==0)) {
  Module1_next_char();
 }
}


void Module1_get_digits (void)
{
 short numeric;
 sym = Module1_sym_integer_const;
 numeric = Module1_true;
 token = cb_EMPTYSTR;
 do {
  if (Module1_is_numeric(cur_ch)) {
   token = cb_StrJoin(NULL, token, cur_ch,NULL);
  }
  else if (Module1_is_alpha(cur_ch)) {
   numeric = Module1_false;
  }
  else {
   break;
  }
  Module1_next_char();
 } while(1);
}


void Module1_get_ident (void)
{
 token = cb_EMPTYSTR;
 while(Module1_is_alpha(cur_ch) | Module1_is_numeric(cur_ch) | cb_vbCBOOL(cb_MemComp(cur_ch,"_",1+1)==0)) {
  token = cb_StrJoin(NULL, token, cur_ch,NULL);
  Module1_next_char();
 }
 sym = Module1_search_key_words(token);
}


cb_Integer Module1_search_key_words (char * token)
{
 short i;
 for (i = lbound(key_words_tab);i<=cb_UBOUND1(key_words_tab);i++) {
  if (cb_vbCBOOL(cb_StrComp(token,cb_RTrim(key_words_tab(i).keyword,(void*)-2))==0)) {
   return key_words_tab(i).sym;
  }
 }
 return Module1_sym_ident;
}


void Module1_init_sym_tab (void)
{
 data_index = 1;
 sym_tab_used = 0;
}


cb_Integer Module1_get_data_size (void)
{
 return data_index;
}


cb_Integer Module1_find_sym_tab (char * ident)
{
 short i;
 for (i = lbound(sym_tab);i<=sym_tab_used;i++) {
  if (cb_vbCBOOL(cb_StrComp(ident,cb_RTrim(sym_tab(i).ident,(void*)-2))==0)) {
   return i;
  }
 }
 return 0;
}


void Module1_insert_sym_tab (char * ident)
{
 if (cb_vbCBOOL(sym_tab_used>=Module1_MAX_SYMTAB)) {
  Module1_error_msg("Symbol table exhausted");
  return;
 }
 if (cb_vbCBOOL(Module1_find_sym_tab(ident)>0)) {
  Module1_error_msg(cb_StrJoin(NULL,ident," has already been defined",NULL));
  return;
 }
 sym_tab_used++;
 sym_tab(sym_tab_used).ident = ident;
 sym_tab(sym_tab_used).data_index = data_index;
 data_index++;
}


cb_Integer Module1_is_in_sym_tab (char * ident,long* address)
{
 short i;
 i = Module1_find_sym_tab(ident);
 if (cb_vbCBOOL(i==0)) {
  return Module1_false;
 }
 address[0] = sym_tab(i).data_index;
 return Module1_true;
}


void Module1_init_code (void)
{
 code_index = 1;
}


void Module1_set_data_size (long* size_to_set)
{
 data_size = size_to_set[0];
}


cb_Integer Module1_get_cur_loc (void)
{
 return code_index;
}


void Module1_emit_at (long* location,long* operand)
{
 code_arr[location[0]] = operand[0];
}


void Module1_emit (long* opcode)
{
 if (cb_vbCBOOL(code_index>=Module1_MAX_CODE)) {
  Module1_error_msg(cb_StrJoin(NULL,"code array exhausted: ",cb_CStrDbl(code_index),NULL));
  return;
 }
 code_arr[code_index] = opcode[0];
 code_index++;
}


cb_Integer Module1_emit2 (long* opcode,long* operand)
{
 long location;
 location = code_index;
 Module1_emit(opcode);
 Module1_emit(operand);
 cb_retVar_(& = location);
 return 0;
}


void Module1_patch_jmp_to_current (long* fix_addr)
{
 Module1_emit_at(fix_addr+1,&code_index);
}


void Module1_list_code (void)
{
 long i;
 long last_code;
 cb_PutS("Code listing...\n");
 last_code = code_index;
 i = 1;
 do {
  {  /* Select Case code_arr[i] */
   if (code_arr[i]==Module1_op_halt) {
    cb_PrintF("%lihalt\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_push_int) {
    cb_PrintF("%lipush-int%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_push_int_var) {
    cb_PrintF("%lipush-int-var%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_stor) {
    cb_PrintF("%listore%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_jmp) {
    cb_PrintF("%lijmp%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_jz) {
    cb_PrintF("%lijz%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_add) {
    cb_PrintF("%liadd\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_sub) {
    cb_PrintF("%lisub\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_mul) {
    cb_PrintF("%limul\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_div) {
    cb_PrintF("%lidiv\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_mod) {
    cb_PrintF("%limod\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_or) {
    cb_PrintF("%lior\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_and) {
    cb_PrintF("%liand\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_neq) {
    cb_PrintF("%lineq\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_equal) {
    cb_PrintF("%liequal\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_lss) {
    cb_PrintF("%lilss\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_leq) {
    cb_PrintF("%lileq\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_gtr) {
    cb_PrintF("%ligtr\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_geq) {
    cb_PrintF("%ligeq\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_neg) {
    cb_PrintF("%lineg\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_not) {
    cb_PrintF("%linot\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_prt_nl) {
    cb_PrintF("%liprint-nl\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_prt_str) {
    long operand;
    char* st;
    long tmp;
    long tmp2;
    st = cb_EMPTYSTR;
    operand = code_arr[i+1];
    tmp = operand;
    tmp2 = i;
    i++;
    while(cb_vbCBOOL(operand>0)) {
     i++;
     st = cb_StrJoin(NULL, st, cb_Chr(code_arr[i]),NULL);
     operand--;
    }
    cb_PrintF("%liprint-str%li%s\n", (long)(tmp2), (long)(tmp), (const char*)(st));
    goto EndSelect_1;
   }
   if (code_arr[i]==Module1_op_prt_int) {
    cb_PrintF("%liprint-int\n", (long)(i));
    goto EndSelect_1;
   }
   {
    Module1_error_msg(cb_StrJoin(NULL,"unexpected opcode ",cb_CStrDbl(code_arr[i])," at position ",cb_CStrDbl(i),NULL));
   }
  }  /* End Select: code_arr[i] */
  EndSelect_1:;
  i++;
 } while(cb_vbCBOOL(i<last_code));
 cb_PutS("\n");
}


void Module1_interpret (void)
{
 long last_code;
 long pc;
 long sp;
 short halted;
 long stack[1 + Module1_MAX_STACK];
 cb_PrintF("%s\n", (const char*)(cb_StrJoin(NULL,"Running... code_index: ",cb_CStrDbl(code_index),NULL)));
 last_code = code_index-1;
 halted = Module1_false;
 pc = 1;
 sp = data_size;
 do {
  long opcode;
  long operand;
  char* st;
  if (cb_vbCBOOL(pc>last_code)) {
   Module1_error_msg(cb_StrJoin(NULL,"pc: (",cb_CStrDbl(pc),") > last_code: (",cb_CStrDbl(last_code),")",NULL));
  }
  if (cb_vbCBOOL(sp<0)) {
   Module1_error_msg("stack underflow");
  }
  opcode = code_arr[pc];
  pc++;
  {  /* Select Case opcode */
   if (opcode==Module1_op_push_int) {
    sp++;
    stack[sp] = code_arr[pc];
    pc++;
    goto EndSelect_1;
   }
   if (opcode==Module1_op_push_int_var) {
    sp++;
    stack[sp] = stack[code_arr[pc]];
    pc++;
    goto EndSelect_1;
   }
   if (opcode==Module1_op_jz) {
    if (cb_vbCBOOL(stack[sp]==0)) {
     pc = code_arr[pc];
    }
    else {
     pc++;
    }
    sp--;
    goto EndSelect_1;
   }
   if (opcode==Module1_op_stor) {
    stack[code_arr[pc]] = stack[sp];
    sp--;
    pc++;
    goto EndSelect_1;
   }
   if (opcode==Module1_op_jmp) {
    pc = code_arr[pc];
    goto EndSelect_1;
   }
   if (opcode==Module1_op_add) {
    sp--;
    stack[sp] = stack[sp] + stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==Module1_op_sub) {
    sp--;
    stack[sp] = stack[sp] - stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==Module1_op_mul) {
    sp--;
    stack[sp] = cbGUI_vbMul(stack[sp],stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==Module1_op_div) {
    sp--;
    if (cb_vbCBOOL(stack[sp+1]==0)) {
     Module1_error_msg("divide by zero");
    }
    stack[sp] = cb_INT(stack[sp]/stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==Module1_op_mod) {
    sp--;
    if (cb_vbCBOOL(stack[sp+1]==0)) {
     Module1_error_msg("divide by zero");
    }
    stack[sp] = cb_INT(stack[sp] % stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==Module1_op_or) {
    sp--;
    stack[sp] = stack[sp] | stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==Module1_op_and) {
    sp--;
    stack[sp] = stack[sp] & stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==Module1_op_neq) {
    sp--;
    stack[sp] = cb_vbCBOOL(stack[sp]!=stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==Module1_op_equal) {
    sp--;
    stack[sp] = cb_vbCBOOL(stack[sp]==stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==Module1_op_lss) {
    sp--;
    stack[sp] = cb_vbCBOOL(stack[sp]<stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==Module1_op_leq) {
    sp--;
    stack[sp] = cb_vbCBOOL(stack[sp]<=stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==Module1_op_gtr) {
    sp--;
    stack[sp] = cb_vbCBOOL(stack[sp]>stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==Module1_op_geq) {
    sp--;
    stack[sp] = cb_vbCBOOL(stack[sp]>=stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==Module1_op_neg) {
    stack[sp] = -stack[sp];
    goto EndSelect_1;
   }
   if (opcode==Module1_op_not) {
    stack[sp] =  ~stack[sp];
    goto EndSelect_1;
   }
   if (opcode==Module1_op_prt_str) {
    operand = code_arr[pc];
    pc++;
    st = cb_EMPTYSTR;
    while(cb_vbCBOOL(operand>0)) {
     st = cb_StrJoin(NULL, st, cb_Chr(code_arr[pc]),NULL);
     pc++;
     operand--;
    }
    cb_PutS((const char*)(st));
    goto EndSelect_1;
   }
   if (opcode==Module1_op_prt_int) {
    cb_PrintF("%li", (long)(stack[sp]));
    sp--;
    goto EndSelect_1;
   }
   if (opcode==Module1_op_prt_nl) {
    cb_PutS("\n");
    goto EndSelect_1;
   }
   if (opcode==Module1_op_halt) {
    halted = Module1_true;
    break;
   }
   {
    Module1_error_msg(cb_StrJoin(NULL,"Unknown opcode",cb_CStrDbl(opcode),NULL));
   }
  }  /* End Select: opcode */
  EndSelect_1:;
 } while(!(halted));
 cb_PutS("Finished...\n");
}


void Module1_emit_op (short* symbol)
{
 {  /* Select Case symbol[0] */
  if (symbol[0]==Module1_sym_or) {
   Module1_emit(&op_orModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_and) {
   Module1_emit(&op_andModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_equal) {
   Module1_emit(&op_equalModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_neq) {
   Module1_emit(&op_neqModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_lss) {
   Module1_emit(&op_lssModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_leq) {
   Module1_emit(&op_leqModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_gtr) {
   Module1_emit(&op_gtrModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_geq) {
   Module1_emit(&op_geqModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_plus) {
   Module1_emit(&op_addModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_minus) {
   Module1_emit(&op_subModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_multiply) {
   Module1_emit(&op_mulModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_divide) {
   Module1_emit(&op_divModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_mod) {
   Module1_emit(&op_modModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_neg) {
   Module1_emit(&op_negModule1_);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_not) {
   Module1_emit(&op_notModule1_);
  }
 }  /* End Select: symbol[0] */
 EndSelect_0:;
}


void Module1_expect (short* symbol)
{
 if (cb_vbCBOOL(symbol[0]==sym)) {
  Module1_next_sym();
 }
 else {
  Module1_error_msg(cb_StrJoin(NULL,"unexpected token - expected: ",cb_CStrDbl(symbol[0])," got: ",cb_CStrDbl(sym),NULL));
 }
}


cb_Integer Module1_is_binary_operator (short* symbol)
{
 cb_retVar_(& = Module1_true);
 {  /* Select Case symbol[0] */
  if ((symbol[0]==Module1_sym_or) || (symbol[0]==Module1_sym_and)) {
   goto EndSelect_0;
  }
  if ((symbol[0]==Module1_sym_equal) || (symbol[0]==Module1_sym_neq)) {
   goto EndSelect_0;
  }
  if ((symbol[0]==Module1_sym_lss) || (symbol[0]==Module1_sym_leq) || (symbol[0]==Module1_sym_gtr) || (symbol[0]==Module1_sym_geq)) {
   goto EndSelect_0;
  }
  if ((symbol[0]==Module1_sym_plus) || (symbol[0]==Module1_sym_minus)) {
   goto EndSelect_0;
  }
  if ((symbol[0]==Module1_sym_multiply) || (symbol[0]==Module1_sym_divide) || (symbol[0]==Module1_sym_mod)) {
   goto EndSelect_0;
  }
  {
   cb_retVar_(& = Module1_false);
  }
 }  /* End Select: symbol[0] */
 EndSelect_0:;
 return 0;
}


cb_Integer Module1_is_relational_operator (short* symbol)
{
 cb_retVar_(& = Module1_true);
 {  /* Select Case symbol[0] */
  if ((symbol[0]==Module1_sym_equal) || (symbol[0]==Module1_sym_neq)) {
   goto EndSelect_0;
  }
  if ((symbol[0]==Module1_sym_lss) || (symbol[0]==Module1_sym_leq) || (symbol[0]==Module1_sym_gtr) || (symbol[0]==Module1_sym_geq)) {
   goto EndSelect_0;
  }
  {
   cb_retVar_(& = Module1_false);
  }
 }  /* End Select: symbol[0] */
 EndSelect_0:;
 return 0;
}


cb_Integer Module1_unary_prec (short* symbol)
{
 cb_Integer cb_retVar_ = {0};
 {  /* Select Case symbol[0] */
  if ((symbol[0]==Module1_sym_neg) || (symbol[0]==Module1_sym_not)) {
   cb_retVar_ = 70;
   goto EndSelect_0;
  }
  {
   cb_retVar_ = 0;
  }
 }  /* End Select: symbol[0] */
 EndSelect_0:;
 return cb_retVar_;
}


cb_Integer Module1_binary_prec (short* symbol)
{
 {  /* Select Case symbol[0] */
  if ((symbol[0]==Module1_sym_multiply) || (symbol[0]==Module1_sym_divide) || (symbol[0]==Module1_sym_mod)) {
   cb_retVar_(& = 60);
   goto EndSelect_0;
  }
  if ((symbol[0]==Module1_sym_plus) || (symbol[0]==Module1_sym_minus)) {
   cb_retVar_(& = 50);
   goto EndSelect_0;
  }
  if ((symbol[0]==Module1_sym_lss) || (symbol[0]==Module1_sym_leq) || (symbol[0]==Module1_sym_gtr) || (symbol[0]==Module1_sym_geq)) {
   cb_retVar_(& = 40);
   goto EndSelect_0;
  }
  if ((symbol[0]==Module1_sym_equal) || (symbol[0]==Module1_sym_neq)) {
   cb_retVar_(& = 30);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_or) {
   cb_retVar_(& = 20);
   goto EndSelect_0;
  }
  if (symbol[0]==Module1_sym_and) {
   cb_retVar_(& = 10);
   goto EndSelect_0;
  }
  {
   cb_retVar_(& = 0);
  }
 }  /* End Select: symbol[0] */
 EndSelect_0:;
 return 0;
}


cb_Integer Module1_associativity (short* symbol)
{
 cb_retVar_(& = Module1_left_assoc);
 return 0;
}


void Module1_primary (void)
{
 long num;
 long junk;
 {  /* Select Case sym */
  if (sym==Module1_sym_integer_const) {
   num = cb_AtoL(token);
   junk = Module1_emit2(&op_push_intModule1_,&num);
   Module1_next_sym();
   goto EndSelect_0;
  }
  if (sym==Module1_sym_ident) {
   long address;
   if ( ~Module1_is_in_sym_tab(token,&address)) {
    Module1_error_msg(cb_StrJoin(NULL,"primary: ",token," has not been defined",NULL));
   }
   junk = Module1_emit2(&op_push_int_varModule1_,&address);
   Module1_next_sym();
   goto EndSelect_0;
  }
  if (sym==Module1_sym_lparen) {
   Module1_next_sym();
   Module1_expr(0);
   if (cb_vbCBOOL(sym!=Module1_sym_rparen)) {
    Module1_error_msg("expecting ')'");
   }
   Module1_next_sym();
   goto EndSelect_0;
  }
  if ((sym==Module1_sym_minus) || (sym==Module1_sym_not)) {
   short op;
   op = sym;
   if (cb_vbCBOOL(sym==Module1_sym_minus)) {
    op = Module1_sym_neg;
   }
   Module1_next_sym();
   Module1_expr(&Module1_unary_prec(&op));
   Module1_emit_op(&op);
   goto EndSelect_0;
  }
  {
   Module1_error_msg("expecting number");
  }
 }  /* End Select: sym */
 EndSelect_0:;
}


void Module1_expr (short* p)
{
 Module1_primary();
 while(Module1_is_binary_operator(&sym) & cb_vbCBOOL(Module1_binary_prec(&sym)>=p[0])) {
  short op;
  long tmp;
  op = sym;
  Module1_next_sym();
  tmp = 0;
  if (cb_vbCBOOL(Module1_associativity(&op)==Module1_left_assoc)) {
   tmp = 1;
  }
  Module1_expr(&Module1_binary_prec(&op) + tmp);
  Module1_emit_op(&op);
  if (Module1_is_relational_operator(&op) & Module1_is_relational_operator(&sym)) {
   Module1_error_msg("consecutive relational operators not allowed");
  }
 }
}


void Module1_assign_stmt (void)
{
 long address;
 long junk;
 if ( ~Module1_is_in_sym_tab(token,&address)) {
  Module1_error_msg(cb_StrJoin(NULL,"assign: ",token," has not been defined",NULL));
 }
 Module1_expect(&sym_identModule1_);
 Module1_expect(&sym_equalModule1_);
 Module1_expr(0);
 junk = Module1_emit2(&op_storModule1_,&address);
}


void Module1_if_stmt (void)
{
 long fix1;
 long fix2;
 fix2 = -1;
 Module1_expect(&sym_ifModule1_);
 Module1_expr(0);
 fix1 = Module1_emit2(&op_jzModule1_,0);
 Module1_expect(&sym_thenModule1_);
 Module1_stmt_seq();
 if (cb_vbCBOOL(sym==Module1_sym_else)) {
  fix2 = Module1_emit2(&op_jmpModule1_,0);
  Module1_patch_jmp_to_current(&fix1);
  Module1_expect(&sym_elseModule1_);
  Module1_stmt_seq();
 }
 else {
  Module1_patch_jmp_to_current(&fix1);
 }
 Module1_expect(&sym_endModule1_);
 Module1_expect(&sym_ifModule1_);
 if (cb_vbCBOOL(fix2!=-1)) {
  Module1_patch_jmp_to_current(&fix2);
 }
}


void Module1_halt_stmt (void)
{
 Module1_emit(&op_haltModule1_);
 Module1_next_sym();
}


void Module1_while_stmt (void)
{
 long top;
 long fix1;
 long junk;
 Module1_expect(&sym_whileModule1_);
 top = Module1_get_cur_loc();
 Module1_expr(0);
 fix1 = Module1_emit2(&op_jzModule1_,0);
 Module1_expect(&sym_doModule1_);
 Module1_stmt_seq();
 junk = Module1_emit2(&op_jmpModule1_,&top);
 Module1_patch_jmp_to_current(&fix1);
 Module1_expect(&sym_endModule1_);
 Module1_expect(&sym_whileModule1_);
}


void Module1_do_string (void)
{
 short i;
 for (i = 1;i<=cb_StrLen(token);i++) {
  Module1_emit(&asc(cb_vbStrMid(token,i,1)));
 }
 Module1_next_sym();
}


void Module1_print_stmt (void)
{
 long junk;
 do {
  Module1_next_sym();
  if (cb_vbCBOOL(sym==Module1_sym_string_const)) {
   junk = Module1_emit2(&op_prt_strModule1_,&Len(token));
   Module1_do_string();
  }
  else if (cb_vbCBOOL(sym==Module1_sym_integer_const) | cb_vbCBOOL(sym==Module1_sym_ident)) {
   Module1_expr(0);
   Module1_emit(&op_prt_intModule1_);
  }
  else {
   Module1_error_msg("expecting string or integer");
  }
 } while(cb_vbCBOOL(sym==Module1_sym_comma));
 Module1_emit(&op_prt_nlModule1_);
}


void Module1_stmt_seq (void)
{
 while(cb_vbCBOOL(sym!=Module1_sym_eoi) & cb_vbCBOOL(sym!=Module1_sym_end) & cb_vbCBOOL(sym!=Module1_sym_else)) {
  {  /* Select Case sym */
   if (sym==Module1_sym_print) {
    Module1_print_stmt();
    goto EndSelect_1;
   }
   if (sym==Module1_sym_halt) {
    Module1_halt_stmt();
    goto EndSelect_1;
   }
   if (sym==Module1_sym_if) {
    Module1_if_stmt();
    goto EndSelect_1;
   }
   if (sym==Module1_sym_while) {
    Module1_while_stmt();
    goto EndSelect_1;
   }
   if (sym==Module1_sym_ident) {
    Module1_assign_stmt();
    goto EndSelect_1;
   }
   {
    Module1_error_msg(cb_StrJoin(NULL,"unrecognized statement: (",cb_CStrDbl(sym),") ",token,NULL));
   }
  }  /* End Select: sym */
  EndSelect_1:;
 }
}


void Module1_variable_decl (void)
{
 while(cb_vbCBOOL(sym==Module1_sym_integer_var)) {
  Module1_expect(&sym_integer_varModule1_);
  do {
   long address;
   if (Module1_is_in_sym_tab(token,&address)) {
    Module1_error_msg(cb_StrJoin(NULL,token," has already been defined",NULL));
   }
   Module1_insert_sym_tab(token);
   Module1_expect(&sym_identModule1_);
   if (cb_vbCBOOL(sym!=Module1_sym_comma)) {
    break;
   }
   Module1_expect(&sym_commaModule1_);
  } while(1);
 }
}


void Module1_parse (void)
{
 Module1_next_sym();
 Module1_variable_decl();
 Module1_stmt_seq();
 if (cb_vbCBOOL(sym!=Module1_sym_eoi)) {
  Module1_error_msg("a statement was expected");
 }
 Module1_emit(&op_haltModule1_);
 Module1_set_data_size(&Module1_get_data_size());
}


void Module1_error_msg (char * msg)
{
 short junk;
 cb_PrintF("%hi%hi%s\n", (short)(error_line), (short)(error_col), (const char*)(msg));
 Module1_press_a_key();
 system();
}


cb_Integer Module1_is_alpha (char * ch)
{
 return (cb_vbCBOOL(ch[0]!=0)) & cb_vbCBOOL(cb_ASC1(cb_UCase(ch))>=0x41) & cb_vbCBOOL(cb_ASC1(cb_UCase(ch))<=0x5A);
}


cb_Integer Module1_is_print (char * ch)
{
 return (cb_vbCBOOL(ch[0]!=0)) & cb_vbCBOOL(cb_ASC1(ch)>=32) & cb_vbCBOOL(cb_ASC1(ch)<=126);
}


cb_Integer Module1_is_numeric (char * ch)
{
 return (cb_vbCBOOL(cb_ASC1(ch)>=0x30) & cb_vbCBOOL(cb_ASC1(ch)<=0x39));
}


void Module1_press_a_key (void)
{
 short junk;
 cb_PutS("Press enter");
 cb_ScanF("%hi", &(junk));
}


static void Module1_Initialize (void)
{
}


static void Module1_Terminate (void)
{
}

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Implementation -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


void cbApp_Terminate (void)
{
 CodeBase_Terminate();
}


void cbApp_Initialize (void)
{
 cbApp_FindData.FileHandle = INVALID_HANDLE_VALUE;
 if (!cbApp_Argv) cbApp_Argv = cb_CommandLineToArgvA(&cbApp_Argc);
 cb_OnEnd(&cbApp_Terminate);
 cb_FileInitialize();
}

/*((((((((((((((  Entry Function  ))))))))))))))*/

cb_Integer cb_CDECL main (cb_Integer argc, char** argv)
{
 cbApp_Initialize();
 cb_Wait();

 return 0;
}
