/*    CodeBase - Compiler Frontend To C++ - (Version 1.00)    */
/*    Copyright � SoftBase Labs.  MIT    */

//CommandLine:
//ToyBasic -c

#define __CODEBASE__
#define true -1
#define false 0
#define MAX_KEYWORDS 13
#define MAX_SYMTAB 100
#define MAX_CODE 1000
#define MAX_STACK 1000
#define sym_unknown 0
#define sym_eoi 1
#define sym_string_const 2
#define sym_lparen 3
#define sym_rparen 4
#define sym_multiply 5
#define sym_plus 6
#define sym_comma 7
#define sym_minus 8
#define sym_divide 9
#define sym_integer_const 10
#define sym_ident 11
#define sym_print 12
#define sym_while 13
#define sym_do 14
#define sym_end 15
#define sym_halt 16
#define sym_if 17
#define sym_then 18
#define sym_else 19
#define sym_integer_var 20
#define sym_equal 21
#define sym_mod 22
#define sym_or 23
#define sym_and 24
#define sym_neq 25
#define sym_lss 26
#define sym_leq 27
#define sym_gtr 28
#define sym_geq 29
#define sym_neg 30
#define sym_not 31
#define sym_whtspc 32
#define left_assoc 1
#define right_assoc 0
#define op_halt 0
#define op_push_int 1
#define op_add 2
#define op_sub 3
#define op_mul 4
#define op_div 5
#define op_prt_str 6
#define op_prt_int 7
#define op_prt_nl 8
#define op_jmp 9
#define op_jz 10
#define op_push_int_var 11
#define op_stor 12
#define op_mod 13
#define op_or 14
#define op_and 15
#define op_neq 16
#define op_equal 17
#define op_lss 18
#define op_leq 19
#define op_gtr 20
#define op_geq 21
#define op_neg 22
#define op_not 23

#if defined(__GNUC__) || defined(__GNUG__)
#define _NO_OLDNAMES
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0502
#endif
#ifndef _WIN32_IE
#define _WIN32_IE 0x0502
#endif
#ifndef WINVER
#define WINVER 0x0502
#endif
#else

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif
#ifndef _WIN32_IE
#define _WIN32_IE 0x0600
#endif
#ifndef WINVER
#define WINVER 0x0600
#endif
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ctype.h>
#include <fcntl.h>
#ifdef _MSC_VER
#define _USE_MATH_DEFINES
#endif
#include <math.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <wctype.h>
#include <sys/stat.h>
#include <conio.h>
#include <direct.h>
#include <io.h>
#ifdef cb_USE_COM
#include <shellapi.h>
#include <objbase.h>
#include <oaidl.h>
#include <shlobj.h>
#endif
#include <wchar.h>
#if defined(__GNUC__) || defined(__GNUG__) || defined(__clang__)
#endif

/*-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-*/
#include <CodeBase.h>
/*-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-*/

#define cb_End exit
#define cb_OnEnd atexit
#define cb_IsAlpha isalpha
#define cb_IsAlphaW iswalpha
#define cb_IsDigit isdigit
#define cb_IsDigitW iswdigit
#define cb_IsAlphaDigit isalnum
#define cb_IsAlphaDigitW iswalnum
#define cb_IsSpace isspace
#define cb_IsSpaceW iswspace
#define cb_IsLower islower
#define cb_IsLowerW iswlower
#define cb_IsUpper isupper
#define cb_IsUpperW iswupper
#define cb_IsSpace isspace
#define cb_IsSpaceW iswspace
#define cb_MemComp memcmp
#define cb_MemChr memchr
#define cb_MemChrW wmemchr
#define cb_MemSet memset
#define cb_MemSetW wmemset
#define cb_MemCopy memcpy
#define cb_MemCopyW wmemcpy
#define cb_MemMove memmove
#define cb_MemMoveW wmemmove
#define cb_StrLen strlen
#define cb_StrLenW wcslen
#define cb_AtoL atol
#define cb_AtoF(x,y) strtof(x,y)
#define cb_AtoD(x,y) strtod(x,y)
#define cb_AtoLD(x,y) strtold(x,y)
#define cb_Ceil ceil
#define cb_Ceilf ceilf
#define cb_Ceill ceill
#define cb_Floor floor
#define cb_Floorf floorf
#define cb_Floorl floorl
#define cb_FMod fmod
#define cb_FModf fmodf
#define cb_FModl fmodl
#define cb_ModF modf
#define cb_ModFf modff
#define cb_ModFl modfl
#define cb_Pow pow
#define cb_Powf powf
#define cb_Powl powl
#define cb_Trunc trunc
#define cb_Truncf truncf
#define cb_Truncl truncl
#define cb_SQR(x,y) pow(x,(double)1.0/(double)(y))
#define cb_SQRF(x,y) powf(x,(float)1.0/(float)(y))
#define cb_SQRLD(x,y) powl(x,(long double)1.0/(long double)(y))
#define cb_Rand rand
#define cb_Randomize srand
#define cb_ChDir _chdir
#define cb_ChDrive _chdrive
#define cb_ChMod _chmod
#define cb_GetDrive _getdrive
#define cb_MkDir _mkdir
#define cb_RmDir _rmdir
#define cb_Remove remove
#define cb_RemoveW wremove
#define cb_Rename !rename
#define cb_RenameW !wrename
#define cb_FilePrintF cb_fprintf
#define cb_SPrintFW cb_snwprintf
#define cb_INT(x) ((cb_Integer)cb_Floor(x))
#define cb_CLEAR1(x) cb_MemSet(&(x),0,sizeof(x))

typedef struct cb_s_Key_words_ {
 char keyword[100];
 cb_Integer sym;
} Key_words;


typedef struct cb_s_Symbol_table_ {
 char ident[128];
 long data_index;
} Symbol_table;

cb_BeginExternC
EXTERN_C cb_Integer  cbApp_Argc;
EXTERN_C char**  cbApp_Argv;
EXTERN_C structcbApp_Error  cbApp_Error;
EXTERN_C char  *cb_TmpDynStrPtrBuf_ [cb_MAX_TMPDYNSTR_CYCLES_];
EXTERN_C cb_Integer  cb_TmpDynStrCyclesMax_;
EXTERN_C cb_Integer  cb_TmpDynStrCyclesFlag;
EXTERN_C cb_Integer  cb_TmpDynStrCyclesCnt_;
EXTERN_C char  cb_PrintBoxBuffer[64 * 0x400];
EXTERN_C char  *cb_CommandLinePtr;
EXTERN_C cb_FIND_DATA  cbApp_FindData;
EXTERN_C cb_File*  cb_StdIn;
EXTERN_C cb_File*  cb_StdErr;
EXTERN_C cb_File*  cb_StdOut;
cb_EndExternC
cb_BeginExternC
char*  cb_DEFCALL  cb_StrMove (void*,const void*);
char*  cb_DEFCALL  cb_StrCat (void*,const void*);
cb_Integer  cb_CDECL  cb_StrComp (const void*, const void*);
char*  cb_CDECL  cb_StrJoin (void*, ...);
char*  cb_DEFCALL  cb_UCaseX (const char*,void* =NULL,cb_Integer=-1,cb_Integer=-1);
char*  cb_DEFCALL  cb_UCase (const char*,void* =NULL);
char*  cb_DEFCALL  cb_Mid (const void*, cb_Integer, cb_Integer=-1, void* =NULL);
char*  cb_DEFCALL  cb_RTrimX (const void*,void* =NULL,cb_Integer=32,cb_Integer=-1,cb_Integer=-1);
char*  cb_DEFCALL  cb_RTrim (const void*,void* =NULL);
char*  cb_DEFCALL  cb_Chr (cb_Integer,void* =NULL);
char*  cb_DEFCALL  cb_CStrDbl (double, void* =NULL, cb_Integer=-1);
cb_Integer  cb_DEFCALL  cb_FileClose (cb_File*);
void  cb_FileInitialize (void);
cb_Integer  cb_DEFCALL  cb_FileFlush (cb_File*);
cb_Integer  cb_DEFCALL  cb_FileEOF (cb_File*);
cb_Integer  cb_DEFCALL  cb_FileError (cb_File*);
cb_Integer  cb_DEFCALL  cb_FileClearError (cb_File*);
cb_File*  cb_DEFCALL  cb_TempFile (const char* =NULL,const char* =cb_EMPTYSTR,const char* =NULL,cb_Integer=-1^_O_APPEND);
cb_File*  cb_DEFCALL  cb_FileOpen (const void* =NULL, cb_Integer=-1, cb_Integer=0);
cb_File*  cb_DEFCALL  cb_FOpen (const void* =NULL, const char* =NULL, cb_Integer=0);
cb_UInteger  cb_DEFCALL  cb_FileTell (cb_File*);
cb_UInteger  cb_DEFCALL  cb_FileRead (cb_File*, void*, cb_UInteger);
cb_UInteger  cb_DEFCALL  cb_FileWrite (cb_File*, const void*, cb_UInteger);
cb_Integer  cb_DEFCALL  cb_FilePutS (cb_File*, const char*);
void*  cb_DEFCALL  cb_FileHandle (cb_File*);
cb_Integer  cb_DEFCALL  cb_FileGetS (cb_File*, char*, cb_Integer);
char*  cb_DEFCALL  cb_FGetS (cb_File*, char*, cb_Integer);
cb_UInteger  cb_DEFCALL  cb_FileSeek (cb_File*, cb_UInteger=0, cb_Integer=SEEK_SET);
cb_Integer  cb_DEFCALL  cb_FSeek (cb_File*, cb_UInteger=0, cb_Integer=SEEK_SET);
char *  cb_DEFCALL  cb_FStrGet (cb_File* =(cb_File*)-1,void* =NULL,void* =NULL,cb_Integer=cb_STRING_SIZE);
char*  cb_DEFCALL  cb_Command (cb_Integer=-1,void* =NULL,cb_Integer=0);
char*  cb_DEFCALL  cb_TempFileName (const char* =NULL,const char* ="tmp",const char* =NULL,void* =NULL);
char*  cb_DEFCALL  cb_GenErrorMsg (const char*,cb_Integer=0,void* =NULL);
char **  cb_DEFCALL  cb_CommandLineToArgvA (cb_Integer* =NULL,void* =NULL,void* =NULL);
cb_Integer  cb_DEFCALL  cb_vsnprintf (char*,cb_UInteger,const char*,void*,void* =NULL);
cb_Integer  cb_CDECL  cb_snprintf (char*,cb_UInteger,const char*,...);
cb_Integer  cb_DEFCALL  cb_vsprintf (char*,const char*,void*,void* =NULL);
cb_Integer  cb_CDECL  cb_SPrintF (char*,const char*,...);
cb_Integer  cb_DEFCALL  cb_vsscanf (const char*,const char*,void*);
cb_Integer  cb_CDECL  cb_SScanF (const char*,const char*,...);
cb_Integer  cb_DEFCALL  cb_PutS (const char*);
void  cb_DEFCALL  cb_Abort (cb_Integer=cb_ABORT_EXIT_CODE,const char* =NULL);
cb_EndExternC
#include <cEachFile.h>
#include "D:/Programming/CodeBase/Source/Lib/Classes/All/EachFile/cEachFile.h"
#include <cString.h>
#include "D:/Programming/CodeBase/Source/Lib/Classes/All/String/cString.h"
static cb_File* cb_Handle1;
EXTERN_C cb_Integer cb_vfprintf (cb_File*,const char *,void*);
EXTERN_C cb_Integer cb_CDECL cb_fprintf (cb_File*,const char *,...);
EXTERN_C cb_Integer cb_CDECL cb_PrintF (const char *,...);
EXTERN_C cb_Integer cb_vfscanf (cb_File*,const char *,void*);
EXTERN_C cb_Integer cb_CDECL cb_fscanf (cb_File*,const char *,...);
EXTERN_C cb_Integer cb_CDECL cb_ScanF (const char *,...);
void assign_stmt (void);
void do_string (void);
void emit (long);
void emit_at (long,long);
void emit_op (cb_Integer);
void error_msg (char *);
void expect (cb_Integer);
void expr (cb_Integer);
void get_digits (void);
void get_ident (void);
void get_string (void);
void halt_stmt (void);
void if_stmt (void);
void init_code (void);
void init_lex (char *);
void init_sym_tab (void);
void insert_sym_tab (char *);
void interpret (void);
void list_code (void);
void next_char (void);
void next_line (void);
void next_sym (void);
void parse (void);
void patch_jmp_to_current (long);
void press_a_key (void);
void primary (void);
void print_stmt (void);
void set_data_size (long);
void skip_white_space (void);
void stmt_seq (void);
void variable_decl (void);
void while_stmt (void);
cb_Integer associativity (cb_Integer);
cb_Integer binary_prec (cb_Integer);
cb_Integer emit2 (long,long);
cb_Integer find_sym_tab (char *);
cb_Integer get_cur_loc (void);
cb_Integer get_data_size (void);
cb_Integer is_alpha (char *);
cb_Integer is_binary_operator (cb_Integer);
cb_Integer is_in_sym_tab (char *,long);
cb_Integer is_numeric (char *);
cb_Integer is_print (char *);
cb_Integer is_relational_operator (cb_Integer);
cb_Integer search_key_words (char *);
cb_Integer unary_prec (cb_Integer);
EXTERN_C char cb_PrintFBuf_[(64*0x400<<1)];
cb_Integer sym;
cb_Integer cur_col;
cb_Integer cur_line_num;
cb_Integer error_line;
cb_Integer error_col;
cb_Integer sym_tab_used;
long data_index;
long code_index;
long data_size;
char cur_line[cb_STRING_SIZE];
char cur_ch[cb_STRING_SIZE];
char token[cb_STRING_SIZE];
Key_words key_words_tab[1 + MAX_KEYWORDS];
Symbol_table sym_tab[1 + MAX_SYMTAB];
long code_arr[1 + MAX_CODE];
void cbApp_Terminate (void);
void cbApp_Initialize (void);

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Declarations -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */

/*((((((((((((((  Implementation  ))))))))))))))*/
cb_Integer cb_DEFCALL cb_FilePutS (cb_File* T, const char *b)
{
  register cb_Integer i = cb_StrLen(b);
  if (i>0) if (cb_FileWrite(T,b,i)!=i) i = -1;
  return i;
}
/* MODULE::cb_vfprintf */


cb_Integer cb_vfprintf (cb_File* f,const char * Str1,void* arg)
{
 #define Buf cb_PrintFBuf_
 register cb_Integer i; i = cb_vsnprintf(Buf,sizeof(Buf),Str1,arg,NULL);
 return cb_FileWrite(f,Buf,i);
 #undef Buf
}


__declspec(noinline) cb_Integer cb_CDECL cb_fprintf (cb_File* f,const char * Str1,...)
{
 return cb_vfprintf(f,Str1,cb_CAST(void*,&Str1+1));
}


__declspec(noinline) cb_Integer cb_CDECL cb_PrintF (const char * Str1,...)
{
 cb_Integer cb_retVar_;
 cb_retVar_ = cb_vfprintf(cb_StdOut,Str1,cb_CAST(void*,&Str1+1));
 cb_FileFlush(cb_StdOut);
 return cb_retVar_;
}
/* END MODULE */
/* MODULE::cb_vfscanf */


cb_Integer cb_vfscanf (cb_File* f,const char * Str1,void* arg)
{
 return vfscanf((FILE*)cb_FileHandle(f),Str1,(va_list)arg);
}


__declspec(noinline) cb_Integer cb_CDECL cb_fscanf (cb_File* f,const char * Str1,...)
{
 return cb_vfscanf(f,Str1,&Str1+1);
}


__declspec(noinline) cb_Integer cb_CDECL cb_ScanF (const char * Str1,...)
{
 return cb_vfscanf(cb_StdIn,Str1,&Str1+1);
}
/* END MODULE */

/*((((((((((((((  Code  ))))))))))))))*/


void init_lex (char * filename)
{
 if ((cb_Handle1 = cb_FOpen(filename,"rb"))==NULL) {
  cb_GenErrorMsg(cb_StrJoin(cb_PrintBoxBuffer,"Can't Open: ",filename,NULL));
cb_AbortLabel_0:
  cb_Abort(cbApp_Error.Number, cbApp_Error.Description);
 }
 cur_line_num = 0;
 key_words_tab[1].sym = sym_and;
 key_words_tab[2].sym = sym_do;
 key_words_tab[3].sym = sym_else;
 key_words_tab[4].sym = sym_end;
 key_words_tab[5].sym = sym_halt;
 key_words_tab[6].sym = sym_if;
 key_words_tab[7].sym = sym_integer_var;
 key_words_tab[8].sym = sym_mod;
 key_words_tab[9].sym = sym_not;
 key_words_tab[10].sym = sym_or;
 key_words_tab[11].sym = sym_print;
 key_words_tab[12].sym = sym_then;
 key_words_tab[13].sym = sym_while;
 cb_MemCopy(key_words_tab[1].keyword, "and", 4);
 cb_MemCopy(key_words_tab[2].keyword, "do", 3);
 cb_MemCopy(key_words_tab[3].keyword, "else", 5);
 cb_MemCopy(key_words_tab[4].keyword, "end", 4);
 cb_MemCopy(key_words_tab[5].keyword, "halt", 5);
 cb_MemCopy(key_words_tab[6].keyword, "if", 3);
 cb_MemCopy(key_words_tab[7].keyword, "integer", 8);
 cb_MemCopy(key_words_tab[8].keyword, "mod", 4);
 cb_MemCopy(key_words_tab[9].keyword, "not", 4);
 cb_MemCopy(key_words_tab[10].keyword, "or", 3);
 cb_MemCopy(key_words_tab[11].keyword, "print", 6);
 cb_MemCopy(key_words_tab[12].keyword, "then", 5);
 cb_MemCopy(key_words_tab[13].keyword, "while", 6);
 next_char();
}


void next_line (void)
{
 cur_line[0] = 0;
 cur_ch[0] = 0;
 if (cb_FileEOF(cb_Handle1)) {
  return;
 }
 if ((cb_FStrGet(cb_Handle1, cur_line, NULL, (sizeof(cur_line)==sizeof(void*)) ? cb_STRING_SIZE : sizeof(cur_line)))==NULL) {
  cb_GenErrorMsg("Line Input/Peek From: 'cb_Handle1', has Failed");
cb_AbortLabel_0:
  cb_Abort(cbApp_Error.Number, cbApp_Error.Description);
 }
 cb_StrCat(cur_line, "\012");
 cur_line_num++;
 cb_PrintF("%s\n", (const char*)(cur_line));
 cur_col = 1;
}


void next_char (void)
{
 cur_ch[0] = 0;
 cur_col++;
 if (cur_col>cb_StrLen(cur_line)) {
  next_line();
 }
 if (cur_col<=cb_StrLen(cur_line)) {
  cb_StrMove(cur_ch, cb_Mid(cur_line,cur_col,1));
 }
}


void skip_white_space (void)
{
 do {
  if (cur_ch[0]==0) {
   break;
  }
  if (cb_MemComp(cur_ch," ",1+1)!=0 && cb_ASC1(cur_ch)!=9 && cb_ASC1(cur_ch)!=10) {
   break;
  }
  next_char();
 } while(1);
}


void next_sym (void)
{
 token[0] = 0;
 skip_white_space();
 error_line = cur_line_num;
 error_col = cur_col;
 {  /* Select Case cur_ch */
  if (cur_ch[0]==0) {
   sym = sym_eoi;
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"+",1+1)==0) {
   sym = sym_plus;
   next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"-",1+1)==0) {
   sym = sym_minus;
   next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"*",1+1)==0) {
   sym = sym_multiply;
   next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"/",1+1)==0) {
   sym = sym_divide;
   next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,",",1+1)==0) {
   sym = sym_comma;
   next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"(",1+1)==0) {
   sym = sym_lparen;
   next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,")",1+1)==0) {
   sym = sym_rparen;
   next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"=",1+1)==0) {
   sym = sym_equal;
   next_char();
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"<",1+1)==0) {
   sym = sym_lss;
   next_char();
   if (cb_MemComp(cur_ch,">",1+1)==0) {
    sym = sym_neq;
    next_char();
   }
   else if (cb_MemComp(cur_ch,"=",1+1)==0) {
    sym = sym_leq;
    next_char();
   }
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,">",1+1)==0) {
   sym = sym_gtr;
   next_char();
   if (cb_MemComp(cur_ch,"=",1+1)==0) {
    sym = sym_geq;
    next_char();
   }
   goto EndSelect_0;
  }
  if (cb_MemComp(cur_ch,"\042",1+1)==0) {
   get_string();
   goto EndSelect_0;
  }
  {
   if (is_numeric(cur_ch)) {
    get_digits();
   }
   else if (is_alpha(cur_ch)) {
    get_ident();
   }
   else {
    error_msg(cb_StrJoin(NULL,"unrecognized character: ",cur_ch,NULL));
   }
  }
 }  /* End Select: cur_ch */
 EndSelect_0:;
}


void get_string (void)
{
 cb_Integer start_line;
 sym = sym_string_const;
 token[0] = 0;
 start_line = error_line;
 next_char();
 while(cb_MemComp(cur_ch,"\042",1+1)!=0) {
  if (cur_ch[0]==0) {
   sym = sym_eoi;
   error_msg("eof found in string");
   break;
  }
  if (error_line>start_line) {
   error_msg("string must be on one line");
   break;
  }
  cb_StrCat(token, cur_ch);
  next_char();
 }
 if (cb_MemComp(cur_ch,"\042",1+1)==0) {
  next_char();
 }
}


void get_digits (void)
{
 cb_Integer numeric;
 sym = sym_integer_const;
 numeric = true;
 token[0] = 0;
 do {
  if (is_numeric(cur_ch)) {
   cb_StrCat(token, cur_ch);
  }
  else if (is_alpha(cur_ch)) {
   numeric = false;
  }
  else {
   break;
  }
  next_char();
 } while(1);
}


void get_ident (void)
{
 token[0] = 0;
 while(is_alpha(cur_ch) || is_numeric(cur_ch) || cb_MemComp(cur_ch,"_",1+1)==0) {
  cb_StrCat(token, cur_ch);
  next_char();
 }
 sym = search_key_words(token);
}


cb_Integer search_key_words (char * token)
{
 cb_Integer i;
 for (i=1;i<=cb_UBOUND1(key_words_tab);i++) {
  if (cb_StrComp(token,cb_RTrim(key_words_tab[i].keyword,(void*)-2))==0) {
   return key_words_tab[i].sym;
  }
 }
 return sym_ident;
}


void init_sym_tab (void)
{
 data_index = 1;
 sym_tab_used = 0;
}


cb_Integer get_data_size (void)
{
 return data_index;
}


cb_Integer find_sym_tab (char * ident)
{
 cb_Integer i;
 for (i=1;i<=sym_tab_used;i++) {
  if (cb_StrComp(ident,cb_RTrim(sym_tab[i].ident,(void*)-2))==0) {
   return i;
  }
 }
 return 0;
}


void insert_sym_tab (char * ident)
{
 if (sym_tab_used>=MAX_SYMTAB) {
  error_msg("Symbol table exhausted");
  return;
 }
 if (find_sym_tab(ident)>0) {
  error_msg(cb_StrJoin(NULL,ident," has already been defined",NULL));
  return;
 }
 sym_tab_used++;
 cb_StrMove(sym_tab[sym_tab_used].ident, ident);
 sym_tab[sym_tab_used].data_index = data_index;
 data_index++;
}


cb_Integer is_in_sym_tab (char * ident,long address)
{
 cb_Integer i;
 i = find_sym_tab(ident);
 if (i==0) {
  return false;
 }
 address = sym_tab[i].data_index;
 return true;
}


void init_code (void)
{
 code_index = 1;
}


void set_data_size (long size_to_set)
{
 data_size = size_to_set;
}


cb_Integer get_cur_loc (void)
{
 return code_index;
}


void emit_at (long location,long operand)
{
 code_arr[location] = operand;
}


void emit (long opcode)
{
 if (code_index>=MAX_CODE) {
  error_msg(cb_StrJoin(NULL,"code array exhausted: ",cb_CStrDbl(code_index),NULL));
  return;
 }
 code_arr[code_index] = opcode;
 code_index++;
}


cb_Integer emit2 (long opcode,long operand)
{
 long location;
 location = code_index;
 emit(opcode);
 emit(operand);
 return location;
}


void patch_jmp_to_current (long fix_addr)
{
 emit_at(fix_addr+1,code_index);
}


void list_code (void)
{
 long i;
 long last_code;
 cb_PutS("Code listing...\n");
 last_code = code_index;
 i = 1;
 do {
  {  /* Select Case code_arr[i] */
   if (code_arr[i]==op_halt) {
    cb_PrintF("%lihalt\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_push_int) {
    cb_PrintF("%lipush-int%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==op_push_int_var) {
    cb_PrintF("%lipush-int-var%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==op_stor) {
    cb_PrintF("%listore%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==op_jmp) {
    cb_PrintF("%lijmp%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==op_jz) {
    cb_PrintF("%lijz%li\n", (long)(i), (long)(code_arr[i+1]));
    i++;
    goto EndSelect_1;
   }
   if (code_arr[i]==op_add) {
    cb_PrintF("%liadd\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_sub) {
    cb_PrintF("%lisub\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_mul) {
    cb_PrintF("%limul\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_div) {
    cb_PrintF("%lidiv\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_mod) {
    cb_PrintF("%limod\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_or) {
    cb_PrintF("%lior\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_and) {
    cb_PrintF("%liand\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_neq) {
    cb_PrintF("%lineq\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_equal) {
    cb_PrintF("%liequal\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_lss) {
    cb_PrintF("%lilss\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_leq) {
    cb_PrintF("%lileq\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_gtr) {
    cb_PrintF("%ligtr\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_geq) {
    cb_PrintF("%ligeq\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_neg) {
    cb_PrintF("%lineg\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_not) {
    cb_PrintF("%linot\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_prt_nl) {
    cb_PrintF("%liprint-nl\n", (long)(i));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_prt_str) {
    long operand;
    char st[cb_STRING_SIZE];
    long tmp;
    long tmp2;
    st[0] = 0;
    operand = code_arr[i+1];
    tmp = operand;
    tmp2 = i;
    i++;
    while(operand>0) {
     i++;
     cb_StrCat(st, cb_Chr(code_arr[i]));
     operand--;
    }
    cb_PrintF("%liprint-str%li%s\n", (long)(tmp2), (long)(tmp), (const char*)(st));
    goto EndSelect_1;
   }
   if (code_arr[i]==op_prt_int) {
    cb_PrintF("%liprint-int\n", (long)(i));
    goto EndSelect_1;
   }
   {
    error_msg(cb_StrJoin(NULL,"unexpected opcode ",cb_CStrDbl(code_arr[i])," at position ",cb_CStrDbl(i),NULL));
   }
  }  /* End Select: code_arr[i] */
  EndSelect_1:;
  i++;
 } while(i<last_code);
 cb_PutS("\n");
}


void interpret (void)
{
 long last_code;
 long pc;
 long sp;
 cb_Integer halted;
 long stack[1 + MAX_STACK];
 cb_PrintF("Running... code_index: %s\n", (const char*)(cb_CStrDbl(code_index)));
 last_code = code_index-1;
 halted = false;
 pc = 1;
 sp = data_size;
 do {
  long opcode;
  long operand;
  char st[cb_STRING_SIZE];
  if (pc>last_code) {
   error_msg(cb_StrJoin(NULL,"pc: (",cb_CStrDbl(pc),") > last_code: (",cb_CStrDbl(last_code),")",NULL));
  }
  if (sp<0) {
   error_msg("stack underflow");
  }
  opcode = code_arr[pc];
  pc++;
  {  /* Select Case opcode */
   if (opcode==op_push_int) {
    sp++;
    stack[sp] = code_arr[pc];
    pc++;
    goto EndSelect_1;
   }
   if (opcode==op_push_int_var) {
    sp++;
    stack[sp] = stack[code_arr[pc]];
    pc++;
    goto EndSelect_1;
   }
   if (opcode==op_jz) {
    if (stack[sp]==0) {
     pc = code_arr[pc];
    }
    else {
     pc++;
    }
    sp--;
    goto EndSelect_1;
   }
   if (opcode==op_stor) {
    stack[code_arr[pc]] = stack[sp];
    sp--;
    pc++;
    goto EndSelect_1;
   }
   if (opcode==op_jmp) {
    pc = code_arr[pc];
    goto EndSelect_1;
   }
   if (opcode==op_add) {
    sp--;
    stack[sp] = stack[sp] + stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_sub) {
    sp--;
    stack[sp] = stack[sp] - stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_mul) {
    sp--;
    stack[sp] = stack[sp]*stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_div) {
    sp--;
    if (stack[sp+1]==0) {
     error_msg("divide by zero");
    }
    stack[sp] = cb_INT(stack[sp]/stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==op_mod) {
    sp--;
    if (stack[sp+1]==0) {
     error_msg("divide by zero");
    }
    stack[sp] = cb_INT(stack[sp] % stack[sp+1]);
    goto EndSelect_1;
   }
   if (opcode==op_or) {
    sp--;
    stack[sp] = stack[sp] | stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_and) {
    sp--;
    stack[sp] = stack[sp] & stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_neq) {
    sp--;
    stack[sp] = stack[sp]!=stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_equal) {
    sp--;
    stack[sp] = stack[sp] = stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_lss) {
    sp--;
    stack[sp] = stack[sp]<stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_leq) {
    sp--;
    stack[sp] = stack[sp]<=stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_gtr) {
    sp--;
    stack[sp] = stack[sp]>stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_geq) {
    sp--;
    stack[sp] = stack[sp]>=stack[sp+1];
    goto EndSelect_1;
   }
   if (opcode==op_neg) {
    stack[sp] = -stack[sp];
    goto EndSelect_1;
   }
   if (opcode==op_not) {
    stack[sp] =  ~stack[sp];
    goto EndSelect_1;
   }
   if (opcode==op_prt_str) {
    operand = code_arr[pc];
    pc++;
    st[0] = 0;
    while(operand>0) {
     cb_StrCat(st, cb_Chr(code_arr[pc]));
     pc++;
     operand--;
    }
    cb_PutS((const char*)(st));
    goto EndSelect_1;
   }
   if (opcode==op_prt_int) {
    cb_PrintF("%li", (long)(stack[sp]));
    sp--;
    goto EndSelect_1;
   }
   if (opcode==op_prt_nl) {
    cb_PutS("\n");
    goto EndSelect_1;
   }
   if (opcode==op_halt) {
    halted = true;
    break;
   }
   {
    error_msg(cb_StrJoin(NULL,"Unknown opcode",cb_CStrDbl(opcode),NULL));
   }
  }  /* End Select: opcode */
  EndSelect_1:;
 } while(!(halted));
 cb_PutS("Finished...\n");
}


void emit_op (cb_Integer symbol)
{
 {  /* Select Case symbol */
  if (symbol==sym_or) {
   emit(op_or);
   goto EndSelect_0;
  }
  if (symbol==sym_and) {
   emit(op_and);
   goto EndSelect_0;
  }
  if (symbol==sym_equal) {
   emit(op_equal);
   goto EndSelect_0;
  }
  if (symbol==sym_neq) {
   emit(op_neq);
   goto EndSelect_0;
  }
  if (symbol==sym_lss) {
   emit(op_lss);
   goto EndSelect_0;
  }
  if (symbol==sym_leq) {
   emit(op_leq);
   goto EndSelect_0;
  }
  if (symbol==sym_gtr) {
   emit(op_gtr);
   goto EndSelect_0;
  }
  if (symbol==sym_geq) {
   emit(op_geq);
   goto EndSelect_0;
  }
  if (symbol==sym_plus) {
   emit(op_add);
   goto EndSelect_0;
  }
  if (symbol==sym_minus) {
   emit(op_sub);
   goto EndSelect_0;
  }
  if (symbol==sym_multiply) {
   emit(op_mul);
   goto EndSelect_0;
  }
  if (symbol==sym_divide) {
   emit(op_div);
   goto EndSelect_0;
  }
  if (symbol==sym_mod) {
   emit(op_mod);
   goto EndSelect_0;
  }
  if (symbol==sym_neg) {
   emit(op_neg);
   goto EndSelect_0;
  }
  if (symbol==sym_not) {
   emit(op_not);
  }
 }  /* End Select: symbol */
 EndSelect_0:;
}


void expect (cb_Integer symbol)
{
 if (symbol==sym) {
  next_sym();
 }
 else {
  error_msg(cb_StrJoin(NULL,"unexpected token - expected: ",cb_CStrDbl(symbol)," got: ",cb_CStrDbl(sym),NULL));
 }
}


cb_Integer is_binary_operator (cb_Integer symbol)
{
 cb_Integer cb_retVar_;
 cb_retVar_ = true;
 {  /* Select Case symbol */
  if ((symbol==sym_or) || (symbol==sym_and)) {
   goto EndSelect_0;
  }
  if ((symbol==sym_equal) || (symbol==sym_neq)) {
   goto EndSelect_0;
  }
  if ((symbol==sym_lss) || (symbol==sym_leq) || (symbol==sym_gtr) || (symbol==sym_geq)) {
   goto EndSelect_0;
  }
  if ((symbol==sym_plus) || (symbol==sym_minus)) {
   goto EndSelect_0;
  }
  if ((symbol==sym_multiply) || (symbol==sym_divide) || (symbol==sym_mod)) {
   goto EndSelect_0;
  }
  {
   cb_retVar_ = false;
  }
 }  /* End Select: symbol */
 EndSelect_0:;
 return cb_retVar_;
}


cb_Integer is_relational_operator (cb_Integer symbol)
{
 cb_Integer cb_retVar_;
 cb_retVar_ = true;
 {  /* Select Case symbol */
  if ((symbol==sym_equal) || (symbol==sym_neq)) {
   goto EndSelect_0;
  }
  if ((symbol==sym_lss) || (symbol==sym_leq) || (symbol==sym_gtr) || (symbol==sym_geq)) {
   goto EndSelect_0;
  }
  {
   cb_retVar_ = false;
  }
 }  /* End Select: symbol */
 EndSelect_0:;
 return cb_retVar_;
}


cb_Integer unary_prec (cb_Integer symbol)
{
 cb_Integer cb_retVar_ = {0};
 {  /* Select Case symbol */
  if ((symbol==sym_neg) || (symbol==sym_not)) {
   cb_retVar_ = 70;
   goto EndSelect_0;
  }
  {
   cb_retVar_ = 0;
  }
 }  /* End Select: symbol */
 EndSelect_0:;
 return cb_retVar_;
}


cb_Integer binary_prec (cb_Integer symbol)
{
 cb_Integer cb_retVar_ = {0};
 {  /* Select Case symbol */
  if ((symbol==sym_multiply) || (symbol==sym_divide) || (symbol==sym_mod)) {
   cb_retVar_ = 60;
   goto EndSelect_0;
  }
  if ((symbol==sym_plus) || (symbol==sym_minus)) {
   cb_retVar_ = 50;
   goto EndSelect_0;
  }
  if ((symbol==sym_lss) || (symbol==sym_leq) || (symbol==sym_gtr) || (symbol==sym_geq)) {
   cb_retVar_ = 40;
   goto EndSelect_0;
  }
  if ((symbol==sym_equal) || (symbol==sym_neq)) {
   cb_retVar_ = 30;
   goto EndSelect_0;
  }
  if (symbol==sym_or) {
   cb_retVar_ = 20;
   goto EndSelect_0;
  }
  if (symbol==sym_and) {
   cb_retVar_ = 10;
   goto EndSelect_0;
  }
  {
   cb_retVar_ = 0;
  }
 }  /* End Select: symbol */
 EndSelect_0:;
 return cb_retVar_;
}


cb_Integer associativity (cb_Integer symbol)
{
 return left_assoc;
}


void primary (void)
{
 long num;
 long junk;
 {  /* Select Case sym */
  if (sym==sym_integer_const) {
   num = cb_AtoL(token);
   junk = emit2(op_push_int,num);
   next_sym();
   goto EndSelect_0;
  }
  if (sym==sym_ident) {
   long address;
   if (!is_in_sym_tab(token,address)) {
    error_msg(cb_StrJoin(NULL,"primary: ",token," has not been defined",NULL));
   }
   junk = emit2(op_push_int_var,address);
   next_sym();
   goto EndSelect_0;
  }
  if (sym==sym_lparen) {
   next_sym();
   expr(0);
   if (sym!=sym_rparen) {
    error_msg("expecting ')'");
   }
   next_sym();
   goto EndSelect_0;
  }
  if ((sym==sym_minus) || (sym==sym_not)) {
   cb_Integer op;
   op = sym;
   if (sym==sym_minus) {
    op = sym_neg;
   }
   next_sym();
   expr(unary_prec(op));
   emit_op(op);
   goto EndSelect_0;
  }
  {
   error_msg("expecting number");
  }
 }  /* End Select: sym */
 EndSelect_0:;
}


void expr (cb_Integer p)
{
 primary();
 while(is_binary_operator(sym) && binary_prec(sym)>=p) {
  cb_Integer op;
  long tmp;
  op = sym;
  next_sym();
  tmp = 0;
  if (associativity(op)==left_assoc) {
   tmp = 1;
  }
  expr(binary_prec(op) + tmp);
  emit_op(op);
  if (is_relational_operator(op) && is_relational_operator(sym)) {
   error_msg("consecutive relational operators not allowed");
  }
 }
}


void assign_stmt (void)
{
 long address;
 long junk;
 if (!is_in_sym_tab(token,address)) {
  error_msg(cb_StrJoin(NULL,"assign: ",token," has not been defined",NULL));
 }
 expect(sym_ident);
 expect(sym_equal);
 expr(0);
 junk = emit2(op_stor,address);
}


void if_stmt (void)
{
 long fix1;
 long fix2;
 fix2 = -1;
 expect(sym_if);
 expr(0);
 fix1 = emit2(op_jz,0);
 expect(sym_then);
 stmt_seq();
 if (sym==sym_else) {
  fix2 = emit2(op_jmp,0);
  patch_jmp_to_current(fix1);
  expect(sym_else);
  stmt_seq();
 }
 else {
  patch_jmp_to_current(fix1);
 }
 expect(sym_end);
 expect(sym_if);
 if (fix2!=-1) {
  patch_jmp_to_current(fix2);
 }
}


void halt_stmt (void)
{
 emit(op_halt);
 next_sym();
}


void while_stmt (void)
{
 long top;
 long fix1;
 long junk;
 expect(sym_while);
 top = get_cur_loc();
 expr(0);
 fix1 = emit2(op_jz,0);
 expect(sym_do);
 stmt_seq();
 junk = emit2(op_jmp,top);
 patch_jmp_to_current(fix1);
 expect(sym_end);
 expect(sym_while);
}


void do_string (void)
{
 cb_Integer i;
 for (i=1;i<=cb_StrLen(token);i++) {
  emit(cb_ASC1(cb_Mid(token,i,1)));
 }
 next_sym();
}


void print_stmt (void)
{
 long junk;
 do {
  next_sym();
  if (sym==sym_string_const) {
   junk = emit2(op_prt_str,cb_StrLen(token));
   do_string();
  }
  else if (sym==sym_integer_const || sym==sym_ident) {
   expr(0);
   emit(op_prt_int);
  }
  else {
   error_msg("expecting string or integer");
  }
 } while(sym==sym_comma);
 emit(op_prt_nl);
}


void stmt_seq (void)
{
 while(sym!=sym_eoi && sym!=sym_end && sym!=sym_else) {
  {  /* Select Case sym */
   if (sym==sym_print) {
    print_stmt();
    goto EndSelect_1;
   }
   if (sym==sym_halt) {
    halt_stmt();
    goto EndSelect_1;
   }
   if (sym==sym_if) {
    if_stmt();
    goto EndSelect_1;
   }
   if (sym==sym_while) {
    while_stmt();
    goto EndSelect_1;
   }
   if (sym==sym_ident) {
    assign_stmt();
    goto EndSelect_1;
   }
   {
    error_msg(cb_StrJoin(NULL,"unrecognized statement: (",cb_CStrDbl(sym),") ",token,NULL));
   }
  }  /* End Select: sym */
  EndSelect_1:;
 }
}


void variable_decl (void)
{
 while(sym==sym_integer_var) {
  expect(sym_integer_var);
  do {
   long address;
   if (is_in_sym_tab(token,address)) {
    error_msg(cb_StrJoin(NULL,token," has already been defined",NULL));
   }
   insert_sym_tab(token);
   expect(sym_ident);
   if (sym!=sym_comma) {
    break;
   }
   expect(sym_comma);
  } while(1);
 }
}


void parse (void)
{
 next_sym();
 variable_decl();
 stmt_seq();
 if (sym!=sym_eoi) {
  error_msg("a statement was expected");
 }
 emit(op_halt);
 set_data_size(get_data_size());
}


void error_msg (char * msg)
{
 cb_Integer junk;
 cb_PrintF("%i%i%s\n", (cb_Integer)(error_line), (cb_Integer)(error_col), (const char*)(msg));
 press_a_key();
 cb_End(0);
}


cb_Integer is_alpha (char * ch)
{
 return ((ch[0]!=0) && cb_ASC1(cb_UCase(ch))>=0x41 && cb_ASC1(cb_UCase(ch))<=0x5A);
}


cb_Integer is_print (char * ch)
{
 return ((ch[0]!=0) && cb_ASC1(ch)>=32 && cb_ASC1(ch)<=126);
}


cb_Integer is_numeric (char * ch)
{
 return (cb_ASC1(ch)>=0x30 && cb_ASC1(ch)<=0x39);
}


void press_a_key (void)
{
 cb_Integer junk;
 cb_PutS("Press enter");
 cb_ScanF("%i", &(junk));
}

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Implementation -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


void cbApp_Terminate (void)
{
 CodeBase_Terminate();
}


void cbApp_Initialize (void)
{
 cbApp_FindData.FileHandle = INVALID_HANDLE_VALUE;
 if (!cbApp_Argv) cbApp_Argv = cb_CommandLineToArgvA(&cbApp_Argc);
 cb_OnEnd(&cbApp_Terminate);
 cb_FileInitialize();
}

/*((((((((((((((  Entry Function  ))))))))))))))*/

cb_Integer cb_CDECL main (cb_Integer argc, char** argv)
{
 cbApp_Initialize();
 char filename[cb_STRING_SIZE];
 cb_StrMove(filename, cb_Command());
 if (filename[0]==0) {
  cb_PutS("enter filename: ");
  cb_ScanF("%s", filename);
 }
 if (filename[0]==0) {
  cb_End(0);
 }
 init_sym_tab();
 init_code();
 init_lex(filename);
 parse();
 if (cb_Handle1!=NULL) {
  if (cb_FileClose(cb_Handle1)==-1) {
   cb_GenErrorMsg("Close File Failed on: 'cb_Handle1'");
cb_AbortLabel_0:
   cb_Abort(cbApp_Error.Number, cbApp_Error.Description);
  }
  cb_Handle1 = NULL;
 }
 list_code();
 interpret();
 press_a_key();

 return 0;
}
