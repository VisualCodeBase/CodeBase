this project doesn't use dialect directive, it is compiled in the default dialect.
so we needed to tweak it a little.

using the dialect directive, those tweaks may not required, but then there would be a problem
with bycopy, which is uncomplete yet.

the problem with bycopy is that microsoft basic's use byref args by default,
but many sources don't actually need byref, only byval, and since many programmers lazy to write byval,
there for they pass invalid byref vars, like consts, pointer expressions, etc...
in these cases the microsoft compilers make bycopy of those and then pass their address to the function.

codebase will surely support this in the future since it commonly used in vb6 files.

NOTE: although this project compiles well, it doesn't actually run well because some more changes that should been made,
  mainly expressions which involved strings.