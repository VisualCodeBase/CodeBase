the support for basic dialects other than VB6 is work in progress.
although sources of other dialects may work when transferring them to a VB6 like module,
we'll try to support them like VB6, with as least modifications as possible.