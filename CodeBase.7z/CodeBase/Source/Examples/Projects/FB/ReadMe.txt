
the support for basic dialects other than VB6 is work in progress.
although sources of other dialects may work when transferring them to a VB6 like module,
we'll try to support them like VB6, with as least modifications as possible.

the project:

* toy - which we haven't change the original source at all!
  it compiles inside a vb module, with almost all the basic rules
  (except of byref, which as with many basic sources is not required here).

  some missing support mainly vb file handling will be implemented soon.

  * * * note: the missing things are implemented now, and the project compiles and run well
          with ZERO changes to the original source, and with all the basic rules.
          there might be some minor printing and input differents behave that need to be implemented.

* Note: ByCopy can work only with -fpermissive gpp.exe flag,
  if you build a project in the ide, be sure to set this flag in the project build settings.
  for example look at 'toy.cbp' .
  when building via the command line, it's not required. codebase set it for you.