
the support for basic dialects other than VB6 is work in progress.
although sources of other dialects may work when transferring them to a VB6 like module,
we'll try to support them like VB6, with as least modifications as possible.

there are two projects:

* toybasic - which we did some (unfinished) tweaks and it compiles with the default dialect

* toy - which we haven't change the original source at all!
  it compiles inside a vb module, with almost all the basic rules
  (except of byref, which as with many basic sources it isn't required here).

  some missing support mainly vb file handling will be implemented soon.