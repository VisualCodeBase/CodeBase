
this is TALE mono/poly_synth.
it's quite big effect which conatins several (nested) import libs.

two libs had to have two tiny changes:
  one removing unused arguemnt.
  the other, moving all instances to first overloaded function.

it doesn't functional correct now, sorry.
