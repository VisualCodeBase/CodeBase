
this is argee arp which is a gui modification of whatsup & argee arp.

the gui of the other arp is also by argee.

we fixed the engine code according to the changes in the original arp.

we didn't tested yet. it may or may not require more changes.

the other arp tested and found to work as expected.

the file was divided for better read and for test purpose.