there is a known bug in this effect, we didn't have time to fix it yet.
the other arp has no known bugs.
