this plug belong to Cockos, it seems they forgot to licence it.
we cannot licence it because it's not our, we didn't touch the code at ALL!
we only use it for example showing what pvf/newtron can do with Cockos sources.