this plug belong to Cockos, it seems they forgot to licence it.
we cannot licence it because it's not our, we didn't touch the code at ALL!

pvf/newtron compiles it to an optimized VST plugin, with ZERO required modification.
