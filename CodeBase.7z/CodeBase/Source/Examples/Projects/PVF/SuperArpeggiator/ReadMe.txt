
this is whatsup & argee arp.
it was started from Cockos-Reaper arp, and were totally changed + extened.
it is the last update from whatsup.

pvf/newtron compiles it to an optimized VST plugin, with ZERO required modification.
