
only one project had to have tiny changes.
the appmodechange - it uses byref const, and the bycopy doesn't implemented yet,
so we added byval.

NOTE : the above is history, it's implemented, so the project require ZERO modifications.

also the common dialog (and other userclasses), don't fully work when declaring them in the form header,
but work well as vars, so we declared it as a variable.

hopefully in the future those changes may not be required.

* * * Note: the last three lines is history now. it is implemented!

* Note: ByCopy can work only with -fpermissive gpp.exe flag. it was updated in the project file.

the ide.bat is for testing the console.exe after it has been changed to console app.

the project with the '_new' suffix has no changes to the original source.
  it has some few additions, for test purpose only!

-------------------------------------------------------

note:
  every app that has no form will be a console app,
  so this appmodechange is not required with CodeBase,
  but you can still test it with gui app, and see that it works correctly.

note:
  in the console app, the vb project and its files hasn't changed at all.
  we only added a pause statement in the main project file without touching the vb sources nore the vb project file.

note:
  the components on a form may not be exactly in the same size/location as vb generates them.
  this hopefully will be solved in the future.