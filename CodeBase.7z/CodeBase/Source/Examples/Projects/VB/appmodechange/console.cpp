/*    CodeBase - Compiler Frontend To C++ - (Version 1.00)    */
/*    Copyright � SoftBase Labs.  MIT    */

//CommandLine:
//-s -c console

#define __CODEBASE__
#if defined(__GNUC__) || defined(__GNUG__)
#define _NO_OLDNAMES
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0502
#endif
#ifndef _WIN32_IE
#define _WIN32_IE 0x0502
#endif
#ifndef WINVER
#define WINVER 0x0502
#endif
#else

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif
#ifndef _WIN32_IE
#define _WIN32_IE 0x0600
#endif
#ifndef WINVER
#define WINVER 0x0600
#endif
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ctype.h>
#include <fcntl.h>
#ifdef _MSC_VER
#define _USE_MATH_DEFINES
#endif
#include <math.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <wctype.h>
#include <sys/stat.h>
#include <conio.h>
#include <direct.h>
#include <io.h>
#ifdef cb_USE_COM
#include <shellapi.h>
#include <objbase.h>
#include <oaidl.h>
#include <shlobj.h>
#endif
#include <wchar.h>
#if defined(__GNUC__) || defined(__GNUG__) || defined(__clang__)
#endif

/*-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-*/
#include <CodeBase.h>
/*-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-*/

#define cb_End exit
#define cb_OnEnd atexit
#define cb_IsAlpha isalpha
#define cb_IsAlphaW iswalpha
#define cb_IsDigit isdigit
#define cb_IsDigitW iswdigit
#define cb_IsAlphaDigit isalnum
#define cb_IsAlphaDigitW iswalnum
#define cb_IsSpace isspace
#define cb_IsSpaceW iswspace
#define cb_IsLower islower
#define cb_IsLowerW iswlower
#define cb_IsUpper isupper
#define cb_IsUpperW iswupper
#define cb_IsSpace isspace
#define cb_IsSpaceW iswspace
#define cb_MemChr memchr
#define cb_MemChrW wmemchr
#define cb_MemSet memset
#define cb_MemSetW wmemset
#define cb_MemCopy memcpy
#define cb_MemCopyW wmemcpy
#define cb_MemMove memmove
#define cb_MemMoveW wmemmove
#define cb_StrLen strlen
#define cb_StrLenW wcslen
#define cb_AtoF(x,y) strtof(x,y)
#define cb_AtoD(x,y) strtod(x,y)
#define cb_AtoLD(x,y) strtold(x,y)
#define cb_Ceil ceil
#define cb_Ceilf ceilf
#define cb_Ceill ceill
#define cb_Floor floor
#define cb_Floorf floorf
#define cb_Floorl floorl
#define cb_FMod fmod
#define cb_FModf fmodf
#define cb_FModl fmodl
#define cb_ModF modf
#define cb_ModFf modff
#define cb_ModFl modfl
#define cb_Pow pow
#define cb_Powf powf
#define cb_Powl powl
#define cb_Trunc trunc
#define cb_Truncf truncf
#define cb_Truncl truncl
#define cb_SQR(x,y) pow(x,(double)1.0/(double)(y))
#define cb_SQRF(x,y) powf(x,(float)1.0/(float)(y))
#define cb_SQRLD(x,y) powl(x,(long double)1.0/(long double)(y))
#define cb_Rand rand
#define cb_Randomize srand
#define cb_ChDir _chdir
#define cb_ChDrive _chdrive
#define cb_ChMod _chmod
#define cb_GetDrive _getdrive
#define cb_MkDir _mkdir
#define cb_RmDir _rmdir
#define cb_Remove remove
#define cb_RemoveW wremove
#define cb_Rename !rename
#define cb_RenameW !wrename
#define cb_CLEAR1(x) cb_MemSet(&(x),0,sizeof(x))
cb_BeginExternC
EXTERN_C cb_Integer  cbApp_Argc;
EXTERN_C char**  cbApp_Argv;
EXTERN_C char  *cb_TmpDynStrPtrBuf_ [cb_MAX_TMPDYNSTR_CYCLES_];
EXTERN_C cb_Integer  cb_TmpDynStrCyclesMax_;
EXTERN_C cb_Integer  cb_TmpDynStrCyclesFlag;
EXTERN_C cb_Integer  cb_TmpDynStrCyclesCnt_;
EXTERN_C char  *cb_CommandLinePtr;
EXTERN_C cb_FIND_DATA  cbApp_FindData;
EXTERN_C cb_File*  cb_StdIn;
EXTERN_C cb_File*  cb_StdErr;
EXTERN_C cb_File*  cb_StdOut;
cb_EndExternC
cb_BeginExternC
char*  cb_CDECL  cb_StrJoin (void*, ...);
void  cb_FileInitialize (void);
cb_Integer  cb_DEFCALL  cb_FileFlush (cb_File*);
cb_UInteger  cb_DEFCALL  cb_FileWrite (cb_File*, const void*, cb_UInteger);
cb_Integer  cb_DEFCALL  cb_FilePutS (cb_File*, const char*);
void  cb_DEFCALL  cb_Wait (const char* =NULL);
const void*  cb_DEFCALL  cb_LoadDllFunc (const char*, const char*, void* =NULL, HMODULE* =NULL);
cb_Integer  cb_DEFCALL  cb_CallAnyFunction (const void*, cb_Integer=0, const void* =NULL);
char*  cb_DEFCALL  cb_Command (cb_Integer=-1,void* =NULL,cb_Integer=0);
char **  cb_DEFCALL  cb_CommandLineToArgvA (cb_Integer* =NULL,void* =NULL,void* =NULL);
cb_EndExternC
#include "D:/Programming/CodeBase/Include/vb_Def.h"
#include <cEachFile.h>
#include "D:/Programming/CodeBase/Source/Lib/Classes/All/EachFile/cEachFile.h"
#include <cString.h>
#include "D:/Programming/CodeBase/Source/Lib/Classes/All/String/cString.h"
#define Module1_STD_OUTPUT_HANDLE -11

enum {
 id_Module1 = 1
};

static HMODULE cbGUI_kernel32_lib_;
static signed int Module1_GetStdHandle (long);
static cb_Boolean Module1_WriteToConsole (char *);
static void Module1_Initialize (void);
static void Module1_Terminate (void);
#define Module1_Create Module1_Initialize
#define Module1_Destroy Module1_Terminate
void cbApp_Terminate (void);
void cbApp_Initialize (void);

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Declarations -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */

/*((((((((((((((  Implementation  ))))))))))))))*/
cb_Integer cb_DEFCALL cb_FilePutS (cb_File* T, const char *b)
{
  register cb_Integer i = cb_StrLen(b);
  if (i>0) if (cb_FileWrite(T,b,i)!=i) i = -1;
  return i;
}

/*((((((((((((((  Code  ))))))))))))))*/
static long Module1_hOutput;
#define cb_vbCBOOL(x) ((x)?-1:0)
static const void* Module1_GetStdHandlePtr_;


static __declspec(noinline) signed int Module1_GetStdHandle (long nStdHandle)
{
 if (!(Module1_GetStdHandlePtr_)) {
  Module1_GetStdHandlePtr_ = cb_LoadDllFunc("GetStdHandle","kernel32",NULL,&cbGUI_kernel32_lib_);
  if (!(Module1_GetStdHandlePtr_)) {
   return 0;
  }
 }
 return cb_CallAnyFunction(Module1_GetStdHandlePtr_,1,(const void*)&nStdHandle);
}
static const void* Module1_WriteFilePtr_;


static signed int Module1_WriteFile (long,void*,long,long*,void*);

static __declspec(noinline) signed int Module1_WriteFile (long hFile,void* lpBuffer,long nNumberOfBytesToWrite,long* lpNumberOfBytesWritten,void* lpOverlapped)
{
 if (!(Module1_WriteFilePtr_)) {
  Module1_WriteFilePtr_ = cb_LoadDllFunc("WriteFile","kernel32",NULL,&cbGUI_kernel32_lib_);
  if (!(Module1_WriteFilePtr_)) {
   return 0;
  }
 }
 return cb_CallAnyFunction(Module1_WriteFilePtr_,5,(const void*)&hFile);
}

typedef struct cb_s_Module1_COORD_ {
 short x;
 short y;
} Module1_COORD;


typedef struct cb_s_Module1_SMALL_RECT_ {
 short Left;
 short Top;
 short Right;
 short Bottom;
} Module1_SMALL_RECT;


typedef struct cb_s_Module1_CONSOLE_SCREEN_BUFFER_INFO_ {
 struct cb_s_Module1_COORD_ dwSize;
 struct cb_s_Module1_COORD_ dwCursorPosition;
 short wAttributes;
 struct cb_s_Module1_SMALL_RECT_ srWindow;
 struct cb_s_Module1_COORD_ dwMaximumWindowSize;
} Module1_CONSOLE_SCREEN_BUFFER_INFO;

static const void* Module1_GetConsoleScreenBufferInfoPtr_;


static signed int Module1_GetConsoleScreenBufferInfo (long,Module1_CONSOLE_SCREEN_BUFFER_INFO*);

static __declspec(noinline) signed int Module1_GetConsoleScreenBufferInfo (long hConsoleOutput,Module1_CONSOLE_SCREEN_BUFFER_INFO* lpConsoleScreenBufferInfo)
{
 if (!(Module1_GetConsoleScreenBufferInfoPtr_)) {
  Module1_GetConsoleScreenBufferInfoPtr_ = cb_LoadDllFunc("GetConsoleScreenBufferInfo","kernel32",NULL,&cbGUI_kernel32_lib_);
  if (!(Module1_GetConsoleScreenBufferInfoPtr_)) {
   return 0;
  }
 }
 return cb_CallAnyFunction(Module1_GetConsoleScreenBufferInfoPtr_,2,(const void*)&hConsoleOutput);
}
static const void* Module1_SetConsoleTextAttributePtr_;


static signed int Module1_SetConsoleTextAttribute (long,long);

static __declspec(noinline) signed int Module1_SetConsoleTextAttribute (long hConsoleOutput,long wAttributes)
{
 if (!(Module1_SetConsoleTextAttributePtr_)) {
  Module1_SetConsoleTextAttributePtr_ = cb_LoadDllFunc("SetConsoleTextAttribute","kernel32",NULL,&cbGUI_kernel32_lib_);
  if (!(Module1_SetConsoleTextAttributePtr_)) {
   return 0;
  }
 }
 return cb_CallAnyFunction(Module1_SetConsoleTextAttributePtr_,2,(const void*)&hConsoleOutput);
}
#define Module1_FOREGROUND_BLUE 0x1
#define Module1_FOREGROUND_GREEN 0x2
#define Module1_FOREGROUND_INTENSITY 0x8
#define Module1_FOREGROUND_RED 0x4


static cb_Boolean Module1_WriteToConsole (char * sText)
{
 cb_Boolean cb_retVar_ = {0};
 long lWritten;
 if (cb_vbCBOOL(Module1_WriteFile(Module1_hOutput,sText,cb_StrLen(sText),&lWritten,0)==0)) {
  cb_retVar_ = FALSE;
 }
 else {
  cb_retVar_ = vbTrue;
 }
 return cb_retVar_;
}


static void Module1_Initialize (void)
{
}


static void Module1_Terminate (void)
{
}


static void cbGUI_FreeLibs_ (void);

static void cbGUI_FreeLibs_ (void)
{
 if (cbGUI_kernel32_lib_) { FreeLibrary(cbGUI_kernel32_lib_); cbGUI_kernel32_lib_ = NULL; }
}

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Implementation -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


void cbApp_Terminate (void)
{
 cbGUI_FreeLibs_();
 CodeBase_Terminate();
}


void cbApp_Initialize (void)
{
 cbApp_FindData.FileHandle = INVALID_HANDLE_VALUE;
 if (!cbApp_Argv) cbApp_Argv = cb_CommandLineToArgvA(&cbApp_Argc);
 cb_OnEnd(&cbApp_Terminate);
 cb_FileInitialize();
}

/*((((((((((((((  Entry Function  ))))))))))))))*/

cb_Integer cb_CDECL main (cb_Integer argc, char** argv)
{
 cbApp_Initialize();
 Module1_CONSOLE_SCREEN_BUFFER_INFO scrbuf;
 Module1_hOutput = Module1_GetStdHandle(Module1_STD_OUTPUT_HANDLE);
 Module1_GetConsoleScreenBufferInfo(Module1_hOutput,&scrbuf);
 Module1_WriteToConsole("Console Application Example In Visual Basic." "\r\n");
 Module1_WriteToConsole("Written by Nir Sofer" "\r\n");
 Module1_WriteToConsole("Web site: http://nirsoft.mirrorz.com" "\r\n" "\r\n");
 Module1_SetConsoleTextAttribute(Module1_hOutput,Module1_FOREGROUND_BLUE | Module1_FOREGROUND_INTENSITY);
 Module1_WriteToConsole("Blue Color !!" "\r\n");
 Module1_SetConsoleTextAttribute(Module1_hOutput,Module1_FOREGROUND_RED | Module1_FOREGROUND_GREEN | Module1_FOREGROUND_INTENSITY);
 Module1_WriteToConsole("Yellow Color !!" "\r\n");
 Module1_SetConsoleTextAttribute(Module1_hOutput,scrbuf.wAttributes);
 if (cb_vbCBOOL(cb_StrLen(cb_Command())!=0)) {
  Module1_WriteToConsole(cb_StrJoin(NULL,"\r\n" "Command Line Parameters: ",cb_Command(),"\r\n",NULL));
 }
 cb_Wait();

 return 0;
}
