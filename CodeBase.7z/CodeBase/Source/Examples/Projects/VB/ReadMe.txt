
only one project had to have tiny changes.
the appmodechange - it uses byref const, and the bycopy doesn't implemented yet,
so we added byval.

also the common dialog (and other userclasses), don't fully work when declaring them in the form header,
but work well as vars, so we declared it as a variable.


hopefully in the future those changes may not be required.

the ide.bat is for testing the console.exe after it has been changed to console app.

-------------------------------------------------------

note:
 every app that has no form will be a console app,
 so this appmodechange is not required with CodeBase,
 but you can still test it with gui app, and see that it works correctly.

note:
  the components on a form may not be exactly in the same size/location as vb generates them.
  this hopefully will be solved in the future.