this project is not complete.
it's only a start that you can contribute to it.

it was written before new features added (dot lang), so it uses 'dot less' style.

licence - public domain