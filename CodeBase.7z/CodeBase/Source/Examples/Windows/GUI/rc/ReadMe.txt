two different ways to include multiple rc's.

note that in a single multiple dialogs file,
 from the second dialog and down, the dialog statement must appear first.
