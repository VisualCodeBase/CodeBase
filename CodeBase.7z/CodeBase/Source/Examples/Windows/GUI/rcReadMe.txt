This shows a little from the abilty to parse RC files.
first it parses the dialog file named 'frm.rc'.
then it adds some other code like events handling, ...

if you want to see the messages it sends to the std out, then run it from WinDos or from the IDE.