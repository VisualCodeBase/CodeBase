#ifndef CRICHEDITCTRL_H_
#define CRICHEDITCTRL_H_

#ifndef MY_CRICHEDIT
#define MY_CRICHEDIT CRichEditCtrl
#endif

#include <windows.h>
#include <richedit.h>

class MY_CRICHEDIT
{
  // Construction/Destruction
  public:
    // Default constructor
    MY_CRICHEDIT();
    // Default destructor
    virtual ~MY_CRICHEDIT();
    HWND m_hWnd;

    int GetWindowText(MY_CSTRING& s);
    int SetWindowText(MY_CSTRING& s);
    int GetLineCount (void);
    int SetRedraw(int iFlag);
    int GetSel(CHARRANGE& c);
    int GetSel(int& iCur);
    int SetSel(CHARRANGE& c);
    int SetSel(int iStart, int iEnd);
    int LineFromChar(int iChar);
    int SetColorCharFormat(COLORREF cClr/*,int bSel*/);
    int LineScroll(int x, int y);
    int GetFirstVisibleLine(void);
    void Invalidate(int x);
    int KillTimer(int id);
    int GetEventMask(void);
    void SetEventMask(int x);
    int GetLine(int nIndex, MY_CSTRING_CHAR* buf, int nMax);
    void GetSel(int& nStart, int& nEnd);
    MY_CSTRING GetSelText() const;
    int LineIndex();
    void PreSubclassWindow(void);
    int SetDefaultCharFormat(CHARFORMAT& c);
    int SetSelectionCharFormat(CHARFORMAT& c);
    int SetWordCharFormat(CHARFORMAT& c);
    int GetTextRange(int x, int y, MY_CSTRING& s);
    int SetTextRange(int x, int y, MY_CSTRING& s);
    int StreamIn(int iCode, EDITSTREAM& es);
};

#endif
