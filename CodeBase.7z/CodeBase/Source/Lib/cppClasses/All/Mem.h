
#ifndef cppMem_H_
#define cppMem_H_

#ifndef cppMemInt
#define cppMemInt long
#endif

class cppMem
{
  protected:
    void *h;
    cppMemInt sze;

  public:
    void free();

    cppMem() { h=NULL; sze=0; };

    ~cppMem() { free(); }

};
#endif  //cppMem_H_
