
#ifndef cppFile_H_
#define cppFile_H_

#include "String.h"

#ifndef cppFileInt
#define cppFileInt long
#endif

#ifndef cppFileLLong
#define cppFileLLong long long
#endif

class cppFile
{
  protected:
    void *h;
    cppFileInt sze;
    cppFileInt pos;
    cppFileInt flg;
    const cppString *s;

    static cppFile* ios_in_;
    static cppFile* ios_out_;
    static cppFile* ios_err_;

    static cppFile& ios_in;
    static cppFile& ios_out;
    static cppFile& ios_err;

  public:
    cppFile& Open(const char*, const char *);
    cppFile& open(const char* s, const char *f) { return Open(s,f); }
    inline cppFile& open(cppString& str, const char* m) { return open(str.c_str(),m); }
    cppFile& Open(const char*, cppFileInt);
    cppFile& open(const char* s, cppFileInt f) { return Open(s,f); }
    inline cppFile& open(cppString& str, cppFileInt f) { return open(str.c_str(),f); }
    cppFile& Open(void*, cppFileInt=0);
    cppFile& open(void* s, cppFileInt f) { return Open(s,f); }

    cppFile();
    cppFile(const char* n, cppFileInt f) { cppFile(); open(n,f); }
    cppFile(cppString& str, cppFileInt f) { cppFile(); open(str,f); }
    cppFile(const char* n, const char *m) { cppFile(); open(n,m); }
    cppFile(cppString& str, const char *m) { cppFile(); open(str,m); }
    cppFile(void* o,cppFileInt f=0) { cppFile(); open(o,f); }

    inline void Close();
    inline void close() { Close(); }
    ~cppFile();

    inline void* c_file() { return h; }
    inline cppFileInt is_open() { return (cppFileInt)h; }
    cppFileInt seek(cppFileInt, cppFileInt);
    cppFileInt fseek(cppFileInt, cppFileInt);
    inline cppFileInt seekg(cppFileInt p, cppFileInt n) { return seek(p,n); }
    cppFileInt tell();
    inline cppFileInt tellg() { return tell(); }
    cppFileInt len();
    cppFileLLong seek64(cppFileLLong, cppFileInt);
    cppFileLLong fseek64(cppFileLLong, cppFileInt);
    cppFileLLong tell64();
    cppFileLLong len64();
    inline cppFileInt Read(void*, cppFileInt);
    inline cppFileInt Write(void*, cppFileInt);
    inline cppFileInt read(void* b, cppFileInt n) { return Read(b,n); }
    inline cppFileInt write(void* b, cppFileInt n) { return Write(b,n); }

    enum { SeekBegin, SeekCurrent, SeekEnd };

    enum {
      modeRead
    };
};

#endif  //cppFile_H_
