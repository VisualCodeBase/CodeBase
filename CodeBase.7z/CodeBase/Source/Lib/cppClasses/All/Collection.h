
#ifndef __cppCollection_H__
#define __cppCollection_H__

#ifndef cppCollectionInt
#define cppCollectionInt long
#endif

#ifndef cppCollectionUInt
#define cppCollectionUInt unsigned long
#endif

class cppCollection
{
public:
    cppCollection();
    ~cppCollection();
    cppCollectionInt GetSize();
    const void * GetAt(cppCollectionInt);
    const void * PutAt(const void*,cppCollectionInt);
    cppCollectionInt InsertAt(const void*,cppCollectionInt);
    cppCollectionInt Add(const void*);
    cppCollectionInt GetUpperBound();
    void Remove(cppCollectionInt);
    void RemoveAll();

protected:
    const void **Buf;
    cppCollectionInt iCnt;
};

#endif
