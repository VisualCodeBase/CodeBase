
#ifndef __cppStringArray_H__
#define __cppStringArray_H__

#include "Collection.h"
#include "String.h"

#ifndef cppStringArrayInt
#define cppStringArrayInt long
#endif

class cppStringArray : public cppCollection
{
public:
	cppStringArray();
	cppString& GetAt(cppStringArrayInt);
};

#endif
