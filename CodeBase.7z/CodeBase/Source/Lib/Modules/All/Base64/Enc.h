
char* cb_DEFCALL cb_Base64_Encode(const char*, char*, cb_Integer=0, cb_Integer* =NULL);