			     Dial - Release Notes


------------------------------------------------------------------------
     Copyright � 1998 Microsoft Corporation.  All rights reserved.

You have a royalty-free right to use, modify, reproduce and distribute
the Sample Application Files (and/or any modified version) in any way
you find useful, provided that you agree that Microsoft has no warranty,
obligations or liability for any Sample Application Files.
------------------------------------------------------------------------


Contents
========
1.  Introduction
2.  Maintaining Version Compatibility
3.  Definitions
4.  Usage
5.  Known Problems


1.  Introduction
================
Dial is a user-control that provides the functionality similar to a 
stereo volume knob, or can also be thought of as a "round slider" 
control.  The control is used to change values by "grabbing" the dial 
by click-and-hold with the left mouse button, and turning the dial.  
Turning the dial clockwise increases the value, and turning 
counter-clockwise decreases the value.


2.  Maintaining Version Compatibility
=====================================

This control relies upon Version Compatibility.

The broader subject of Version Compatibility is discussed in 
"Versioning Issues for Controls" and "When Should I Use Version 
Compatibility?" in Books Online.

To access Books Online:
1. Click the Help command.
2. Select Books Online...

To Find the information:
1. Click the binoculars icon.
2. In the Find pane, type "version compatibility" -- including the 
quote marks.

Users of Version Compatibility may also find it helpful to read the 
Online Help topic "Permission Denied or Unexpected Error when 
compiling OCX or DLL (ReadMe)."  Search the Help Index for Project 
Properties Dialog Box.

If you're using the Control Creation Edition of Visual Basic, you 
don't have access to Books Online.  You can find the Books Online 
topics referred to here in "Creating an ActiveX Control.doc" and 
"Building ActiveX Controls.doc," which you can download from the 
Control Creation Edition site.

There is also a broader discussion of this issue on our "Visual Basic 
Owner's Area" web site which is available to registered users of 
VB 5.0.  Search for the document entitled "Maintaining Version 
Compatibility".


3.  Definitions
===============
The Dial contains several properties and events.  Each is described 
below:

ColorDial
---------
Sets the OLE-Color of the face of the Dial.  The default value is 
the Button Face color.

ColorShadow
-----------
Sets the OLE-Color of the "shadow", or depth, of the Dial.  The 
default value is the Button Shadow color.

ColorLED
--------
Sets the OLE-Color of the LED indicator on the Dial.  The default 
value is red ... RGB(255,0,0).

Depth
-----
Sets the depth, in twips, of the Dial.  Obviously, a larger value 
makes for a "taller" dial.  However, based on the size of the dial, 
a large value of Depth will take away the 3D effect of the dial.  The 
default value is 25.

Limit
-----
A Boolean that determines if the Dial is limited to one revolution.  
If Limit is set to False, then the Dial can be turned multiple 
revolutions, with each revolution increasing or decreasing the 
Value by (Max - Min).  The default is True.

Min
---
The value at the minimum extreme of the Dial.  The default is 0.

Max
---
The value at the maximum extreme of the Dial.  The default is 100.

Value
-----
A Long which contains current setting of the Dial.  The default is 0.

Changing
--------
An event that fires each time the dial is changed.


4.  Usage
=========
The Dial control can be used in a number of situations.  For example, 
it can be used in most cases where a regular slider control can be 
used.  Examples of implementations include:

Example 1
---------
With Limit=True, the Dial operates as a normal slider control.  The 
Value can be increased and decreased between the limits defined by 
Min and Max.

Example 2
---------
With Limit=False, the Dial can be used to make adjustments to large 
numbers.  For example, use the Dial to adjust the margin of a control.  
Each revolution of the dial increases or decreases the value 
by (Min - Max).  This could allow for "fine tuning" of the number, 
while also allowing for rapid variations also.


5.  Known Problems
==================
1.      The current version determines the LED setting using angles in 
degrees.  Therefore, there can not be more than 360 "continuous" values 
on one revolution.  For example, if Min=0 and Max=720, then Value will 
change in increments of 2, since each angle change is equal to 2 
(720/360).  If greater resolution is needed, then code can be 
written on the user side to address this.  For example, use Min=0 and 
Max=100, and then write code to do a percentage of the required 
number ... "MyNumber = (Value/(Max-Min)) * FullRange".
