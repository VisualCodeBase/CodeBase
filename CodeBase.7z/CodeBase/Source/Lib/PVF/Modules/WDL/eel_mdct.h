#ifndef EEL_MDCT_H_
#define EEL_MDCT_H_


#ifdef __cplusplus
extern "C" {
#endif

extern EEL_F *eel_mdct(EEL_F *start, int length);
extern EEL_F *eel_imdct(EEL_F *start, int length);

#ifdef __cplusplus
};
#endif


#endif
