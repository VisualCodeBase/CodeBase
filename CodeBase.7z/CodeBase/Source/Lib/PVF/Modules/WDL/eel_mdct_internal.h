
#define EEL_DCT_MINBITLEN 5
#define EEL_DCT_MAXBITLEN 12


#ifndef WDL_PI_
#define WDL_PI_ 3.1415926535897932384626433832795
#endif

typedef struct {
  int n;
  int log2n;
  EEL_F *trig;
  int  *bitrev;
  EEL_F *oldw;
  EEL_F scale;
  EEL_F *window;
} mdct_lookup;


// MDCT/iMDCT borrowed from Vorbis, thanks xiph!


#define cPI3_8 .38268343236508977175
#define cPI2_8 .70710678118654752441
#define cPI1_8 .92387953251128675613

#define WDL_MDCT_FLOAT_CONV(x) ((EEL_F) ( x ))
#define WDL_MDCT_MULT_NORM(x) (x)
#define WDL_MDCT_HALVE(x) ((x)*.5f)
