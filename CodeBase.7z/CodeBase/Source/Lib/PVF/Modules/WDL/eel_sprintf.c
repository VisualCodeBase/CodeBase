
#ifndef _eel_sprintf_c_
#define _eel_sprintf_c_

static int eel_validate_format_specifier(const char *fmt_in, char *typeOut,
                                         char *fmtOut, int fmtOut_sz,
                                         char *varOut, int varOut_sz,
                                         int *varOut_used
                                         )
{
  const char *fmt = fmt_in+1;
  int state=0;
  if (fmt_in[0] != '%') return 0; // ugh passed a non-specifier

  *varOut_used = 0;
  *varOut = 0;

  if (fmtOut_sz-- < 2) return 0;
  *fmtOut++ = '%';

  while (*fmt)
  {
    const char c = *fmt++;
    if (fmtOut_sz < 2) return 0;

    if (c == 'f'|| c=='e' || c=='E' || c=='g' || c=='G' || c == 'd' || c == 'u' ||
        c == 'x' || c == 'X' || c == 'c' || c == 'C' || c =='s' || c=='S' || c=='i')
    {
      *typeOut = c;
      fmtOut[0] = c;
      fmtOut[1] = 0;
      return (int) (fmt - fmt_in);
    }
    else if (c == '.')
    {
      *fmtOut++ = c; fmtOut_sz--;
      if (state&(2)) break;
      state |= 2;
    }
    else if (c == '+')
    {
      *fmtOut++ = c; fmtOut_sz--;
      if (state&(32|16|8|4)) break;
      state |= 8;
    }
    else if (c == '-' || c == ' ')
    {
      *fmtOut++ = c; fmtOut_sz--;
      if (state&(32|16|8|4)) break;
      state |= 16;
    }
    else if (c >= '0' && c <= '9')
    {
      *fmtOut++ = c; fmtOut_sz--;
      state|=4;
    }
    else if (c == '{')
    {
      if (state & 64) break;
      state|=64;
      if (*fmt == '.' || (*fmt >= '0' && *fmt <= '9')) return 0; // symbol name can't start with 0-9 or .

      while (*fmt != '}')
      {
        if ((*fmt >= 'a' && *fmt <= 'z') ||
            (*fmt >= 'A' && *fmt <= 'Z') ||
            (*fmt >= '0' && *fmt <= '9') ||
            *fmt == '_' || *fmt == '.' || *fmt == '#')
        {
          if (varOut_sz < 2) return 0;
          *varOut++ = *fmt++;
          varOut_sz -- ;
        }
        else
        {
          return 0; // bad character in variable name
        }
      }
      fmt++;
      *varOut = 0;
      *varOut_used=1;
    }
    else
    {
      break;
    }
  }
  return 0;
}

int eel_format_strings(void *opaque, const char *fmt, const char *fmt_end, char *buf, int buf_sz, int num_fmt_parms, EEL_F **fmt_parms)
{
  int fmt_parmpos = 0;
  char *op = buf;
  while ((fmt_end ? fmt < fmt_end : *fmt) && op < buf+buf_sz-128)
  {
    if (fmt[0] == '%' && fmt[1] == '%')
    {
      *op++ = '%';
      fmt+=2;
    }
    else if (fmt[0] == '%')
    {
      char ct=0;
      char fs[128];
      char varname[128];
      int varname_used=0;
      const int l=eel_validate_format_specifier(fmt,&ct,fs,sizeof(fs),varname,sizeof(varname),&varname_used);
      if (!l || !ct)
      {
        *op=0;
        return -1;
      }

      EEL_F vv=0.0;
      const EEL_F *varptr = NULL;
      if (varname_used)
      {
#ifdef EEL_STRING_GETNAMEDVAR
        if (varname[0]) varptr=EEL_STRING_GETNAMEDVAR(varname,0,&vv);
#endif
      }
      else
      {
        if (fmt_parmpos < num_fmt_parms) varptr = fmt_parms[fmt_parmpos];
#ifdef EEL_STRING_GETFMTVAR
        if (!varptr) varptr = EEL_STRING_GETFMTVAR(fmt_parmpos);
#endif
        fmt_parmpos++;
      }
      double v = varptr ? (double)*varptr : 0.0;

      if (ct == 's' || ct=='S')
      {
        EEL_STRING_STORAGECLASS *wr=NULL;
        const char *str = EEL_STRING_GET_FOR_INDEX(v,&wr);
        const int maxl=(int) (buf+buf_sz - 2 - op);
        if (wr && !fs[2]) // %s or %S -- todo: implement padding modes for binary compat too?
        {
          int wl = wr->GetLength();
          if (wl > maxl) wl=maxl;
          memcpy(op,wr->Get(),wl);
          op += wl;
          *op=0;
        }
        else
        {
          snprintf(op,maxl,fs,str ? str : "");
        }
      }
      else
      {
        if (varptr == &vv) // passed %{#str}d etc, convert to float
        {
          const char *str = EEL_STRING_GET_FOR_INDEX(v,NULL);
          v = str ? atof(str) : 0.0;
        }

        if (ct == 'x' || ct == 'X' || ct == 'd' || ct == 'u' || ct=='i')
        {
          snprintf(op,64,fs,(int) (v));
        }
        else if (ct == 'c')
        {
          *op++=(char) (int)v;
          *op=0;
        }
        else if (ct == 'C')
        {
          const unsigned int iv = (unsigned int) v;
          int bs = 0;
          if (iv &      0xff000000) bs=24;
          else if (iv & 0x00ff0000) bs=16;
          else if (iv & 0x0000ff00) bs=8;
          while (bs>=0)
          {
            const char c=(char) (iv>>bs);
            *op++=c?c:' ';
            bs-=8;
          }
          *op=0;
        }
        else
          snprintf(op,64,fs,v);
      }

      while (*op) op++;

      fmt += l;
    }
    else
    {
      *op++ = *fmt++;
    }

  }
  *op=0;
  return (int) (op - buf);
}


#if 0
static EEL_F NSEEL_CGEN_CALL _eel_sprintf(void *opaque, INT_PTR num_param, EEL_F **parms)
{
  if (num_param<2) return 0.0;

  if (opaque)
  {
    EEL_STRING_MUTEXLOCK_SCOPE
    EEL_STRING_STORAGECLASS *wr=NULL;
    EEL_STRING_GET_FOR_INDEX(*(parms[0]), &wr);
    if (!wr)
    {
#ifdef EEL_STRING_DEBUGOUT
      EEL_STRING_DEBUGOUT("sprintf: bad destination specifier passed %f",*(parms[0]));
#endif
    }
    else
    {
      EEL_STRING_STORAGECLASS *wr_src=NULL;
      const char *fmt = EEL_STRING_GET_FOR_INDEX(*(parms[1]),&wr_src);
      if (fmt)
      {
        char buf[16384];
        const int fmt_len = eel_format_strings(opaque,fmt,wr_src?(fmt+wr_src->GetLength()):NULL,buf,(int)sizeof(buf), (int)num_param-2, parms+2);

        if (fmt_len>=0)
        {
          wr->SetRaw(buf,fmt_len);
        }
        else
        {
#ifdef EEL_STRING_DEBUGOUT
          EEL_STRING_DEBUGOUT("sprintf: bad format string %s",fmt);
#endif
        }
      }
      else
      {
#ifdef EEL_STRING_DEBUGOUT
        EEL_STRING_DEBUGOUT("sprintf: bad format specifier passed %f",*(parms[1]));
#endif
      }
    }
  }
  return *(parms[0]);
}


static EEL_F NSEEL_CGEN_CALL _eel_printf(void *opaque, INT_PTR num_param, EEL_F **parms)
{
  if (num_param>0 && opaque)
  {
    EEL_STRING_MUTEXLOCK_SCOPE
    EEL_STRING_STORAGECLASS *wr_src=NULL;
    const char *fmt = EEL_STRING_GET_FOR_INDEX(*(parms[0]),&wr_src);
    if (fmt)
    {
      char buf[16384];
      const int len = eel_format_strings(opaque,fmt,wr_src?(fmt+wr_src->GetLength()):NULL,buf,(int)sizeof(buf), (int)num_param-1, parms+1);

      if (len >= 0)
      {
#ifdef EEL_STRING_STDOUT_WRITE
        EEL_STRING_STDOUT_WRITE(buf,len);
#endif
        return 1.0;
      }
      else
      {
#ifdef EEL_STRING_DEBUGOUT
        EEL_STRING_DEBUGOUT("printf: bad format string %s",fmt);
#endif
      }
    }
    else
    {
#ifdef EEL_STRING_DEBUGOUT
      EEL_STRING_DEBUGOUT("printf: bad format specifier passed %f",*(parms[0]));
#endif
    }
  }
  return 0.0;
}
#endif

#endif
