/*
  WDL - fft.cpp
  Copyright (C) 2006 and later Cockos Incorporated
  Copyright 1999 D. J. Bernstein

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.
  


  This file implements the WDL FFT library. These routines are based on the 
  DJBFFT library, which are   Copyright 1999 D. J. Bernstein, djb@pobox.com

  The DJB FFT web page is:  http://cr.yp.to/djbfft.html

*/


// this is based on djbfft

#ifndef WDL_FFT_C_
#define WDL_FFT_C_


#include <math.h>
#include "fft.h"
#include "fft_internal.h"


static void WDL_c2_(register WDL_FFT_COMPLEX *a)
{
  register WDL_FFT_REAL t1;

  t1 = a[1].re;
  a[1].re = a[0].re - t1;
  a[0].re += t1;

  t1 = a[1].im;
  a[1].im = a[0].im - t1;
  a[0].im += t1;
}

static inline void WDL_c4_(register WDL_FFT_COMPLEX *a)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;

  t5 = a[2].re;
  t1 = a[0].re - t5;
  t7 = a[3].re;
  t5 += a[0].re;
  t3 = a[1].re - t7;
  t7 += a[1].re;
  t8 = t5 + t7;
  a[0].re = t8;
  t5 -= t7;
  a[1].re = t5;
  t6 = a[2].im;
  t2 = a[0].im - t6;
  t6 += a[0].im;
  t5 = a[3].im;
  a[2].im = t2 + t3;
  t2 -= t3;
  a[3].im = t2;
  t4 = a[1].im - t5;
  a[3].re = t1 + t4;
  t1 -= t4;
  a[2].re = t1;
  t5 += a[1].im;
  a[0].im = t6 + t5;
  t6 -= t5;
  a[1].im = t6;
}

static void WDL_c8_(register WDL_FFT_COMPLEX *a)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;

  t7 = a[4].im;
  t4 = a[0].im - t7;
  t7 += a[0].im;
  a[0].im = t7;

  t8 = a[6].re;
  t5 = a[2].re - t8;
  t8 += a[2].re;
  a[2].re = t8;

  t7 = a[6].im;
  a[6].im = t4 - t5;
  t4 += t5;
  a[4].im = t4;

  t6 = a[2].im - t7;
  t7 += a[2].im;
  a[2].im = t7;

  t8 = a[4].re;
  t3 = a[0].re - t8;
  t8 += a[0].re;
  a[0].re = t8;

  a[4].re = t3 - t6;
  t3 += t6;
  a[6].re = t3;

  t7 = a[5].re;
  t3 = a[1].re - t7;
  t7 += a[1].re;
  a[1].re = t7;

  t8 = a[7].im;
  t6 = a[3].im - t8;
  t8 += a[3].im;
  a[3].im = t8;
  t1 = t3 - t6;
  t3 += t6;

  t7 = a[5].im;
  t4 = a[1].im - t7;
  t7 += a[1].im;
  a[1].im = t7;

  t8 = a[7].re;
  t5 = a[3].re - t8;
  t8 += a[3].re;
  a[3].re = t8;

  t2 = t4 - t5;
  t4 += t5;

  t6 = t1 - t4;
  t8 = WDL_sqrthalf_;
  t6 *= t8;
  a[5].re = a[4].re - t6;
  t1 += t4;
  t1 *= t8;
  a[5].im = a[4].im - t1;
  t6 += a[4].re;
  a[4].re = t6;
  t1 += a[4].im;
  a[4].im = t1;

  t5 = t2 - t3;
  t5 *= t8;
  a[7].im = a[6].im - t5;
  t2 += t3;
  t2 *= t8;
  a[7].re = a[6].re - t2;
  t2 += a[6].re;
  a[6].re = t2;
  t5 += a[6].im;
  a[6].im = t5;

  WDL_c4_(a);
}

static void WDL_c16_(register WDL_FFT_COMPLEX *a)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;

  WDL_TRANSFORMZERO_(a[0],a[4],a[8],a[12]);
  WDL_TRANSFORM_(a[1],a[5],a[9],a[13],WDL_d16_[0].re,WDL_d16_[0].im);
  WDL_TRANSFORMHALF_(a[2],a[6],a[10],a[14]);
  WDL_TRANSFORM_(a[3],a[7],a[11],a[15],WDL_d16_[0].im,WDL_d16_[0].re);
  WDL_c4_(a + 8);
  WDL_c4_(a + 12);

  WDL_c8_(a);
}

/* a[0...8n-1], w[0...2n-2]; n >= 2 */
static void WDL_cpass_(register WDL_FFT_COMPLEX *a,register const WDL_FFT_COMPLEX *w,register unsigned int n)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;
  register WDL_FFT_COMPLEX *a1;
  register WDL_FFT_COMPLEX *a2;
  register WDL_FFT_COMPLEX *a3;

  a2 = a + 4 * n;
  a1 = a + 2 * n;
  a3 = a2 + 2 * n;
  --n;

  WDL_TRANSFORMZERO_(a[0],a1[0],a2[0],a3[0]);
  WDL_TRANSFORM_(a[1],a1[1],a2[1],a3[1],w[0].re,w[0].im);

  for (;;) {
    WDL_TRANSFORM_(a[2],a1[2],a2[2],a3[2],w[1].re,w[1].im);
    WDL_TRANSFORM_(a[3],a1[3],a2[3],a3[3],w[2].re,w[2].im);
    if (!--n) break;
    a += 2;
    a1 += 2;
    a2 += 2;
    a3 += 2;
    w += 2;
  }
}

static void WDL_c32_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpass_(a,WDL_d32_,4);
  WDL_c8_(a + 16);
  WDL_c8_(a + 24);
  WDL_c16_(a);
}

static void WDL_c64_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpass_(a,WDL_d64_,8);
  WDL_c16_(a + 32);
  WDL_c16_(a + 48);
  WDL_c32_(a);
}

static void WDL_c128_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpass_(a,WDL_d128_,16);
  WDL_c32_(a + 64);
  WDL_c32_(a + 96);
  WDL_c64_(a);
}

static void WDL_c256_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpass_(a,WDL_d256_,32);
  WDL_c64_(a + 128);
  WDL_c64_(a + 192);
  WDL_c128_(a);
}

static void WDL_c512_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpass_(a,WDL_d512_,64);
  WDL_c128_(a + 384);
  WDL_c128_(a + 256);
  WDL_c256_(a);
}

/* a[0...8n-1], w[0...n-2]; n even, n >= 4 */
static void WDL_cpassbig_(register WDL_FFT_COMPLEX *a,register const WDL_FFT_COMPLEX *w,register unsigned int n)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;
  register WDL_FFT_COMPLEX *a1;
  register WDL_FFT_COMPLEX *a2;
  register WDL_FFT_COMPLEX *a3;
  register unsigned int k;

  a2 = a + 4 * n;
  a1 = a + 2 * n;
  a3 = a2 + 2 * n;
  k = n - 2;

  WDL_TRANSFORMZERO_(a[0],a1[0],a2[0],a3[0]);
  WDL_TRANSFORM_(a[1],a1[1],a2[1],a3[1],w[0].re,w[0].im);
  a += 2;
  a1 += 2;
  a2 += 2;
  a3 += 2;

  do {
    WDL_TRANSFORM_(a[0],a1[0],a2[0],a3[0],w[1].re,w[1].im);
    WDL_TRANSFORM_(a[1],a1[1],a2[1],a3[1],w[2].re,w[2].im);
    a += 2;
    a1 += 2;
    a2 += 2;
    a3 += 2;
    w += 2;
  } while (k -= 2);

  WDL_TRANSFORMHALF_(a[0],a1[0],a2[0],a3[0]);
  WDL_TRANSFORM_(a[1],a1[1],a2[1],a3[1],w[0].im,w[0].re);
  a += 2;
  a1 += 2;
  a2 += 2;
  a3 += 2;

  k = n - 2;
  do {
    WDL_TRANSFORM_(a[0],a1[0],a2[0],a3[0],w[-1].im,w[-1].re);
    WDL_TRANSFORM_(a[1],a1[1],a2[1],a3[1],w[-2].im,w[-2].re);
    a += 2;
    a1 += 2;
    a2 += 2;
    a3 += 2;
    w -= 2;
  } while (k -= 2);
}


static void WDL_c1024_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpassbig_(a,WDL_d1024_,128);
  WDL_c256_(a + 768);
  WDL_c256_(a + 512);
  WDL_c512_(a);
}

static void WDL_c2048_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpassbig_(a,WDL_d2048_,256);
  WDL_c512_(a + 1536);
  WDL_c512_(a + 1024);
  WDL_c1024_(a);
}

static void WDL_c4096_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpassbig_(a,WDL_d4096_,512);
  WDL_c1024_(a + 3072);
  WDL_c1024_(a + 2048);
  WDL_c2048_(a);
}

static void WDL_c8192_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpassbig_(a,WDL_d8192_,1024);
  WDL_c2048_(a + 6144);
  WDL_c2048_(a + 4096);
  WDL_c4096_(a);
}

static void WDL_c16384_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpassbig_(a,WDL_d16384_,2048);
  WDL_c4096_(a + 8192 + 4096);
  WDL_c4096_(a + 8192);
  WDL_c8192_(a);
}

static void WDL_c32768_(register WDL_FFT_COMPLEX *a)
{
  WDL_cpassbig_(a,WDL_d32768_,4096);
  WDL_c8192_(a + 16384 + 8192);
  WDL_c8192_(a + 16384);
  WDL_c16384_(a);
}


/* n even, n > 0 */
void WDL_fft_complexmul(WDL_FFT_COMPLEX *a,WDL_FFT_COMPLEX *b,int n)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;
  if (n<2 || (n&1)) return;

  do {
    t1 = a[0].re * b[0].re;
    t2 = a[0].im * b[0].im;
    t3 = a[0].im * b[0].re;
    t4 = a[0].re * b[0].im;
    t5 = a[1].re * b[1].re;
    t6 = a[1].im * b[1].im;
    t7 = a[1].im * b[1].re;
    t8 = a[1].re * b[1].im;
    t1 -= t2;
    t3 += t4;
    t5 -= t6;
    t7 += t8;
    a[0].re = t1;
    a[1].re = t5;
    a[0].im = t3;
    a[1].im = t7;
    a += 2;
    b += 2;
  } while (n -= 2);
}

void WDL_fft_complexmul2(WDL_FFT_COMPLEX *c, WDL_FFT_COMPLEX *a, WDL_FFT_COMPLEX *b, int n)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;
  if (n<2 || (n&1)) return;

  do {
    t1 = a[0].re * b[0].re;
    t2 = a[0].im * b[0].im;
    t3 = a[0].im * b[0].re;
    t4 = a[0].re * b[0].im;
    t5 = a[1].re * b[1].re;
    t6 = a[1].im * b[1].im;
    t7 = a[1].im * b[1].re;
    t8 = a[1].re * b[1].im;
    t1 -= t2;
    t3 += t4;
    t5 -= t6;
    t7 += t8;
    c[0].re = t1;
    c[1].re = t5;
    c[0].im = t3;
    c[1].im = t7;
    a += 2;
    b += 2;
    c += 2;
  } while (n -= 2);
}
void WDL_fft_complexmul3(WDL_FFT_COMPLEX *c, WDL_FFT_COMPLEX *a, WDL_FFT_COMPLEX *b, int n)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;
  if (n<2 || (n&1)) return;

  do {
    t1 = a[0].re * b[0].re;
    t2 = a[0].im * b[0].im;
    t3 = a[0].im * b[0].re;
    t4 = a[0].re * b[0].im;
    t5 = a[1].re * b[1].re;
    t6 = a[1].im * b[1].im;
    t7 = a[1].im * b[1].re;
    t8 = a[1].re * b[1].im;
    t1 -= t2;
    t3 += t4;
    t5 -= t6;
    t7 += t8;
    c[0].re += t1;
    c[1].re += t5;
    c[0].im += t3;
    c[1].im += t7;
    a += 2;
    b += 2;
    c += 2;
  } while (n -= 2);
}


static inline void WDL_u4_(register WDL_FFT_COMPLEX *a)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;

  t1 = VOL a[1].re;
  t3 = a[0].re - t1;
  t6 = VOL a[2].re;
  t1 += a[0].re;
  t8 = a[3].re - t6;
  t6 += a[3].re;
  a[0].re = t1 + t6;
  t1 -= t6;
  a[2].re = t1;

  t2 = VOL a[1].im;
  t4 = a[0].im - t2;
  t2 += a[0].im;
  t5 = VOL a[3].im;
  a[1].im = t4 + t8;
  t4 -= t8;
  a[3].im = t4;

  t7 = a[2].im - t5;
  t5 += a[2].im;
  a[1].re = t3 + t7;
  t3 -= t7;
  a[3].re = t3;
  a[0].im = t2 + t5;
  t2 -= t5;
  a[2].im = t2;
}

static void WDL_u8_(register WDL_FFT_COMPLEX *a)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;

  WDL_u4_(a);

  t1 = a[5].re;
  a[5].re = a[4].re - t1;
  t1 += a[4].re;

  t3 = a[7].re;
  a[7].re = a[6].re - t3;
  t3 += a[6].re;

  t8 = t3 - t1;
  t1 += t3;

  t6 = a[2].im - t8;
  t8 += a[2].im;
  a[2].im = t8;

  t5 = a[0].re - t1;
  a[4].re = t5;
  t1 += a[0].re;
  a[0].re = t1;

  t2 = a[5].im;
  a[5].im = a[4].im - t2;
  t2 += a[4].im;

  t4 = a[7].im;
  a[7].im = a[6].im - t4;
  t4 += a[6].im;

  a[6].im = t6;

  t7 = t2 - t4;
  t2 += t4;

  t3 = a[2].re - t7;
  a[6].re = t3;
  t7 += a[2].re;
  a[2].re = t7;

  t6 = a[0].im - t2;
  a[4].im = t6;
  t2 += a[0].im;
  a[0].im = t2;

  t6 = WDL_sqrthalf_;

  t1 = a[5].re;
  t2 = a[5].im - t1;
  t2 *= t6;
  t1 += a[5].im;
  t1 *= t6;
  t4 = a[7].im;
  t3 = a[7].re - t4;
  t3 *= t6;
  t4 += a[7].re;
  t4 *= t6;

  t8 = t3 - t1;
  t1 += t3;
  t7 = t2 - t4;
  t2 += t4;

  t4 = a[3].im - t8;
  a[7].im = t4;
  t5 = a[1].re - t1;
  a[5].re = t5;
  t3 = a[3].re - t7;
  a[7].re = t3;
  t6 = a[1].im - t2;
  a[5].im = t6;

  t8 += a[3].im;
  a[3].im = t8;
  t1 += a[1].re;
  a[1].re = t1;
  t7 += a[3].re;
  a[3].re = t7;
  t2 += a[1].im;
  a[1].im = t2;
}

static void WDL_u16_(register WDL_FFT_COMPLEX *a)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;

  WDL_u8_(a);
  WDL_u4_(a + 8);
  WDL_u4_(a + 12);

  WDL_UNTRANSFORMZERO_(a[0],a[4],a[8],a[12]);
  WDL_UNTRANSFORMHALF_(a[2],a[6],a[10],a[14]);
  WDL_UNTRANSFORM_(a[1],a[5],a[9],a[13],WDL_d16_[0].re,WDL_d16_[0].im);
  WDL_UNTRANSFORM_(a[3],a[7],a[11],a[15],WDL_d16_[0].im,WDL_d16_[0].re);
}

/* a[0...8n-1], w[0...2n-2] */
static void WDL_upass_(register WDL_FFT_COMPLEX *a,register const WDL_FFT_COMPLEX *w,register unsigned int n)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;
  register WDL_FFT_COMPLEX *a1;
  register WDL_FFT_COMPLEX *a2;
  register WDL_FFT_COMPLEX *a3;

  a2 = a + 4 * n;
  a1 = a + 2 * n;
  a3 = a2 + 2 * n;
  n -= 1;

  WDL_UNTRANSFORMZERO_(a[0],a1[0],a2[0],a3[0]);
  WDL_UNTRANSFORM_(a[1],a1[1],a2[1],a3[1],w[0].re,w[0].im);

  for (;;) {
    WDL_UNTRANSFORM_(a[2],a1[2],a2[2],a3[2],w[1].re,w[1].im);
    WDL_UNTRANSFORM_(a[3],a1[3],a2[3],a3[3],w[2].re,w[2].im);
    if (!--n) break;
    a += 2;
    a1 += 2;
    a2 += 2;
    a3 += 2;
    w += 2;
  }
}

static void WDL_u32_(register WDL_FFT_COMPLEX *a)
{
  WDL_u16_(a);
  WDL_u8_(a + 16);
  WDL_u8_(a + 24);
  WDL_upass_(a,WDL_d32_,4);
}

static void WDL_u64_(register WDL_FFT_COMPLEX *a)
{
  WDL_u32_(a);
  WDL_u16_(a + 32);
  WDL_u16_(a + 48);
  WDL_upass_(a,WDL_d64_,8);
}

static void WDL_u128_(register WDL_FFT_COMPLEX *a)
{
  WDL_u64_(a);
  WDL_u32_(a + 64);
  WDL_u32_(a + 96);
  WDL_upass_(a,WDL_d128_,16);
}

static void WDL_u256_(register WDL_FFT_COMPLEX *a)
{
  WDL_u128_(a);
  WDL_u64_(a + 128);
  WDL_u64_(a + 192);
  WDL_upass_(a,WDL_d256_,32);
}

static void WDL_u512_(register WDL_FFT_COMPLEX *a)
{
  WDL_u256_(a);
  WDL_u128_(a + 256);
  WDL_u128_(a + 384);
  WDL_upass_(a,WDL_d512_,64);
}


/* a[0...8n-1], w[0...n-2]; n even, n >= 4 */
static void WDL_upassbig_(register WDL_FFT_COMPLEX *a,register const WDL_FFT_COMPLEX *w,register unsigned int n)
{
  register WDL_FFT_REAL t1, t2, t3, t4, t5, t6, t7, t8;
  register WDL_FFT_COMPLEX *a1;
  register WDL_FFT_COMPLEX *a2;
  register WDL_FFT_COMPLEX *a3;
  register unsigned int k;

  a2 = a + 4 * n;
  a1 = a + 2 * n;
  a3 = a2 + 2 * n;
  k = n - 2;

  WDL_UNTRANSFORMZERO_(a[0],a1[0],a2[0],a3[0]);
  WDL_UNTRANSFORM_(a[1],a1[1],a2[1],a3[1],w[0].re,w[0].im);
  a += 2;
  a1 += 2;
  a2 += 2;
  a3 += 2;

  do {
    WDL_UNTRANSFORM_(a[0],a1[0],a2[0],a3[0],w[1].re,w[1].im);
    WDL_UNTRANSFORM_(a[1],a1[1],a2[1],a3[1],w[2].re,w[2].im);
    a += 2;
    a1 += 2;
    a2 += 2;
    a3 += 2;
    w += 2;
  } while (k -= 2);

  WDL_UNTRANSFORMHALF_(a[0],a1[0],a2[0],a3[0]);
  WDL_UNTRANSFORM_(a[1],a1[1],a2[1],a3[1],w[0].im,w[0].re);
  a += 2;
  a1 += 2;
  a2 += 2;
  a3 += 2;

  k = n - 2;
  do {
    WDL_UNTRANSFORM_(a[0],a1[0],a2[0],a3[0],w[-1].im,w[-1].re);
    WDL_UNTRANSFORM_(a[1],a1[1],a2[1],a3[1],w[-2].im,w[-2].re);
    a += 2;
    a1 += 2;
    a2 += 2;
    a3 += 2;
    w -= 2;
  } while (k -= 2);
}



static void WDL_u1024_(register WDL_FFT_COMPLEX *a)
{
  WDL_u512_(a);
  WDL_u256_(a + 512);
  WDL_u256_(a + 768);
  WDL_upassbig_(a,WDL_d1024_,128);
}

static void WDL_u2048_(register WDL_FFT_COMPLEX *a)
{
  WDL_u1024_(a);
  WDL_u512_(a + 1024);
  WDL_u512_(a + 1536);
  WDL_upassbig_(a,WDL_d2048_,256);
}


static void WDL_u4096_(register WDL_FFT_COMPLEX *a)
{
  WDL_u2048_(a);
  WDL_u1024_(a + 2048);
  WDL_u1024_(a + 3072);
  WDL_upassbig_(a,WDL_d4096_,512);
}

static void WDL_u8192_(register WDL_FFT_COMPLEX *a)
{
  WDL_u4096_(a);
  WDL_u2048_(a + 4096);
  WDL_u2048_(a + 6144);
  WDL_upassbig_(a,WDL_d8192_,1024);
}

static void WDL_u16384_(register WDL_FFT_COMPLEX *a)
{
  WDL_u8192_(a);
  WDL_u4096_(a + 8192);
  WDL_u4096_(a + 8192 + 4096);
  WDL_upassbig_(a,WDL_d16384_,2048);
}

static void WDL_u32768_(register WDL_FFT_COMPLEX *a)
{
  WDL_u16384_(a);
  WDL_u8192_(a + 16384);
  WDL_u8192_(a + 16384  + 8192 );
  WDL_upassbig_(a,WDL_d32768_,4096);
}


static void __fft_gen(WDL_FFT_COMPLEX *buf, const WDL_FFT_COMPLEX *buf2, int sz, int isfull)
{
  int x;
  double div=WDL_PI_*0.25/(sz+1);

  if (isfull) div*=2.0;

  for (x = 0; x < sz; x ++)
  {
    if (!(x & 1) || !buf2)
    {
      buf[x].re = (WDL_FFT_REAL) cos((x+1)*div);
      buf[x].im = (WDL_FFT_REAL) sin((x+1)*div);
    }
    else
    {
      buf[x].re = buf2[x >> 1].re;
      buf[x].im = buf2[x >> 1].im;
    }
  }
}

#ifndef WDL_FFT_NO_PERMUTE

static unsigned int fftfreq_c(unsigned int i,unsigned int n)
{
  unsigned int m;

  if (n <= 2) return i;

  m = n >> 1;
  if (i < m) return fftfreq_c(i,m) << 1;

  i -= m;
  m >>= 1;
  if (i < m) return (fftfreq_c(i,m) << 2) + 1;
  i -= m;
  return ((fftfreq_c(i,m) << 2) - 1) & (n - 1);
}

static int _idxperm[2<<FFT_MAXBITLEN];

static void idx_perm_calc(int offs, int n)
{
	int i, j;
	_idxperm[offs] = 0;
	for (i = 1; i < n; ++i) {
		j = fftfreq_c(i, n);
		_idxperm[offs+n-j] = i;
	}
}

int WDL_fft_permute(int fftsize, int idx)
{
  return _idxperm[fftsize+idx-2];
}
int *WDL_fft_permute_tab(int fftsize)
{
  return _idxperm + fftsize - 2;
}


#endif

void WDL_fft_init()
{
  static int ffttabinit;
  if (!ffttabinit)
  {
    int i, offs;
  	ffttabinit=1;

#define fft_gen(x,y,z) __fft_gen(x,y,sizeof(x)/sizeof(x[0]),z)
    fft_gen(WDL_d16_,0,1);
    fft_gen(WDL_d32_,WDL_d16_,1);
    fft_gen(WDL_d64_,WDL_d32_,1);
    fft_gen(WDL_d128_,WDL_d64_,1);
    fft_gen(WDL_d256_,WDL_d128_,1);
    fft_gen(WDL_d512_,WDL_d256_,1);
    fft_gen(WDL_d1024_,WDL_d512_,0);
    fft_gen(WDL_d2048_,WDL_d1024_,0);
    fft_gen(WDL_d4096_,WDL_d2048_,0);
    fft_gen(WDL_d8192_,WDL_d4096_,0);
    fft_gen(WDL_d16384_,WDL_d8192_,0);
    fft_gen(WDL_d32768_,WDL_d16384_,0);
#undef fft_gen

#ifndef WDL_FFT_NO_PERMUTE
	  offs = 0;
	  for (i = 2; i <= 32768; i *= 2) 
    {
		  idx_perm_calc(offs, i);
		  offs += i;
	  }
#endif

  }
}

void WDL_fft(WDL_FFT_COMPLEX *buf, int len, int isInverse)
{
  switch (len)
  {
    case 2: WDL_c2_(buf); break;
#define TMP(x) case x: if (!isInverse) WDL_c##x##_(buf); else WDL_u##x##_(buf); break;
    TMP(4)
    TMP(8)
    TMP(16)
    TMP(32)
    TMP(64)
    TMP(128)
    TMP(256)
    TMP(512)
    TMP(1024)
    TMP(2048)
    TMP(4096)
    TMP(8192)
    TMP(16384)
    TMP(32768)
#undef TMP
  }
}

static inline void WDL_r2_(register WDL_FFT_REAL *a)
{
  register WDL_FFT_REAL t1, t2;

  t1 = a[0] + a[1];
  t2 = a[0] - a[1];
  a[0] = t1 * 2;
  a[1] = t2 * 2;
}

static inline void WDL_v2_(register WDL_FFT_REAL *a)
{
  register WDL_FFT_REAL t1, t2;

  t1 = a[0] + a[1];
  t2 = a[0] - a[1];
  a[0] = t1;
  a[1] = t2;
}

static void WDL_two_for_one_(WDL_FFT_REAL* buf, const WDL_FFT_COMPLEX *d, int len, int isInverse)
{
  const unsigned int half = (unsigned)len >> 1, quart = half >> 1, eighth = quart >> 1;
  const int *permute = WDL_fft_permute_tab(half);
  unsigned int i, j;

  WDL_FFT_COMPLEX *p, *q, tw, sum, diff;
  WDL_FFT_REAL tw1, tw2;

  if (!isInverse)
  {
  	WDL_fft((WDL_FFT_COMPLEX*)buf, half, isInverse);
  	WDL_r2_(buf);
  }
  else
  {
  	WDL_v2_(buf);
  }

  /* Source: http://www.katjaas.nl/realFFT/realFFT2.html */

  for (i = 1; i < quart; ++i)
  {
    p = (WDL_FFT_COMPLEX*)buf + permute[i];
    q = (WDL_FFT_COMPLEX*)buf + permute[half - i];

/*  tw.re = cos(2*WDL_PI_ * i / len);
    tw.im = sin(2*WDL_PI_ * i / len); */

    if (i < eighth)
    {
      j = i - 1;
      tw.re = d[j].re;
      tw.im = d[j].im;
    }
    else if (i > eighth)
    {
      j = quart - i - 1;
      tw.re = d[j].im;
      tw.im = d[j].re;
    }
    else
    {
      tw.re = tw.im = WDL_sqrthalf_;
    }

    if (!isInverse) tw.re = -tw.re;

    sum.re = p->re + q->re;
    sum.im = p->im + q->im;
    diff.re = p->re - q->re;
    diff.im = p->im - q->im;

    tw1 = tw.re * sum.im + tw.im * diff.re;
    tw2 = tw.im * sum.im - tw.re * diff.re;

    p->re = sum.re - tw1;
    p->im = diff.im - tw2;
    q->re = sum.re + tw1;
    q->im = -(diff.im + tw2);
  }

  p = (WDL_FFT_COMPLEX*)buf + permute[i];
  p->re *=  2;
  p->im *= -2;

  if (isInverse) WDL_fft((WDL_FFT_COMPLEX*)buf, half, isInverse);
}

void WDL_real_fft(WDL_FFT_REAL* buf, int len, int isInverse)
{
  switch (len)
  {
    case 2: if (!isInverse) WDL_r2_(buf); else WDL_v2_(buf); break;
    case 4: case 8: WDL_two_for_one_(buf, 0, len, isInverse); break;
#define TMP(x) case x: WDL_two_for_one_(buf, WDL_d##x##_, len, isInverse); break;
    TMP(16)
    TMP(32)
    TMP(64)
    TMP(128)
    TMP(256)
    TMP(512)
    TMP(1024)
    TMP(2048)
    TMP(4096)
    TMP(8192)
    TMP(16384)
    TMP(32768)
#undef TMP
  }
}


#endif
