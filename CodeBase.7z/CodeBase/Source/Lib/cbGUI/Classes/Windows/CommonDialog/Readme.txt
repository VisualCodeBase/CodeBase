this class made to support vb classes.
