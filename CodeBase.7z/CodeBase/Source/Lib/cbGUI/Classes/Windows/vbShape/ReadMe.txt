this class made to support vb6 classes.
we add some shapes (unfinished yet).
also add support for gradient fill.