
#ifndef cb_cPALETTE2_H_
#define cb_cPALETTE2_H_

cb_BeginExternC
cb_Integer cb_cPalette_ClosestIndex (cb_cPalette*,COLORREF);
COLORREF cb_cPalette_Color (cb_cPalette*,cb_Integer);
void cb_cPalette_Apply (cb_cPalette*,cb_Integer,cb_Integer,COLORREF*,COLORREF* =NULL);
cb_EndExternC

#endif
