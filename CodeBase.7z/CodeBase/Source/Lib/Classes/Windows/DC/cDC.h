
#ifndef cb_cDC2_H_
#define cb_cDC2_H_

#define cb_cDC_GetR cb_cDC_GetForeR
#define cb_cDC_SetR cb_cDC_SetForeR
#define cb_cDC_GetG cb_cDC_GetForeG
#define cb_cDC_SetG cb_cDC_SetForeG
#define cb_cDC_GetB cb_cDC_GetForeB
#define cb_cDC_SetB cb_cDC_SetForeB
#define cb_cDC_GetDC(x) cb_cDC_Get
#define cb_cDC_Clear cb_cDC_Set
#define cb_cDC_Free cb_cDC_Set
#define cb_cDC_CreateMem(x) cb_cDC_Set(x,(HDC)-2)
#define cb_cDC_ReStart(x) cb_cDC_Set(x,(HDC)-1)
#define cb_cDC_Invalidate cb_cDC_ReStart
#define cb_cDC_AssignBmp(x,y) cb_cDC_Set(x,(HDC)-2,y)
#define cb_cDC_ReleaseBmp(x) (HBITMAP)cb_cDC_Set(x,(HDC)-4)
#define cb_cDC_GetFont(x) cb_GetWndFont((x)->hWnd)
#define cb_cDC_Terminate(x) cb_cDC_Close(x)

cb_BeginExternC
COLORREF cb_cDC_GetBackColor (cb_cDC*);
void cb_cDC_SetBackColor (cb_cDC*,COLORREF);
COLORREF cb_cDC_GetForeColor (cb_cDC*);
void cb_cDC_SetForeColor (cb_cDC*,COLORREF);
BYTE cb_cDC_GetBackR (cb_cDC*);
void cb_cDC_SetBackR (cb_cDC*,BYTE);
BYTE cb_cDC_GetBackG (cb_cDC*);
void cb_cDC_SetBackG (cb_cDC*,BYTE);
BYTE cb_cDC_GetBackB (cb_cDC*);
void cb_cDC_SetBackB (cb_cDC*,BYTE);
BYTE cb_cDC_GetForeR (cb_cDC*);
void cb_cDC_SetForeR (cb_cDC*,BYTE);
BYTE cb_cDC_GetForeG (cb_cDC*);
void cb_cDC_SetForeG (cb_cDC*,BYTE);
BYTE cb_cDC_GetForeB (cb_cDC*);
void cb_cDC_SetForeB (cb_cDC*,BYTE);
COLORREF cb_cDC_GetBkColor (cb_cDC*);
void cb_cDC_SetBkColor (cb_cDC*,COLORREF);
COLORREF cb_cDC_GetTextColor (cb_cDC*);
void cb_cDC_SetTextColor (cb_cDC*,COLORREF);
HDC cb_cDC_Get (cb_cDC*);
HDC cb_cDC_Set (cb_cDC*,HDC =NULL,HBITMAP =NULL);
HBITMAP cb_cDC_GetBmp (cb_cDC*);
void cb_cDC_SetBmp (cb_cDC*,HBITMAP);
void cb_cDC_Flush (cb_cDC*,HDC =NULL);
cb_Integer cb_cDC_GetLeft (cb_cDC*);
void cb_cDC_SetLeft (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetTop (cb_cDC*);
void cb_cDC_SetTop (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetWidth (cb_cDC*);
void cb_cDC_SetWidth (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetHeight (cb_cDC*);
void cb_cDC_SetHeight (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_GetTransparency (cb_cDC*);
void cb_cDC_SetTransparency (cb_cDC*,cb_Integer);
cb_Integer cb_cDC_Line (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =FALSE);
cb_Integer cb_cDC_LineTo (cb_cDC*,cb_Integer,cb_Integer,cb_Integer =FALSE);
cb_Integer cb_cDC_Rect (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
cb_Integer cb_cDC_RectTo (cb_cDC*,cb_Integer,cb_Integer);
cb_Integer cb_cDC_Circle (cb_cDC*,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
cb_Integer cb_cDC_CircleTo (cb_cDC*,cb_Integer,cb_Integer);
cb_Integer cb_cDC_Arc (cb_cDC*,cb_Integer,cb_Integer);
cb_Integer cb_cDC_Triangle (cb_cDC*,cb_Integer,cb_Integer);
cb_Integer cb_cDC_GetPixel (cb_cDC*,cb_Integer*,cb_Integer*,cb_Integer*);
cb_Integer cb_cDC_SetPixel (cb_cDC*,cb_Integer,cb_Integer,cb_Integer);
HWND cb_cDC_GethWnd (cb_cDC*);
HWND cb_cDC_SethWnd (cb_cDC*,HWND);
HFONT cb_cDC_SetFont (cb_cDC*,HFONT,cb_Integer =FALSE);
cb_Integer cb_cDC_GetTextHeight (cb_cDC*,const cb_String =NULL);
cb_Integer cb_cDC_Clw (cb_cDC*,COLORREF =CLR_INVALID);
cb_Integer cb_cDC_Blit (cb_cDC*,HBITMAP,float,float);
cb_Integer cb_cDC_BlitExt (cb_cDC*,HBITMAP,cb_Integer*,float);
cb_Integer cb_cDC_DrawText (cb_cDC*,const cb_String,cb_Integer =-1);
cb_Integer cb_cDC_DrawChar (cb_cDC*,cb_UInteger);
cb_Integer cb_cDC_DrawNumber (cb_cDC*,double,cb_Integer);
cb_Integer cb_cDC_PrintFV (cb_cDC*,cb_String,const cb_String,void*);
cb_Integer cb_CDECL cb_cDC_PrintF (cb_cDC*,cb_String,const cb_String,...);
cb_Integer cb_cDC_MeasureText (cb_cDC*,const cb_String,cb_Integer*);
void cb_cDC_Open (cb_cDC*,void*,cb_Integer =FALSE,RECT* =NULL);
void cb_cDC_Settings (cb_cDC*,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,COLORREF =CLR_INVALID,cb_Integer =-1,cb_Integer =-1);
void cb_cDC_Reset (cb_cDC*);
void cb_cDC_Close (cb_cDC*);
void cb_cDC_Initialize (cb_cDC*);
cb_EndExternC

#endif
