
#ifndef cb_cCollection2_H_
#define cb_cCollection2_H_

#define cb_cCollection_Add cb_cCollection_InsertAt
#define cb_cCollection_GetCount cb_cCollection_Count
#define cb_cCollection_GetItems cb_cCollection_Items
#define cb_cCollection_Collection cb_cCollection_Items
#define cb_cCollection_GetFreeLocation cb_cCollection_Find
#define cb_cCollection_SetAt cb_cCollection_PutAt
#define cb_cCollection_Create cb_cCollection_Initialize
#define cb_cCollection_Destroy cb_cCollection_Terminate

cb_BeginExternC
cb_Integer cb_cCollection_InsertAt (cb_cCollection*,const void*,cb_Integer =-1);
cb_Integer cb_cCollection_Count (cb_cCollection*);
const void* cb_cCollection_Items (cb_cCollection*);
cb_Integer cb_cCollection_Find (cb_cCollection*,const void* =cb_INVALID);
cb_Integer cb_cCollection_FreeAt (cb_cCollection*,cb_Integer,cb_Boolean =FALSE);
cb_Integer cb_cCollection_RemoveAt (cb_cCollection*,cb_Integer =-1);
const void* cb_cCollection_GetAt (cb_cCollection*,cb_Integer);
const void* cb_cCollection_PutAt (cb_cCollection*,const void*,cb_Integer =-2);
cb_Boolean cb_cCollection_GetAutoFree (cb_cCollection*);
void cb_cCollection_SetAutoFree (cb_cCollection*,cb_Boolean =FALSE);
cb_Integer cb_cCollection_GetElementSize (cb_cCollection*);
void cb_cCollection_SetElementSize (cb_cCollection*,cb_Integer =0);
cb_Boolean cb_cCollection_GetAutoReDim (cb_cCollection*);
void cb_cCollection_SetAutoReDim (cb_cCollection*,cb_Boolean =FALSE);
cb_Integer cb_cCollection_SetVectorSize (cb_cCollection*,cb_Integer =-1);
void cb_cCollection_Sort (cb_cCollection*,cb_Integer (cb_CDECL *)(const void*,const void*,const void*));
cb_cCollection* cb_cCollection_Initialize (cb_cCollection* =NULL,void* =NULL,void* =NULL);
void cb_cCollection_Terminate (cb_cCollection*);
cb_EndExternC

#endif
