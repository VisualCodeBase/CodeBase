
#ifndef cb_cFile2_H_
#define cb_cFile2_H_

#define cb_cFile_RDWR_BIT (cb_cFile_READ_BIT | cb_cFile_WRITE_BIT)
#define cb_cFile_EOF cb_cFile_GetEOF
#define cb_cFile_GetFileName UserClassFileName
#define cb_cFile_FGetS cb_cFile_StrRead
#define cb_cFile_Tell cb_cFile_GetPos
#define cb_cFile_Seek cb_cFile_SetPos
#define cb_cFile_ClearError cb_cFile_Clear
#define cb_cFile_Temp cb_cFile_Open
#define cb_cFile_FWrite cb_cFile_StrWrite
#define cb_cFile_PutS cb_cFile_StrWrite

enum {
  cb_cFile_BINARY_BIT = 4,
  cb_cFile_MEM_BIT = cb_cFile_BINARY_BIT << 1,
  cb_cFile_NEW_BIT = cb_cFile_MEM_BIT << 1,
  cb_cFile_READ_BIT = cb_cFile_NEW_BIT << 1,
  cb_cFile_WRITE_BIT = cb_cFile_READ_BIT << 1,
  cb_cFile_APPEND_BIT = cb_cFile_WRITE_BIT << 1,
  cb_cFile_EXCLUSIVE_BIT = cb_cFile_APPEND_BIT << 1,
  cb_cFile_RANDOM_BIT = cb_cFile_EXCLUSIVE_BIT << 1,
  cb_cFile_SEQUENTIAL_BIT = cb_cFile_RANDOM_BIT << 1,
  cb_cFile_SOCKET_BIT = cb_cFile_SEQUENTIAL_BIT << 1,
  cb_cFile_FTP_BIT = cb_cFile_SOCKET_BIT << 1,
  cb_cFile_TEMP_BIT = cb_cFile_FTP_BIT << 1,
  cb_cFile_TEXT_BIT = cb_cFile_TEMP_BIT << 1
};

EXTERN_C void* cb_cFile_StdIn;
EXTERN_C void* cb_cFile_StdErr;
EXTERN_C void* cb_cFile_StdOut;

cb_BeginExternC
cb_Integer cb_cFile_Close (void*);
cb_Integer cb_cFile_CloseAll (void);
void cb_cFile_Terminate (void);
#if !defined(USER_LIBRARY) && !defined(USE_CFILE)
#endif
void cb_cFile_Initialize (void);
void* cb_cFile_TempName (void);
void* cb_cFile_Open (const cb_String =NULL,cb_Integer =0,cb_Integer =0);
void* cb_cFile_FOpen (const cb_String =NULL,const cb_String =NULL);
void* cb_cFile_DOpen (void*,cb_Integer =0,cb_Integer =0);
void* cb_cFile_FDOpen (void*,const cb_String =NULL);
void* cb_cFile_PipeOpen (const cb_String =NULL,cb_Integer =0);
void* cb_cFile_POpen (const cb_String =NULL,const cb_String =NULL);
void* cb_cFile_MemFile (void* =NULL,cb_Integer =-1,cb_Integer =0);
void* cb_cFile_Release (void*,cb_Integer* =NULL);
void* cb_cFile_Attatch (void*,void*,cb_Integer,cb_Integer =FALSE);
cb_Integer cb_cFile_Flush (void*);
cb_Integer cb_cFile_Attr (void*);
cb_PString cb_cFile_FileName (void*,void* =NULL);
long long cb_cFile_GetPos (void*);
long long cb_cFile_SetPos (void*,long long,cb_Integer =0);
long long cb_cFile_ResetPos (void*);
cb_Integer cb_cFile_GetEOF (void*);
long long cb_cFile_SetEOF (void*,long long =-1);
long long cb_cFile_SeekEOF (void*);
long long cb_cFile_GetSize (void*,long long* =NULL);
long long cb_cFile_SetSize (void*,long long);
void* cb_cFile_Read (void*,void*,cb_Integer,void* =NULL);
cb_Integer cb_cFile_FileRead (void*,void*,cb_Integer);
cb_Integer cb_cFile_Write (void*,const void*,cb_Integer);
void* cb_cFile_StrRead (void*,void*,cb_Integer =cb_STRING_SIZE,void* =NULL,cb_Integer =FALSE);
cb_Integer cb_cFile_FRead (void*,void*,cb_Integer);
cb_Integer cb_cFile_GetS (void*,void*,cb_Integer);
cb_Integer cb_cFile_StrWrite (void*,const void*,cb_Integer =-1);
cb_Integer cb_cFile_PutC (void*,cb_Integer);
void cb_cFile_Clear (void*);
cb_Integer cb_cFile_Error (void*);
cb_Integer cb_cFile_Delete (void*,cb_Integer,long long =-1);
cb_Integer cb_cFile_Insert (void*,const void*,cb_Integer,long long =-1);
cb_EndExternC

#endif
