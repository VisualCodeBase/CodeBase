
#ifndef cb_cThread2_H_
#define cb_cThread2_H_

#define cb_cThread_Str cb_cThread_StrPtr
#define cb_cThread_GetLen cb_cThread_GetLength
#define cb_cThread_Len cb_cThread_GetLength
#define cb_cThread_SetLen cb_cThread_SetLength
#define cb_cThread_StrCopyAt cb_cThread_PutAt
#define cb_cThread_StrCopy cb_cThread_PutAt
#define cb_cThread_StrInsert cb_cThread_StrInsertAt
#define cb_cThread_Insert cb_cThread_InsertAt
#define cb_cThread_Mid cb_cThread_GetMid
#define cb_cThread_Left cb_cThread_GetLeft
#define cb_cThread_Right cb_cThread_GetRight
#define cb_cThread_GetChar cb_cThread_Asc
#define cb_cThread_Len cb_cThread_GetLen
#define cb_cThread_Length cb_cThread_GetLength
#define cb_cThread_StrAdd cb_cThread_StrCat
#define cb_cThread_StrCat cb_cThread_StrAppend
#define cb_cThread_Cat cb_cThread_Append
#define cb_cThread_Add cb_cThread_Cat
#define cb_cThread_StrNCat cb_cThread_StrNAppend
#define cb_cThread_NCat cb_cThread_NAppend
#define cb_cThread_CharAdd cb_cThread_CharAppend
#define cb_cThread_DeleteChars cb_cThread_Delete
#define cb_cThread_GetData(x,y,z) cb_cThread_Get(x,y,0,NULL,0,z)
#define cb_cThread_PeekData(x,y) cb_cThread_Get(x,y,0,NULL,0,TRUE)
#define cb_cThread_Rewind cb_cThread_Seek

cb_BeginExternC
cb_cThread* cb_cThread_Initialize (cb_cThread*);
void cb_cThread_Terminate (cb_cThread*);
cb_cThread* cb_cThread_SetBufferSize (cb_cThread*,int,BOOL =FALSE);
cb_cThread* cb_cThread_New (int =0);
cb_cThread* cb_cThread_SetBuffer (cb_cThread*,void*,int =0);
cb_cThread* cb_cThread_Attatch (cb_cThread*,void*,int =0,int =FALSE);
cb_PThread cb_cThread_Release (cb_cThread*,int* =NULL);
const cb_PThread cb_cThread_StrPtr (const cb_cThread*);
int cb_cThread_GetLength (const cb_cThread*);
cb_cThread* cb_cThread_SetLength (cb_cThread*,int);
void cb_cThread_Clear (cb_cThread*);
cb_PThread cb_cThread_GetAt (cb_cThread*,int =0,void* =NULL);
cb_cThread* cb_cThread_PutAt (cb_cThread*,const void*,int =0,int =-1);
cb_cThread* cb_cThread_Copy (cb_cThread*,const cb_cThread*);
cb_cThread* cb_cThread_StrNCopy (cb_cThread*,const void*,int,int =0,int =-1);
cb_cThread* cb_cThread_NCopy (cb_cThread*,const cb_cThread*,int,int =0);
cb_cThread* cb_cThread_Dup (cb_cThread*,cb_cThread* =NULL);
cb_cThread* cb_cThread_StrInsertAt (cb_cThread*,const void*,int =0,int =-1,int =0);
cb_cThread* cb_cThread_InsertAt (cb_cThread*,const cb_cThread*,int =0,int =0);
cb_PThread cb_cThread_GetMid (cb_cThread*,int =-1,int =-1,void* =NULL);
cb_PThread cb_cThread_GetLeft (cb_cThread*,int =-1,void* =NULL);
cb_PThread cb_cThread_GetRight (cb_cThread*,int =-1,void* =NULL);
cb_cThread* cb_cThread_SetMid (cb_cThread*,const void*,int =0,int =-1,int =-1);
int cb_cThread_Asc (cb_cThread*,unsigned int =0);
void cb_cThread_SetChar (cb_cThread*,unsigned int,BYTE);
int cb_cThread_InStr (cb_cThread*,const cb_Thread,int =0,int =0);
int cb_cThread_In (cb_cThread*,const cb_cThread*,int =0,int =0);
int cb_cThread_StrFind (cb_cThread*,const cb_Thread,int =0,BOOL =FALSE,int =0);
int cb_cThread_Find (cb_cThread*,const cb_cThread*,int =0,BOOL =FALSE,int =0);
cb_cThread* cb_cThread_UCase (cb_cThread*);
cb_cThread* cb_cThread_LCase (cb_cThread*);
cb_cThread* cb_cThread_ReverseStr (cb_cThread*);
cb_cThread* cb_cThread_StrAppend (cb_cThread*,const void*,int =-1);
cb_cThread* cb_cThread_LineAppend (cb_cThread*,const cb_Thread,int =-1);
cb_cThread* cb_cThread_Append (cb_cThread*,const cb_cThread*);
cb_cThread* cb_cThread_StrNAppend (cb_cThread*,const void*,int,int =-1);
cb_cThread* cb_cThread_NAppend (cb_cThread*,const cb_cThread*,int);
cb_cThread* cb_cThread_CharAppend (cb_cThread*,char);
cb_cThread* cb_CDECL cb_cThread_StrJoin (cb_cThread*,const cb_Thread,...);
cb_cThread* cb_CDECL cb_cThread_Join (cb_cThread*,const cb_cThread*,...);
cb_cThread* cb_CDECL cb_cThread_StrConCat (cb_cThread*,const cb_Thread,...);
cb_cThread* cb_CDECL cb_cThread_ConCat (cb_cThread*,const cb_cThread*,...);
cb_cThread* cb_CDECL cb_cThread_SPrintF (cb_cThread*,const cb_Thread,...);
int cb_cThread_StrCompareCase (cb_cThread*,const cb_Thread);
int cb_cThread_StrCompareNoCase (cb_cThread*,const cb_Thread);
int cb_cThread_CompareCase (cb_cThread*,const cb_cThread*);
int cb_cThread_CompareNoCase (cb_cThread*,const cb_cThread*);
int cb_cThread_Backspace (cb_cThread*,int =1);
void cb_cThread_Delete (cb_cThread*,int,int =0);
char* cb_cThread_Get (cb_cThread*,void* =NULL,int =0,void* =NULL,int =0,BOOL =FALSE);
char* cb_cThread_Peek (cb_cThread*,void* =NULL,int =0,void* =NULL,int =0);
char* cb_cThread_GetLine (cb_cThread*,void* =NULL,void* =NULL,int =0,int =-1,int =FALSE);
char* cb_cThread_PeekLine (cb_cThread*,void* =NULL,void* =NULL,int =0,int =-1);
char* cb_cThread_ReadLine (cb_cThread*,void* =NULL,void* =NULL,int =0,int =-1);
int cb_cThread_HasLine (cb_cThread*,int =0);
int cb_cThread_WriteFile (cb_cThread*,cb_File*);
int cb_cThread_WriteFileName (cb_cThread*,const cb_Thread);
cb_cThread* cb_cThread_ReadFile (cb_cThread*,cb_File*,int =0);
cb_cThread* cb_cThread_ReadFileName (cb_cThread*,const cb_Thread,int =0);
int cb_cThread_Seek (cb_cThread*,int =0,int =SEEK_SET);
int cb_cThread_Tell (cb_cThread*);
char* cb_cThread_Read (cb_cThread*,int* =NULL,void* =NULL,int =-1);
cb_cThread* cb_cThread_Write (cb_cThread*,const void*,int =-1);
cb_EndExternC

#endif
