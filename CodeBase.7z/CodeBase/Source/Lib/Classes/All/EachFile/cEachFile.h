
#ifndef cb_cEachFile2_H_
#define cb_cEachFile2_H_

#define cb_cEachFile_Rewind(x) cb_cEachFile_Open(x,NULL)
#define cb_cEachFile_Next cb_cEachFile_Get
#define cb_cEachFile_Name(x) (x)->sFileName
#define cb_cEachFile_IsDir cb_cEachFile_IsFolder

cb_BeginExternC
cb_cEachFile* cb_cEachFile_Terminate (cb_cEachFile*);
cb_Integer cb_cEachFile_OpenV (cb_cEachFile*,void**);
char* cb_cEachFile_Get (cb_cEachFile*,void* =NULL,cb_Integer =cb_MIN_INTEGER32);
cb_Boolean cb_cEachFile_IsFile (cb_cEachFile*);
cb_Boolean cb_cEachFile_IsFolder (cb_cEachFile*);
cb_cEachFile* cb_cEachFile_Initialize (cb_cEachFile* =NULL);
cb_Integer cb_CDECL cb_cEachFile_Open (cb_cEachFile*,...);
char* cb_CDECL cb_cEachFile_First (cb_cEachFile*,...);
cb_EndExternC

#endif
