
For this Compiler Suite to work out of the box,
you must have gcc installed and set in the PATH enviroment.
you can download it from here:
https://sourceforge.net/projects/mingw-w64/files/

note: instead of setting gcc path in the enviroment,
you can set it in the compiler cfg file - CodeBase/Bin/cb.cfg

Other than gcc path, you need no furthur setting,
just extract codebase folder to any writeable location on your HD.

you can start with the ide located in CodeBase/Bin/cbIDE.exe

for more details look at the doc folder,
and browse the Examples under CodeBase/Source, they contained self executing batch files.