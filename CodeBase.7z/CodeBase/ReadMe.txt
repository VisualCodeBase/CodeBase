
For this Compiler Suite to work you must have gcc
you can download it from here
https://sourceforge.net/projects/mingw-w64/files/

for more details look at the doc folder