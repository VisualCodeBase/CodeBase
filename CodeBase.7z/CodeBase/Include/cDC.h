
#ifndef cb_cDC1_H_
#define cb_cDC1_H_

typedef struct cb_s_cb_cDC_ {
  HWND hWnd;
  HDC hDC_;
  HBITMAP hBmp_;
  HBITMAP hOldBmp_;
  HFONT hOldFnt_;
  cb_Integer bkMode_;
  cb_Integer X_;
  cb_Integer Y_;
  cb_Integer L_;
  cb_Integer T_;
  cb_Integer W_;
  cb_Integer H_;
  cb_Integer Top_;
  RECT rc_;
  cb_Integer A_;
  cb_Integer iMode_;
  cb_Integer TextH;
  COLORREF clrFore;
  COLORREF clrBack;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cDC, *Pcb_cDC;

#endif
