
#ifndef cb_Def_h_
#define cb_Def_h_

#ifdef _WIN32_WINNT

#ifndef GWLP_STYLE
#define GWLP_STYLE GWL_STYLE
#endif
#ifndef GWLP_EXSTYLE
#define GWLP_EXSTYLE GWL_EXSTYLE
#endif

#ifndef LVIS_UNCHECKED
#define LVIS_UNCHECKED 0x1000
#endif

#ifndef LVIS_CHECKED
#define LVIS_CHECKED 0x2000
#endif

#ifndef TVIS_FOCUSED
#define TVIS_FOCUSED 1
#endif

#ifndef TVIS_UNCHECKED
#define TVIS_UNCHECKED 0x1000
#endif

#ifndef TVIS_CHECKED
#define TVIS_CHECKED 0x2000
#endif

#ifndef DECLSPEC_UUID
#if (_MSC_VER >= 1100) && defined(__cplusplus)
#define DECLSPEC_UUID(x) __declspec(uuid(x))
#else
#define DECLSPEC_UUID(x)
#endif
#endif

#if (WINVER >= 0x0501)
#ifndef SS_REALSIZECONTROL
#define SS_REALSIZECONTROL  0x00000040L
#endif
#endif

#ifndef SCF_NOKBUPDATE
#define SCF_NOKBUPDATE  0x0020
#endif

#if defined(__GNUC__) || defined(__GNUG__) || defined(__BCPLUSPLUS__) || defined(__POCC__)

#ifdef __BCPLUSPLUS__
#define _memicmp memicmp
#define _stricmp stricmp
#define _kbhit kbhit
#define _strlwr strlwr
#define _strupr strupr
#define _chmod chmod
#define _chsize chsize
#define wremove _wremove
#endif

#ifndef __POCC__
#if(WINVER >= 0x0500)
#define TPM_HORPOSANIMATION 0x0400L
#define TPM_HORNEGANIMATION 0x0800L
#define TPM_VERPOSANIMATION 0x1000L
#define TPM_VERNEGANIMATION 0x2000L
#if(_WIN32_WINNT >= 0x0500)
#define TPM_NOANIMATION     0x4000L
#if(_WIN32_WINNT >= 0x0501)
#ifndef CB_GETCOMBOBOXINFO
#define CB_GETCOMBOBOXINFO  0x0164
#endif
#define TPM_LAYOUTRTL       0x8000L
#endif /* _WIN32_WINNT >= 0x0501 */
#endif /* _WIN32_WINNT >= 0x0500 */
#endif /* WINVER >= 0x0500 */
#if(_WIN32_WINNT >= 0x0601)
#define TPM_WORKAREA        0x10000L
#endif /* _WIN32_WINNT >= 0x0601 */

#define TVM_GETEXTENDEDSTYLE (TV_FIRST + 45)
#define TreeView_GetExtendedStyle(x) (DWORD)SNDMSG(x, TVM_GETEXTENDEDSTYLE, 0, 0L)
#define TVM_SETEXTENDEDSTYLE (TV_FIRST + 44)
#define TreeView_SetExtendedStyle(x, p1, p2) (DWORD)SNDMSG(x, TVM_SETEXTENDEDSTYLE, p2, p1)
#endif  // ifndef __POCC__

#if defined(__GNUC__) || defined(__GNUG__)
#define SES_EXTENDBACKCOLOR  4

#define ERROR_INTERNET_DIALOG_PENDING  (INTERNET_ERROR_BASE+49)
#define ERROR_INTERNET_RETRY_DIALOG  (INTERNET_ERROR_BASE+50)
#define ERROR_INTERNET_HTTPS_HTTP_SUBMIT_REDIR  (INTERNET_ERROR_BASE+52)
#define ERROR_INTERNET_INSERT_CDROM  (INTERNET_ERROR_BASE+53)
#define ERROR_INTERNET_FORTEZZA_LOGIN_NEEDED  (INTERNET_ERROR_BASE+54)
#define ERROR_INTERNET_SEC_CERT_ERRORS  (INTERNET_ERROR_BASE+55)
#define ERROR_INTERNET_SEC_CERT_NO_REV  (INTERNET_ERROR_BASE+56)
#define ERROR_INTERNET_SEC_CERT_REV_FAILED  (INTERNET_ERROR_BASE+57)
#define ERROR_FTP_NO_PASSIVE_MODE  (INTERNET_ERROR_BASE+112)
#define ERROR_HTTP_COOKIE_NEEDS_CONFIRMATION  (INTERNET_ERROR_BASE+161)
#define ERROR_HTTP_COOKIE_DECLINED  (INTERNET_ERROR_BASE+162)
#define ERROR_INTERNET_DISCONNECTED  (INTERNET_ERROR_BASE+163)
#define ERROR_INTERNET_SERVER_UNREACHABLE  (INTERNET_ERROR_BASE+164)
#define ERROR_INTERNET_PROXY_SERVER_UNREACHABLE  (INTERNET_ERROR_BASE+165)
#define ERROR_INTERNET_BAD_AUTO_PROXY_SCRIPT  (INTERNET_ERROR_BASE+166)
#define ERROR_INTERNET_UNABLE_TO_DOWNLOAD_SCRIPT  (INTERNET_ERROR_BASE+167)
#define ERROR_HTTP_REDIRECT_NEEDS_CONFIRMATION  (INTERNET_ERROR_BASE+168)
#define ERROR_INTERNET_SEC_INVALID_CERT  (INTERNET_ERROR_BASE+169)
#define ERROR_INTERNET_SEC_CERT_REVOKED  (INTERNET_ERROR_BASE+170)
#define ERROR_INTERNET_FAILED_DUETOSECURITYCHECK  (INTERNET_ERROR_BASE+171)
#define ERROR_INTERNET_NOT_INITIALIZED  (INTERNET_ERROR_BASE+172)
#define ERROR_INTERNET_NEED_MSN_SSPI_PKG  (INTERNET_ERROR_BASE+173)
#define ERROR_INTERNET_LOGIN_FAILURE_DISPLAY_ENTITY_BODY  (INTERNET_ERROR_BASE+174)
#undef INTERNET_ERROR_LAST
#define INTERNET_ERROR_LAST  ERROR_INTERNET_LOGIN_FAILURE_DISPLAY_ENTITY_BODY
#define INTERNET_FLAG_FROM_CACHE  0x01000000
#define INTERNET_FLAG_OFFLINE  INTERNET_FLAG_FROM_CACHE

#define INTERNET_STATUS_DETECTING_PROXY         80
#define INTERNET_STATUS_INTERMEDIATE_RESPONSE   120
#define INTERNET_STATUS_USER_INPUT_REQUIRED     140
#define INTERNET_STATUS_STATE_CHANGE            200
#else  // defined(__GNUC__) || defined(__GNUG__)

#define INTERNET_STATUS_COOKIE_SENT             320
#define INTERNET_STATUS_COOKIE_RECEIVED         321
#define INTERNET_STATUS_PRIVACY_IMPACTED        324
#define INTERNET_STATUS_P3P_HEADER              325
#define INTERNET_STATUS_P3P_POLICYREF           326
#define INTERNET_STATUS_COOKIE_HISTORY          327

typedef struct {
    BOOL    fAccepted;
    BOOL    fLeashed;
    BOOL    fDowngraded;
    BOOL    fRejected;
}
InternetCookieHistory;
#endif

#elif defined(__WATCOM_CPLUSPLUS__) //|| defined(__TINYC__)

//commctrl.h
#ifdef UNICODE
    #define HDN_ITEMCHANGING        HDN_ITEMCHANGINGW
    #define HDN_ITEMCHANGED         HDN_ITEMCHANGEDW
    #define HDN_ITEMCLICK           HDN_ITEMCLICKW
    #define HDN_ITEMDBLCLICK        HDN_ITEMDBLCLICKW
    #define HDN_DIVIDERDBLCLICK     HDN_DIVIDERDBLCLICKW
    #define HDN_BEGINTRACK          HDN_BEGINTRACKW
    #define HDN_ENDTRACK            HDN_ENDTRACKW
    #if (_WIN32_IE >= 0x0300)
        #define HDN_GETDISPINFO     HDN_GETDISPINFOW
    #endif
#else
    #define HDN_ITEMCHANGING        HDN_ITEMCHANGINGA
    #define HDN_ITEMCHANGED         HDN_ITEMCHANGEDA
    #define HDN_ITEMCLICK           HDN_ITEMCLICKA
    #define HDN_ITEMDBLCLICK        HDN_ITEMDBLCLICKA
    #define HDN_DIVIDERDBLCLICK     HDN_DIVIDERDBLCLICKA
    #define HDN_BEGINTRACK          HDN_BEGINTRACKA
    #define HDN_ENDTRACK            HDN_ENDTRACKA
    #if (_WIN32_IE >= 0x0300)
        #define HDN_GETDISPINFO     HDN_GETDISPINFOA
    #endif
#endif

//mmsystem.h
#define MIXER_SETCONTROLDETAILSF_VALUE  0x00000000L
#define MIXER_SETCONTROLDETAILSF_CUSTOM  0x00000001L
#define MIXER_SETCONTROLDETAILSF_QUERYMASK  0x0000000FL

#ifndef LVM_SORTITEMSEX
#define LVM_SORTITEMSEX                 (LVM_FIRST + 81)
#endif

#elif defined(__DMC__)

#if (_WIN32_WINNT >= 0x0500)
#ifndef LWA_ALPHA
#define LWA_ALPHA 0x00000002
#endif
#ifndef TPM_NOANIMATION
#define TPM_NOANIMATION  0x4000L
#endif
#if (_WIN32_WINNT >= 0x0501)
#ifndef CB_GETCOMBOBOXINFO
#define CB_GETCOMBOBOXINFO  0x0164
#endif
#endif
#endif

typedef struct tagINITCOMMONCONTROLSEX {
    DWORD dwSize;
    DWORD dwICC;
} INITCOMMONCONTROLSEX, *LPINITCOMMONCONTROLSEX;

///WINCOMMCTRLAPI BOOL WINAPI InitCommonControlsEx(LPINITCOMMONCONTROLSEX);

#define InitCommonControlsEx(x) InitCommonControls

#define ICC_LISTVIEW_CLASSES  0x00000001
#define ICC_TREEVIEW_CLASSES  0x00000002
#define ICC_BAR_CLASSES  0x00000004
#define ICC_TAB_CLASSES  0x00000008
#define ICC_UPDOWN_CLASS  0x00000010
#define ICC_PROGRESS_CLASS  0x00000020
#define ICC_USEREX_CLASSES  0x00000200
#define ICC_DATE_CLASSES  0x00000100
#define WS_EX_LAYERED  0x00080000
#define LWA_COLORKEY  0x00000001
#define LWA_ALPHA  0x00000002
///WINUSERAPI BOOL WINAPI SetLayeredWindowAttributes(HWND,COLORREF,BYTE,DWORD);

#ifndef UINT_PTR
#define UINT_PTR DWORD
#endif
#ifndef LONG_PTR
#define LONG_PTR LONG
#endif

#ifndef GWLP_WNDPROC
#define GWLP_WNDPROC GWL_WNDPROC
#define GWLP_USERDATA GWL_USERDATA
#define GCLP_HBRBACKGROUND GCL_HBRBACKGROUND
#define GetWindowLongPtr GetWindowLong
#define SetWindowLongPtr SetWindowLong
#define GetClassLongPtr GetClassLong
#define SetClassLongPtr SetClassLong
#endif

#ifndef IDC_HAND
#define IDC_HAND MAKEINTRESOURCE(32649)
#endif

#ifndef LVITEM
#define LVITEM LV_ITEMA

typedef struct tagNMLISTVIEW {
    NMHDR hdr;
    int iItem;
    int iSubItem;
    UINT uNewState;
    UINT uOldState;
    UINT uChanged;
    POINT ptAction;
    LPARAM lParam;
} NMLISTVIEW, *LPNMLISTVIEW;
#endif

#endif  // defined(__GNUC__) || defined(__GNUG__) || defined(__BCPLUSPLUS__) || define(__POCC__)

#endif  // _WIN32_WINNT

#endif  // cb_Def_h_
