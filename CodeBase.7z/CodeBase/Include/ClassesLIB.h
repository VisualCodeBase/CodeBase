void cb_DEFCALL cb_HRTimerThreadFunction_ (HWND hWnd,unsigned int id,void* HRInterval,cb_Integer* iFlag,void (cb_CDECL *onTimer)(void* T,unsigned int lParam));
