/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*    This file was generated with    */
/*    CodeBase - A Compiler Frontend To C/C++ Compilers - (Version 1.00)    */
/*    Copyright � SoftBase Labs.  All rights reserved. (R)    */
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

#ifndef Classes_h_
#define Classes_h_

#if defined(__GNUC__) || defined(__GNUG__)
#include <malloc.h>
#endif
#include <wchar.h>

/*((((((((((((((  Compilers/Platforms Definitions  ))))))))))))))*/

#define cb_CLIBCALL cb_CDECL
#if defined(__GNUC__) || defined(__GNUG__) || defined(__clang__)
#endif

/*((((((((((((((  Public Headers  ))))))))))))))*/


/*((((((((((((((  Global Macros/Constants  ))))))))))))))*/

#ifndef ONE_SECOND
#define ONE_SECOND 1000
#endif
#ifndef ONE_MINUTE
#define ONE_MINUTE (ONE_SECOND*60)
#endif

/*((((((((((((((  Global Variables  ))))))))))))))*/

extern cb_cFile* cb_cFile_ArrayFiles_;
extern cb_Integer cb_cFile_MaxFiles_;
extern cb_Integer cb_cFile_FilesNum_;
extern void* cb_cFile_StdIn;
extern void* cb_cFile_StdErr;
extern void* cb_cFile_StdOut;

/*((((((((((((((  Global Prototypes  ))))))))))))))*/

cb_BeginExternC
#if !defined(USER_LIBRARY) && !defined(USE_CFILE)
void cb_cFile_OnEnd_ (void);
#endif
cb_cFile* cb_cFile_FreeFile_ (void);
cb_cTimer* cb_cTimer_Initialize (cb_cTimer* =NULL,void* =NULL,void* =NULL);
void cb_cTimer_Terminate (cb_cTimer*);
cb_EndExternC

/*((((((((((((((  Public Macros  ))))))))))))))*/

#define cb_cTimer_Create cb_cTimer_Initialize
#define cb_cTimer_Destroy cb_cTimer_Terminate

/*((((((((((((((  Public Declarations  ))))))))))))))*/

EXTERN_C void Classes_Terminate (void);

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Declarations -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


#endif  // Classes_h_
