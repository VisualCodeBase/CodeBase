
#ifndef cppString_H_
#define cppString_H_

#ifndef cppStringInt
#define cppStringInt long
#endif

#ifndef cppStringUInt
#define cppStringUInt unsigned long
#endif

#ifndef cppStringChar
#define cppStringChar char // Don't change this!
#endif

class cppString
{
  protected:
    cppStringChar *b;
    cppStringInt sze;
    cppStringInt l;

  public:
    cppString& append(const cppStringChar*, cppStringInt);
    inline cppString& append(const cppString& str) { return append(str.b,str.l); }
    inline cppString& append(const cppStringChar*);
    inline cppString& append(const cppStringChar);
    inline cppString& append(cppStringInt);
    inline cppString& append(double);

    cppString& assign(const cppStringChar*, cppStringInt);
    inline cppString& assign(const cppString& str) { return assign(str.b,str.l); }
    inline cppString& assign(const cppStringChar*);
    inline cppString& assign(const cppStringChar);
    inline cppString& assign(cppStringInt);
    inline cppString& assign(double);

    cppString() { b=NULL; sze=0; l=0; }
    cppString(const cppStringChar* s, cppStringInt n) { b=NULL; sze=0; assign(s,n); }
    cppString(const cppStringChar* s) { b=NULL; sze=0; assign(s); }
    cppString(const cppString& str) { b=NULL; sze=0; assign(str); }
    cppString(const cppStringChar c) { b=NULL; sze=0; assign(c); }
    cppString(cppStringInt val) { b=NULL; sze=0; assign(val); }
    cppString(double val) { b=NULL; sze=0; assign(val); }

    void clear();

    ~cppString() { clear(); }

    inline const cppStringChar* c_str() { return b; }
    inline const cppStringChar* strptr() { return b; }

    inline cppStringInt length() { return l; }
    inline cppStringInt GetLength() { return l; }

    inline operator const cppString*() const { return (const cppString*)b; }


    cppString& operator = (const cppString& str) { return assign(str); }
    cppString& operator = (const cppStringChar* s) { return assign(s); }
    cppString& operator = (const cppStringChar c) { return assign(c); }
    cppString& operator = (cppStringInt val) { return assign(val); }
    cppString& operator = (double val) { return assign(val); }

    cppString& operator += (const cppString& str) { return append(str); }
    cppString& operator += (const cppStringChar* s) { return append(s); }
    cppString& operator += (const cppStringChar c) { return append(c); }
    cppString& operator += (cppStringInt val) { return append(val); }
    cppString& operator += (double val) { return append(val); }

    inline cppStringInt cmpcase(const cppStringChar*);
    inline cppStringInt cmpcase(const cppString&);
    cppStringInt cmpcase(cppStringChar);
    cppStringInt cmpcase(cppStringInt);
    cppStringInt cmpcase(double);

    inline cppStringInt cmpnocase(const cppStringChar*);
    inline cppStringInt cmpnocase(const cppString&);
    cppStringInt cmpnocase(cppStringChar);
    cppStringInt cmpnocase(cppStringInt);
    cppStringInt cmpnocase(double);

    cppStringInt FindAt(const cppStringChar*,cppStringInt);
    cppStringInt FindAt(cppStringInt,cppStringInt);
    inline cppStringInt Find(const cppStringChar* s) { return FindAt(s,0); }
    inline cppStringInt Find(const cppString& s) { return FindAt(s.b,0); }
    inline cppStringInt Find(cppStringInt c) { return FindAt(c,0); }
    //inline cppStringInt FindAt(const cppString& s,cppStringInt n) { return FindAt(s.b,n); }
    inline cppStringInt Find(const cppString& s,cppStringInt n) { return FindAt(s.b,n); }
    cppStringInt FindNoCaseAt(const cppStringChar*,cppStringInt);
    cppStringInt FindNoCaseAt(cppStringInt,cppStringInt);
    inline cppStringInt FindNoCase(const cppStringChar* s) { return FindNoCaseAt(s,0); }
    inline cppStringInt FindNoCase(const cppString& s) { return FindNoCaseAt(s.b,0); }
    inline cppStringInt FindNoCase(cppStringInt c) { return FindNoCaseAt(c,0); }
    inline cppStringInt FindNoCaseAt(const cppString& s,cppStringInt n) { return FindNoCaseAt(s.b,n); }

    inline cppString& MakeLower();
    inline cppString& MakeUpper();

    inline cppStringChar getat(cppStringUInt);

    cppStringChar putat(cppStringChar, cppStringUInt, cppStringUInt=-1);
    cppString& putat(cppStringChar*, cppStringUInt, cppStringUInt=-1);

    cppStringInt getlineat(cppStringChar*, cppStringUInt=0);

    inline cppStringChar operator [] (cppStringUInt n) { return getat(n); }

  private:
    static cppString* AddTmp_(cppStringInt=1); // this is for garbage collection. the operator +, and Left/Mid/Right use it.

  public:
    static void Terminate(); // this should be called only after all the instances of the class were deleted. on app close all memory is anyway freed by the OS.

    cppString* Mid(cppStringUInt, cppStringInt=-1);
    inline cppString* Left(cppStringInt n) { return Mid(0,n); }
    inline cppString* Right(cppStringInt);
    inline cppString* substr(cppStringUInt p, cppStringInt n) { return Mid(p,n); }

    friend cppString operator + (const cppString&, const cppString&);
    friend cppString operator + (const cppString&, const cppStringChar*);
    friend cppString operator + (const cppString&, cppStringChar);
    friend cppString operator + (const cppString&, cppStringInt);
    friend cppString operator + (const cppString&, double);
    friend cppString operator + (const cppStringChar*, const cppString&);
    friend cppString operator + (cppStringChar, const cppString&);
    friend cppString operator + (cppStringInt, const cppString&);
    friend cppString operator + (double, const cppString&);
    friend cppStringInt operator == (const cppStringChar* s, cppString& str) { return !str.cmpcase(s); }
    friend cppStringInt operator == (cppString& str, const cppStringChar* s) { return !str.cmpcase(s); }
    friend cppStringInt operator == (cppString& str1, cppString& str2) { return !str1.cmpcase(str2); }
    friend cppStringInt operator != (const cppStringChar* s, cppString& str) { return str.cmpcase(s); }
    friend cppStringInt operator != (cppString& str, const cppStringChar* s) { return str.cmpcase(s); }
    friend cppStringInt operator != (cppString& str1, cppString& str2) { return str1.cmpcase(str2); }
    friend cppStringInt operator == (const cppStringChar c, cppString& str) { return !str.cmpcase(c); }
    friend cppStringInt operator == (cppStringInt val, cppString& str) { return !str.cmpcase(val); }
    friend cppStringInt operator == (double val, cppString& str) { return !str.cmpcase(val); }
    friend cppStringInt operator == (cppString& str, const cppStringChar c) { return !str.cmpcase(c); }
    friend cppStringInt operator == (cppString& str, cppStringInt val) { return !str.cmpcase(val); }
    friend cppStringInt operator == (cppString& str, double val) { return !str.cmpcase(val); }
    friend cppStringInt operator != (const cppStringChar c, cppString& str) { return str.cmpcase(c); }
    friend cppStringInt operator != (cppStringInt val, cppString& str) { return str.cmpcase(val); }
    friend cppStringInt operator != (double val, cppString& str) { return str.cmpcase(val); }
    friend cppStringInt operator != (cppString& str, const cppStringChar c) { return str.cmpcase(c); }
    friend cppStringInt operator != (cppString& str, cppStringInt val) { return str.cmpcase(val); }
    friend cppStringInt operator != (cppString& str, double val) { return str.cmpcase(val); }
};

#endif  //cppString_H_
