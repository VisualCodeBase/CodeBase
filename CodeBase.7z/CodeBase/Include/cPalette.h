
#ifndef cb_cPalette1_H_
#define cb_cPalette1_H_

#define cb_cPalette_MAX_SIZE_ 256

typedef struct cb_s_cb_cPalette_ {
  COLORREF m_Buf[cb_cPalette_MAX_SIZE_];
  cb_Integer m_Len;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cPalette, *Pcb_cPalette;

#endif
