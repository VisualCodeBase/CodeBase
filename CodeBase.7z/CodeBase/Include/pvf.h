/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*    This file was generated with    */
/*    CodeBase - A Compiler Frontend To C++ - (Version 1.00)    */
/*    Copyright � SoftBase Labs.  MIT    */
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

#ifndef pvf_h_
#define pvf_h_

#if defined(__GNUC__) || defined(__GNUG__)
#include <malloc.h>
#endif
#include <wchar.h>
#include <tchar.h>
#include <winsock2.h>
#include <wininet.h>
#include <vb_Def.h>

/*((((((((((((((  Compilers/Platforms Definitions  ))))))))))))))*/

#ifndef WINSOCK_VERSION
#define WINSOCK_VERSION  MAKEWORD(2,2)
#endif
#define cb_CLIBCALL cb_CDECL
#if defined(__GNUC__) || defined(__GNUG__) || defined(__clang__)
#define INTERNET_DIAL_FORCE_PROMPT 0x2000
#define INTERNET_DIAL_SHOW_OFFLINE 0x4000
#define FLAG_ICC_FORCE_CONNECTION 0x00000001
#endif

/*((((((((((((((  Public Headers  ))))))))))))))*/


#pragma pack(1)
// The format chunk of a wave file
typedef struct {
  char chunkID[4];        // String: must be "fmt " (0x666D7420).
  unsigned cbDataSize;      // Unsigned 4-byte little endian int: Byte count for the remainder of the chunk: 16 + extraFormatbytes.
  unsigned short FormatTag;    // Unsigned 2-byte little endian int
  unsigned short nChannels;    // Unsigned 2-byte little endian int
  unsigned sampleRate;        // Unsigned 4-byte little endian int
  unsigned avgBytesPerSecond;  // Unsigned 4-byte little endian int: This value indicates how many bytes of wave data must be streamed to a D/A converter per second in order to play the wave file. This information is useful when determining if data can be streamed from the source fast enough to keep up with playback. = SampleRate * BlockAlign.
  unsigned short blockAlign;        // Unsigned 2-byte little endian int: The number of bytes per sample slice. This value is not affected by the number of channels and can be calculated with the formula: blockAlign = BitsPerSample / 8 * nChannels
  unsigned short BitsPerSample;// Unsigned 2-byte little endian int
} WaveFormatChunk;
#pragma pack()

/*((((((((((((((  Global Types and Unions  ))))))))))))))*/


typedef struct cb_s_pvf_WaveFile_ {
  cb_File* fp;
  char s[cb_MAX_FILE_NAME];
  cb_Integer f;
  cb_Integer sze;
  cb_Integer smprate;
  cb_Integer ch;
  cb_Integer bps;
} pvf_WaveFile, *Ppvf_WaveFile;

/*((((((((((((((  Global Prototypes  ))))))))))))))*/

cb_BeginExternC
char* cb_DEFCALL pvf_Float2Str (double,void* =NULL,cb_Integer =0);
char* cb_DEFCALL pvf_LLong2Str (long long,void* =NULL,cb_Integer =0);
cb_Integer pvf_GetMouseShift (HWND);
cb_Integer pvf_eelGetMouseShift (HWND);
cb_Integer cb_DEFCALL pvf_WaveFile_Get (pvf_WaveFile*,void*,cb_Integer);
cb_Integer cb_DEFCALL pvf_WaveFile_GetAsSingle (pvf_WaveFile*,void*,cb_Integer);
cb_Integer cb_DEFCALL pvf_WaveFile_GetAsDouble (pvf_WaveFile*,void*,cb_Integer);
cb_Integer cb_DEFCALL pvf_GetWaveSingle (cb_File*,float*,cb_Integer,void* =NULL,WORD* =NULL,void* =NULL,WORD* =NULL,WaveFormatChunk* =NULL);
cb_Integer cb_DEFCALL pvf_GetWaveDouble (cb_File*,double*,cb_Integer,void* =NULL,WORD* =NULL,void* =NULL,WORD* =NULL,WaveFormatChunk* =NULL);
void cb_DEFCALL pvf_ImageBlt (HWND,HBITMAP,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer =0,cb_Integer =0,cb_Integer =-1,cb_Integer =-1);
cb_EndExternC

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Declarations -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


#endif  // pvf_h_
