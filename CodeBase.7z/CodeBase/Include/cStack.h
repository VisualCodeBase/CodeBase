
#ifndef cb_cStack1_H_
#define cb_cStack1_H_

typedef struct cb_s_cb_cStack_ {
  cb_Integer m_Cnt;
  cb_Integer m_Size;
  BYTE* m_Buf;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cStack, *Pcb_cStack;

#endif
