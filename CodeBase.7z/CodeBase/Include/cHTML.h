
#ifndef cb_cHTML1_H_
#define cb_cHTML1_H_

typedef struct cb_s_cb_cHTML_ {
  cb_Boolean m_Enabled;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cHTML, *Pcb_cHTML;

#endif
