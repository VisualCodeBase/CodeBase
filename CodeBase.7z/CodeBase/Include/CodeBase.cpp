/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*    This file was generated with    */
/*    CodeBase - A Compiler Frontend To C/C++/Java/Pascal Compilers - (Version 1.00)    */
/*    Copyright © SoftBase Labs.  MIT    */
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

//CommandLine:
//-l

#define __CODEBASE__
#define __CODEBASE_LIB__


/* MODULE::cb_MemICompW */
cb_Integer cb_DEFCALL cb_MemICompW (const wchar_t *a,const wchar_t *b,cb_UInteger sze)
{
  register const wchar_t *i1 = a;
  register const wchar_t *i2 = b;
  register cb_UInteger i, j;

  for(;sze;i1++,i2++,sze--) {
    i = (cb_UInteger)cb_ToLowerW(i1[0]); j = (cb_UInteger)cb_ToLowerW(i2[0]);
    if (i!=j) { if (i<j) return -1; return 1; }
  }
  return 0;
}
/* END MODULE */


/* MODULE::cb_MemIChar */
const void*  cb_DEFCALL  cb_MemIChar (const void *a,cb_Integer b,cb_UInteger sze)
{
  register const char *tmp1 = (const char*)a;
  register cb_Integer i, c = cb_ToLower(b);
  for(i = sze;i;tmp1++,i--) if (cb_ToLower(*tmp1)==c) goto exit0000;
  tmp1 = NULL;
exit0000:
  return tmp1;
}
/* END MODULE */


/* MODULE::cb_MemICharW */
const wchar_t*  cb_DEFCALL  cb_MemICharW (const wchar_t *a,wchar_t b,cb_UInteger sze)
{
  register const wchar_t *tmp1 = a;
  register cb_Integer i;
  register cb_UInteger c = cb_ToLowerW(b);
  for(i = sze;i;tmp1++,i--) if (cb_ToLowerW(*tmp1)==c) goto exit0000;
  tmp1 = NULL;
exit0000:
  return tmp1;
}
/* END MODULE */


/* MODULE::cb_AddTmpDynStr_ */
char * cb_DEFCALL cb_AddTmpDynStr_ (void *Ptr1)
{
  cb_TmpDynStrCyclesCnt_ = (cb_TmpDynStrCyclesCnt_ + 1) & cb_TmpDynStrCyclesMax_;
  register char **sTmp = cb_TmpDynStrPtrBuf_ + cb_TmpDynStrCyclesCnt_;
  if (sTmp[0]) cb_MemFreeM(sTmp[0]);
  return (sTmp[0] = (char*)Ptr1);
}
/* END MODULE */


/* MODULE::cb_TmpDynStr */
char * cb_DEFCALL cb_TmpDynStr (cb_Integer Bites)
{
  cb_TmpDynStrCyclesCnt_ = (cb_TmpDynStrCyclesCnt_ + 1) & cb_TmpDynStrCyclesMax_;
  register char **sTmp = cb_TmpDynStrPtrBuf_ + cb_TmpDynStrCyclesCnt_;
  if (sTmp[0]) cb_MemFreeM(sTmp[0]);
  return (sTmp[0] = (char*)cb_MemAllocM(Bites+sizeof(cb_Integer)));
}
/* END MODULE */


/* MODULE::cb_FreeTmpDynStr */
void cb_FreeTmpDynStr (void)
{
  register cb_Integer i;
  register char *sTmp;
  i = cb_TmpDynStrCyclesMax_; do { sTmp = cb_TmpDynStrPtrBuf_[i]; if (sTmp) cb_MemFreeM(sTmp); i--; } while(i);
}
/* END MODULE */


/* MODULE::cb_NewStr_ */
char * cb_DEFCALL cb_NewStr_ (const void *src, void *dst, cb_Integer len)
{
  register char *strtmp = (char*)dst;
  register cb_Integer i = len;
  register const char *Src1 = (const char*)src;
  if (!strtmp) { strtmp = cb_TmpDynStr(i); goto Chk0000; }
  if ((cb_UInteger)strtmp>=(cb_UInteger)-3) {
    strtmp = (char*)cb_MemAllocM(i+sizeof(cb_Integer));
Chk0000:
    if (strtmp) {
      if (i) { if (Src1) cb_MemCopy(strtmp,Src1,i); else i = 0; }
      *((wchar_t*)(strtmp+i)) = 0;
    }
  }
  else if (i>=0) if (Src1) {
    if (i>0) cb_MemMove(strtmp,Src1,i);
    strtmp[i] = 0;
  }
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_NewStr */
char * cb_DEFCALL cb_NewStr (const void *src, void *dst, cb_Integer len)
{
  register cb_Integer i = len;
  register const char *Src1 = (const char*)src;
  if ((cb_UInteger)(i-1)>=(cb_UInteger)-6) { if (Src1) i = cb_StrLen(Src1); else i = 0; }
  return cb_NewStr_(Src1, dst, i);
}
/* END MODULE */


/* MODULE::cb_NewStrX */
char * cb_DEFCALL cb_NewStrX (const void *src, void *dst, cb_Integer len, cb_Integer sze)
{
  register cb_Integer i = len; if ((cb_UInteger)(i-1)>=(cb_UInteger)-6) i = cb_StrLen((const char*)src);
  if ((cb_UInteger)i>(cb_UInteger)(sze-1)) { i = sze; i--; }
  return cb_NewStr_(src,dst,i);
}
/* END MODULE */


/* MODULE::cb_NewStrW_ */
wchar_t * cb_DEFCALL cb_NewStrW_ (const void *src, void *dst, cb_Integer len)
{
  register char *strtmp = (char*)dst;
  register cb_Integer i = len; i <<= 1;
  register const char *Src1 = (const char*)src;
  if (!strtmp) { strtmp = (char*)cb_TmpDynStr(i+sizeof(cb_Integer)); goto Chk0000; }
  if ((cb_UInteger)strtmp>=(cb_UInteger)-3) {
    strtmp = (char*)cb_MemAllocM(i+sizeof(cb_Integer)+sizeof(cb_Integer));
Chk0000:
    if (!strtmp) goto Exit0000;
    if (i) { if (Src1) cb_MemCopy(strtmp,Src1,i); else i = 0; }
  }
  else if (i<0 || !Src1) goto Exit0000;
  else if (i>0) cb_MemMove(strtmp,Src1,i);
  *(wchar_t*)(strtmp+i) = 0;
Exit0000:
  return (wchar_t*)strtmp;
}
/* END MODULE */


/* MODULE::cb_NewStrW */
wchar_t * cb_DEFCALL cb_NewStrW (const void *src, void *dst, cb_Integer len)
{
  register cb_UInteger i = len;
  register const wchar_t *Src1 = (const wchar_t*)src;
  if ((cb_UInteger)(i-1)>=(cb_UInteger)-6) { if (Src1) i = cb_StrLenW(Src1); else i = 0; }
  return (wchar_t*)cb_NewStrW_(Src1, dst, i);
}
/* END MODULE */


/* MODULE::cb_NewStrXW */
wchar_t * cb_DEFCALL cb_NewStrXW (const void *src, void *dst, cb_Integer len, cb_Integer sze)
{
  register cb_Integer i = len; if ((cb_UInteger)(i-1)>=(cb_UInteger)-6) i = cb_StrLenW((const wchar_t*)src);
  if ((cb_UInteger)i>(cb_UInteger)(sze-1)) { i = sze; i--; }
  return cb_NewStrW_(src,dst,i);
}
/* END MODULE */


/* MODULE::cb_NewTempStr */
char * cb_DEFCALL cb_NewTempStr (const void *src)
{
  return cb_NewStr_(src, NULL, cb_StrLen((const char*)src));
}
/* END MODULE */


/* MODULE::cb_NewTempStrW */
wchar_t * cb_DEFCALL cb_NewTempStrW (const void *src)
{
  return cb_NewStrW_(src, NULL, cb_StrLenW((const wchar_t*)src));
}
/* END MODULE */


/* MODULE::cb_StrCopy */
char*  cb_DEFCALL  cb_StrCopy (void *a,const void *b)
{
  return (char*)cb_MemCopy(a,b,cb_StrLen((const char*)b)+sizeof(char));
}
/* END MODULE */


/* MODULE::cb_StrCopyW */
wchar_t*  cb_DEFCALL  cb_StrCopyW (void *a,const void *b)
{
  #define sze (cb_StrLenW((const wchar_t*)b) << 1)
  return (wchar_t*)cb_MemCopy(a,b,sze+sizeof(wchar_t));
  #undef sze
}
/* END MODULE */


/* MODULE::cb_StrNCopy */
char*  cb_DEFCALL  cb_StrNCopy (void *a,const void *b,cb_UInteger c)
{
  register cb_UInteger sze = cb_StrLen((const char*)b);
  register char *strtmp = (char*)a;
  if (sze>=c) { sze=c; sze--; }
  if (sze) cb_MemCopy(strtmp,b,sze);
  strtmp[sze] = 0;
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_StrNCopyW */
wchar_t*  cb_DEFCALL  cb_StrNCopyW (void *a,const void *b,cb_UInteger c)
{
  register cb_UInteger sze = cb_StrLenW((const wchar_t*)b);
  register wchar_t *strtmp = (wchar_t*)a;
  if (sze>=c) { sze=c; sze--; }
  sze<<=1;
  if (sze) cb_MemCopy(strtmp,b,sze);
  *(wchar_t*)(((char*)strtmp)+sze) = 0;
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_StrMove */
char*  cb_DEFCALL  cb_StrMove (void *a,const void *b)
{
  return (char*)cb_MemMove(a,b,cb_StrLen((const char*)b)+sizeof(char));
}
/* END MODULE */


/* MODULE::cb_StrMoveW */
wchar_t*  cb_DEFCALL  cb_StrMoveW (void *a,const void *b)
{
  #define sze (cb_StrLenW((const wchar_t*)b) << 1)
  return (wchar_t*)cb_MemMove(a,b,sze+sizeof(wchar_t));
  #undef sze
}
/* END MODULE */


/* MODULE::cb_StrNMove */
char*  cb_DEFCALL  cb_StrNMove (void *a,const void *b,cb_UInteger c)
{
  register cb_UInteger sze = cb_StrLen((const char*)b);
  register char *strtmp = (char*)a;
  if (sze>=c) { sze=c; sze--; }
  if (sze) cb_MemMove(strtmp,b,sze);
  strtmp[sze] = 0;
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_StrNMoveW */
wchar_t*  cb_DEFCALL  cb_StrNMoveW (void *a,const void *b,cb_UInteger c)
{
  register cb_UInteger sze = cb_StrLenW((const wchar_t*)b);
  register wchar_t *strtmp = (wchar_t*)a;
  if (sze>=c) { sze=c; sze--; }
  sze<<=1;
  if (sze) cb_MemMove(strtmp,b,sze);
  *(wchar_t*)(((char*)strtmp)+sze) = 0;
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_StrCat */
char*  cb_DEFCALL  cb_StrCat (void *a,const void *b)
{
  cb_MemCopy(((char*)a)+cb_StrLen((const char*)a),b,cb_StrLen((const char*)b)+sizeof(char));
  return (char*)a;
}
/* END MODULE */


/* MODULE::cb_StrCatW */
wchar_t*  cb_DEFCALL  cb_StrCatW (void *a,const void *b)
{
  register cb_UInteger sze = cb_StrLenW((const wchar_t*)a) << 1;
  register cb_UInteger tmp2 = cb_StrLenW((const wchar_t*)b) << 1;
  cb_MemCopy(((char*)a)+sze,b,tmp2+sizeof(wchar_t));
  return (wchar_t*)a;
}
/* END MODULE */


/* MODULE::cb_StrNCat */
char*  cb_DEFCALL  cb_StrNCat (void *a,const void *b,cb_UInteger c)
{
  register char *strtmp = (char*)a;
  register cb_UInteger len1, len2; len1 = cb_StrLen(strtmp);
  len2 = cb_StrLen((const char*)b); if (len2>c) len2 = c;
  if (len2) { cb_MemCopy(strtmp+len1,b,len2); len1 += len2; strtmp[len1] = 0; }
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_StrNCatW */
wchar_t*  cb_DEFCALL  cb_StrNCatW (void *a,const void *b,cb_UInteger c)
{
  register wchar_t *strtmp = (wchar_t*)a;
  register cb_UInteger len1, len2; len1 = cb_StrLenW(strtmp);
  len2 = cb_StrLenW((const wchar_t*)b); if (len2>c) len2 = c;
  if (len2) { cb_MemCopy(strtmp+len1,b,len2<<1); len1 += len2; strtmp[len1] = 0; }
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_StrComp */
__declspec(noinline) cb_Integer cb_CDECL cb_StrComp (const void *a, const void *b)
{
  return cb_MemComp(a,b,cb_StrLen((const char*)a)+1);
}
/* END MODULE */


/* MODULE::cb_StrIComp */
__declspec(noinline) cb_Integer cb_CDECL cb_StrIComp (const void *a, const void *b)
{
  return cb_MemIComp(a,b,cb_StrLen((const char*)a)+1);
}
/* END MODULE */


/* MODULE::cb_StrCompW */
__declspec(noinline) cb_Integer cb_CDECL cb_StrCompW (const wchar_t *a, const wchar_t *b)
{
  return cb_MemCompW(a,b,(cb_StrLenW(a)+1)<<1);
}
/* END MODULE */


/* MODULE::cb_StrICompW */
__declspec(noinline) cb_Integer cb_CDECL cb_StrICompW (const wchar_t *a, const wchar_t *b)
{
  return cb_MemICompW(a,b,cb_StrLenW(a)+1);
}
/* END MODULE */


/* MODULE::cb_LStrComp */
cb_Integer cb_DEFCALL cb_LStrComp (const void *A, const char *B, cb_Integer flg1, cb_UInteger sze)
{
  register cb_UInteger i = sze;
  if (i==(cb_UInteger)-1) i = cb_StrLen(B);
  register cb_Integer i1 = cb_MemComp(A,B,i);
  if (i1==0) {
    if (flg1) {
      i1 = ((const char*)A)[i]; if (!cb_IsAlphaDigit(i1)) if (i1!='_') return 0;
    }
  }
  return i1;
}
/* END MODULE */


/* MODULE::cb_LStrIComp */
cb_Integer cb_DEFCALL cb_LStrIComp (const void *A, const char *B, cb_Integer flg1, cb_UInteger sze)
{
  register cb_UInteger i = sze;
  if (i==(cb_UInteger)-1) i = cb_StrLen(B);
  register cb_Integer i1 = cb_MemIComp(A,B,i);
  if (i1==0) {
    if (flg1) {
      i1 = ((const char*)A)[i]; if (!cb_IsAlphaDigit(i1)) if (i1!='_') return 0;
    }
  }
  return i1;
}
/* END MODULE */


/* MODULE::cb_LStrCompW */
cb_Integer cb_DEFCALL cb_LStrCompW (const wchar_t *A, const wchar_t *B, cb_Integer flg1, cb_UInteger sze)
{
  register cb_UInteger i = sze;
  if (i==(cb_UInteger)-1) i = cb_StrLenW(B);
  register wint_t i1 = (wint_t)cb_MemComp(A,B,i<<1);
  if (i1==0) {
    if (flg1) {
      i1 = A[i]; if (!cb_IsAlphaDigitW(i1)) if (i1!='_') return 0;
    }
  }
  return (cb_Integer)i1;
}
/* END MODULE */


/* MODULE::cb_LStrICompW */
cb_Integer cb_DEFCALL cb_LStrICompW (const wchar_t *A, const wchar_t *B, cb_Integer flg1, cb_UInteger sze)
{
  register cb_UInteger i = sze;
  if (i==(cb_UInteger)-1) i = cb_StrLenW(B);
  register wint_t i1 = (wint_t)cb_MemICompW(A,B,i);
  if (i1==0) {
    if (flg1) {
      i1 = A[i]; if (!cb_IsAlphaDigitW(i1)) if (i1!='_') return 0;
    }
  }
  return (cb_Integer)i1;
}
/* END MODULE */


/* MODULE::cb_RStrComp */
cb_Integer cb_DEFCALL cb_RStrComp (const void *A, const char *B, cb_Integer flg1, cb_UInteger sze)
{
  register cb_UInteger i = sze;
  register cb_UInteger n = cb_StrLen((const char*)A);
  if (i==(cb_UInteger)-1) i = cb_StrLen(B);
  if (n<i) return -1;
  n -= i;
  register cb_Integer i1 = cb_MemComp(((const char*)A)+n,B,i);
  if (i1==0) {
    if (n) {
      if (flg1) {
        n--;
        i1 = ((const char*)A)[n]; if (!cb_IsAlphaDigit(i1)) if (i1!='_') return 0;
      }
    }
  }
  return i1;
}
/* END MODULE */


/* MODULE::cb_RStrIComp */
cb_Integer cb_DEFCALL cb_RStrIComp (const void *A, const char *B, cb_Integer flg1, cb_UInteger sze)
{
  register cb_UInteger i = sze;
  register cb_UInteger n = cb_StrLen((const char*)A);
  if (i==(cb_UInteger)-1) i = cb_StrLen(B);
  if (n<i) return -1;
  n -= i;
  register cb_Integer i1 = cb_MemIComp(((const char*)A)+n,B,i);
  if (i1==0) {
    if (n) {
      if (flg1) {
        n--;
        i1 = ((const char*)A)[n]; if (!cb_IsAlphaDigit(i1)) if (i1!='_') return 0;
      }
    }
  }
  return i1;
}
/* END MODULE */


/* MODULE::cb_RStrCompW */
cb_Integer cb_DEFCALL cb_RStrCompW (const wchar_t *A, const wchar_t *B, cb_Integer flg1, cb_UInteger sze)
{
  register cb_UInteger i = sze;
  register cb_UInteger n = cb_StrLenW(A);
  if (i==(cb_UInteger)-1) i = cb_StrLenW(B);
  i <<= 1;
  n <<= 1;
  if (n<i) return -1;
  n -= i;
  register wint_t i1 = (wint_t)cb_MemComp(A+n,B,i);
  if (i1==0) {
    if (n) {
      if (flg1) {
        n--;
        n--;
        i1 = *(wchar_t*)(((const char*)A)+n); if (!cb_IsAlphaDigitW(i1)) if (i1!='_') return 0;
      }
    }
  }
  return (cb_Integer)i1;
}
/* END MODULE */


/* MODULE::cb_RStrICompW */
cb_Integer cb_DEFCALL cb_RStrICompW (const wchar_t *A, const wchar_t *B, cb_Integer flg1, cb_UInteger sze)
{
  register cb_UInteger i = sze;
  register cb_UInteger n = cb_StrLenW(A);
  if (i==(cb_UInteger)-1) i = cb_StrLenW(B);
  if (n<i) return -1;
  n -= i;
  register wint_t i1 = (wint_t)cb_MemICompW(A+n,B,i);
  if (i1==0) {
    if (n) {
      if (flg1) {
        n--;
        i1 = A[n]; if (!cb_IsAlphaDigitW(i1)) if (i1!='_') return 0;
      }
    }
  }
  return (cb_Integer)i1;
}
/* END MODULE */


/* MODULE::cb_StrChar */
const char*  cb_DEFCALL  cb_StrChar (const void *a,cb_Integer b)
{
  register const char *p;
  register cb_Integer i = b;
  for(p=(const char*)a;*p;p++) if (*p==i) return p;
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharW */
const wchar_t*  cb_DEFCALL  cb_StrCharW (const wchar_t *a,wchar_t b)
{
  register const wchar_t *p;
  register cb_UInteger i = b;
  for(p=a;*p;p++) if (*p==i) return p;
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrIChar */
const char*  cb_DEFCALL  cb_StrIChar (const void *a,cb_Integer b)
{
  register const char *p = (const char*)a;
  register cb_Integer i = cb_ToLower(b);
  do {
    if (*p==0) break;
    if (cb_ToLower(*p)==i) return p;
    p++;
  } while(1);
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrICharW */
const wchar_t*  cb_DEFCALL  cb_StrICharW (const wchar_t *a,wchar_t b)
{
  register const wchar_t *p = a;
  register cb_UInteger i = cb_ToLowerW(b);
  do {
    if (*p==0) break;
    if (cb_ToLowerW(*p)==i) return p;
    p++;
  } while(1);
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrStr */
const char*  cb_DEFCALL  cb_StrStr (const void *a,const char *b)
{
  register const char *p1, *p2;
  register cb_Integer i;
  register const char *p3;
  p2 = b; i = *p2;
  for(p1=(const char*)a;;) {
    if (*p1==i) {
      if (i==0) return p1;
      p3 = p1;
      do { p2++; i = *p2; if (i==0) return p3; p1++; } while(*p1==i);
      p1 = p3; p2 = b; i = *p2;
    }
    else if (!*p1) break;
    p1++;
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrStrW */
const wchar_t*  cb_DEFCALL  cb_StrStrW (const wchar_t *a,const wchar_t *b)
{
  register const wchar_t *p1, *p2;
  register cb_UInteger i;
  register const wchar_t *p3;
  p2 = b; i = *p2;
  for(p1=a;;) {
    if (*p1==i) {
      if (i==0) return p1;
      p3 = p1;
      do { p2++; i = *p2; if (i==0) return p3; p1++; } while(*p1==i);
      p1 = p3; p2 = b; i = *p2;
    }
    else if (!*p1) break;
    p1++;
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrIStr */
const char*  cb_DEFCALL  cb_StrIStr (const void *a,const char *b)
{
  register const char *p1, *p2 = b;
  register cb_Integer i = cb_ToLower(*b);
  register const char *p3;
  for(p1=(const char*)a;;) {
    if (cb_ToLower(*p1)==i) {
      if (i==0) return p1;
      p3 = p1;
      do {
        p2++; if (*p2==0) return p3; p1++;
      } while(cb_ToLower(*p1)==cb_ToLower(*p2));
      p1 = p3; p2 = b;
    }
    else if (!*p1) break;
    p1++;
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrIStrW */
const wchar_t*  cb_DEFCALL  cb_StrIStrW (const wchar_t *a,const wchar_t *b)
{
  register const wchar_t *p1, *p2 = b;
  register cb_Integer i = cb_ToLowerW(*b);
  register const wchar_t *p3;
  for(p1=a;;) {
    if (cb_ToLowerW(*p1)==i) {
      if (i==0) return p1;
      p3 = p1;
      do {
        p2++; if (*p2==0) return p3; p1++;
      } while(cb_ToLowerW(*p1)==cb_ToLowerW(*p2));
      p1 = p3; p2 = b;
    }
    else if (!*p1) break;
    p1++;
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrStrRev */
const char*  cb_DEFCALL  cb_StrStrRev (const void *a,const char *b)
{
  register const char *p1, *p2;
  register cb_Integer i;
  register const char *p3;
  p2 = b; i = *p2;
  p1 = (const char*)a; p1 += cb_StrLen(p1); if (i==0) return p1;
  while(p1!=(const char*)a) {
    p1--;
    if (*p1==i) {
      p3 = p1;
      do { p2++; i = *p2; if (i==0) return p3; p1++; } while(*p1==i);
      p1 = p3; p2 = b; i = *p2;
    }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrStrRevW */
const wchar_t*  cb_DEFCALL  cb_StrStrRevW (const wchar_t *a,const wchar_t *b)
{
  register const wchar_t *p1, *p2;
  register cb_UInteger i;
  register const wchar_t *p3;
  p2 = b; i = *p2;
  p1 = a; p1 += cb_StrLenW(p1); if (i==0) return p1;
  while(p1!=a) {
    p1--;
    if (*p1==i) {
      p3 = p1;
      do { p2++; i = *p2; if (i==0) return p3; p1++; } while(*p1==i);
      p1 = p3; p2 = b; i = *p2;
    }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrIStrRev */
const char*  cb_DEFCALL  cb_StrIStrRev (const void *a,const char *b)
{
  register const char *p1, *p2 = b;
  register cb_Integer i = cb_ToLower(*b);
  register const char *p3;
  p1 = (const char*)a; p1 += cb_StrLen(p1); if (i==0) return p1;
  while(p1!=(const char*)a) {
    p1--;
    if (cb_ToLower(*p1)==i) {
      p3 = p1;
      do {
        p2++; if (*p2==0) return p3; p1++;
      } while(cb_ToLower(*p1)==cb_ToLower(*p2));
      p1 = p3; p2 = b;
    }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrIStrRevW */
const wchar_t*  cb_DEFCALL  cb_StrIStrRevW (const wchar_t *a,const wchar_t *b)
{
  register const wchar_t *p1, *p2 = b;
  register cb_Integer i = cb_ToLowerW(*b);
  register const wchar_t *p3;
  p1 = a; p1 += cb_StrLenW(p1); if (i==0) return p1;
  while(p1!=a) {
    p1--;
    if (cb_ToLowerW(*p1)==i) {
      p3 = p1;
      do {
        p2++; if (*p2==0) return p3; p1++;
      } while(cb_ToLowerW(*p1)==cb_ToLowerW(*p2));
      p1 = p3; p2 = b;
    }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrChars */
const char* cb_DEFCALL cb_StrChars (const void *A, const char *B)
{
  register const char *C;
  register const char *B1;
  for(C=(const char*)A;C[0]!=0;C++) {
    for(B1=B;B1[0]!=0;B1++) if (C[0]==B1[0]) return C;
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharsRev */
const char* cb_DEFCALL cb_StrCharsRev (const void *A, const char *B, cb_UInteger offset)
{
  register const char *C = (const char*)A;
  register const char *B1;
  register const char *A1 = C; B1 = (const char*)cb_StrLen(C);
  if (offset>0) if (offset!=(cb_UInteger)-1) { if ((cb_UInteger)B1<offset) return NULL; B1 = (const char*)offset; }
  C += (cb_Integer)B1;
  while (C!=A1) {
    C--;
    for(B1=B;B1[0]!=0;B1++) {
      if (C[0]==B1[0]) return C;
    }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrIChars */
const char* cb_DEFCALL cb_StrIChars (const void *A, const char *B)
{
  register const char *C;
  register const char *B1;
  for(C=(const char*)A;C[0]!=0;C++) {
    for(B1=B;B1[0]!=0;B1++) if (cb_ToLower(C[0])==cb_ToLower(B1[0])) return C;
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrICharsRev */
const char* cb_DEFCALL cb_StrICharsRev (const void *A, const char *B, cb_UInteger offset)
{
  register const char *C = (const char*)A;
  register const char *B1;
  register const char *A1 = C; B1 = (const char*)cb_StrLen(C);
  if (offset>0) if (offset!=(cb_UInteger)-1) { if ((cb_UInteger)B1<offset) return NULL; B1 = (const char*)offset; }
  C += (cb_Integer)B1;
  while (C!=A1) {
    C--;
    for(B1=B;B1[0]!=0;B1++) {
      if (cb_ToLower(C[0])==cb_ToLower(B1[0])) return C;
    }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharsW */
const wchar_t* cb_DEFCALL cb_StrCharsW (const wchar_t *A, const wchar_t *B)
{
  register const wchar_t *C;
  register const wchar_t *B1;
  for(C=A;C[0]!=0;C++) {
    for(B1=B;B1[0]!=0;B1++) if (C[0]==B1[0]) return C;
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharsRevW */
const wchar_t* cb_DEFCALL cb_StrCharsRevW (const wchar_t *A, const wchar_t *B, cb_UInteger offset)
{
  register const wchar_t *C = A;
  register const wchar_t *B1;
  register const wchar_t *A1 = C; B1 = (const wchar_t*)cb_StrLenW(C);
  if (offset>0) if (offset!=(cb_UInteger)-1) { if ((cb_UInteger)B1<offset) return NULL; B1 = (const wchar_t*)offset; }
  C += (cb_Integer)B1;
  while (C!=A1) {
    C--;
    for(B1=B;B1[0]!=0;B1++) {
      if (C[0]==B1[0]) return C;
    }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrICharsW */
const wchar_t* cb_DEFCALL cb_StrICharsW (const wchar_t *A, const wchar_t *B)
{
  register const wchar_t *C;
  register const wchar_t *B1;
  for(C=A;C[0]!=0;C++) {
    for(B1=B;B1[0]!=0;B1++) if (cb_ToLowerW(C[0])==cb_ToLowerW(B1[0])) return C;
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrICharsRevW */
const wchar_t* cb_DEFCALL cb_StrICharsRevW (const wchar_t *A, const wchar_t *B, cb_UInteger offset)
{
  register const wchar_t *C = A;
  register const wchar_t *B1;
  register const wchar_t *A1 = C; B1 = (const wchar_t*)cb_StrLenW(C);
  if (offset>0) if (offset!=(cb_UInteger)-1) { if ((cb_UInteger)B1<offset) return NULL; B1 = (const wchar_t*)offset; }
  C += (cb_Integer)B1;
  while (C!=A1) {
    C--;
    for(B1=B;B1[0]!=0;B1++) {
      if (cb_ToLowerW(C[0])==cb_ToLowerW(B1[0])) return C;
    }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_InChars */
cb_Integer cb_DEFCALL cb_InChars (const void *A, const char *B)
{
  register const char *C = cb_StrChars(A,B); if (!C) return -1;
  return ((cb_Integer)C-(cb_Integer)A);
}
/* END MODULE */


/* MODULE::cb_InCharsRev */
cb_Integer cb_DEFCALL cb_InCharsRev (const void *A, const char *B, cb_UInteger offset)
{
  register const char *C = cb_StrCharsRev(A,B,offset); if (!C) return -1;
  return ((cb_Integer)C-(cb_Integer)A);
}
/* END MODULE */


/* MODULE::cb_InCharsW */
cb_Integer cb_DEFCALL cb_InCharsW (const wchar_t *A, const wchar_t *B)
{
  register const wchar_t *C = cb_StrCharsW(A,B); if (!C) return -1;
  return ((cb_UInteger)C-(cb_UInteger)A)>>1;
}
/* END MODULE */


/* MODULE::cb_InCharsRevW */
cb_Integer cb_DEFCALL cb_InCharsRevW (const wchar_t *A, const wchar_t *B, cb_UInteger offset)
{
  register const wchar_t *C = cb_StrCharsRevW(A,B,offset); if (!C) return -1;
  return ((cb_UInteger)C-(cb_UInteger)A)>>1;
}
/* END MODULE */


/* MODULE::cb_StrCharEx */
// flag & 1 => case insensitive
// flag & 2 => don't search inside double quotes
// flag & 4 => don't search inside single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't search inside brackets
const char* cb_DEFCALL cb_StrCharEx (const void *A, cb_Integer B, cb_UInteger offset, cb_Integer flag, cb_UInteger sze)
{
  register const char *C = (const char*)A;
  register cb_Integer D;
  register cb_Integer E;
  if ((cb_UInteger)(sze-1)>=(cb_UInteger)-2) sze = cb_StrLen(C);
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (sze<=offset) return NULL; C += offset; sze -= offset; }
  D = 0; E = 0;
  if (!(flag & 1))
  for (;sze;C++,sze--) {
    if (D==0) {
      if (E) { if (E<0) goto Exit0000; }
      else if (C[0]==B) return C;
    }
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk0001; goto Chk0000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) continue;
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk0001;
Chk0000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk0001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) continue;
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E++;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E--;
    }
  }
  else {
  B = cb_ToLower(B);
  for (;sze;C++,sze--) {
    if (D==0) {
      if (E) { if (E<0) break; }
      else if (cb_ToLower(C[0])==B) return C;
    }
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk001; goto Chk000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) continue;
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk001;
Chk000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) continue;
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E++;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E--;
    }
  }
  }
Exit0000:
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharRevEx */
// flag & 1 => case insensitive
// flag & 2 => don't search inside double quotes
// flag & 4 => don't search inside single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't search inside brackets
const char* cb_DEFCALL cb_StrCharRevEx (const void *A, cb_Integer B, cb_UInteger offset, cb_Integer flag, cb_UInteger sze)
{
  register const char *C = (const char*)A;
  register cb_UInteger D = sze; if ((cb_UInteger)(D-1)>=(cb_UInteger)-2) D = cb_StrLen(C);
  register cb_Integer E;
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (D<offset) return NULL; D = offset; }
  C += D;
  D = 0; E = 0;
  if (!(flag & 1))
  while (C!=A) {
    C--;
    if ((D|E)==0) if (C[0]==B) return C;
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk0001; goto Chk0000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) continue;
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk0001;
Chk0000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk0001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) continue;
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E--;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E++;
    }
  }
  else {
  B = cb_ToLower(B);
  while (C!=A) {
    C--;
    if ((D|E)==0) if (cb_ToLower(C[0])==B) return C;
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk001; goto Chk000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) continue;
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk001;
Chk000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) continue;
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E--;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E++;
    }
  }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharExW */
// flag & 1 => case insensitive
// flag & 2 => don't search inside double quotes
// flag & 4 => don't search inside single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't search inside brackets
const wchar_t* cb_DEFCALL cb_StrCharExW (const wchar_t *A, cb_UInteger B, cb_UInteger offset, cb_Integer flag, cb_UInteger sze)
{
  register const wchar_t *C = A;
  register cb_Integer D;
  register cb_Integer E;
  if ((cb_UInteger)(sze-1)>=(cb_UInteger)-2) sze = cb_StrLenW(C);
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (sze<=offset) return NULL; C += offset; sze -= offset; }
  D = 0; E = 0;
  if (!(flag & 1))
  for (;sze;C++,sze--) {
    if (D==0) {
      if (E) { if (E<0) goto Exit0000; }
      else if (C[0]==B) return C;
    }
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk0001; goto Chk0000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) continue;
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk0001;
Chk0000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk0001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) continue;
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E++;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E--;
    }
  }
  else {
  B = cb_ToLowerW(B);
  for (;sze;C++,sze--) {
    if (D==0) {
      if (E) { if (E<0) break; }
      else if (cb_ToLowerW(C[0])==B) return C;
    }
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk001; goto Chk000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) continue;
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk001;
Chk000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) continue;
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E++;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E--;
    }
  }
  }
Exit0000:
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharRevExW */
// flag & 1 => case insensitive
// flag & 2 => don't search inside double quotes
// flag & 4 => don't search inside single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't search inside brackets
const wchar_t* cb_DEFCALL cb_StrCharRevExW (const wchar_t *A, cb_UInteger B, cb_UInteger offset, cb_Integer flag, cb_UInteger sze)
{
  register const wchar_t *C = A;
  register cb_UInteger D = sze; if ((cb_UInteger)(D-1)>=(cb_UInteger)-2) D = cb_StrLenW(C);
  register cb_Integer E;
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (D<offset) return NULL; D = offset; }
  C += D; D = 0; E = 0;
  if (!(flag & 1)) {
    while (C!=A) {
    C--;
    if ((D|E)==0) if (C[0]==B) return C;
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk0001; goto Chk0000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) continue;
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk0001;
Chk0000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk0001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) continue;
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E--;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E++;
    }
    }
  }
  else {
    B = cb_ToLowerW(B);
    while (C!=A) {
    C--;
    if ((D|E)==0) if (cb_ToLowerW(C[0])==B) return C;
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk001; goto Chk000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) continue;
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk001;
Chk000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) continue;
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E--;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E++;
    }
    }
  }
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharsEx */
// flag & 1 => case insensitive
// flag & 2 => don't look in double quotes
// flag & 4 => don't look in single quotes
// flag & 8 => don't look in linux quotes
// flag & 16 => don't look in brackets
const char* cb_DEFCALL cb_StrCharsEx (const void *A, const char *B, cb_UInteger offset, cb_Integer flag)
{
  register const char *C = (const char*)A;
  register cb_Integer D;
  register cb_Integer E;
  register const char *B1;
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (cb_StrLen(C)<=offset) return NULL; C += offset; }
  for (D=0,E=0;C[0];C++) {
    if (D==0) {
      if (!E) {
        B1 = B;
        do {
          if ((flag&1)!=0) { if (cb_ToLower(C[0])==cb_ToLower(B1[0])) return C; }
          else if (C[0]==B1[0]) return C;
          if (!B1[0]) break;
          B1++;
        } while(1);
      }
      else if (E<0) goto Exit0000;
    }
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk0001; goto Chk0000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) { continue; }
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk0001;
Chk0000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk0001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) { continue; }
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E++;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E--;
    }
  }
Exit0000:
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharsRevEx */
// flag & 1 => case insensitive
// flag & 2 => don't look in double quotes
// flag & 4 => don't look in single quotes
// flag & 8 => don't look in linux quotes
// flag & 16 => don't look in brackets
const char* cb_DEFCALL cb_StrCharsRevEx (const void *A, const char *B, cb_UInteger offset, cb_Integer flag)
{
  register const char *C = (const char*)A;
  register cb_UInteger D = cb_StrLen(C);
  register cb_Integer E;
  register const char *B1;
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (D<offset) return NULL; D = offset; }
  C += D; D = 0; E = 0;
  while(C!=A) {
    C--;
    if (D==0) {
      if (!E) {
        B1 = B;
        do {
          if ((flag&1)!=0) { if (cb_ToLower(C[0])==cb_ToLower(B1[0])) return C; }
          else if (C[0]==B1[0]) return C;
          if (!B1[0]) break;
          B1++;
        } while(1);
      }
      else if (E<0) goto Exit0000;
    }
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk0001; goto Chk0000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) { continue; }
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk0001;
Chk0000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk0001:
      if (C[0]=='`') { D ^= 4; continue; }
      if (D) { continue; }
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E--;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E++;
    }
  }
Exit0000:
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharsExW */
// flag & 1 => case insensitive
// flag & 2 => don't look in double quotes
// flag & 4 => don't look in single quotes
// flag & 8 => don't look in linux quotes
// flag & 16 => don't look in brackets
const wchar_t* cb_DEFCALL cb_StrCharsExW (const wchar_t *A, const wchar_t *B, cb_UInteger offset, cb_Integer flag)
{
  register const wchar_t *C = A;
  register cb_Integer D;
  register cb_Integer E;
  register const wchar_t *B1;
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (cb_StrLenW(C)<=offset) return NULL; C += offset; }
  for (D=0,E=0;C[0];C++) {
    if (D==0) {
      if (!E) {
        B1 = B;
        do {
          if ((flag&1)!=0) { if (cb_ToLowerW(C[0])==cb_ToLowerW(B1[0])) return C; }
          else if (C[0]==B1[0]) return C;
          if (!B1[0]) break;
          B1++;
        } while(1);
      }
      else if (E<0) goto Exit0000;
    }
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk0001; goto Chk0000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) { continue; }
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk0001;
Chk0000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk0001:
      if (C[0]=='`') { D ^= 2; continue; }
      if (D) { continue; }
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E++;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E--;
    }
  }
Exit0000:
  return NULL;
}
/* END MODULE */


/* MODULE::cb_StrCharsRevExW */
// flag & 1 => case insensitive
// flag & 2 => don't look in double quotes
// flag & 4 => don't look in single quotes
// flag & 8 => don't look in linux quotes
// flag & 16 => don't look in brackets
const wchar_t* cb_DEFCALL cb_StrCharsRevExW (const wchar_t *A, const wchar_t *B, cb_UInteger offset, cb_Integer flag)
{
  register const wchar_t *C = A;
  register cb_UInteger D = cb_StrLenW(C);
  register cb_Integer E;
  register const wchar_t *B1;
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (D<offset) return NULL; D = offset; }
  C += D; D = 0; E = 0;
  while(C!=A) {
    C--;
    if (D==0) {
      if (!E) {
        B1 = B;
        do {
          if ((flag&1)!=0) { if (cb_ToLowerW(C[0])==cb_ToLowerW(B1[0])) return C; }
          else if (C[0]==B1[0]) return C;
          if (!B1[0]) break;
          B1++;
        } while(1);
      }
      else if (E<0) goto Exit0000;
    }
    if ((flag&2)!=0) {
      if ((D&(2|4))!=0) { if ((D&4)!=0) goto Chk0001; goto Chk0000; }
      if (C[0]=='"') { D ^= 1; continue; }
      if (D) { continue; }
    }
    if ((flag&4)!=0) {
      if ((D&4)!=0) goto Chk0001;
Chk0000:
      if (C[0]=='\'') { D ^= 2; continue; }
      if (D) continue;
    }
    if ((flag&8)!=0) {
Chk0001:
      if (C[0]=='`') { D ^= 2; continue; }
      if (D) { continue; }
    }
    if ((flag&16)!=0) {
      if (C[0] == '(' || C[0] == '[' || C[0] == '{') E--;
      else if (C[0] == ')' || C[0] == ']' || C[0] == '}') E++;
    }
  }
Exit0000:
  return NULL;
}
/* END MODULE */


/* MODULE::cb_InChar */
cb_Integer cb_DEFCALL cb_InChar (const void *A, cb_Integer B)
{
  register const char *C;
  register cb_Integer D = B;
  for (C=(const char*)A;C[0]!=0;C++) if (C[0]==D) return ((cb_Integer)C-(cb_Integer)A);
  return -1;
}
/* END MODULE */


/* MODULE::cb_InCharRev */
cb_Integer cb_DEFCALL cb_InCharRev (const void *A, cb_Integer B, cb_UInteger offset)
{
  register const char *C = (const char*)A;
  register cb_UInteger D = cb_StrLen(C);
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (D<offset) return -1; D=offset; }
  for (C+=D;C!=A;) { C--; if (C[0]==B) return ((cb_Integer)C-(cb_Integer)A); }
  return -1;
}
/* END MODULE */


/* MODULE::cb_InCharW */
cb_Integer cb_DEFCALL cb_InCharW (const wchar_t *A, wchar_t B)
{
  register const wchar_t *C;
  register cb_Integer D = B;
  for (C=A;C[0]!=0;C++) if (C[0]==D) return (((cb_UInteger)((cb_Integer)C-(cb_Integer)A))>>1);
  return -1;
}
/* END MODULE */


/* MODULE::cb_InCharRevW */
cb_Integer cb_DEFCALL cb_InCharRevW (const wchar_t *A, wchar_t B, cb_UInteger offset)
{
  register const wchar_t *C = A;
  register cb_UInteger D = cb_StrLenW(C);
  if (offset>0) if (offset!=(cb_UInteger)-1) { if (D<offset) return -1; D=offset; }
  for (C+=D;C!=A;) { C--; if (C[0]==B) return (((cb_UInteger)((cb_Integer)C-(cb_Integer)A))>>1); }
  return -1;
}
/* END MODULE */


/* MODULE::cb_InCharEx */
// flag & 1 => case insensitive
// flag & 2 => don't search inside double quotes
// flag & 4 => don't search inside single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't search inside brackets
cb_Integer cb_DEFCALL cb_InCharEx (const void *A, cb_Integer B, cb_UInteger offset, cb_Integer flag, cb_UInteger sze)
{
  register const char *C = cb_StrCharEx(A,B,offset,flag,sze); if (!C) return -1;
  return ((cb_Integer)C-(cb_Integer)A);
}
/* END MODULE */


/* MODULE::cb_InCharRevEx */
// flag & 1 => case insensitive
// flag & 2 => don't search inside double quotes
// flag & 4 => don't search inside single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't search inside brackets
cb_Integer cb_DEFCALL cb_InCharRevEx (const void *A, cb_Integer B, cb_UInteger offset, cb_Integer flag, cb_UInteger sze)
{
  register const char *C = cb_StrCharRevEx(A,B,offset,flag,sze); if (!C) return -1;
  return ((cb_Integer)C-(cb_Integer)A);
}
/* END MODULE */


/* MODULE::cb_InCharExW */
// flag & 1 => case insensitive
// flag & 2 => don't search inside double quotes
// flag & 4 => don't search inside single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't search inside brackets
cb_Integer cb_DEFCALL cb_InCharExW (const wchar_t *A, cb_UInteger B, cb_UInteger offset, cb_Integer flag, cb_UInteger sze)
{
  register const wchar_t *C = cb_StrCharExW(A,B,offset,flag,sze); if (!C) return -1;
  return ((cb_UInteger)((cb_Integer)C-(cb_Integer)A)) >> 1;
}
/* END MODULE */


/* MODULE::cb_InCharRevExW */
// flag & 1 => case insensitive
// flag & 2 => don't search inside double quotes
// flag & 4 => don't search inside single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't search inside brackets
cb_Integer cb_DEFCALL cb_InCharRevExW (const wchar_t *A, cb_UInteger B, cb_UInteger offset, cb_Integer flag, cb_UInteger sze)
{
  register const wchar_t *C = cb_StrCharRevExW(A,B,offset,flag,sze); if (!C) return -1;
  return ((cb_UInteger)((cb_Integer)C-(cb_Integer)A)) >> 1;
}
/* END MODULE */


/* MODULE::cb_InCharsEx */
// flag & 1 => case insensitive
// flag & 2 => don't look in double quotes
// flag & 4 => don't look in single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't look in brackets
cb_Integer cb_DEFCALL cb_InCharsEx (const void *A, const char *B, cb_UInteger offset, cb_Integer flag)
{
  register const char *C = cb_StrCharsEx(A,B,offset,flag); if (!C) return -1;
  return (cb_Integer)C-(cb_Integer)A;
}
/* END MODULE */


/* MODULE::cb_InCharsRevEx */
// flag & 1 => case insensitive
// flag & 2 => don't look in double quotes
// flag & 4 => don't look in single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't look in brackets
cb_Integer cb_DEFCALL cb_InCharsRevEx (const void *A, const char *B, cb_UInteger offset, cb_Integer flag)
{
  register const char *C = cb_StrCharsRevEx(A,B,offset,flag); if (!C) return -1;
  return (cb_Integer)C-(cb_Integer)A;
}
/* END MODULE */


/* MODULE::cb_InCharsExW */
// flag & 1 => case insensitive
// flag & 2 => don't look in double quotes
// flag & 4 => don't look in single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't look in brackets
cb_Integer cb_DEFCALL cb_InCharsExW (const wchar_t *A, const wchar_t *B, cb_UInteger offset, cb_Integer flag)
{
  register const wchar_t *C = cb_StrCharsExW(A,B,offset,flag); if (!C) return -1;
  return ((cb_UInteger)((cb_Integer)C-(cb_Integer)A)) >> 1;
}
/* END MODULE */


/* MODULE::cb_InCharsRevExW */
// flag & 1 => case insensitive
// flag & 2 => don't look in double quotes
// flag & 4 => don't look in single quotes
// flag & 8 => don't search inside linux quotes
// flag & 16 => don't look in brackets
cb_Integer cb_DEFCALL cb_InCharsRevExW (const wchar_t *A, const wchar_t *B, cb_UInteger offset, cb_Integer flag)
{
  register const wchar_t *C = cb_StrCharsRevExW(A,B,offset,flag); if (!C) return -1;
  return ((cb_UInteger)((cb_Integer)C-(cb_Integer)A)) >> 1;
}
/* END MODULE */


/* MODULE::cb_InStr */
cb_Integer cb_DEFCALL cb_InStr (const void *Str1, const char *sMatch, cb_Integer offset, cb_Integer nosens)
{
  register const char *MyPtr1 = (const char*)Str1, *MyPtr2, *MyPtr3;
  cb_Integer j;

  if (offset>0) MyPtr1+=offset;
  if (sMatch[0]==0) { if (MyPtr1[0]) return -1; return 0; }
  j = 0;

Loop0000:
  if ((nosens&1)==0) {
Start0000:
    for(MyPtr2=sMatch;MyPtr1[0];MyPtr1++)
    {
      if (MyPtr1[0]==MyPtr2[0]) {
        MyPtr3 = MyPtr1;
        do {
          MyPtr2++;
          if (MyPtr2[0]==0) break;
          MyPtr3++;
          if (MyPtr2[0]!=MyPtr3[0]) { MyPtr1++; goto Start0000; }
        } while(1);
        goto Exit0000;
      }
    }
  }
  else {
Start0001:
    for(MyPtr2=sMatch;MyPtr1[0];MyPtr1++)
    {
      if (cb_ToLower(MyPtr1[0])==cb_ToLower(MyPtr2[0])) {
        MyPtr3 = MyPtr1;
        do {
          MyPtr2++;
          if (MyPtr2[0]==0) break;
          MyPtr3++;
          if (cb_ToLower(MyPtr2[0])!=cb_ToLower(MyPtr3[0])) { MyPtr1++; goto Start0001; }
        } while(1);
Exit0000:
  if ((nosens&2)!=0) {
    if ((cb_UInteger)MyPtr1>(cb_UInteger)Str1) {
      if (cb_IsAlphaDigit(MyPtr1[0]) || MyPtr1[0]=='_') {
        MyPtr1--;
        if (cb_IsAlphaDigit(MyPtr1[0]) || MyPtr1[0]=='_') {
          MyPtr1++;
Loop00:
          MyPtr1++;
          goto Loop0000;
        }
        MyPtr1++;
      }
    }
    if (j==0) j = cb_StrLen(sMatch);
    if (cb_IsAlphaDigit(MyPtr1[j]) || MyPtr1[j]=='_') { j--; if (cb_IsAlphaDigit(MyPtr1[j]) || MyPtr1[j]=='_') { j++; goto Loop00; } }
  }

        return (cb_Integer)MyPtr1-(cb_Integer)Str1;
      }
    }
  }
  return -1;
}
/* END MODULE */


/* MODULE::cb_InStrW */
cb_Integer cb_DEFCALL cb_InStrW (const wchar_t *Str1, const wchar_t *sMatch, cb_Integer offset, cb_Integer nosens)
{
  register const wchar_t *MyPtr1 = Str1, *MyPtr2, *MyPtr3;
  cb_Integer j;

  if (offset>0) MyPtr1+=offset;
  if (sMatch[0]==0) { if (MyPtr1[0]) return -1; return 0; }
  j = 0;

Loop0000:
  if ((nosens&1)==0) {
Start0000:
    for(MyPtr2=sMatch;MyPtr1[0];MyPtr1++)
    {
      if (MyPtr1[0]==MyPtr2[0]) {
        MyPtr3 = MyPtr1;
        do {
          MyPtr2++;
          if (MyPtr2[0]==0) break;
          MyPtr3++;
          if (MyPtr2[0]!=MyPtr3[0]) { MyPtr1++; goto Start0000; }
        } while(1);
        goto Exit0000;
      }
    }
  }
  else {
Start0001:
    for(MyPtr2=sMatch;MyPtr1[0];MyPtr1++)
    {
      if (cb_ToLowerW(MyPtr1[0])==cb_ToLowerW(MyPtr2[0])) {
        MyPtr3 = MyPtr1;
        do {
          MyPtr2++;
          if (MyPtr2[0]==0) break;
          MyPtr3++;
          if (cb_ToLowerW(MyPtr2[0])!=cb_ToLowerW(MyPtr3[0])) { MyPtr1++; goto Start0001; }
        } while(1);
Exit0000:
  if ((nosens&2)!=0) {
    if ((cb_UInteger)MyPtr1>(cb_UInteger)Str1) {
      if (cb_IsAlphaDigitW(MyPtr1[0]) || MyPtr1[0]=='_') {
        MyPtr1--;
        if (cb_IsAlphaDigitW(MyPtr1[0]) || MyPtr1[0]=='_') {
          MyPtr1++;
Loop00:
          MyPtr1++;
          goto Loop0000;
        }
        MyPtr1++;
      }
    }
    if (j==0) j = cb_StrLenW(sMatch);
    if (cb_IsAlphaDigitW(MyPtr1[j]) || MyPtr1[j]=='_') { j--; if (cb_IsAlphaDigitW(MyPtr1[j]) || MyPtr1[j]=='_') { j++; goto Loop00; } }
  }

        return ((cb_UInteger)((cb_Integer)MyPtr1-(cb_Integer)Str1))>>1;
      }
    }
  }
  return -1;
}
/* END MODULE */


/* MODULE::cb_StrStrEx */
cb_Integer cb_DEFCALL cb_StrStrEx (const void *Str1, const char *sMatch, cb_Integer nosens, cb_UInteger sze)
{
  register const char *p1 = (const char*)Str1, *p2; if (sMatch[0]==0) { if (p1[0]) return -1; return 0; }
  register cb_UInteger i = sze, sze1, j = 0;
  cb_Integer D = 0;
  const char *s;

  if ((cb_UInteger)(i-1)>=(cb_UInteger)-2) {
    i = cb_StrLen(p1); sze = i;
  }

Loop0000:
  s = p1;
  sze1 = i;
  if ((nosens&1)==0) {
Start0000:
    p2=sMatch;
    do {
      if (i<=0) return -1;
      if (nosens&2) { if (p1[0]=='"') { D ^= 1; goto Cont0000; } if (D) goto Cont0000; }
      if (p1[0]!=p2[0]) {
        s++; p1=s; sze1--; i=sze1; goto Start0000;
      }
Cont0000:
      p1++;
      p2++;
      i--;
    } while(p2[0]);
  }
  else {
Start0001:
    p2=sMatch;
    do {
      if (i<=0) return -1;
      if (nosens&2) { if (p1[0]=='"') { D ^= 1; goto Cont000; } if (D) goto Cont000; }
      if (cb_ToLower(p1[0])!=cb_ToLower(p2[0])) {
        s++; p1=s; sze1--; i=sze1; goto Start0001;
      }
Cont000:
      p1++;
      p2++;
      i--;
    } while(p2[0]);
  }

  p1 = s;

  if ((nosens&2)!=0) {
    if ((cb_UInteger)p1>(cb_UInteger)Str1) {
      if (cb_IsAlphaDigit(p1[0]) || p1[0]=='_') {
        p1--;
        if (cb_IsAlphaDigit(p1[0]) || p1[0]=='_') {
          p1++;
Loop00:
          p1++;
          i = sze; i -= (cb_UInteger)p1-(cb_UInteger)Str1;
          goto Loop0000;
        }
        p1++;
      }
    }
    if (j==0) j = cb_StrLen(sMatch);
    if (cb_IsAlphaDigit(p1[j]) || p1[j]=='_') { j--; if (cb_IsAlphaDigit(p1[j]) || p1[j]=='_') { j++; goto Loop00; } }
  }

  return (cb_Integer)p1-(cb_Integer)Str1;
}
/* END MODULE */


/* MODULE::cb_StrStrRevEx */
cb_Integer cb_DEFCALL cb_StrStrRevEx (const void *Str1, const char *sMatch, cb_UInteger offset, cb_Integer nosens, cb_UInteger sze)
{
  const char *p1 = (const char*)Str1, *p2;
  register cb_UInteger i = sze, h = cb_StrLen(sMatch);
  cb_Integer D = 0;

  if ((cb_UInteger)(i-1)>=(cb_UInteger)-2) i = cb_StrLen(p1);
  if (i<h) return -1;
  if ((cb_UInteger)(offset-1)>=(cb_UInteger)-2) offset = i;
  else { if (i<offset) return -1; i=offset; }
  if (h==0) return i;
  if ((nosens&1)==0) {
Start0000:
    p1 = (const char*)Str1; p1 += i;
    p2 = sMatch; p2 += h;
    do {
again0000:
      if (i==0) return -1;
      i--; p1--; p2--;
      if (nosens&2) { if (p1[0]=='"') { D ^= 1; goto again0000; } if (D) goto again0000; }
      if (p1[0] != p2[0]) {
Start0001:
        offset--; i=offset; goto Start0000;
      }
    } while (p2!=sMatch);
  }
  else {
Start000:
    p1 = (const char*)Str1; p1 += i;
    p2 = sMatch; p2 += h;
    do {
again000:
      if (i==0) return -1;
      i--; p1--; p2--;
      if (nosens&2) { if (p1[0]=='"') { D ^= 1; goto again000; } if (D) goto again000; }
      if (cb_ToLower(p1[0]) != cb_ToLower(p2[0])) {
Start001:
        offset--; i=offset; goto Start000;
      }
    } while (p2!=sMatch);
  }

  if ((nosens&2)!=0) {
    if (i) {
      if (cb_IsAlphaDigit(p1[0]) || p1[0]=='_') {
        p1--;
        if (cb_IsAlphaDigit(p1[0]) || p1[0]=='_') {
Loop00:
          if ((nosens&1)==0) goto Start0001;
          goto Start001;
        }
        p1++;
      }
    }
    p1 += h;
    if (cb_IsAlphaDigit(p1[0]) || p1[0]=='_') { p1--; if (cb_IsAlphaDigit(p1[0]) || p1[0]=='_') goto Loop00; }
  }

  return i;
}
/* END MODULE */


/* MODULE::cb_StrStrExW */
cb_Integer cb_DEFCALL cb_StrStrExW (const wchar_t *Str1, const wchar_t *sMatch, cb_Integer nosens, cb_UInteger sze)
{
  register const wchar_t *p1 = Str1, *p2; if (sMatch[0]==0) { if (p1[0]) return -1; return 0; }
  register cb_UInteger i = sze, sze1, j = 0;
  const wchar_t *s;

  if ((cb_UInteger)(i-1)>=(cb_UInteger)-2) {
    i = cb_StrLenW(p1); sze = i;
  }

Loop0000:
  s = p1;
  sze1 = i;
  if ((nosens&1)==0) {
Start0000:
    p2=sMatch;
    do {
      if (i<=0) return -1;
      if (p1[0]!=p2[0]) {
        s++; p1=s; sze1--; i=sze1; goto Start0000;
      }
      p1++;
      p2++;
      i--;
    } while(p2[0]);
  }
  else {
Start0001:
    p2=sMatch;
    do {
      if (i<=0) return -1;
      if (cb_ToLowerW(p1[0])!=cb_ToLowerW(p2[0])) {
        s++; p1=s; sze1--; i=sze1; goto Start0001;
      }
      p1++;
      p2++;
      i--;
    } while(p2[0]);
  }

  p1 = s;

  if ((nosens&2)!=0) {
    if (p1>Str1) {
      if (cb_IsAlphaDigitW(p1[0]) || p1[0]=='_') {
        p1--;
        if (cb_IsAlphaDigitW(p1[0]) || p1[0]=='_') {
          p1++;
Loop00:
          p1++;
          i = sze; i -= (cb_UInteger)(p1-Str1);
          goto Loop0000;
        }
        p1++;
      }
    }
    if (j==0) j = cb_StrLenW(sMatch);
    if (cb_IsAlphaDigitW(p1[j]) || p1[j]=='_') { j--; if (cb_IsAlphaDigitW(p1[j]) || p1[j]=='_') { j++; goto Loop00; } }
  }

  return (cb_UInteger)(p1-Str1) >> 1;
}
/* END MODULE */


/* MODULE::cb_StrStrRevExW */
cb_Integer cb_DEFCALL cb_StrStrRevExW (const wchar_t *Str1, const wchar_t *sMatch, cb_UInteger offset, cb_Integer nosens, cb_UInteger sze)
{
  const wchar_t *p1 = Str1, *p2;
  register cb_UInteger i = sze, h = cb_StrLenW(sMatch);

  if ((cb_UInteger)(i-1)>=(cb_UInteger)-2) i = cb_StrLenW(p1);
  if (i<h) return -1;
  if ((cb_UInteger)(offset-1)>=(cb_UInteger)-2) offset = i;
  else { if (i<offset) return -1; i=offset; }
  if (h==0) return i;
  if ((nosens&1)==0) {
Start0000:
    p1 = Str1; p1 += i;
    p2 = sMatch; p2 += h;
    do {
      if (i==0) return -1;
      i--; p1--; p2--;
      if (p1[0] != p2[0]) {
Start0001:
        offset--; i=offset; goto Start0000;
      }
    } while (p2!=sMatch);
  }
  else {
Start000:
    p1 = Str1; p1 += i;
    p2 = sMatch; p2 += h;
    do {
      if (i==0) return -1;
      i--; p1--; p2--;
      if (cb_ToLowerW(p1[0]) != cb_ToLowerW(p2[0])) {
Start001:
        offset--; i=offset; goto Start000;
      }
    } while (p2!=sMatch);
  }

  if ((nosens&2)!=0) {
    if (i) {
      if (cb_IsAlphaDigitW(p1[0]) || p1[0]=='_') {
        p1--;
        if (cb_IsAlphaDigitW(p1[0]) || p1[0]=='_') {
Loop00:
          if ((nosens&1)==0) goto Start0001;
          goto Start001;
        }
        p1++;
      }
    }
    p1 += h;
    if (cb_IsAlphaDigitW(p1[0]) || p1[0]=='_') { p1--; if (cb_IsAlphaDigitW(p1[0]) || p1[0]=='_') goto Loop00; }
  }

  return i;
}
/* END MODULE */


/* MODULE::cb_InStrEx */
cb_Integer cb_DEFCALL cb_InStrEx (const void *src,const char *sMatch,cb_UInteger offset,cb_Integer nosens, cb_UInteger sze)
{
  register cb_UInteger i, sze1;
  register cb_Integer iRet;

  if (!*(const char*)src || !sMatch) return 0;
  i = offset; if (i==(cb_UInteger)-1) i++;
  sze1 = sze;
  if ((cb_UInteger)(sze1-1)>=(cb_UInteger)-2) sze1=cb_StrLen((const char*)src);
  if (sMatch[0]==0 || i>=sze1) return -1;
  sze1-=i;
  iRet = cb_StrStrEx(((const char*)src)+i,sMatch,nosens,sze1);
  if (iRet!=-1) iRet += i;
  return iRet;
}
/* END MODULE */


/* MODULE::cb_InStrRevEx */
cb_Integer cb_DEFCALL cb_InStrRevEx (const void *src, const char *sMatch, cb_UInteger offset, cb_Integer nosens, cb_UInteger sze)
{
  if (!*(const char*)src || !sMatch || sMatch[0]==0) return -1;
  return cb_StrStrRevEx(src,sMatch,offset,nosens,sze);
}
/* END MODULE */


/* MODULE::cb_InStrExW */
cb_Integer cb_DEFCALL cb_InStrExW (const wchar_t *src,const wchar_t *sMatch,cb_UInteger offset,cb_Integer nosens, cb_UInteger sze)
{
  register cb_UInteger i, iRet, sze1;
  if (!src || !sMatch) return 0;
  i = offset; if (i==(cb_UInteger)-1) i++;
  sze1 = sze;
  if ((cb_UInteger)(sze1-1)>=(cb_UInteger)-2) sze1=cb_StrLenW(src);
  if (sMatch[0]==0 || i>=sze1) return -1;
  sze1-=i;
  iRet = cb_StrStrExW(src+i,sMatch,nosens,sze1);
  if (iRet) iRet += i;
  return iRet;
}
/* END MODULE */


/* MODULE::cb_InStrRevExW */
cb_Integer cb_DEFCALL cb_InStrRevExW (const wchar_t *src, const wchar_t *sMatch, cb_UInteger offset, cb_Integer nosens, cb_UInteger sze)
{
  if (!src || !sMatch || sMatch[0]==0) return -1;
  return cb_StrStrRevExW(src,sMatch,offset,nosens,sze);
}
/* END MODULE */


/* MODULE::cb_InWord */
cb_Integer cb_DEFCALL cb_InWord (const char *Str1,const char *Str2,cb_Integer iLen,cb_Integer ch)
{
  register const char *s; s = Str1;
  register cb_Integer c; c = ch;
  register cb_Integer i; i = iLen; if (i<=0) i = cb_StrLen(Str2);
  while (s[0]==c) { again0000:; s++; }
  if (cb_MemComp(s,Str2,i)==0) {
    s += i;
    if (s[0]==c || s[0]==0) {
      return (cb_Integer)s - i - (cb_Integer)Str1;
    }
  }
  for (;s[0]!=0;s++) {
    if (s[0]==c) goto again0000;
  }
  return -1;
}
/* END MODULE */


/* MODULE::cb_CountChar */
cb_Integer cb_DEFCALL cb_CountChar (const void *szLine, cb_Integer iChar)
{
  register cb_Integer iCount = 0;
  register const char *szLne = (const char*)szLine;
  do {
    szLne = cb_StrChar(szLne, iChar);
    if (szLne==NULL) break;
    iCount++;
    szLne++;
  }while(1);
  return iCount;
}
/* END MODULE */


/* MODULE::cb_CountCharEx */
cb_Integer cb_DEFCALL cb_CountCharEx (const void *szLine, cb_Integer iChar, cb_Integer flag)
{
  register cb_Integer iCount = 0;
  register cb_UInteger p;
  register const char *szLne = (const char*)szLine;
  do {
    p = cb_InCharEx(szLne, iChar, 0, flag);
    if (p==(cb_UInteger)-1) break;
    iCount++;
    p++;
    szLne+=p;
  }while(1);
  return iCount;
}
/* END MODULE */


/* MODULE::cb_CountStr */
cb_Integer cb_DEFCALL cb_CountStr (const void *szLine, const char *szChar, cb_Integer nosens)
{
  if (!*szChar) return 0;
  register cb_Integer iCount = 0;
  register cb_UInteger p;
  register const char *szLne = (const char*)szLine;
  cb_UInteger mlen = cb_StrLen(szChar);
  do {
    p = cb_InStr(szLne, szChar, 0, nosens);
    if (p==(cb_UInteger)-1) break;
    iCount++;
    p+=mlen;
    szLne+=p;
  }while(1);
  return iCount;
}
/* END MODULE */


/* MODULE::cb_Like */
cb_Integer cb_DEFCALL cb_Like (const void *a,const void *b,cb_Integer nosens)
{  register char *x;
  register char *y;
  register cb_Integer iMatch1;
  char PrevChar;
  char NextChar;

  x=(char*)a;
  y=(char*)b;
  if (nosens) {
    x = cb_NewStr(x, (void*)-1); if (!x) { iMatch1 = -1; goto Exit0002; }
    y = cb_NewStr(y, (void*)-1); if (!y) { iMatch1 = -1; goto Exit0001; }
    cb_StrLower(x);
    cb_StrLower(y);
  }

  do {
    if (x[0]==0) {
      if (y[0]==0) {
        goto Found0000;
      }
      goto NotFound0000;
    }
    /* Select Case  */
    if (y[0]==0) {
      goto NotFound0000;
    }
    if (y[0]=='#') {
      if ((x[0]<'0') || (x[0]>'9')) {
        goto NotFound0000;
      }
      goto EndSelect_1;
    }
    if (y[0]=='*') {
      ++y;
      do {
        if (x[0]==y[0]) {
          break;
        }
        if (x[0]==0) {
          break;
        }
        ++x;
      }while(1);
      if (x[0]==0) {
        if (y[0]!=0) goto NotFound0000;
Found0000:
        iMatch1 = TRUE;
        goto Exit0000;
      }
      goto EndSelect_1;
    }
    if (y[0]=='\?') {
      goto EndSelect_1;
    }
    if (y[0]=='[') {
      iMatch1 = TRUE;
      ++y;
      if (y[0]=='!') {
        iMatch1 = FALSE;
        ++y;
      }
      do {
        if (y[0]==']') {
          goto NotFound0000;
        }
        if (y[0]==0) {
          goto NotFound0000;
        }
        if (y[0]=='-') {
          --y;
          PrevChar=y[0];
          y+=2;
          NextChar=y[0];
          --y;
          if ((PrevChar=='[') || (PrevChar=='!') || (NextChar==']')) {
            if (y[0]==x[0]) {
              if (iMatch1==FALSE) {
                goto NotFound0000;
              }
              break;
            }
          }
          else {
            if ((x[0]>=PrevChar) && (x[0]<=NextChar)) {
              if (iMatch1==FALSE) {
                goto NotFound0000;
              }
              break;
            }
            else {
              ++y;
            }
          }
        }
        else if (y[0]==x[0]) {
          if (iMatch1==FALSE) {
            goto NotFound0000;
          }
          break;
        }
        ++y;
      }while(1);
      do {
        if (y[0]==']') {
          break;
        }
        if (y[0]==0) {
          goto NotFound0000;
        }
        ++y;
      }while(1);
    }
    else if (x[0]!=y[0]) {
NotFound0000:
      iMatch1 = FALSE;
      goto Exit0000;
    }
    EndSelect_1:;  /* y[0] */
    ++x;
    ++y;
  }while(1);

Exit0000:;
  if (nosens) {
    cb_MemFreeM(y);
Exit0001:;
    cb_MemFreeM(x);
  }
Exit0002:;
  return iMatch1;
}
/* END MODULE */


/* MODULE::cb_StrVerify */
cb_Integer cb_DEFCALL cb_StrVerify (const void *src, const char *sMatch, cb_Integer nosens)
{
  register const char *s = (const char*)src;

  if ((nosens & 1)==0) {
  for (; s[0]; s++)
    if ((nosens & 2)==0) { if (!cb_StrChar(sMatch,s[0])) goto Exit0000; }
    else if (cb_StrChar(sMatch,s[0])) goto Exit0000;
  }
  else {
  for (; s[0]; s++)
    if ((nosens & 2)==0) { if (cb_InCharEx(sMatch,s[0],0,1)<0) goto Exit0000; }
    else if (cb_InCharEx(sMatch,s[0],0,1)>=0) { Exit0000:; return ((cb_Integer)s-(cb_Integer)src); }
  }
  return 0;
}
/* END MODULE */


/* MODULE::cb_CmpByte */
cb_Integer cb_CDECL cb_CmpByte (const void *UserData, const void *a, const void *b)
{
  register cb_UInteger x = (cb_UInteger)*((BYTE*)a);
  x -= (cb_UInteger)*((BYTE*)b);
  return (cb_Integer)x;
}
/* END MODULE */


/* MODULE::cb_CmpByteB */
cb_Integer cb_CDECL cb_CmpByteB (const void *UserData, const void *a, const void *b)
{
  register cb_UInteger x = (cb_UInteger)*((BYTE*)b);
  x -= (cb_UInteger)*((BYTE*)a);
  return (cb_Integer)x;
}
/* END MODULE */


/* MODULE::cb_CmpWord */
cb_Integer cb_CDECL cb_CmpWord (const void *UserData, const void *a, const void *b)
{
  register cb_UInteger x = *((WORD*)a);
  x -= *((WORD*)b);
  return (cb_Integer)x;
}
/* END MODULE */


/* MODULE::cb_CmpWordB */
cb_Integer cb_CDECL cb_CmpWordB (const void *UserData, const void *a, const void *b)
{
  register cb_UInteger x = *((WORD*)b);
  x -= *((WORD*)a);
  return (cb_Integer)x;
}
/* END MODULE */


/* MODULE::cb_CmpInt */
cb_Integer cb_CDECL cb_CmpInt (const void *UserData, const void *a, const void *b)
{
  register cb_Integer x = *((cb_Integer*)a);
  x -= *((cb_Integer*)b);
  return x;
}
/* END MODULE */


/* MODULE::cb_CmpIntB */
cb_Integer cb_CDECL cb_CmpIntB (const void *UserData, const void *a, const void *b)
{
  register cb_Integer x = *((cb_Integer*)b);
  x -= *((cb_Integer*)a);
  return x;
}
/* END MODULE */


/* MODULE::cb_CmpLLong */
cb_Integer cb_CDECL cb_CmpLLong (const void *UserData, const void *a, const void *b)
{
  register long long x = *((long long*)a);
  register long long y = *((long long*)b);
  if (x>y) return 1;
  if (x<y) return -1;
  return 0;
}
/* END MODULE */


/* MODULE::cb_CmpLLongB */
cb_Integer cb_CDECL cb_CmpLLongB (const void *UserData, const void *a, const void *b)
{
  return cb_CmpLLong(UserData,b,a);
}
/* END MODULE */


/* MODULE::cb_CmpULLong */
cb_Integer cb_CDECL cb_CmpULLong (const void *UserData, const void *a, const void *b)
{
  register unsigned long long x = *((unsigned long long*)a);
  register unsigned long long y = *((unsigned long long*)b);
  if (x>y) return 1;
  if (x<y) return -1;
  return 0;
}
/* END MODULE */


/* MODULE::cb_CmpULLongB */
cb_Integer cb_CDECL cb_CmpULLongB (const void *UserData, const void *a, const void *b)
{
  return cb_CmpULLong(UserData,b,a);
}
/* END MODULE */


/* MODULE::cb_CmpSng */
cb_Integer cb_CDECL cb_CmpSng (const void *UserData, const void *a, const void *b)
{
  register float x = *((float*)a);
  register float y = *((float*)b);
  if (x>y) return 1;
  if (x<y) return -1;
  return 0;
}
/* END MODULE */


/* MODULE::cb_CmpSngB */
cb_Integer cb_CDECL cb_CmpSngB (const void *UserData, const void *a, const void *b)
{
  return cb_CmpSng(UserData,b,a);
}
/* END MODULE */


/* MODULE::cb_CmpDbl */
cb_Integer cb_CDECL cb_CmpDbl (const void *UserData, const void *a, const void *b)
{
  register double x = *((double*)a);
  register double y = *((double*)b);
  if (x>y) return 1;
  if (x<y) return -1;
  return 0;
}
/* END MODULE */


/* MODULE::cb_CmpDblB */
cb_Integer cb_CDECL cb_CmpDblB (const void *UserData, const void *a, const void *b)
{
  return cb_CmpDbl(UserData,b,a);
}
/* END MODULE */


/* MODULE::cb_CmpLDbl */
cb_Integer cb_CDECL cb_CmpLDbl (const void *UserData, const void *a, const void *b)
{
  register long double x = *((long double*)a);
  register long double y = *((long double*)b);
  if (x>y) return 1;
  if (x<y) return -1;
  return 0;
}
/* END MODULE */


/* MODULE::cb_CmpLDblB */
cb_Integer cb_CDECL cb_CmpLDblB (const void *UserData, const void *a, const void *b)
{
  return cb_CmpLDbl(UserData,b,a);
}
/* END MODULE */


/* MODULE::cb_CmpStr */
cb_Integer cb_CDECL cb_CmpStr (const void *UserData, const void *a, const void *b)
{
  return cb_StrComp(a,b);
}
/* END MODULE */


/* MODULE::cb_CmpStrB */
cb_Integer cb_CDECL cb_CmpStrB (const void *UserData, const void *a, const void *b)
{
  return cb_StrComp(b,a);
}
/* END MODULE */


/* MODULE::cb_CmpStrW */
cb_Integer cb_CDECL cb_CmpStrW (const void *UserData, const void *a, const void *b)
{
  return cb_StrCompW((const wchar_t*)a,(const wchar_t*)b);
}
/* END MODULE */


/* MODULE::cb_CmpStrBW */
cb_Integer cb_CDECL cb_CmpStrBW (const void *UserData, const void *a, const void *b)
{
  return cb_StrCompW((const wchar_t*)b,(const wchar_t*)a);
}
/* END MODULE */


/* MODULE::cb_StrLower */
char * cb_DEFCALL cb_StrLower (char *b)
{
  register char *s = b;
  register cb_Integer i;
  if (s)
    do {
      i = *s;
      if (!i) break;
      i -= 'A'; if ((cb_UInteger)i<=(cb_UInteger)('Z'-'A')) *s |= 32;
      s++;
    } while(1);
  return b;
}
/* END MODULE */


/* MODULE::cb_StrUpper */
char * cb_DEFCALL cb_StrUpper (char *b)
{
  register char *s = b;
  register cb_Integer i;
  if (s)
    do {
      i = *s;
      if (!i) break;
      i -= 'a'; if ((cb_UInteger)i<=(cb_UInteger)('z'-'a')) *s -= 32;
      s++;
    } while(1);
  return b;
}
/* END MODULE */


/* MODULE::cb_StrLowerW */
wchar_t * cb_DEFCALL cb_StrLowerW (wchar_t *b)
{
  register wchar_t *s = b;
  register wint_t i;
  if (s)
    do {
      i = *s;
      if (!i) break;
      i -= L'A'; if ((cb_UInteger)i<=(cb_UInteger)(L'Z'-L'A')) *s |= 32;
      s++;
    } while(1);
  return b;
}
/* END MODULE */


/* MODULE::cb_StrUpperW */
wchar_t * cb_DEFCALL cb_StrUpperW (wchar_t *b)
{
  register wchar_t *s = b;
  register wint_t i;
  if (s)
    do {
      i = *s;
      if (!i) break;
      i -= L'a'; if ((cb_UInteger)i<=(cb_UInteger)(L'z'-L'a')) *s -= 32;
      s++;
    } while(1);
  return b;
}
/* END MODULE */


/* MODULE::cb_LCase */
char* cb_DEFCALL cb_LCaseX (const char *src,void *dst,cb_Integer len,cb_Integer sze)
{
  return cb_StrLower(cb_NewStrX(src,dst,len,sze));
}

char* cb_DEFCALL cb_LCase (const char *src,void *dst)
{
  return cb_StrLower(cb_NewStr(src,dst));
}
/* END MODULE */


/* MODULE::cb_UCase */
char* cb_DEFCALL cb_UCaseX (const char *src,void *dst,cb_Integer len,cb_Integer sze)
{
  return cb_StrUpper(cb_NewStrX(src,dst,len,sze));
}

char* cb_DEFCALL cb_UCase (const char *src,void *dst)
{
  return cb_StrUpper(cb_NewStr(src,dst));
}
/* END MODULE */


/* MODULE::cb_LCaseW */
wchar_t* cb_DEFCALL cb_LCaseXW (const wchar_t *src,void *dst,cb_Integer len,cb_Integer sze)
{
  return cb_StrLowerW(cb_NewStrXW(src,dst,len,sze));
}

wchar_t* cb_DEFCALL cb_LCaseW (const wchar_t *src,void *dst)
{
  return cb_StrLowerW(cb_NewStrW(src,dst));
}
/* END MODULE */


/* MODULE::cb_UCaseW */
wchar_t* cb_DEFCALL cb_UCaseXW (const wchar_t *src,void *dst,cb_Integer len,cb_Integer sze)
{
  return cb_StrUpperW(cb_NewStrXW(src,dst,len,sze));
}

wchar_t* cb_DEFCALL cb_UCaseW (const wchar_t *src,void *dst)
{
  return cb_StrUpperW(cb_NewStrW(src,dst));
}
/* END MODULE */


/* MODULE::cb_MCase */
char * cb_DEFCALL cb_MCaseX (const char *src, void *dst, cb_Integer len, cb_Integer sze)
{
  register char *sTmp = cb_LCaseX(src, dst, len, sze);
  register char *s = sTmp;
  do {
    while(!cb_IsAlpha(*s)) { if (s[0]==0) return sTmp; s++; }
    s[0] &= ~32;
    while(cb_IsAlpha(*++s));
  } while(1);
}

char * cb_DEFCALL cb_MCase (const char *src, void *dst)
{
  return cb_MCaseX(src,dst);
}
/* END MODULE */


/* MODULE::cb_MCaseW */
wchar_t * cb_DEFCALL cb_MCaseXW (const wchar_t *src, void *dst, cb_Integer len, cb_Integer sze)
{
  register wchar_t *sTmp = cb_LCaseXW(src, dst, len, sze);
  register wchar_t *s = sTmp;
  do {
    while(!iswalpha(*s)) { if (s[0]==0) return sTmp; s++; }
    s[0] &= ~32;
    while(iswalpha(*++s));
  } while(1);
}

wchar_t * cb_DEFCALL cb_MCaseW (const wchar_t *src, void *dst)
{
  return cb_MCaseXW(src,dst);
}
/* END MODULE */


/* MODULE::cb_StrConCat */
__declspec(noinline) char * cb_CDECL cb_StrConCat (void *dst, ...)
{
  register cb_UInteger i1;
  register const char **s_=(const char**)(&dst);
  register char *sTmp = (char*)dst;
  sTmp += cb_StrLen(sTmp);
  do {
    s_++; if (!s_[0]) break;
    i1 = cb_StrLen(s_[0]);
    if (i1) { cb_MemCopy(sTmp, s_[0], i1); sTmp += i1; }
  } while(1);
  sTmp[0] = 0;
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_StrConCatW */
__declspec(noinline) wchar_t * cb_CDECL cb_StrConCatW (void *dst, ...)
{
  register cb_UInteger i1;
  register const wchar_t **s_=(const wchar_t**)(&dst);
  register char *sTmp = (char*)dst;
  sTmp += cb_StrLenW((const wchar_t*)sTmp) << 1;
  do {
    s_++; if (!s_[0]) break;
    i1 = cb_StrLenW(s_[0]) << 1;
    if (i1) { cb_MemCopy(sTmp, s_[0], i1); sTmp += i1; }
  } while(1);
  ((wchar_t*)sTmp)[0] = 0;
  return (wchar_t*)dst;
}
/* END MODULE */


/* MODULE::cb_StrJoin */
__declspec(noinline) char * cb_CDECL cb_StrJoin (void *dst, ...)
{
  register const char **s_=(const char**)(&dst);
  register cb_UInteger i1;
  register char *sTmp = (char*)dst;
  if (!sTmp || (cb_UInteger)sTmp>=(cb_UInteger)-2) {
    i1 = 0;
    do {
      s_++; if (!s_[0]) break;
      i1 += cb_StrLen(s_[0]);
    } while(1);
    if (!sTmp) sTmp = cb_TmpDynStr(i1);
    else if (sTmp==(char*)-2) return (char*)(i1+1);
    else sTmp = (char*)cb_MemAllocM(i1+sizeof(cb_Integer));
    if (!sTmp) return NULL;
    s_=(const char**)(&dst);
    dst = (void*)sTmp;
  }
  do {
    s_++; if (!s_[0]) break;
    i1 = cb_StrLen(s_[0]);
    if (i1) { cb_MemCopy(sTmp, s_[0], i1); sTmp += i1; }
  } while(1);
  sTmp[0] = 0;
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_StrJoinW */
__declspec(noinline) wchar_t * cb_CDECL cb_StrJoinW (void *dst, ...)
{
  register const wchar_t **s_=(const wchar_t**)(&dst);
  register cb_UInteger i1;
  register char *sTmp = (char*)dst;
  if (!sTmp || (cb_UInteger)sTmp>=(cb_UInteger)-2) {
    i1 = 0;
    do {
      s_++; if (!s_[0]) break;
      i1 += cb_StrLenW(s_[0]);
    } while(1);
    if (!sTmp) sTmp = cb_TmpDynStr(i1 << 1);
    else if (sTmp==(char*)-2) return (wchar_t*)(i1+1);
    else sTmp = (char*)cb_MemAllocM((i1 << 1)+sizeof(cb_Integer));
    if (!sTmp) return NULL;
    s_=(const wchar_t**)(&dst);
    dst = (void*)sTmp;
  }
  do {
    s_++; if (!s_[0]) break;
    i1 = cb_StrLenW(s_[0]) << 1;
    if (i1) { cb_MemCopy(sTmp, s_[0], i1); sTmp += i1; }
  } while(1);
  ((wchar_t*)sTmp)[0] = 0;
  return (wchar_t*)dst;
}
/* END MODULE */


/* MODULE::cb_StrJoinEx */
__declspec(noinline) char * cb_CDECL cb_StrJoinEx (cb_Integer flag1, void *dst, const void *sDelim, ...)
{
#define MyMax_ (32<<1)
  register cb_Integer i;
  register const void **s1 = &sDelim;
  register const char *s2 = (const char*)sDelim; if (!s2) s2 = " ";
  const void *buf[2+MyMax_];
  buf[0] = dst;
  i=0;
  do {
    s1++;
    i++; buf[i] = s1[0];
    if (!s1[0]) {
      if (i>1) i--;
      break;
    }
    i++; buf[i] = s2;
  } while(i<MyMax_);
  buf[i] = NULL; i++;
  return (char*)cb_CallAnyFunction(flag1?(const void*)cb_StrJoinW:(const void*)cb_StrJoin,i,buf);
#undef MyMax_
}
/* END MODULE */


/* MODULE::cb_StrDelete */
char * cb_DEFCALL cb_StrDelete (const char *src, cb_Integer j, cb_Integer Pos1, void *dst)
{
  register cb_UInteger n = cb_StrLen(src);
  register cb_UInteger i = Pos1; if (i==(cb_UInteger)-1) i++;
  register char *sTmp = (char*)dst;
  if (i>n || j==0) { i = 0; j = 0; }
  n-=j; if (n<i) { n=i; j=0; }
  if (sTmp==NULL || (sTmp==(char*)-1)) { sTmp = cb_NewStr_(NULL,sTmp,n); if (sTmp==NULL) goto Exit0000; }
  n++;
  if (i!=0) { n-=i; if (sTmp<src) cb_MemCopy(sTmp,src,i); }
  cb_MemMove(sTmp+i,src+i+j,n);
  if (i!=0) if (sTmp>src) cb_MemMove(sTmp,src,i);
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_StrDeleteW */
wchar_t * cb_DEFCALL cb_StrDeleteW (const wchar_t *src, cb_Integer j, cb_Integer Pos1, void *dst)
{
  register cb_UInteger n = cb_StrLenW(src);
  register cb_UInteger i = Pos1; if (i==(cb_UInteger)-1) i++;
  register wchar_t *sTmp = (wchar_t*)dst;
  if (i>n || j==0) { i = 0; j = 0; }
  n-=j; if (n<i) { n=i; j=0; }
  n <<= 1;
  if (sTmp==NULL || (sTmp==(wchar_t*)-1)) { sTmp = (wchar_t*)cb_NewStr_(NULL,sTmp,n); if (sTmp==NULL) goto Exit0000; }
  i <<= 1; j <<= 1;
  n++;
  if (i!=0) { n-=i; if (sTmp<src) cb_MemCopy(sTmp,src,i); }
  cb_MemMove(((char*)sTmp)+i,((char*)src)+i+j,n);
  if (i!=0) if (sTmp>src) cb_MemMove(sTmp,src,i);
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_StrInsert */
char * cb_DEFCALL cb_StrInsert (const char *src, const char *a, cb_Integer Pos1, void *dst, cb_Integer iLen)
{
  register cb_UInteger i = Pos1; if (i==(cb_UInteger)-1) i++;
  register cb_UInteger j = cb_StrLen(src);
  register char *sTmp = (char*)dst;
  register cb_UInteger h = iLen; if ((cb_Integer)h<0) h = cb_StrLen(a);
  if (i>j || h==0 || (j+h)<j) { i = 0; h = 0; }
  if (sTmp==NULL || (sTmp==(char*)-1)) { sTmp = cb_NewStr_(NULL,sTmp,j+h); if (sTmp==NULL) goto Exit0000; }
  j++;
  if (i!=0) { j-=i; if (sTmp<src) cb_MemCopy(sTmp,src,i); }
  cb_MemMove(sTmp+i+h,src+i,j);
  if (h!=0) {
    if (a) cb_MemMove(sTmp+i,a,h);
    if (i!=0) if (sTmp>src) cb_MemMove(sTmp,src,i);
  }
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_StrInsertW */
wchar_t * cb_DEFCALL cb_StrInsertW (const wchar_t *src, const wchar_t *a, cb_Integer Pos1, void *dst)
{
  register cb_UInteger i = Pos1; if (i==(cb_UInteger)-1) i++;
  register cb_UInteger j = cb_StrLenW(src);
  register wchar_t *sTmp = (wchar_t*)dst;
  register cb_UInteger h = cb_StrLenW(a);
  if (i>j || h==0 || (j+h)<j) { i = 0; h = 0; }
  j <<= 1; h <<= 1;
  if (sTmp==NULL || (sTmp==(wchar_t*)-1)) { sTmp = (wchar_t*)cb_NewStr_(NULL,sTmp,j+h); if (sTmp==NULL) goto Exit0000; }
  i <<= 1;
  j++;
  if (i!=0) { j-=i; if (sTmp<src) cb_MemCopy(sTmp,src,i); }
  cb_MemMove(((char*)sTmp)+i+h,((char*)src)+i,j);
  if (h!=0) {
    cb_MemMove(((char*)sTmp)+i,a,h);
    if (i!=0) if (sTmp>src) cb_MemMove(sTmp,src,i);
  }
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_StrSet */
char * cb_DEFCALL cb_StrSet (cb_Integer count, cb_UInteger c, void *dst)
{
  register cb_Integer i = count;
  register char *sTmp = (char*)dst;
  if (!sTmp || sTmp==(char*)-1) { sTmp = cb_NewStr_(NULL,sTmp,i); if (!sTmp) goto Exit0000; }
  if (i) cb_MemSet(sTmp,c,i);
  sTmp[i] = 0;
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_StrSetW */
wchar_t * cb_DEFCALL cb_StrSetW (cb_Integer count, wchar_t c, void *dst)
{
  register cb_Integer i = count;
  register wchar_t *sTmp = (wchar_t*)dst;
  if (!sTmp || sTmp==(wchar_t*)-1) { sTmp = (wchar_t*)cb_NewStr_(NULL,sTmp,i << 1); if (!sTmp) goto Exit0000; }
  if (i) cb_MemSetW(sTmp,c,i);
  sTmp[i] = 0;
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_LPad */
char* cb_DEFCALL cb_LPad (const char *src, cb_UInteger l, cb_Integer c, void *dst, cb_Integer bWidth)
{
  register char *sTmp = (char*)dst;
  register cb_UInteger i = bWidth ? cb_StrLenW((const wchar_t*)src)<<1 : cb_StrLen(src);
  register cb_UInteger l1 = l;
  if (l1<=i) {
    if (!sTmp) return (char*)src;
    i++;
    if (sTmp==(char*)-1) { sTmp = (char*)cb_MemAllocM(i+3); if (!sTmp) goto Exit0000; }
    if (bWidth) i++;
    cb_MemMove(sTmp,src,i); goto Exit0000;
  }
  if (!sTmp || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(NULL,sTmp,l1);
    if (!sTmp) goto Exit0000;
  }
  l1 -= i;
  i++; if (bWidth) i++;
  cb_MemMove(sTmp+l1,src,i);
  if (!bWidth) cb_MemSet(sTmp,c,l1); else cb_MemSetW((wchar_t*)sTmp,c,l1>>1);
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_RPad */
char* cb_DEFCALL cb_RPad (const char *src, cb_UInteger l, cb_Integer c, void *dst, cb_Integer bWidth)
{
  register char *sTmp = (char*)dst;
  register cb_UInteger i = bWidth ? cb_StrLenW((const wchar_t*)src)<<1 : cb_StrLen(src);
  register cb_UInteger l1 = l;
  if (l1<=i) {
    if (!sTmp) return (char*)src;
    i++;
    if (sTmp==(char*)-1) { sTmp = (char*)cb_MemAllocM(i+3); if (!sTmp) goto Exit0000; }
    if (bWidth) i++;
    cb_MemMove(sTmp,src,i); goto Exit0000;
  }
  if (!sTmp || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(NULL,sTmp,l1);
    if (!sTmp) goto Exit0000;
  }
  if (sTmp!=src) cb_MemMove(sTmp,src,i);
  if (!bWidth) { cb_MemSet(sTmp+i,c,l1-i); sTmp[l1] = 0; }
  else { cb_MemSetW((wchar_t*)(sTmp+i),c,(l1-1)>>1); *(short*)(sTmp+l1) = 0; }
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_LPadW */
wchar_t* cb_DEFCALL cb_LPadW (const wchar_t *src, cb_UInteger l, cb_Integer c, void *dst)
{
  return (wchar_t*)cb_LPad((const char*)src,l<<1,c,dst,TRUE);
}
/* END MODULE */


/* MODULE::cb_RPadW */
wchar_t* cb_DEFCALL cb_RPadW (const wchar_t *src, cb_UInteger l, cb_Integer c, void *dst)
{
  return (wchar_t*)cb_RPad((const char*)src,l<<1,c,dst,TRUE);
}
/* END MODULE */


/* MODULE::cb_StrLPad */
char* cb_DEFCALL cb_StrLPad (const char *src, cb_UInteger l, const char *c, void *dst, cb_Integer bWidth)
{
  register char *sTmp = (char*)c; if (sTmp==NULL) sTmp = " ";
  register cb_UInteger i;
  register cb_UInteger l1 = l;
  register cb_UInteger l2;
  if (bWidth) { i = cb_StrLenW((const wchar_t*)src)<<1; l2 = cb_StrLenW((const wchar_t*)sTmp)<<1; }
  else { i = cb_StrLen(src); l2 = cb_StrLen(sTmp); }
  sTmp = (char*)dst;
  l1 *= l2;
  if (l1<=i) {
    if (!sTmp) return (char*)src;
    i++;
    if (sTmp==(char*)-1) { sTmp = (char*)cb_MemAllocM(i+3); if (!sTmp) goto Exit0000; }
    if (bWidth) i++;
    cb_MemMove(sTmp,src,i); goto Exit0000;
  }
  if (!sTmp || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(NULL,sTmp,l1);
    if (!sTmp) goto Exit0000;
  }
  l1 -= i;
  i++; if (bWidth) i++;
  cb_MemMove(sTmp+l1,src,i);
  i = l2;
  do {
    if (l1>=i) l1 -= i;
    else { i = l1; l1 = 0; }
    cb_MemMove(sTmp+l1,c,i);
  } while(l1);
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_StrRPad */
char* cb_DEFCALL cb_StrRPad (const char *src, cb_UInteger l, const char *c, void *dst, cb_Integer bWidth)
{
  register char *sTmp = (char*)c; if (sTmp==NULL) sTmp = " ";
  register cb_UInteger i;
  register cb_UInteger l1 = l;
  register cb_UInteger l2;
  if (bWidth) { i = cb_StrLenW((const wchar_t*)src)<<1; l2 = cb_StrLenW((const wchar_t*)sTmp)<<1; }
  else { i = cb_StrLen(src); l2 = cb_StrLen(sTmp); }
  sTmp = (char*)dst;
  l1 *= l2;
  if (l1<=i) {
    if (!sTmp) return (char*)src;
    i++;
    if (sTmp==(char*)-1) { sTmp = (char*)cb_MemAllocM(i+3); if (!sTmp) goto Exit0000; }
    if (bWidth) i++;
    cb_MemMove(sTmp,src,i); goto Exit0000;
  }
  if (!sTmp || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(NULL,sTmp,l1);
    if (!sTmp) goto Exit0000;
  }
  if (sTmp!=src) cb_MemMove(sTmp,src,i);
  do {
    if (l1<i+l2) l2 = l1-i;
    cb_MemMove(sTmp+i,c,l2);
    i += l2;
  } while(l1>i);
  if (!bWidth) sTmp[l1] = 0; else *(short*)(sTmp+l1) = 0;
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_StrLPadW */
wchar_t* cb_DEFCALL cb_StrLPadW (const wchar_t *src, cb_UInteger l, const wchar_t *c, void *dst)
{
  return (wchar_t*)cb_StrLPad((const char*)src,l<<1,(const char*)c,dst,TRUE);
}
/* END MODULE */


/* MODULE::cb_StrRPadW */
wchar_t* cb_DEFCALL cb_StrRPadW (const wchar_t *src, cb_UInteger l, const wchar_t *c, void *dst)
{
  return (wchar_t*)cb_StrRPad((const char*)src,l<<1,(const char*)c,dst,TRUE);
}
/* END MODULE */


/* MODULE::cb_LSet */
char* cb_DEFCALL cb_LSet (const char *Str1,const char *Str2,void *dst,cb_Integer bWidth)
{
  register cb_Integer i, j;
  if (bWidth&1) { i = cb_StrLenW((const wchar_t*)Str1)<<1; j = cb_StrLenW((const wchar_t*)Str2)<<1; }
  else { i = cb_StrLen(Str1); j = cb_StrLen(Str2); }
  register char* sTmp;
  sTmp = (char*)dst;
  if (sTmp==NULL || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(Str1,sTmp,i);
  }
  else {
    cb_MemMove(sTmp,Str1,i+1+(bWidth&1));
  }
  if (i<=j) {
    j = i;
  }
  else if (bWidth&2) {
    i -= j;
    if (!(bWidth&1)) cb_MemSet(sTmp+j,32,i); else cb_MemSetW((wchar_t*)(sTmp+j),32,i>>1);
  }
  return (char*)cb_MemCopy(sTmp,Str2,j);
}
/* END MODULE */


/* MODULE::cb_RSet */
char* cb_DEFCALL cb_RSet (const char *Str1,const char *Str2,void *dst,cb_Integer bWidth)
{
  register cb_Integer i, j;
  if (bWidth&1) { i = cb_StrLenW((const wchar_t*)Str1)<<1; j = cb_StrLenW((const wchar_t*)Str2)<<1; }
  else { i = cb_StrLen(Str1); j = cb_StrLen(Str2); }
  register char* sTmp;
  sTmp = (char*)dst;
  if (sTmp==NULL || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(Str1,sTmp,i);
  }
  else {
    cb_MemMove(sTmp,Str1,i+1+(bWidth&1));
  }
  if (i<=j) {
    j = i;
    i = 0;
  }
  else if (bWidth&2) {
    i -= j;
    if (!(bWidth&1)) cb_MemSet(sTmp,32,i); else cb_MemSetW((wchar_t*)sTmp,32,i>>1);
  }
  cb_MemCopy(sTmp+i,Str2,j);
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_LSetW */
wchar_t* cb_DEFCALL cb_LSetW (const wchar_t *Str1,const wchar_t *Str2,void *dst,cb_Integer flag1)
{
  register cb_Integer i = 1; if (flag1) i |= 2;
  return (wchar_t*)cb_LSet((const char*)Str1,(const char*)Str2,dst,i);
}
/* END MODULE */


/* MODULE::cb_RSetW */
wchar_t* cb_DEFCALL cb_RSetW (const wchar_t *Str1,const wchar_t *Str2,void *dst,cb_Integer flag1)
{
  register cb_Integer i = 1; if (flag1) i |= 2;
  return (wchar_t*)cb_RSet((const char*)Str1,(const char*)Str2,dst,i);
}
/* END MODULE */


/* MODULE::cb_Mid */
char * cb_DEFCALL cb_Mid (const void *Str1, cb_Integer Pos1, cb_Integer length, void *dst)
{
  register char *sTmp = (char*)Str1;
  register cb_Integer tmplen = sTmp ? cb_StrLen(sTmp) : 0;
  register cb_Integer i = Pos1; if (i<0) i = 0;
  if (i>=tmplen) {
    sTmp = (char*)dst;
    if (!sTmp) return cb_EMPTYSTR;
    return cb_NewStr_(cb_EMPTYSTR, sTmp, 0);
  }
  if (length>(tmplen-i)) tmplen -= i; else tmplen = length;
  sTmp+=i; return cb_NewStr(sTmp, dst, tmplen);
}
/* END MODULE */


/* MODULE::cb_Left */
char * cb_DEFCALL cb_Left (const void *src, cb_Integer length, void *dst)
{
  return cb_NewStr(src,dst,length);
}
/* END MODULE */


/* MODULE::cb_Right */
char * cb_DEFCALL cb_Right (const void *src, cb_Integer length,void *dst)
{
  register cb_UInteger i = cb_StrLen((const char*)src);
  register cb_UInteger len1 = length;
  if (i < (cb_UInteger)(len1-1)) len1 = i;
  i-=len1; return cb_NewStr_((const char*)src+i,dst,len1);
}
/* END MODULE */


/* MODULE::cb_MidW */
wchar_t * cb_DEFCALL cb_MidW (const void *Str1, cb_Integer Pos1, cb_Integer length, void *dst)
{
  register wchar_t *sTmp = (wchar_t*)Str1;
  register cb_Integer tmplen = sTmp ? cb_StrLenW(sTmp) : 0;
  register cb_Integer i = Pos1; if (i<0) i = 0;
  if (i>=tmplen) {
    sTmp = (wchar_t*)dst;
    if (!sTmp) return (wchar_t*)cb_EMPTYSTR;
    return cb_NewStrW_(cb_EMPTYSTR, sTmp, 0);
  }
  if (length>(tmplen-i)) tmplen -= i; else tmplen = length;
  sTmp+=i; tmplen <<= 1; return cb_NewStrW(sTmp, dst, tmplen);
}
/* END MODULE */


/* MODULE::cb_LeftW */
wchar_t * cb_DEFCALL cb_LeftW (const void *src, cb_Integer length, void *dst)
{
  return cb_NewStrW(src,dst,length);
}
/* END MODULE */


/* MODULE::cb_RightW */
wchar_t * cb_DEFCALL cb_RightW (const void *src, cb_Integer length,void *dst)
{
  register cb_UInteger i = cb_StrLenW((const wchar_t*)src);
  register cb_UInteger len1 = length;
  if (i < (cb_UInteger)(len1-1)) len1 = i;
  i-=len1; i<<=1; return cb_NewStrW_((const char*)src+i,dst,len1);
}
/* END MODULE */


/* MODULE::cb_MidSet */
char* cb_DEFCALL cb_MidSet (const void *str1, cb_Integer Pos1, const void *str2, cb_Integer len1, cb_Integer len2, void *dst)
{
  register cb_Integer i = Pos1; if (i<0) i = 0;
  register cb_Integer l1 = cb_StrLen((const char*)str1), l2 = len2;
  char *strtmp = (char*)dst;
  if (i>l1) { strtmp = NULL; goto Exit0000; }
  if (l2<=0) l2 = cb_StrLen((const char*)str2);
  if (len1<0) len1 = 0;
  len2 = l1; l1 -= i; if (len1) l1 += l2-len1; else if (l1<l2) l1 = l2;
  if (strtmp!=str1) {
    if (strtmp==NULL || (cb_Integer)strtmp==-1) {
      strtmp = cb_NewStr_(NULL,strtmp,i+l1); if (!strtmp) { if (!dst) strtmp = cb_EMPTYSTR; goto Exit0000; }
    }
    cb_MemMove(strtmp,str1,len2);
  }
  if (len1) if (l2!=len1) cb_MemMove(strtmp+i+l2,strtmp+len1,len2-i-len1);
  if (l2) cb_MemCopy(strtmp+i,str2,l2);
  strtmp[i+l1] = 0;
Exit0000:
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_LeftSet */
char * cb_DEFCALL cb_LeftSet (const void *str1, const void *str2, cb_Integer len1, cb_Integer len2, void *dst)
{
  return cb_MidSet(str1,0,str2,len1,len2,dst);
}
/* END MODULE */


/* MODULE::cb_RightSet */
char * cb_DEFCALL cb_RightSet (const void *str1, const void *str2, cb_Integer len1, cb_Integer len2, void *dst)
{
  register cb_Integer i = len1; if (i<=0) { i = len2; if (i<=0) i = cb_StrLen((const char*)str2); }
  i = cb_StrLen((const char*)str1)-i; if (i<0) if (len1<=0) i = 0;
  return cb_MidSet(str1,i,str2,len1,len2,dst);
}
/* END MODULE */


/* MODULE::cb_MidSetW */
wchar_t* cb_DEFCALL cb_MidSetW (const void *str1, cb_Integer Pos1, const void *str2, cb_Integer len1, cb_Integer len2, void *dst)
{
  register cb_Integer i = Pos1; if (i<0) i = 0;
  register cb_Integer l1 = cb_StrLenW((const wchar_t*)str1), l2 = len2;
  wchar_t *strtmp = (wchar_t*)dst;
  if (i>l1) { strtmp = NULL; goto Exit0000; }
  if (l2<=0) l2 = cb_StrLenW((const wchar_t*)str2);
  if (len1<0) len1 = 0;
  len2 = l1; l1 -= i; if (len1) l1 += l2-len1; else if (l1<l2) l1 = l2;
  if (strtmp!=str1) {
    if (strtmp==NULL || (cb_Integer)strtmp==-1) {
      strtmp = cb_NewStrW_(NULL,strtmp,i+l1); if (!strtmp) { if (!dst) strtmp = (wchar_t*)cb_EMPTYSTR; goto Exit0000; }
    }
    cb_MemMove(strtmp,str1,len2<<1);
  }
  if (len1) if (l2!=len1) cb_MemMove(strtmp+i+l2,strtmp+len1,(len2-i-len1)<<1);
  if (l2) cb_MemCopy(strtmp+i,str2,l2);
  strtmp[i+l1] = 0;
Exit0000:
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_LeftSetW */
wchar_t * cb_DEFCALL cb_LeftSetW (const void *str1, const void *str2, cb_Integer len1, cb_Integer len2, void *dst)
{
  return cb_MidSetW(str1,0,str2,len1,len2,dst);
}
/* END MODULE */


/* MODULE::cb_RightSetW */
wchar_t * cb_DEFCALL cb_RightSetW (const void *str1, const void *str2, cb_Integer len1, cb_Integer len2, void *dst)
{
  register cb_Integer i = len1; if (i<=0) { i = len2; if (i<=0) i = cb_StrLenW((const wchar_t*)str2); }
  i = cb_StrLenW((const wchar_t*)str1)-i; if (i<0) if (len1<=0) i = 0;
  return cb_MidSetW(str1,i,str2,len1,len2,dst);
}
/* END MODULE */


/* MODULE::cb_AtoU */
wchar_t * cb_DEFCALL cb_AtoU (const void *aStr, void *wStr, cb_Integer sze)
{
  register cb_Integer i = sze;
  register const char *src = (const char*)aStr;
  register wchar_t *sTmp = (wchar_t*)wStr;
  if (i<=0) i = cb_StrLen(src);
  if (sTmp==NULL || sTmp==(wchar_t*)-1) {
    sTmp = (wchar_t*)cb_NewStr_(NULL,sTmp,i << 1);
    if (!sTmp) return NULL;
  }
  sTmp[i] = 0; while(i>0) { i--; sTmp[i] = ((unsigned char*)src)[i]; }
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_UtoA */
char * cb_DEFCALL cb_UtoA (const void *wStr, void *aStr, cb_Integer sze)
{
  register cb_Integer i = sze;
  register const wchar_t *src = (const wchar_t*)wStr;
  register char *sTmp = (char*)aStr;
  if (i<=0) i = cb_StrLenW(src);
  if (sTmp==NULL || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(NULL,sTmp,i);
    if (!sTmp) return NULL;
  }
  sTmp[i] = 0; while(i>0) { i--; sTmp[i] = (char)(src[i]); }
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_UnicodeToAnsi */
char * cb_DEFCALL cb_UnicodeToAnsi (const wchar_t *WideStr,void *dst,cb_UInteger CodePage,DWORD dwFlags)
{
  register char *RetVar;
  register cb_UInteger uLen;
  uLen = WideCharToMultiByte(CodePage,dwFlags,WideStr,-1,NULL,0,NULL,NULL);
  RetVar = (char*)dst;
  if (!RetVar || RetVar==(char*)-1) {
    RetVar = (char*)cb_NewStr_(NULL,RetVar,uLen);
    if (!RetVar) goto Exit0000;
  }
  if (!uLen) { RetVar[0] = 0; return RetVar; }
  WideCharToMultiByte(CodePage,dwFlags,WideStr,uLen,RetVar,uLen,NULL,NULL);
Exit0000:
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_AnsiToUnicode */
wchar_t * cb_DEFCALL cb_AnsiToUnicode (const char *AnsiStr,void *dst,cb_UInteger CodePage,DWORD dwFlags)
{
  register wchar_t *RetVar;
  register cb_UInteger uLen;
  if (dwFlags==(DWORD)-1) dwFlags = MB_PRECOMPOSED;
  if (CodePage==(cb_UInteger)-1) CodePage = CP_ACP;
  uLen = MultiByteToWideChar(CodePage,dwFlags,AnsiStr,-1,NULL,0);
  RetVar = (wchar_t*)dst;
  if (!RetVar || RetVar==(wchar_t*)-1) {
    RetVar = (wchar_t*)cb_NewStr_(NULL,RetVar,uLen<<1);
    if (!RetVar) goto Exit0000;
  }
  if (uLen<=1) RetVar[0] = 0;
  else MultiByteToWideChar(CodePage,dwFlags,AnsiStr,uLen,RetVar,uLen);
Exit0000:
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_GetEnv */
char* cb_DEFCALL cb_GetEnv (const char *S, void *dst, cb_Integer c)
{
  register char *dst1;
  register cb_UInteger i, n;

  if (S==NULL) {
    dst1 = GetEnvironmentStrings();
    S = dst1; n = 0;
    if (dst1)
    do {
      i = cb_StrLen(dst1); if (i==0) break;
      i++; n += i; dst1 += i;
    } while(1);
    if (dst!=(void*)-2) {
      dst1 = cb_NewStr_(S,dst,n);
      if (S) FreeEnvironmentStrings((char*)S);
      if (!dst1) goto exit000;
      n = (cb_UInteger)dst1;
      do {
        i = cb_StrLen(dst1); if (i==0) break;
        dst1 += i; dst1[0] = c; dst1++;
      } while(1);
    }
    return (char*)n;
  }

  n = 0x1800;
  do {
    dst1 = cb_NewStr_(NULL,(void*)-1,n); if (!dst1) { exit000:; if (!dst) dst1 = cb_EMPTYSTR; goto exit0000; }
    i = GetEnvironmentVariable(S,dst1,n); if (i<n) break;
    i += 2; n = i; cb_MemFreeM(dst1);
  } while (1);
  dst1[i] = 0;
  n = (cb_UInteger)dst;
  if (n==0) cb_AddTmpDynStr_(dst1);
  else if (n!=-1) { if (i) cb_MemCopy((void*)n,dst1,i); cb_MemFreeM(dst1); dst1 = (char*)n; dst1[i] = 0; }
exit0000:
  return dst1;
}
/* END MODULE */


/* MODULE::cb_GetPathEnv */
char * cb_DEFCALL cb_GetPathEnv (const char *szFile, void *dst, const char *envname)
{
  register char *RetVar = (char*)dst;

  if (!RetVar || RetVar==(char*)-1) {
    RetVar = cb_NewStr_(NULL,RetVar,64 * 0x400);
    if (!RetVar) { if (!dst) RetVar = cb_EMPTYSTR; goto Exit0000; }
  }
  _searchenv(szFile,envname,RetVar);
Exit0000:
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_Chr */
char * cb_DEFCALL cb_Chr (cb_Integer a,void *dst)
{
  register char *strtmp = (char*)dst;
  if (!strtmp || (strtmp==(char*)-1)) strtmp = cb_NewStr_(NULL,strtmp,1);
  strtmp[0] = a;
  strtmp[1] = 0;
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_ChrW */
wchar_t * cb_DEFCALL cb_ChrW (cb_Integer a,void *dst)
{
  register wchar_t *strtmp = (wchar_t*)dst;
  if (!strtmp || (strtmp==(wchar_t*)-1)) strtmp = (wchar_t*)cb_NewStr_(NULL,strtmp,2);
  strtmp[0] = a;
  strtmp[1] = 0;
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_pasChr */
cb_PpasString cb_DEFCALL cb_pasChr (cb_Integer a,void *dst)
{
}
/* END MODULE */


/* MODULE::cb_pasChrW */
cb_PpasStringW cb_DEFCALL cb_pasChrW (cb_Integer a,void *dst)
{
}
/* END MODULE */


/* MODULE::cb_StrPrintF */
__declspec(noinline) char* cb_CDECL cb_StrPrintF (void *dst, const char *A, ...)
{
  register char* Str1 = (char*)dst;
  register cb_Integer i;
  register char* Str2 = Str1;
  if (!Str1 || Str1==(char*)-1) Str1 = cb_PrintBoxBuffer;
  i = cb_vsnprintf(Str1,sizeof(cb_PrintBoxBuffer),A,&A+1);
  if (i<=0) {
    if (Str2==(char*)-1) { i = 0; goto New0000; }
    if (!Str2) Str2 = cb_EMPTYSTR; else Str2[0] = 0;
  }
  else if (!Str2 || Str2==(char*)-1) {
New0000:
    Str2 = cb_NewStr_(Str1, Str2, i);
  }
  return Str2;
}
/* END MODULE */


/* MODULE::cb_StrPrintFW */
__declspec(noinline) wchar_t* cb_CDECL cb_StrPrintFW (void *dst, const wchar_t *A, ...)
{
  register wchar_t* Str1 = (wchar_t*)dst;
  register cb_Integer i;
  register wchar_t* Str2 = Str1;
  if (!Str1 || Str1==(wchar_t*)-1) Str1 = (wchar_t*)cb_PrintBoxBuffer;
  i = cb_vsnwprintf(Str1,sizeof(cb_PrintBoxBuffer)>>1,A,&A+1);
  if (i<=0) {
    if (Str2==(wchar_t*)-1) { i = 0; goto New0000; }
    if (!Str2) Str2 = (wchar_t*)cb_EMPTYSTR; else Str2[0] = 0;
  }
  else if (!Str2 || Str2==(wchar_t*)-1) {
New0000:
    Str2 = (wchar_t*)cb_NewStr_(Str1, Str2, i<<1);
  }
  return Str2;
}
/* END MODULE */


/* MODULE::cb_TimeFormat */
char* cb_DEFCALL cb_TimeFormat (char* szTime,void *dst,cb_Integer flag1)
{
  char sBuf[512];
  register char *sTmp = szTime; if (!sTmp || !sTmp[0]) sTmp = "%H:%M:%S";
  time_t   elapse_time;
  time(&elapse_time);
  register struct tm *tp;  tp = (flag1 ? gmtime(&elapse_time) : localtime(&elapse_time));
  strftime(sBuf,sizeof(sBuf)-1,sTmp,tp);
  sTmp = (char*)dst;
  return cb_NewStr(sBuf,sTmp);
}
/* END MODULE */


/* MODULE::cb_XorStr */
char* cb_DEFCALL cb_XorStr (const void *Ptr1, const char *sXor1, void *dst, cb_Integer iLen)
{
  register cb_Integer i = iLen;
  register char *sTmp = (char*)dst;
  register const char *Str2;
  const char *Str3 = (const char*)Ptr1;

  if (i<=0) i = cb_StrLen(Str3);
  if (!sTmp || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(NULL,sTmp,i);
    if (!sTmp) return NULL;
    dst = sTmp;
  }

  Str2 = sXor1;
  for (;i;sTmp++) {
    i--;
    if (Str2[0]==0) Str2 = sXor1;
    sTmp[0] = Str3[0] ^ Str2[0];
    Str2++; Str3++;
  }
  if (iLen<=0) sTmp[0] = 0;

  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_RolStr */
char* cb_DEFCALL cb_RolStr (const void *Ptr1, cb_Integer iCnt, void *dst, cb_Integer iLen)
{
  register cb_Integer i = iLen;
  register BYTE *sTmp = (BYTE*)dst;
  register const BYTE *Str1 = (const BYTE*)Ptr1;
  BYTE iCarry1, iCarry2;

  if (i<=0) i = cb_StrLen((const char*)Str1);
  if (!sTmp || (cb_Integer)sTmp==-1) {
    sTmp = (BYTE*)cb_NewStr_(NULL,sTmp,i);
    if (!sTmp) goto Exit0000;
  }

  if (iLen<=0) { sTmp[i] = 0; iLen = i; }
  if (!iCnt) { cb_MemMove(sTmp,Str1,i); goto Exit0000; }
  do {
    iCarry1 = Str1[0];
    sTmp += i;
    Str1 += i;
    while (i) {
      i--;
      sTmp--;
      Str1--;
      iCarry2 = Str1[0];
      sTmp[0] = iCarry2 << 1;
      if ((iCarry1 & 128)!=0) sTmp[0] |= 1;
      iCarry1 = iCarry2;
    }
    i = iLen;
    Str1 = (const BYTE*)sTmp;
    iCnt--;
  } while(iCnt);

Exit0000:
  return (char*)sTmp;
}
/* END MODULE */


/* MODULE::cb_RorStr */
char* cb_DEFCALL cb_RorStr (const void *Ptr1, cb_Integer iCnt, void *dst, cb_Integer iLen)
{
  register cb_Integer i = iLen;
  register BYTE *sTmp = (BYTE*)dst;
  register const BYTE *Str1 = (const BYTE*)Ptr1;
  BYTE iCarry1, iCarry2;

  if (i<=0) i = cb_StrLen((const char*)Str1);
  if (!sTmp || (cb_Integer)sTmp==-1) {
    sTmp = (BYTE*)cb_NewStr_(NULL,sTmp,i);
    if (!sTmp) goto Exit0000;
    dst = sTmp;
  }

  if (iLen<=0) { sTmp[i] = 0; iLen = i; }
  if (i) {
  if (!iCnt) { cb_MemMove(sTmp,Str1,i); goto Exit0000; }
  i--;
  iCarry1 = Str1[i];
  i++;
  do {
    do {
      i--;
      iCarry2 = Str1[0];
      sTmp[0] = iCarry2 >> 1;
      if ((iCarry1 & 1)!=0) sTmp[0] |= 128;
      iCarry1 = iCarry2;
      if (!i) break;
      sTmp++;
      Str1++;
    } while(1);
    iCarry1 = sTmp[0];
    i = iLen;
    sTmp=(BYTE*)dst;
    Str1 = (const BYTE*)sTmp;
    iCnt--;
  } while(iCnt);
  }

Exit0000:
  return (char*)sTmp;
}
/* END MODULE */


/* MODULE::cb_GetRelativePath */
char* cb_DEFCALL cb_GetRelativePath (const char *sPath1,const char *sPath2,void *dst,const char *sPath3)
{
  register cb_Integer i = 0;
  register cb_Integer j;
  register char *sBuf = (char*)sPath1;
  register cb_Integer h;

  do {
    if (sBuf[i]!=sPath2[i]) {
      if (sBuf[i]!='\\' && sBuf[i]!='/') break;
      if (sPath2[i]!='\\' && sPath2[i]!='/') break;
    }
    i++;
  } while(sBuf[i]);
  do {
    i--;
    if (i<0) {
      if (sPath3) goto Exit000;
      break;
    }
    if (sBuf[i]=='\\' || sBuf[i]=='/') {
      if (sPath3) {
        j = cb_StrLen(sPath3);
        if (!j) goto Exit000;
        j--;
        if (sPath3[j]!='\\' && sPath3[j]!='/') j++;
        if (j>i || (sBuf[j]!='\\' && sBuf[j]!='/')) goto Exit000;
        h = j;
        for (j=0;j<h;j++) {
          if (sBuf[j]!='\\' && sBuf[j]!='/') goto Exit000;
          if (sPath3[j]!='\\' && sPath3[j]!='/') {
Exit000:
            j = 0;
            goto Exit0000;
          }
        }
      }
      i++;
      sBuf += i;
      sPath2 += i;
      break;
    }
  } while(1);
  i = cb_StrLen(sBuf);
  j = 0;
  while (i) {
    i--;
    if (sBuf[i]=='\\' || sBuf[i]=='/') {
      j++;
    }
  }
Exit0000:
  sBuf = (char*)dst;
  i = cb_StrLen(sPath2);
  if (sBuf==NULL || sBuf==(char*)-1) {
    sBuf = cb_NewStr_(NULL,sBuf,(j*3)+i);
  }
  i++;
  sBuf+=j*3;
  cb_MemMove(sBuf,sPath2,i);
  for (;j>0;j--) { sBuf -= 3; cb_MemCopy(sBuf,"..\\",3); }
  return sBuf;
}
/* END MODULE */


/* MODULE::cb_Choose */
__declspec(noinline) cb_Integer cb_CDECL cb_Choose (cb_Integer iCond, cb_Integer iDef, cb_Integer iNum, ...)
{
  register cb_Integer i = 0;
  register cb_Integer *p = &iNum;
  register cb_Integer j = iCond;
  while (i<iNum) {
    i++; p++; if (i==j) return *p;
  }
  return iDef
;}
/* END MODULE */


/* MODULE::cb_StrChoose */
__declspec(noinline) const char* cb_CDECL cb_StrChoose (cb_Integer iCond, const char *sDef, cb_Integer iNum, ...)
{
  register cb_Integer i = 0;
  register cb_Integer *p = &iNum;
  register cb_Integer j = iCond;
  while (i<iNum) {
    i++; p++; if (i==j) return *(const char**)p;
  }
  i = (cb_Integer)sDef; if (!i) i = (cb_Integer)cb_EMPTYSTR;
  return (const char*)i;
}
/* END MODULE */


/* MODULE::cb_Switch */
__declspec(noinline) cb_Integer cb_CDECL cb_Switch (cb_Integer iNum, ...)
{
  register cb_Integer i = iNum;
  register cb_Integer *p = &iNum;
  while (i>1) {
    p++; if (*p) { p++; return *p; }
    p++;
    i-=2;
  }
  return 0;
}
/* END MODULE */


/* MODULE::cb_StrSwitch */
__declspec(noinline) const char* cb_CDECL cb_StrSwitch (cb_Integer iNum, ...)
{  register cb_Integer i = iNum;  register cb_Integer *p = &iNum;  while (i>1) {
    p++; if (*p) { p++; return *(const char**)p; }    p++;    i-=2;  }
  return cb_EMPTYSTR;}
/* END MODULE */


/* MODULE::cb_StrRemain */
char * cb_DEFCALL cb_StrRemain (const void *src, const char *sMatch, cb_Integer ofs, void *dst, cb_Integer nosens)
{
  register cb_UInteger p = cb_InStr(src,sMatch,0,nosens);
  register char *sTmp = (char*)dst;
  if (p!=(cb_UInteger)-1) { p+=cb_StrLen(sMatch)+ofs; src=(const char*)src+p; }
  if (sTmp==(char*)-2) return (char*)src;
  return cb_NewStr(src,sTmp);
}
/* END MODULE */


/* MODULE::cb_StrRemainW */
wchar_t * cb_DEFCALL cb_StrRemainW (const wchar_t *src, const wchar_t *sMatch, cb_Integer ofs, void *dst, cb_Integer nosens)
{
  register cb_UInteger p = cb_InStrW(src,sMatch,0,nosens);
  register wchar_t *sTmp = (wchar_t*)dst;
  if (p!=(cb_UInteger)-1) { p+=cb_StrLenW(sMatch)+ofs; src+=p; }
  if (sTmp==(wchar_t*)-2) return (wchar_t*)src;
  return cb_NewStrW(src,sTmp);
}
/* END MODULE */


/* MODULE::cb_StrRepeat */
char * cb_DEFCALL cb_StrRepeat (cb_Integer count, const char *src, void *dst)
{
  register cb_Integer i = cb_StrLen(src);
  register char *sTmp = (char*)dst;
  register char *RetVar;
  if (!sTmp || (sTmp==(char*)-1)) { sTmp = cb_NewStr_(NULL,sTmp,count*i); if (!sTmp) return NULL; }
  RetVar = sTmp;
  if (i>0) for(;count>0;count--) { cb_MemCopy(sTmp,src,i); sTmp+=i; }
  sTmp[0] = 0;
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_StrRepeatW */
wchar_t * cb_DEFCALL cb_StrRepeatW (cb_Integer count, const wchar_t *src, void *dst)
{
  register cb_Integer i = cb_StrLenW(src) << 1;
  register char *sTmp = (char*)dst;
  register wchar_t *RetVar;
  if (!sTmp || (sTmp==(char*)-1)) { sTmp = cb_NewStr_(NULL,sTmp,count*i); if (!sTmp) return NULL; }
  RetVar = (wchar_t*)sTmp;
  if (i>0) for(;count>0;count--) { cb_MemCopy(sTmp,src,i); sTmp+=i; }
  ((wchar_t*)sTmp)[0] = 0;
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_StrRetain */
char * cb_DEFCALL cb_StrRetain (const void *src, const char *sChars, void *dst, cb_Integer nosens)
{
  register const char *sVar = (const char*)src;
  register char *tmp = (char*)dst;
  if (!tmp || (tmp==(char*)-1)) { tmp = cb_NewStr_(NULL,tmp,cb_StrLen(sVar)); if (!tmp) return NULL; dst = tmp; }

  if ((nosens & 1)!=0)
  for (;sVar[0];sVar++) {
    if (cb_StrIChar(sChars,sVar[0])) { if ((nosens&2)==0) goto Add0000; }
    else if ((nosens & 2)!=0) goto Add0000;
  }
  else
  for (;sVar[0];sVar++) {
    if (cb_StrChar(sChars,sVar[0])) { if ((nosens&2)==0) goto Add0000; }
    else if ((nosens & 2)!=0) { Add0000:; tmp[0] = sVar[0]; tmp++; }
  }
  tmp[0] = 0;
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_StrRetainW */
wchar_t * cb_DEFCALL cb_StrRetainW (const wchar_t *src, const wchar_t *sChars, void *dst, cb_Integer nosens)
{
  register const wchar_t *sVar = src;
  register wchar_t *tmp = (wchar_t*)dst;
  if (!tmp || (tmp==(wchar_t*)-1)) { tmp = (wchar_t*)cb_NewStr_(NULL,tmp,cb_StrLenW(sVar) << 1); if (!tmp) return NULL; dst = tmp; }

  if ((nosens & 1)!=0)
  for (;sVar[0];sVar++) {
    if (cb_StrICharW(sChars,sVar[0])) { if ((nosens&2)==0) goto Add0000; }
    else if ((nosens & 2)!=0) goto Add0000;
  }
  else
  for (;sVar[0];sVar++) {
    if (cb_StrCharW(sChars,sVar[0])) { if ((nosens&2)==0) goto Add0000; }
    else if ((nosens & 2)!=0) { Add0000:; tmp[0] = sVar[0]; tmp++; }
  }
  tmp[0] = 0;
  return (wchar_t*)dst;
}
/* END MODULE */


/* MODULE::cb_StrReverse */
char * cb_DEFCALL cb_StrReverse (const char *src, void *dst, cb_Integer flg1)
{
  register cb_Integer i = cb_StrLen(src);
  register char *rstr = (char*)dst;
  register cb_Integer i1;
  cb_Integer b = 0;

    if (rstr==src) { if (i) { b = i; rstr = (char*)-1; goto New0000; } }
    else if (!rstr || (rstr==(char*)-1)) {
New0000:
      rstr = cb_NewStr_(NULL,rstr,i);
    }
    rstr[i] = 0;
    for(;i;src++) {
      i--;
      i1 = src[0];
      if (!flg1 || i1!='\\' || !i) rstr[i] = i1;
      else { src++; rstr[i] = src[0]; i--; rstr[i] = '\\'; }
    }
  if (b) { cb_MemCopy(dst,rstr,b); cb_MemFreeM(rstr); rstr = (char*)dst; }
  return rstr;
}
/* END MODULE */


/* MODULE::cb_StrReverseW */
wchar_t * cb_DEFCALL cb_StrReverseW (const wchar_t *src, void *dst, cb_Integer flg1)
{
  register cb_Integer i=cb_StrLenW(src);
  register wchar_t *rstr = (wchar_t*)dst;
  register cb_Integer i1;
  cb_Integer b = 0;

    if (rstr==src) { if (i) { b = i; rstr = (wchar_t*)-1; goto New0000; } }
    else if (!rstr || (rstr==(wchar_t*)-1)) { New0000:; rstr = (wchar_t*)cb_NewStr_(NULL,rstr,i << 1); }
    rstr[i] = 0;
    for(;i;src++) {
      i--;
      b = src[0];
      if (!flg1 || b!='\\' || !i) rstr[i] = b;
      else { src++; rstr[i] = src[0]; i--; rstr[i] = '\\'; }
    }
  if (b) { cb_MemCopy(dst,rstr,b << 1); cb_MemFreeM(rstr); rstr = (wchar_t*)dst; }
  return rstr;
}
/* END MODULE */


/* MODULE::cb_ReverseAny */
void cb_DEFCALL cb_ReverseAny (const void *src,cb_UInteger iNum,cb_UInteger len)
{
  register cb_UInteger cnt = iNum, i;
  if (cnt<=1) return;
  register cb_UInteger sze = len;
  register char *lpBits;
  void *p1 = cb_MemAllocM(sze);
  if (!p1) return;
  lpBits = (char*)src;
  i=0;
  cnt--;
  do {
    cb_MemCopy(p1,lpBits+(sze*cnt),sze);
    cb_MemCopy(lpBits+(sze*cnt),lpBits+(sze*i),sze);
    cb_MemCopy(lpBits+(sze*i),p1,sze);
    i++;
    cnt--;
  }while(cnt>i);
  cb_MemFreeM(p1);
}
/* END MODULE */


/* MODULE::cb_Extract */
char * cb_DEFCALL cb_Extract (const void *src, const char *sMatch, void *dst, cb_Integer offset, cb_Integer nosens)
{
  register cb_UInteger i;
  register char *sTmp = (char*)dst;
  register cb_Integer ofs;
  if (sMatch[0]!=0) {
    ofs = offset; if (ofs<0) ofs = 0;
    i = cb_InStr(src,sMatch,ofs,nosens);
    if (i==(cb_UInteger)-1) i = cb_StrLen((const char*)src);
    i -= ofs;
    if (i>0) {
      src = (const char*)src + ofs;
      if (sTmp!=src) {
        return cb_NewStr_(src, sTmp, i);
      }
      sTmp[i] = 0;
      return sTmp;
    }
  }
  if (sTmp==(char*)-1) return cb_NewStr_(NULL,(void*)-1,0);
  if (!sTmp) return cb_EMPTYSTR;
  sTmp[0] = 0; return sTmp;
}
/* END MODULE */


/* MODULE::cb_ExtractW */
wchar_t * cb_DEFCALL cb_ExtractW (const wchar_t *src, const wchar_t *sMatch, void *dst, cb_Integer offset, cb_Integer nosens)
{
  register cb_UInteger i;
  register char *sTmp = (char*)dst;
  register cb_Integer ofs;
  if (sMatch[0]!=0) {
    ofs = offset; if (ofs<0) ofs = 0;
    i = cb_InStrW(src,sMatch,ofs,nosens);
    if (i==(cb_UInteger)-1) i = cb_StrLenW(src);
    i -= ofs;
    i <<= 1;
    if (i>0) {
      src = (const wchar_t*)src + ofs;
      if (sTmp!=(char*)src) {
        return (wchar_t*)cb_NewStr_(src, sTmp, i);
      }
      ((wchar_t*)(sTmp+i))[0] = 0;
      return (wchar_t*)sTmp;
    }
  }
  if (sTmp==(char*)-1) return (wchar_t*)cb_NewStr_(NULL,(void*)-1,0);
  if (!sTmp) return (wchar_t*)cb_EMPTYSTR;
  ((wchar_t*)sTmp)[0] = 0; return (wchar_t*)sTmp;
}
/* END MODULE */


/* MODULE::cb_StrToken */
char * cb_DEFCALL cb_StrToken (const void *Source, const char *TokenChar, cb_UInteger n, void *dst, cb_Integer nosens)
{
  register char *RetVar;
  register const char *sCopy;
  register cb_UInteger i;
  cb_UInteger Find, Posn;
  i = cb_CountStr(Source,TokenChar,nosens);
  if (i==0) {
Exit0000:
    RetVar = (char*)dst;
    if (!RetVar) return cb_EMPTYSTR;
    return cb_NewStr_(cb_EMPTYSTR,RetVar,0);
  }
  if (n==1) return cb_Extract(Source,TokenChar,dst,0,nosens);
  if (n>i+1) goto Exit0000;
  sCopy=(const char*)Source;
  Find = 0;
  Posn = 0;
  do {
    if (*sCopy==*TokenChar) Find++;
    if (Find==n) break;
    sCopy++;
    Posn++;
  }while(*sCopy);
  if (n==i+1) {
    i = cb_StrLen((const char*)Source);
    sCopy=(const char*)Source; sCopy+=i;
    while(*sCopy&&((const char*)Source)[i]!=TokenChar[0]) {
      i--;
      sCopy--;
    }
  }
  else i = Posn;
  RetVar = cb_Mid(Source,0,i,dst);
  i = cb_InStrRev(RetVar,TokenChar,0,nosens)+1;
  cb_StrCopy(RetVar, RetVar+i);
  return cb_StrRemove(RetVar,TokenChar,RetVar,nosens);
}
/* END MODULE */


/* MODULE::cb_LTrimX */
char * cb_DEFCALL cb_LTrimX (const void *Str1, void *dst, cb_Integer c, cb_Integer len, cb_Integer sze)
{
  register char *sTmp = (char*)Str1;
  register cb_Integer i;
  register char *dst1 = (char*)dst;

    i = len; if (i<=0) i = cb_StrLen(sTmp);
    for(;i;i--) {
      if (sTmp[0]!=32) if (sTmp[0]<9 || sTmp[0]>13) if (sTmp[0]!=c) break;
      sTmp++;
    }
    if (dst1==(char*)-2) return sTmp;
    if ((cb_UInteger)i>(cb_UInteger)(sze-1)) { i = sze; i--; } return cb_NewStr_(sTmp, dst1, i);
}
/* END MODULE */


/* MODULE::cb_RTrimX */
char * cb_DEFCALL cb_RTrimX (const void *Str1, void *dst, cb_Integer c, cb_Integer len, cb_Integer sze)
{
  register char *sTmp = (char*)Str1;
  register cb_Integer i;
  register char *dst1;

    i = len; if (i<=0) i = cb_StrLen(sTmp); dst1 = sTmp; dst1 += i;
    for(;i;i--) {
      dst1--;
      if (dst1[0]!=32) if (dst1[0]<9 || dst1[0]>13) if (dst1[0]!=c) { dst1++; break; }
    }
    if (dst!=(void*)-2) {
  dst1 = (char*)dst;
  if ((cb_UInteger)i>(cb_UInteger)(sze-1)) { i = sze; i--; } return cb_NewStr_(sTmp, dst1, i);
  }
  return dst1;
}
/* END MODULE */


/* MODULE::cb_TrimX */
char * cb_DEFCALL cb_TrimX (const void *Str1, void *dst, cb_Integer c, cb_Integer len, cb_Integer sze)
{
  register char *s1 = (char*)Str1;
  register cb_Integer i = len; if (i<=0) i = cb_StrLen(s1);
  s1 = cb_LTrimX(s1,(void*)-2,c,i,sze); i += (cb_Integer)Str1; i -= (cb_Integer)s1; return cb_RTrimX(s1,dst,c,i,sze);
}
/* END MODULE */


/* MODULE::cb_LTrim */
char * cb_DEFCALL cb_LTrim (const void *Str1, void *dst)
{
  return cb_LTrimX(Str1,dst);
}
/* END MODULE */


/* MODULE::cb_RTrim */
char * cb_DEFCALL cb_RTrim (const void *Str1, void *dst)
{
  return cb_RTrimX(Str1,dst);
}
/* END MODULE */


/* MODULE::cb_Trim */
char * cb_DEFCALL cb_Trim (const void *Str1, void *dst)
{
  return cb_TrimX(Str1,dst);
}
/* END MODULE */


/* MODULE::cb_LTrimXW */
wchar_t * cb_DEFCALL cb_LTrimXW (const void *Str1, void *dst, cb_Integer c, cb_Integer len, cb_Integer sze)
{
  register wchar_t *sTmp = (wchar_t*)Str1;
  register cb_Integer i;
  register wchar_t *dst1 = (wchar_t*)dst;

    i = len; if (i<=0) i = cb_StrLenW(sTmp);
    for(;i;i--) {
      if (sTmp[0]!=32) if (sTmp[0]<9 || sTmp[0]>13) if (sTmp[0]!=c) break;
      sTmp++;
    }
    if (dst1==(wchar_t*)-2) return sTmp;
    if ((cb_UInteger)i>=(cb_UInteger)(sze-1)) { i = sze; i--; }
 return cb_NewStrW_(sTmp, dst1, i);
}
/* END MODULE */


/* MODULE::cb_RTrimXW */
wchar_t * cb_DEFCALL cb_RTrimXW (const void *Str1, void *dst, cb_Integer c, cb_Integer len, cb_Integer sze)
{
  register wchar_t *sTmp = (wchar_t*)Str1;
  register cb_Integer i;
  register wchar_t *dst1;

    i = len; if (i<=0) i = cb_StrLenW(sTmp); dst1 = sTmp; dst1 += i;
    for(;i;i--) {
      dst1--;
      if (dst1[0]!=32) if (dst1[0]<9 || dst1[0]>13) if (dst1[0]!=c) { dst1++; break; }
    }
    if (dst!=(void*)-2) {
  dst1 = (wchar_t*)dst;
  if ((cb_UInteger)i>=(cb_UInteger)(sze-1)) { i = sze; i--; }
 return cb_NewStrW_(sTmp, dst1, i);
  }
  return dst1;
}
/* END MODULE */


/* MODULE::cb_TrimXW */
wchar_t * cb_DEFCALL cb_TrimXW (const void *Str1, void *dst, cb_Integer c, cb_Integer len, cb_Integer sze)
{
  register wchar_t *s1 = (wchar_t*)Str1;
  register cb_UInteger i = len; if (i<=0) i = cb_StrLenW(s1);
  s1 = cb_LTrimXW(s1,(void*)-2,c,i,sze); i <<= 1; i += (cb_UInteger)Str1; i -= (cb_UInteger)s1; i >>= 1; return cb_RTrimXW(s1,dst,c,i,sze);
}
/* END MODULE */


/* MODULE::cb_LTrimW */
wchar_t * cb_DEFCALL cb_LTrimW (const void *Str1, void *dst)
{
  return cb_LTrimXW(Str1,dst);
}
/* END MODULE */


/* MODULE::cb_RTrimW */
wchar_t * cb_DEFCALL cb_RTrimW (const void *Str1, void *dst)
{
  return cb_RTrimXW(Str1,dst);
}
/* END MODULE */


/* MODULE::cb_TrimW */
wchar_t * cb_DEFCALL cb_TrimW (const void *Str1, void *dst)
{
  return cb_TrimXW(Str1,dst);
}
/* END MODULE */


/* MODULE::cb_TrimText */
char * cb_DEFCALL cb_TrimText (const char* sText,void* dst,cb_Integer* bDirty,const char *sDelimitor)
{
  register cb_Integer i;
  register cb_Integer j;
  register const char *MyPtr1 = sText;
  register char *MyPtr2 = (char*)dst;
  cb_Integer iLen;
  cb_Integer flag1;

  if (MyPtr2==NULL || MyPtr2==(char*)-1) {
    MyPtr2 = cb_NewStr_(NULL,MyPtr2,cb_StrLen(MyPtr1));
    if (MyPtr2==NULL) return NULL;
    dst = MyPtr2;
  }

  if (sDelimitor==NULL) sDelimitor = "\r\n";
  iLen = cb_StrLen(sDelimitor); flag1 = FALSE;

  do {
    i = (cb_Integer)cb_StrStr(MyPtr1,sDelimitor);
    if (i) i -= (cb_Integer)MyPtr1;
    else { i = cb_StrLen(MyPtr1); iLen = -1; }
    if (i>0) {
      j = i;
      do {
        j--;
        if (MyPtr1[j]!=' ') {
          if (MyPtr1[j]!='\t') {
            j++;
            cb_MemMove(MyPtr2,MyPtr1,j);
            MyPtr2 += j;
            if (i==j) {
              goto Cont0000;
            }
            break;
          }
        }
      } while(j>0);
      flag1 = TRUE;
    }
Cont0000:
    if (iLen<=0) break;
    cb_MemCopy(MyPtr2,sDelimitor,iLen);
    MyPtr2 += iLen;
    MyPtr1 += i;
    MyPtr1 += iLen;
  } while(1);

  MyPtr2[0] = 0;
  if (bDirty) {
    bDirty[0] = flag1;
  }
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_CharsRemove */
char * cb_DEFCALL cb_CharsRemove (const void *a, const char *b, void *dst, cb_Integer nosens)
{
  register char *d;
  register const char *a1;
  register const char *b1;

  d = (char*)dst;
  a1=(const char*)a;
  if (!d || (d==(char*)-1)) { d = cb_NewStr_(NULL,d,cb_StrLen(a1)); if (!d) return NULL; dst = d; }
  if (b) {
    if (!nosens) {
      for(;a1[0];a1++) {
        for(b1=b;b1[0];b1++) {
          if (b1[0]==a1[0]) goto Again0000;
        }
        d[0] = a1[0]; d++;
Again0000:;
      }
    }
    else {
      for(;a1[0];a1++) {
        for(b1=b;b1[0];b1++) {
          if (cb_ToLower(b1[0])==cb_ToLower(a1[0])) goto Again000;
        }
        d[0] = a1[0]; d++;
Again000:;
      }
    }
    d[0] = 0;
  }
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_CharsIRemove */
char * cb_DEFCALL cb_CharsIRemove (const void *a, const char *b, void *dst)
{
  return cb_CharsRemove(a,b,dst,TRUE);
}
/* END MODULE */


/* MODULE::cb_StrRemove */
char * cb_DEFCALL cb_StrRemove (const void *a, const char *b, void *dst, cb_Integer nosens, cb_Integer iNum)
{
  register cb_UInteger tmplen, p;
  register char *d;

  d = (char*)dst;
  if (!d) { d = cb_TmpDynStr(cb_StrLen((const char*)a)); goto Chk0000; }
  if (d==(char*)-1) {
    d = (char*)cb_MemAllocM(cb_StrLen((const char*)a)+4);
Chk0000:
    if (!d) return NULL; dst = d;
  }
  if (b) {
    tmplen = cb_StrLen(b);
    if (tmplen)
    do {
      p=cb_InStr(a,b,0,nosens);
      if (p==(cb_UInteger)-1) break;
      cb_MemCopy(d,a,p);
      d+=p;
      p+=tmplen;
      a = (const char*)a+p;
      iNum--;
    }while(iNum);
  }
  cb_StrCopy(d,a);
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_StrRemoveW */
wchar_t * cb_DEFCALL cb_StrRemoveW (const wchar_t *a, const wchar_t *b, void *dst, cb_Integer nosens, cb_Integer iNum)
{
  register cb_UInteger tmplen, p;
  register wchar_t *d = (wchar_t*)dst;

  if (!d) { d = (wchar_t*)cb_TmpDynStr(cb_StrLenW(a) << 1); goto Chk0000; }
  if (d==(wchar_t*)-1) {
    d = (wchar_t*)cb_MemAllocM((cb_StrLenW(a) << 1) + 4);
Chk0000:
    if (!d) return NULL; dst = d;
  }
  if (b && b[0]) {
    tmplen = cb_StrLenW(b);
    do {
      p=cb_InStrW(a,b,0,nosens);
      if (p==(cb_UInteger)-1) break;
      cb_MemCopy(d,a,p<<1);
      d+=p;
      p+=tmplen;
      a+=p;
      iNum--;
    }while(iNum);
  }
  cb_StrCopyW(d,a);
  return (wchar_t*)dst;
}
/* END MODULE */


/* MODULE::cb_LStrRemove */
char * cb_DEFCALL cb_LStrRemove (const void *a, const char *b, void *dst, cb_Integer nosens, cb_Integer iNum)
{
  register cb_UInteger tmplen;
  register char *d;
  register cb_UInteger i = cb_StrLen((const char*)a);
  d = (char*)dst;
  if (!d) { d = cb_TmpDynStr(i); goto Chk0000; }
  if (d==(char*)-1) {
    d = (char*)cb_MemAllocM(i+4);
Chk0000:
    if (!d) return NULL;
  }
  if (b) {
    tmplen = cb_StrLen(b);
    if (tmplen) {
      do {
        if (tmplen>i) break;
        i -= tmplen;
        if (nosens) { if (cb_MemIComp(a,b,tmplen)==0) { a = (const char*)a+tmplen; goto Ok0000; } }
        else { if (cb_MemComp(a,b,tmplen)==0) { a = (const char*)a+tmplen; goto Ok0000; } }
        i += tmplen; break;
Ok0000:
        iNum--;
      }while(iNum);
    }
  }
  if ((cb_Integer)d==-2) return (char*)a;
  if (i>0) cb_MemCopy(d,a,i);
  d[i] = 0;
  return d;
}
/* END MODULE */


/* MODULE::cb_RStrRemove */
char * cb_DEFCALL cb_RStrRemove (const void *a, const char *b, void *dst, cb_Integer nosens, cb_Integer iNum)
{
  register cb_UInteger tmplen;
  register char *d;
  register cb_UInteger i = cb_StrLen((const char*)a);
  d = (char*)dst;
  if (!d) { d = cb_TmpDynStr(i); goto Chk0000; }
  if (d==(char*)-1) {
    d = (char*)cb_MemAllocM(i+4);
Chk0000:
    if (!d) return NULL; dst = d;
  }
  if (b) {
    tmplen = cb_StrLen(b);
    if (tmplen) {
      do {
        if (tmplen>i) break;
        i -= tmplen;
        if (nosens) { if (cb_MemIComp((const char*)a+i,b,tmplen)==0) goto Ok0000; }
        else { if (cb_MemComp((const char*)a+i,b,tmplen)==0) goto Ok0000; }
        i += tmplen; break;
Ok0000:
        iNum--;
      }while(iNum);
    }
  }
  if (i>0) if (d!=(char*)a) cb_MemCopy(d,a,i);
  d[i] = 0;
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_LStrRemoveW */
wchar_t * cb_DEFCALL cb_LStrRemoveW (const void *a, const wchar_t *b, void *dst, cb_Integer nosens, cb_Integer iNum)
{
  register cb_UInteger tmplen;
  register wchar_t *d;
  register cb_UInteger i = cb_StrLenW((const wchar_t*)a)<<1;
  d = (wchar_t*)dst;
  if (!d) { d = (wchar_t*)cb_TmpDynStr(i); goto Chk0000; }
  if (d==(wchar_t*)-1) {
    d = (wchar_t*)cb_MemAllocM(i+4);
Chk0000:
    if (!d) return NULL;
  }
  if (b) {
    tmplen = cb_StrLenW(b)<<1;
    if (tmplen) {
      do {
        if (tmplen>i) break;
        i -= tmplen;
        if (nosens) { if (cb_MemIComp(a,b,tmplen)==0) { a = (const char*)a+tmplen; goto Ok0000; } }
        else { if (cb_MemComp(a,b,tmplen)==0) { a = (const char*)a+tmplen; goto Ok0000; } }
        i += tmplen; break;
Ok0000:
        iNum--;
      }while(iNum);
    }
  }
  if ((cb_Integer)d==-2) return (wchar_t*)a;
  if (i>0) cb_MemCopy(d,a,i);
  *(short*)((cb_Integer)d+i) = 0;
  return d;
}
/* END MODULE */


/* MODULE::cb_RStrRemoveW */
wchar_t * cb_DEFCALL cb_RStrRemoveW (const void *a, const wchar_t *b, void *dst, cb_Integer nosens, cb_Integer iNum)
{
  register cb_UInteger tmplen;
  register wchar_t *d;
  register cb_UInteger i = cb_StrLenW((const wchar_t*)a)<<1;
  d = (wchar_t*)dst;
  if (!d) { d = (wchar_t*)cb_TmpDynStr(i); goto Chk0000; }
  if (d==(wchar_t*)-1) {
    d = (wchar_t*)cb_MemAllocM(i+4);
Chk0000:
    if (!d) return NULL;
  }
  if (b) {
    tmplen = cb_StrLenW(b)<<1;
    if (tmplen) {
      do {
        if (tmplen>i) break;
        i -= tmplen;
        if (nosens) { if (cb_MemIComp((const char*)a+i,b,tmplen)==0) goto Ok0000; }
        else { if (cb_MemComp((const char*)a+i,b,tmplen)==0) goto Ok0000; }
        i += tmplen; break;
Ok0000:
        iNum--;
      }while(iNum);
    }
  }
  if (i>0) if (d!=(wchar_t*)a) cb_MemCopy(d,a,i);
  *(short*)((cb_Integer)d+i) = 0;
  return d;
}
/* END MODULE */


/* MODULE::cb_StrIRemove */
char * cb_DEFCALL cb_StrIRemove (const void *a, const char *b, void *dst, cb_Integer flag1, cb_Integer iNum)
{
  return cb_StrRemove(a,b,dst,1|flag1,iNum);
}
/* END MODULE */


/* MODULE::cb_StrIRemoveW */
wchar_t * cb_DEFCALL cb_StrIRemoveW (const wchar_t *a, const wchar_t *b, void *dst, cb_Integer flag1, cb_Integer iNum)
{
  return cb_StrRemoveW(a,b,dst,1|flag1,iNum);
}
/* END MODULE */


/* MODULE::cb_LStrIRemove */
char * cb_DEFCALL cb_LStrIRemove (const void *a, const char *b, void *dst, cb_Integer iNum)
{
  return cb_LStrRemove(a,b,dst,TRUE,iNum);
}
/* END MODULE */


/* MODULE::cb_RStrIRemove */
char * cb_DEFCALL cb_RStrIRemove (const void *a, const char *b, void *dst, cb_Integer iNum)
{
  return cb_RStrRemove(a,b,dst,TRUE,iNum);
}
/* END MODULE */


/* MODULE::cb_LStrIRemoveW */
wchar_t * cb_DEFCALL cb_LStrIRemoveW (const void *a, const wchar_t *b, void *dst, cb_Integer iNum)
{
  return cb_LStrRemoveW(a,b,dst,TRUE,iNum);
}
/* END MODULE */


/* MODULE::cb_RStrIRemoveW */
wchar_t * cb_DEFCALL cb_RStrIRemoveW (const void *a, const wchar_t *b, void *dst, cb_Integer iNum)
{
  return cb_RStrRemoveW(a,b,dst,TRUE,iNum);
}
/* END MODULE */


/* MODULE::cb_CharReplace */
char * cb_DEFCALL cb_CharReplace (const void *src, cb_Integer a, cb_Integer b, void *dst, cb_Integer nosens, cb_Integer iNum)
{
  register const char *sTmp = (const char*)src;
  register char *d = (char*)dst;
  register cb_Integer a1;

  if (!d || (d==(char*)-1)) { d = cb_NewStr_(NULL,d,cb_StrLen(sTmp)); if (!d) return NULL; dst = d; }
  if (!nosens) {
    a1 = a;
    for(;sTmp[0];sTmp++) {
      if (a1!=sTmp[0]) d[0] = sTmp[0];
      else { d[0] = b; iNum--; if (!iNum) { d++; sTmp++; cb_StrMove(d,sTmp); goto Exit0000; } }
      d++;
    }
  }
  else {
    a1 = cb_ToLower(a);
    for(;sTmp[0];sTmp++) {
      if (a1!=cb_ToLower(sTmp[0])) d[0] = sTmp[0];
      else { d[0] = b; iNum--; if (!iNum) { d++; sTmp++; cb_StrMove(d,sTmp); goto Exit0000; } }
      d++;
    }
  }
  d[0] = 0;
Exit0000:
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_CharIReplace */
char * cb_DEFCALL cb_CharIReplace (const void *src, cb_Integer a, cb_Integer b, void *dst, cb_Integer iNum)
{
  return cb_CharReplace(src,a,b,dst,TRUE,iNum);
}
/* END MODULE */


/* MODULE::cb_StrReplace */
char * cb_DEFCALL cb_StrReplace (const void *src, const char *sMatch, const char *sRep, void *dst, cb_Integer nosens, cb_Integer iNum)
{
  register cb_UInteger i;
  register char *d = (char*)dst;
  register const char *s = (const char*)src;
  cb_UInteger tmplen, matchlen, replen;
  cb_UInteger sze = cb_StrLen(s);
  cb_Integer n;

  if (!sMatch || !*sMatch) {
    if (s!=d) {
      if (!d || (d==(char*)-1)) return cb_NewStr_(s,d,sze);
      cb_MemCopy(d, s, sze+1);
    }
    return d;
  }
  replen = cb_StrLen(sRep);
  matchlen = cb_StrLen(sMatch);
  cb_UInteger delta1;
  char *buf2 = NULL;
  if (!d || (d==(char*)-1) || (nosens & (8|16))!=0) {
  delta1 = replen - matchlen;
  tmplen = sze;
  for (n=iNum; (i=cb_InStr(s,sMatch,0,nosens))!=-1; s+=i+matchlen) {
    tmplen += delta1;
    n--; if (!n) break;
  }
  if (!d) {
    d = cb_TmpDynStr(tmplen);
    goto dst0000;
  }
  if (d==(char*)-1) {
    d = (char*)cb_MemAllocM(tmplen + 4);
    goto dst0000;
  }
  if ((nosens & 8)!=0) {
    d = (char*)cb_MemAllocM(tmplen + 4); buf2 = d;
  }
  else {
    d = (char*)cb_ReMemAllocM(d, tmplen+4);
dst0000:
    dst = d;
  }
  if (!d) return NULL;
  s = (const char*)src;
  }
  n = iNum;
  do {
    i = cb_InStr(s,sMatch,0,nosens);
    if (s!=d) {
      if (i==(cb_UInteger)-1) { cb_MemCopy(d,s,sze+1); break; }
      cb_MemCopy(d,s,i);
      d += i;
      i += matchlen;
      sze -= i;
    }
    else {
      if (i==(cb_UInteger)-1) break;
      sze -= i+matchlen;
      d += i;
      cb_MemMove(d+replen,d+matchlen,sze+1);
      i += replen;
    }
    cb_MemCopy(d,sRep,replen);
    d += replen;
    s += i;
    n--;
  }while(n);
  if (buf2) { cb_MemCopy(dst, buf2, tmplen+1); cb_MemFreeM(buf2); }
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_LStrReplace */
char * cb_DEFCALL cb_LStrReplace (const void *a, const char *b, const char *sRep, void *dst, cb_Integer nosens)
{
  register cb_UInteger tmplen;
  register char *d = (char*)dst;
  register cb_UInteger i = cb_StrLen((const char*)a);
  cb_Integer j = cb_StrLen(sRep);

  if (!d) { d = cb_TmpDynStr(i+j); goto Chk0000; }
  if (d==(char*)-1) {
    d = (char*)cb_MemAllocM(i+j+4);
Chk0000:
    if (!d) return NULL; dst = d;
  }
  if (b) {
    tmplen = cb_StrLen(b);
    if (tmplen) {
      if (tmplen<=i) {
        i-=tmplen;
        if (nosens) {
          if (cb_MemIComp(a,b,tmplen)==0) goto Ok0000;
        }
        else {
          if (cb_MemComp(a,b,tmplen)==0) {
Ok0000:
            a=(const char*)a+tmplen;
            cb_MemMove(d+j,a,i);
            cb_MemCopy(d,sRep,j);
            i+=j;
            goto Exit0000;
          }
        }
        i+=tmplen;
      }
    }
  }
  cb_MemCopy(d,a,i);
Exit0000:
  d[i] = 0;
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_RStrReplace */
char * cb_DEFCALL cb_RStrReplace (const void *a, const char *b, const char *sRep, void *dst, cb_Integer nosens)
{
  register cb_UInteger tmplen = 0;
  register char *d = (char*)dst;
  register cb_UInteger i = cb_StrLen((const char*)a);
  cb_Integer j = cb_StrLen(sRep);

  if (!d) { d = cb_TmpDynStr(i+j); goto Chk0000; }
  if (d==(char*)-1) {
    d = (char*)cb_MemAllocM(i+j+4);
Chk0000:
    if (!d) return NULL; dst = d;
  }
  if (b) {
    tmplen = cb_StrLen(b);
    if (tmplen) {
      if (tmplen<=i) {
        i-=tmplen;
        if (nosens) { if (cb_MemIComp((const char*)a+i,b,tmplen)==0) goto Ok0000; }
        else { if (cb_MemComp((const char*)a+i,b,tmplen)==0) goto Ok0000; }
        i+=tmplen;
      }
      tmplen=0;
    }
  }
Ok0000:
  if (d!=(char*)a) cb_MemCopy(d,a,i);
  d+=i;
  if (tmplen) {
    tmplen = j;
    if (tmplen) {
      cb_MemCopy(d,sRep,tmplen);
      d+=tmplen;
    }
  }
  d[0] = 0;
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_StrReplaceW */
wchar_t * cb_DEFCALL cb_StrReplaceW (const wchar_t *src, const wchar_t *sMatch, const wchar_t *sRep, void *dst, cb_Integer nosens, cb_Integer iNum)
{
  register cb_UInteger i;
  register wchar_t *d = (wchar_t*)dst;
  register const wchar_t *s = src;
  cb_UInteger tmplen, matchlen, replen;
  cb_UInteger sze = cb_StrLenW(s);
  cb_Integer n;

  if (!sMatch || !*sMatch) {
    if (s!=d) {
      if (!d || (d==(wchar_t*)-1)) return (wchar_t*)cb_NewStr_(s,d,sze<<1);
      cb_MemCopy(d, s, (sze<<1)+2);
    }
    return d;
  }
  replen = cb_StrLenW(sRep);
  matchlen = cb_StrLenW(sMatch);
  cb_UInteger delta1;
  wchar_t *buf2 = NULL;
  if (!d || (d==(wchar_t*)-1) || (nosens & (8|16))!=0) {
  delta1 = replen - matchlen;
  tmplen = sze;
  for (n=iNum;(i=cb_InStrW(s,sMatch,0,nosens))!=-1; s+=i+matchlen) {
    tmplen += delta1;
    n--; if (!n) break;
  }
  if (!d) {
    d = (wchar_t*)cb_TmpDynStr(tmplen << 1);
    goto dst0000;
  }
  if (d==(wchar_t*)-1) {
    d = (wchar_t*)cb_MemAllocM((tmplen << 1) + 4);
    goto dst0000;
  }
  if ((nosens & 8)!=0) {
    d = (wchar_t*)cb_MemAllocM((tmplen << 1) + 4); buf2 = d;
  }
  else {
    d = (wchar_t*)cb_ReMemAllocM(d, (tmplen << 1) + 4);
dst0000:
    dst = d;
  }
  if (!d) return NULL;
  s = src;
  }
  n = iNum;
  do {
    i = cb_InStrW(s,sMatch,0,nosens);
    if (s!=d) {
      if (i==(cb_UInteger)-1) { cb_MemCopy(d,s,(sze+1)<<1); break; }
      cb_MemCopy(d,s,i<<1);
      d += i;
      i += matchlen;
      sze -= i;
    }
    else {
      if (i==(cb_UInteger)-1) break;
      sze -= i+matchlen;
      d += i;
      cb_MemMove(d+replen,d+matchlen,(sze+1)<<1);
      i += replen;
    }
    cb_MemCopy(d,sRep,replen<<1);
    d += replen;
    s += i;
    n--;
  }while(n);
  if (buf2) { cb_MemCopy(dst, buf2, (tmplen+1)<<1); cb_MemFreeM(buf2); }
  return (wchar_t*)dst;
}
/* END MODULE */


/* MODULE::cb_StrIReplace */
char * cb_DEFCALL cb_StrIReplace (const void *src, const char *sMatch, const char *sRep, void *dst, cb_Integer flag1, cb_Integer iNum)
{
  return cb_StrReplace(src,sMatch,sRep,dst,1|flag1,iNum);
}
/* END MODULE */


/* MODULE::cb_LStrIReplace */
char * cb_DEFCALL cb_LStrIReplace (const void *src, const char *sMatch, const char *sRep, void *dst)
{
  return cb_LStrReplace(src,sMatch,sRep,dst,TRUE);
}
/* END MODULE */


/* MODULE::cb_RStrIReplace */
char * cb_DEFCALL cb_RStrIReplace (const void *src, const char *sMatch, const char *sRep, void *dst)
{
  return cb_RStrReplace(src,sMatch,sRep,dst,TRUE);
}
/* END MODULE */


/* MODULE::cb_StrIReplaceW */
wchar_t * cb_DEFCALL cb_StrIReplaceW (const wchar_t *src, const wchar_t *sMatch, const wchar_t *sRep, void *dst, cb_Integer flag1, cb_Integer iNum)
{
  return cb_StrReplaceW(src,sMatch,sRep,dst,1|flag1,iNum);
}
/* END MODULE */


/* MODULE::cb_CharEnclose */
char * cb_DEFCALL cb_CharEnclose (const char *src, cb_UInteger a, cb_UInteger b, void *dst)
{
  register cb_Integer i = cb_StrLen(src);
  register char *RetVar = (char*)dst;
  register cb_UInteger b1 = b;

  if (b1==0) b1 = a;
  if (!RetVar || (RetVar==(char*)-1)) RetVar = cb_NewStr_(NULL,RetVar,i+2);
  cb_MemMove(RetVar+1,src,i);
  RetVar[0] = ((char*)&a)[0];
  b1 &= 0x00ff;
  ((short*)(RetVar+i+1))[0] = (short)b1;
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_CharEncloseW */
wchar_t * cb_DEFCALL cb_CharEncloseW (const wchar_t *src, cb_UInteger a, cb_UInteger b, void *dst)
{
  register cb_Integer i = cb_StrLenW(src) << 1;
  register char *RetVar = (char*)dst;
  register cb_UInteger b1 = b;

  if (b1==0) b1 = a;
  if (!RetVar || (RetVar==(char*)-1)) RetVar = cb_NewStr_(NULL,RetVar,i+(2<<1));
  cb_MemMove(RetVar+2,src,i);
  ((wchar_t*)RetVar)[0] = ((wchar_t*)&a)[0];
  b1 &= 0x0000ffff;
  ((signed int*)(RetVar+i+2))[0] = b1;
  return (wchar_t*)RetVar;
}
/* END MODULE */


/* MODULE::cb_StrEnclose */
char * cb_DEFCALL cb_StrEnclose (const char *src, const char *a, const char *b, void *dst)
{
  register char *RetVar = (char*)dst;
  register cb_Integer i = cb_StrLen(src), i1, i2;

  if (b==NULL) b = a;
  i1 = cb_StrLen(a); i2 = cb_StrLen(b);
  if (!RetVar || (RetVar==(char*)-1)) RetVar = cb_NewStr_(NULL,RetVar,i+i1+i2);
  cb_MemMove(RetVar+i1,src,i);
  cb_MemMove(RetVar,a,i1);
  i += i1;
  cb_MemMove(RetVar+i,b,i2+1);
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_StrEncloseW */
wchar_t * cb_DEFCALL cb_StrEncloseW (const wchar_t *src, const wchar_t *a, const wchar_t *b, void *dst)
{
  register char *RetVar = (char*)dst;
  register cb_Integer i = cb_StrLenW(src) << 1, i1, i2;

  if (b==NULL) b = a;
  i1 = cb_StrLenW(a) << 1; i2 = cb_StrLenW(b) << 1;
  if (!RetVar || (RetVar==(char*)-1)) RetVar = cb_NewStr_(NULL,RetVar,i+i1+i2);
  cb_MemMove(RetVar+i1,src,i);
  cb_MemMove(RetVar,a,i1);
  i += i1;
  cb_MemMove(RetVar+i,b,i2+2);
  return (wchar_t*)RetVar;
}
/* END MODULE */


/* MODULE::cb_CharDisclose */
char * cb_DEFCALL cb_CharDisclose (const char *src, cb_UInteger a, cb_UInteger b, void *dst)
{
  register cb_Integer i;
  register const char *s = src;
  register cb_UInteger b1 = b;

  if (b1==0) b1 = a;
  i = cb_StrLen(s);
  if (s[0]==a) { s++; i--; } else if (b1==a) goto Exit0000;
  if (i>0) { i--; if (s[i]!=b1) i++; }
Exit0000:
  return cb_NewStr_(s,dst,i);
}
/* END MODULE */


/* MODULE::cb_CharDiscloseW */
wchar_t * cb_DEFCALL cb_CharDiscloseW (const wchar_t *src, cb_UInteger a, cb_UInteger b, void *dst)
{
  register cb_Integer i;
  register const wchar_t *s = src;
  register cb_UInteger b1 = b;

  if (b1==0) b1 = a;
  i = cb_StrLenW(s);
  if (s[0]==a) { s++; i--; } else if (b1==a) goto Exit0000;
  if (i>0) { i--; if (s[i]!=b1) i++; }
Exit0000:
  return cb_NewStrW_(s,dst,i);
}
/* END MODULE */


/* MODULE::cb_StrDisclose */
char * cb_DEFCALL cb_StrDisclose (const char *src, const char *a, const char *b, void *dst)
{
  register const char *s = src;
  register cb_Integer i, i1, i2;

  if (b==NULL) b = a;
  i1 = cb_StrLen(a);
  i = cb_StrLen(s);
  if (0==cb_MemComp(s,a,i1)) { s+=i1; i-=i1; } else if (b==a) goto Exit0000;
  i2 = cb_StrLen(b);
  if (i>=i2) if (0==cb_MemComp(s-i2,b,i2)) i-=i2;
Exit0000:
  return cb_NewStr_(s,dst,i);
}
/* END MODULE */


/* MODULE::cb_StrDiscloseW */
wchar_t * cb_DEFCALL cb_StrDiscloseW (const wchar_t *src, const wchar_t *a, const wchar_t *b, void *dst)
{
  register const wchar_t *s = src;
  register cb_Integer i, i1, i2;

  if (b==NULL) b = a;
  i1 = cb_StrLenW(a);
  i = cb_StrLenW(s);
  if (0==cb_MemComp(s,a,i1<<1)) { s+=i1; i-=i1; } else if (b==a) goto Exit0000;
  i2 = cb_StrLenW(b);
  if (i>=i2) if (0==cb_MemComp(s-i2,b,i2<<1)) i-=i2;
Exit0000:
  return cb_NewStrW_(s,dst,i);
}
/* END MODULE */


/* MODULE::cb_Format */
char * cb_DEFCALL cb_Format (float n, const char *sFrmt, void *dst)
{
  register char *strtmp1 = (char*)dst, *dst1 = cb_PrintBoxBuffer+0x100;
  register const char *sFrmt1 = sFrmt;
  cb_Integer i1, i2;
  char *strtmp2, *dst2;

  if (!strtmp1 || strtmp1==(char*)-1) strtmp1 = cb_PrintBoxBuffer;
  cb_CStrDbl(n,strtmp1);
  if (!sFrmt1) sFrmt1 = cb_EMPTYSTR;
  for (i1=0;sFrmt1[0];i1++,sFrmt1++) if (sFrmt1[0]=='.') goto Found000;
  i1 |= 0x10000;
Found000:
  dst1[0] = 0;
  for (i2=0;strtmp1[0];i2++,strtmp1++)
    if (strtmp1[0]=='.') {
      strtmp2 = strtmp1;
      dst2 = dst1;
      sFrmt = sFrmt1;
      if (i1<0x10000) {
      goto Do0011;
Do0000:
      do {
        if (sFrmt1[0]!='#')
          dst1[0] = sFrmt1[0];
        else if (strtmp1[0]==0)
          dst1[0] = '0';
        else {
Do0011:
          dst1[0] = strtmp1[0]; strtmp1++;
        }
        dst1++;
        sFrmt1++;
      } while (sFrmt1[0]);
      }
      while (strtmp1[0]) {
        dst1[0] = strtmp1[0];
        strtmp1++;
        dst1++;
      }
      dst1[0] = 0;
      strtmp1 = strtmp2;
      dst1 = dst2;
      sFrmt1 = sFrmt;
      goto Found0000;
    }
  if (i1<0x10000) {
    strtmp2 = strtmp1;
    dst2 = dst1;
    sFrmt = sFrmt1;
    goto Do0000;
  }
Found0000:
  i1 &= 0xFFFF;
  while(i1) {
    i1--;
    sFrmt1--;
    dst1--;
    if (!i2) {
      if (sFrmt1[0]!='#') goto Put0000;
      dst1[0] = '0';
    }
    else if (sFrmt1[0]=='#') {
      strtmp1--; i2--; dst1[0] = strtmp1[0];
    }
    else {
Put0000:
      dst1[0] = sFrmt1[0];
    }
  }
  while(i2) {
    dst1--;
    strtmp1--; i2--;
    dst1[0] = strtmp1[0];
  }
  if (!dst || dst==(void*)-1) strtmp1 = cb_NewStr(dst1, dst);
  else cb_StrCopy(strtmp1,dst1);
  return strtmp1;
}
/* END MODULE */


/* MODULE::cb_FormatFileTime */
char* cb_DEFCALL cb_FormatFileTime (FILETIME* ft,cb_Integer flag1,LPVOID dst)
{
  SYSTEMTIME st1, st2;
  register char *d = (char*)dst;

  if (FileTimeToSystemTime(ft,&st2)) {
  if (SystemTimeToTzSpecificLocalTime(NULL,&st2,&st1)) {
    if (d==NULL || d==(LPVOID)-1) {
      d = cb_NewStr_(NULL,d,23);
    }
    cb_CStr(st1.wDay,10,d,2);
    cb_StrCat(d,"/");
    cb_CStr(st1.wMonth,10,d+3,2);
    cb_StrCat(d,"/");
    cb_CStr(st1.wYear,10,d+3+3,4);
    cb_StrCat(d," ");
    cb_CStr(st1.wHour,10,d+3+3+5,2);
    cb_StrCat(d,":");
    cb_CStr(st1.wMinute,10,d+3+3+5+3,2);
    if ((flag1 & (1 | 2))!=0) {
      cb_StrCat(d,":");
      cb_CStr(st1.wSecond,10,d+3+3+5+3+3,2);
      if ((flag1 & 2)!=0) {
        cb_StrCat(d,".");
        cb_CStr(st1.wMilliseconds,10,d+3+3+5+3+3+3,3);
      }
    }
    goto Exit0000;
  }
  }
  if (d==NULL)
    d = cb_EMPTYSTR;
  else {
    if (d==(LPVOID)-1) {
      d = (char*)cb_MemAllocM(sizeof(cb_Integer));
    }
    d[0] = 0;
  }
Exit0000:
  return d;
}
/* END MODULE */


/* MODULE::cb_CStrL */
char * cb_DEFCALL cb_CStrL (long long a, cb_Integer b, void *dst, cb_Integer c, cb_Integer c1)
{
  char sBuf[80];
  register cb_Integer i;
  register char *strtmp;
  register unsigned long long t1;
  register unsigned long long t2;
  register unsigned long long b1;
  cb_Integer d = 0;
  if (b!=10) { b &= cb_MAX_INTEGER; goto Start0000; }
  if (a>=0) { Start0000:; t1 = (unsigned long long)a; }
  else { d++; t1 = -a; }
  b1 = b; i = sizeof(sBuf)-1;
  strtmp = sBuf + sizeof(sBuf)-1;
  do {
    i--;
    strtmp--;
    t2 = t1 % b1;
    t1 = t1 / b1;
    if (t2 >= 36) t2 += 'a'-36;
    else if (t2 >= 10) t2 += 'A'-10;
    else t2 += '0';
    strtmp[0] = (char)t2;
  } while(t1);
  c -=sizeof(sBuf)-1 - i;
  if (c<0) c = d;
  sBuf[sizeof(sBuf)-1] = 0;
  if (!dst) { dst = (void*)cb_TmpDynStr(sizeof(sBuf)-1 + c - i); if (!dst) return cb_EMPTYSTR; }
  else if (dst==(void*)-1) { dst = cb_MemAllocM(sizeof(cb_Integer) + sizeof(sBuf)-1 + c - i); if (!dst) return NULL; }
  cb_MemCopy(((char*)dst)+c, strtmp, sizeof(sBuf)-i);
  strtmp = (char*)dst;
  if (d) { strtmp[0] = '-'; c--; }
  if (c>0) if (c<i) cb_MemSet(strtmp+d, c1, c);
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_CStr */
char * cb_DEFCALL cb_CStr (cb_Integer a, cb_Integer b, void *dst, cb_Integer c, cb_Integer c1)
{  if (b==10) return cb_CStrL(a,b,dst,c,c1);  return cb_CStrL((cb_UInteger)a,b,dst,c,c1);}
/* END MODULE */


/* MODULE::cb_CStrDbl */
char * cb_DEFCALL cb_CStrDbl (double d, void *dst, cb_Integer num1)
{
  register char *strtmp = (char*)dst;
  if (!strtmp || strtmp==(char*)-1) { strtmp = cb_NewStr_(NULL,strtmp,80); if (!strtmp) goto Exit0000; }
  register char *str1;
  register cb_Integer i; i = num1;
  cb_dtoa(d,strtmp,i);
  if (i>0) {
    str1 = (char*)cb_StrChar(strtmp,'.');
    if (str1) {
      str1++; num1 = cb_StrLen(str1); if (num1>i) num1 = i;
      i = (cb_Integer)str1; i--; str1 += num1; do { str1--; } while(*str1=='0');
      if ((cb_Integer)str1!=i) str1++;
      else { str1++; if (*str1) str1++; else str1--; }
      *str1 = 0;
    }
  }
Exit0000:
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_CStrLDbl */
char * cb_DEFCALL cb_CStrLDbl (long double d, void *dst, cb_Integer num1)
{
  register char *strtmp = (char*)dst;
  if (!strtmp || strtmp==(char*)-1) { strtmp = cb_NewStr_(NULL,strtmp,80); if (!strtmp) goto Exit0000; }
  register char *str1;
  register cb_Integer i; i = num1;
  cb_ldtoa(d,strtmp,i);
  if (i>0) {
    str1 = (char*)cb_StrChar(strtmp,'.');
    if (str1) {
      str1++; num1 = cb_StrLen(str1); if (num1>i) num1 = i;
      i = (cb_Integer)str1; i--; str1 += num1; do { str1--; } while(*str1=='0');
      if ((cb_Integer)str1!=i) str1++;
      else { str1++; if (*str1) str1++; else str1--; }
      *str1 = 0;
    }
  }
Exit0000:
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_StrSplit */
char * cb_DEFCALL cb_StrSplit (const char *src, const char *sDelim, void *dst, void *iNum, cb_UInteger iMax, cb_Integer sze, cb_Integer iFlags)
{
  register cb_UInteger Ndx;
  register cb_UInteger i;
  register cb_UInteger iPos = 0;
  register cb_UInteger iCnt = 0;
  if (!sDelim) sDelim = " ";
  register cb_UInteger lenD = cb_StrLen(sDelim);
  register cb_UInteger lenSrc = cb_StrLen(src);
  cb_UInteger lenDelim = lenD;
  cb_UInteger iCnt_ = 0;
  char *MyPtr1, *Buf = (char*)dst;

  if (sze<=0) sze = cb_STRING_SIZE;

  if ((iFlags & 8)!=0) lenD = 1;
  Ndx=0;
Loop0000:
  while (Ndx<lenSrc) {
    if ((iFlags & 8)!=0) {
      for (i=0;i<lenDelim;i++) if (src[Ndx]==sDelim[i]) goto Found0000;
NotFound0000:
      i = src[Ndx];
      if (i=='"' || i=='\'' || i=='`')
      do {
        Ndx++; if (Ndx>=lenSrc) goto Exit0000;
        if (src[Ndx]==i) { Ndx++; if (src[Ndx]!=i) break; }
        else if ((iFlags & 32)!=0) if (src[Ndx]=='\\') Ndx++;
      } while(1);
      goto Loop0000;
    }
    for (i=0;i<lenD;i++) if (i+Ndx>=lenSrc || src[i+Ndx]!=sDelim[i]) goto NotFound0000;
Found0000:;
    if ((iFlags & 128)!=0) if (iCnt>=iCnt_) { iCnt_+=10; dst = cb_ReMemAllocM(dst,iCnt_*sze); if (!Buf) Buf = (char*)dst; }
    cb_MemMove(Buf,src+iPos,Ndx-iPos); Buf[Ndx-iPos] = 0;
    if ((iFlags & (1 | 64))==1) {
      MyPtr1 = cb_LTrimX(Buf, (void*)-2);
      i = MyPtr1[0];
      if (i=='"' || i=='\'' || i=='`') {
        MyPtr1++;
        i = cb_StrLen(MyPtr1);
        if (i) { i--; if (MyPtr1[i]==MyPtr1[-1]) MyPtr1[i] = 0; }
        if ((iFlags & 4)!=0) goto Trim0000;
        cb_StrCopy(Buf,MyPtr1);
        goto NoTrim0000;
      }
    }
    if ((iFlags & (4 | 64))==4) {
      MyPtr1 = Buf;
Trim0000:
      cb_TrimX(MyPtr1, Buf);
    }
NoTrim0000:
    if (Buf[0]!=0)
      { iCnt++; Buf+=sze; }
    else if ((iFlags & (2|8|16|64))==(2|8|16)) {
      if (iCnt) {
        iCnt--;
        Buf-=sze;
        if (((unsigned char*)Buf)[0]<=' ') if (((unsigned char*)src)[Ndx]<=' ') { cb_StrCat(Buf, " "); goto Cont0000; }
        iCnt++;
        Buf+=sze;
      }
    }
    if ((iFlags & 2)!=0) {
      if ((iFlags & 128)!=0) if (iCnt>=iCnt_) { iCnt_+=10; dst = cb_ReMemAllocM(dst,iCnt_*sze); if (!Buf) Buf = (char*)dst; }
      cb_MemMove(Buf,src+Ndx,lenD); Buf[lenD]=0;
Cont0000:
      iCnt++;
      Buf+=sze;
    }
    Ndx+=lenD;
    iPos=Ndx;
    if ((cb_UInteger)iCnt>=iMax) break;
  }
Exit0000:
  if (iPos<lenSrc) { iFlags &= ~2; goto Found0000; }
  *(cb_UInteger*)iNum = iCnt;
  if ((iFlags & 128)!=0) if (iCnt<iCnt_) dst = cb_ReMemAllocM(dst,iCnt*sze);
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_StrSplitP */
char ** cb_DEFCALL cb_StrSplitP (const char *src, const char *sDelim, char **Buf, void *iNum, cb_UInteger iMax, cb_Integer iFlags)
{
  register cb_UInteger Ndx;
  register cb_UInteger i;
  register cb_UInteger iPos = 0;
  register cb_UInteger iCnt = 0;
  if (!sDelim) sDelim = " ";
  register cb_UInteger lenD = cb_StrLen(sDelim);
  register cb_UInteger lenSrc = cb_StrLen(src);
  cb_UInteger lenDelim = lenD;
  cb_UInteger iCnt_ = 0;
  char *MyPtr1;

  if ((iFlags & 8)!=0) lenD = 1;
  Ndx=0;
Loop0000:
  while (Ndx<lenSrc) {
    if ((iFlags & 8)!=0) {
      for (i=0;i<lenDelim;i++) if (src[Ndx]==sDelim[i]) goto Found0000;
NotFound0000:
      i = src[Ndx];
      if (i=='"' || i=='\'' || i=='`')
      do {
        Ndx++; if (Ndx>=lenSrc) goto Exit0000;
        if (src[Ndx]==i) { Ndx++; if (src[Ndx]!=i) break; }
        else if ((iFlags & 32)!=0) if (src[Ndx]=='\\') Ndx++;
      } while(1);
      goto Loop0000;
    }
    for (i=0;i<lenD;i++) if (i+Ndx>=lenSrc || src[i+Ndx]!=sDelim[i]) goto NotFound0000;
Found0000:;
    if ((iFlags & 128)!=0) if (iCnt>=iCnt_) { iCnt_+=10; Buf = (char**)cb_ReMemAllocM(Buf,iCnt_*sizeof(char*)); }
    if ((iFlags & 64)!=0) Buf[iCnt] = (char*)(src+iPos);
    else { Buf[iCnt] = (char*)cb_MemAllocM(Ndx+1-iPos); cb_MemMove(Buf[iCnt],src+iPos,Ndx-iPos); Buf[iCnt][Ndx-iPos] = 0; }
    if ((iFlags & (1 | 64))==1) {
      MyPtr1 = cb_LTrimX(Buf[iCnt], (void*)-2);
      i = MyPtr1[0];
      if (i=='"' || i=='\'' || i=='`') {
        MyPtr1++;
        i = cb_StrLen(MyPtr1);
        if (i) { i--; if (MyPtr1[i]==MyPtr1[-1]) MyPtr1[i] = 0; }
        if ((iFlags & 4)!=0) goto Trim0000;
        cb_StrCopy(Buf[iCnt],MyPtr1);
        goto NoTrim0000;
      }
    }
    if ((iFlags & (4 | 64))==4) {
      MyPtr1 = Buf[iCnt];
Trim0000:
      cb_TrimX(MyPtr1, Buf[iCnt]);
    }
NoTrim0000:
    if (Buf[iCnt][0]!=0)
      iCnt++;
    else if ((iFlags & (2|8|16|64))==(2|8|16)) {
      if (iCnt) {
        iCnt--;
        if (((unsigned char*)Buf[iCnt])[0]<=' ') if (((unsigned char*)src)[Ndx]<=' ') { cb_StrCat(Buf[iCnt], " "); goto Cont0000; }
        iCnt++;
      }
    }
    if ((iFlags & 2)!=0) {
      if ((iFlags & 128)!=0) if (iCnt>=iCnt_) { iCnt_+=10; Buf = (char**)cb_ReMemAllocM(Buf,iCnt_*sizeof(char*)); }
      if ((iFlags & 64)!=0) Buf[iCnt] = (char*)(src+Ndx);
      else { Buf[iCnt] = (char*)cb_MemAllocM(lenD+1); cb_MemMove(Buf[iCnt],src+Ndx,lenD); Buf[iCnt][lenD]=0; }
Cont0000:
      iCnt++;
    }
    Ndx+=lenD;
    iPos=Ndx;
    if ((cb_UInteger)iCnt>=iMax) break;
  }
Exit0000:
  if (iPos<lenSrc) { iFlags &= ~2; goto Found0000; }
  *(cb_UInteger*)iNum = iCnt;
  if ((iFlags & 128)!=0) if (iCnt+1<iCnt_) Buf = (char**)cb_ReMemAllocM(Buf,(iCnt+1)*sizeof(char*));
  Buf[iCnt] = NULL;
  return Buf;
}
/* END MODULE */


/* MODULE::cb_AtoULLBase */
unsigned long long cb_DEFCALL cb_AtoULLBase (const char *Num1, cb_Integer iBase1, const char **sEnd)
{
  register cb_UInteger h;
  register unsigned long long j;
  register const char *i = Num1;
  register unsigned long long Base1 = iBase1;
  register cb_Integer n = FALSE;

  if (i[0]=='-') {
    i++; n++;
  }
    h = *(short*)i; h |= 32<<8;
    if (h=='x0' || h=='h&') { i+=2; Base1=16; }
    else if (h=='b0' || h=='b&') { i+=2; Base1=2; }
    else if (h=='o0' || h=='o&') { i+=2; Base1=8; }
  j = 0;
  do {
    h = i[0];
    if (h <= '9') h-= '0';
    else if (h <= 'Z') h -= 'A'-10;
    else if (Base1<=36) h -= 'a'-10;
    else h -= 'a'-36;
    if (h >= Base1) break;
    j = (j*Base1) + h;
    ++i;
  } while(1);
  if (sEnd) *sEnd = i;
  if (n!=0) j = 0-j;
  return j;
}
/* END MODULE */


/* MODULE::cb_RandFunc */
double cb_DEFCALL cb_RandFunc (double min1, double max1)
{
  return ((double)cb_Rand() * (max1-min1) / (double)RAND_MAX) + min1;
}
/* END MODULE */


/* MODULE::cb_Round */
double cb_DEFCALL cb_Round (double n, cb_Integer d)
{
  return (floor((n)*pow(10.0,d)+0.5)/pow(10.0,d));
}
/* END MODULE */


/* MODULE::cb_ModFF */
#if defined(__WATCOM_CPLUSPLUS__) || defined(__BCPLUSPLUS__)
float cb_DEFCALL cb_ModFF (float d, float *f)
{  double f1;  d = (float)modf((double)d,&f1); f[0] = (float)f1;  return d;}
#endif
/* END MODULE */


/* MODULE::cb_ModFL */
#ifdef __WATCOM_CPLUSPLUS__
long double cb_DEFCALL cb_ModFL (long double d, long double *f)
{  double f1;  d = (long double)modf((double)d,&f1); f[0] = (long double)f1;  return d;}
#endif
/* END MODULE */


/* MODULE::cb_FracD */
double cb_DEFCALL cb_FracD (double d)
{  double f;  return modf(d,&f);}
/* END MODULE */


/* MODULE::cb_FracF */
float cb_DEFCALL cb_FracF (float d)
{
  float f;  return modff(d,&f);
}
/* END MODULE */


/* MODULE::cb_FracLD */
long double cb_DEFCALL cb_FracLD (long double d)
{
  long double f;  return modfl(d,&f);
}
/* END MODULE */


/* MODULE::cb_IsHexDigits */
cb_Integer cb_DEFCALL cb_IsHexDigits (const void *a,cb_Integer flag1)
{
  register const char *i = (const char*)a;
  register cb_Integer j, h = 0;

  do {
    j = i[0];
    if (j==0) break;
    if (!cb_IsDigit(j)) {
      j &= ~32;
      if (j<'A' || j>'F') {
        if (h) return 0; h++;
        if (j!='L') if (!flag1 || (j!='G' && j!='K' && j!='M')) {
          if (j!='P') return 0;
          j = i[1]; if (j=='+' || j=='-') i++;
        }
      }
    }
    ++i;
  } while(1);
  return (i!=(const char*)a?16:0);
}
/* END MODULE */


/* MODULE::cb_IsBinOctDigits */
cb_Integer cb_DEFCALL cb_IsBinOctDigits (const void *a,cb_Integer digit,cb_Integer flag1)
{
  register const char *i = (const char*)a;
  register cb_Integer j, d = digit, h = 0;

  do {
    j = i[0];
    if (j==0) break;
    if (j<'0' || j>d) {
      j &= ~32;
      if (h<0) {
        if (j!='B') return 0; h = 1;
      }
      else {
        if (h) return 0; h++;
        if (j!='L') { if (!flag1 || (j!='G' && j!='K' && j!='M')) return 0; h = -1; }
      }
    }
    i++;
  } while(1);
  d -= '0'-1; if (i==(const char*)a) d = 0;
  return d;
}
/* END MODULE */


/* MODULE::cb_IsNumeric */
cb_Integer cb_DEFCALL cb_IsNumeric (const void *a,cb_Integer flag1,cb_Integer flag2)
{
  register const char *i = (const char*)a;
  register cb_Integer j = i[0], h; if (j=='+' || j=='-') { ++i; j = i[0]; }

  if (j=='&') {
    h = i[1]; h |= 32;
    if (h=='h') return cb_IsHexDigits(i+2,flag2);
    if (h=='b') return cb_IsBinOctDigits(i+2,'1',flag2);
    if (h=='o') return cb_IsBinOctDigits(i+2,'7',flag2);
    return 0;
  }
  if (!cb_IsDigit(j)) return 0;
  if (flag1==2) {
    return TRUE;
  }
  if (j=='0') {
    h = i[1]; h |= 32;
    if (h=='x') return cb_IsHexDigits(i+2,flag2);
    if (h=='b') return cb_IsBinOctDigits(i+2,'1',flag2);
    if (h=='o') return cb_IsBinOctDigits(i+2,'7',flag2);
  }
  h = 0;
  while(j) {
    if (!cb_IsDigit(j)) {
      if ((flag1 & 1)==0 || h<=0) return 0;
      if (j=='.') h=-10000;
      else {
        j &= ~32;
        if (j=='E') { j = i[1]; if (j=='+' || j=='-') i++; h=-10000; }
        else if (j!='L' && j!='U') {
          if (i[1]!=0 || (j!='F' && j!='D')) {
            if ((flag1 & 4)==0 || (j!='G' && j!='K' && j!='M')) return 0;
            j = i[1] & (~32); if (j!=0) if (j!='B') return 0;
          }
        }
      }
    }
    ++h;
    ++i;
    j = i[0];
  }
  return h;
}
/* END MODULE */


/* MODULE::cb_LtoA */

char * cb_DEFCALL cb_LtoA (long a, void *dst, cb_Integer b)
{
  return cb_CStrL(a,b,dst);
}
/* END MODULE */


/* MODULE::cb_LLtoA */

char * cb_DEFCALL cb_LLtoA (long long a, void *dst, cb_Integer b)
{
  return cb_CStrL(a,b,dst);
}
/* END MODULE */


/* MODULE::cb_ULLtoA */

char * cb_DEFCALL cb_ULLtoA (unsigned long long a, void *dst, cb_Integer b)
{
  return cb_CStrL(a,b|cb_MIN_INTEGER,dst);
}
/* END MODULE */


/* MODULE::cb_ResetBit */
void cb_DEFCALL cb_ResetBit (void *a,cb_Integer iBit)
{
  register cb_UInteger i, j; i = iBit;
  register BYTE *b; b = (BYTE*)a;
  j = i; i >>= 3; j &= 7;
  b[i] &= ~(1 << j);
}
/* END MODULE */


/* MODULE::cb_SetBit */
void cb_DEFCALL cb_SetBit (void *a,cb_Integer iBit)
{
  register cb_UInteger i, j; i = iBit;
  register BYTE *b; b = (BYTE*)a;
  j = i; i >>= 3; j &= 7;
  b[i] |= 1 << j;
}
/* END MODULE */


/* MODULE::cb_NotBit */
void cb_DEFCALL cb_NotBit (void *a,cb_Integer iBit)
{
  register cb_UInteger i, j; i = iBit;
  register BYTE *b; b = (BYTE*)a;
  j = i; i >>= 3; j &= 7;
  b[i] ^= 1 << j;
}
/* END MODULE */


/* MODULE::cb_TestBit */
cb_UInteger cb_DEFCALL cb_TestBit (const void *a,cb_Integer iBit)
{
  register cb_UInteger i, j; i = iBit;
  register const BYTE *b; b = (const BYTE*)a;
  j = i; i >>= 3; j &= 7;
  return b[i] & (1 << j);
}
/* END MODULE */


/* MODULE::cb_FileClose */
cb_Integer cb_DEFCALL cb_FileClose_ (cb_File_ *T)
{
  register cb_File_ *p = T;
  register cb_Integer i = p->m_Size;
  register cb_Integer n;
  if (i>=0) { i = (cb_Integer)(p->m_Buffer); if (i) i = 0; else i = -2; }
  else if (p->m_Buffer) {
    if (i>=-6 && i<=-3) i = 0;
    else {
      n = i;
      if (i==-10) { cb_cEachFile_Terminate((cb_cEachFile*)(p->m_Buffer)); i = 0; }
      else if (i==-3) i = _pclose((FILE*)(p->m_Buffer));
      else i = fclose((FILE*)(p->m_Buffer));
      if (p->m_Len) { if (n==-2) cb_Remove((const char*)(p->m_Len+sizeof(cb_Integer))); cb_MemFreeM((void*)(p->m_Len)); }
    }
    p->m_Buffer = NULL;
  }
  else i = -2;
  cb_cString_Terminate(p);
  return i;
}

cb_Integer cb_DEFCALL cb_FileClose (cb_File* T)
{
  if (T) return cb_FileClose_((cb_File_*)T);
  return -1;
}
/* END MODULE */


/* MODULE::cb_PipeClose */
cb_Integer cb_DEFCALL cb_PipeClose (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  if (p) {
    if (p->m_Size==-3)
    return cb_FileClose_(p);
  }
  return -1;
}
/* END MODULE */


/* MODULE::cb_FileCloseAll */
cb_Integer cb_DEFCALL cb_FileCloseAll_ (cb_Integer flag1)
{
  register cb_File_ *p = &cb_FilesArrayPtr_[cb_FilesArrayCnt_];
  register cb_Integer i = flag1;
  while (p>cb_FilesArrayPtr_) {
    p--;
    if (!i) { if (p->m_Size>-3) goto Close0000; }
    else if (i<=-10 || p->m_Size==i) {
Close0000:
      cb_FileClose_(p);
    }
  }
  return cb_FilesArrayCnt_;
}

cb_Integer cb_DEFCALL cb_FileCloseAll (void)
{
  return cb_FileCloseAll_(0);
}
/* END MODULE */


/* MODULE::cb_PipeCloseAll */
cb_Integer cb_PipeCloseAll (void)
{
  register cb_File_ *p = &cb_FilesArrayPtr_[cb_FilesArrayCnt_];
  register cb_Integer i = 0;
  while (p>cb_FilesArrayPtr_) {
    p--; if (p->m_Size==-3) { cb_FileClose_(p); i++; }
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_FreeFile_ */
cb_File_ *cb_FreeFile_ (void)
{
  register cb_File_ *p = &cb_FilesArrayPtr_[cb_FilesArrayCnt_];
  while (p>cb_FilesArrayPtr_) { p--; if (p->m_Buffer==NULL) if (p->m_Size==0) return p; }
  p = NULL;
  if (cb_FilesArrayCnt_<0x0C00) {
    p = &cb_FilesArrayPtr_[cb_FilesArrayCnt_];
    cb_FilesArrayCnt_++;
  }
  return p;
}
/* END MODULE */


/* MODULE::cb_FileInitialize */
void cb_FileInitialize (void)
{
  ((cb_File_*)cb_StdIn)->m_Buffer = (BYTE*)stdin; ((cb_File_*)cb_StdIn)->m_Size = -4; ((cb_File_*)cb_StdIn)->m_Pos = 0;
  ((cb_File_*)cb_StdOut)->m_Buffer = (BYTE*)stdout; ((cb_File_*)cb_StdOut)->m_Size = -5; ((cb_File_*)cb_StdOut)->m_Pos = 0;
  ((cb_File_*)cb_StdErr)->m_Buffer = (BYTE*)stderr; ((cb_File_*)cb_StdErr)->m_Size = -6; ((cb_File_*)cb_StdErr)->m_Pos = 0;
}
/* END MODULE */


/* MODULE::cb_FileTerminate */
void cb_FileTerminate (void)
{
  cb_FileCloseAll_(-100);
}
/* END MODULE */


/* MODULE::cb_FileEOF */
cb_Integer cb_DEFCALL cb_FileEOF (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  if (p->m_Size>=0) { if (p->m_Pos>=p->m_Len) return TRUE; return FALSE; }
  if (p->m_Size==-10) { if (*cb_cEachFile_Name((cb_cEachFile*)(p->m_Buffer))) return FALSE; return TRUE; }
  return feof((FILE*)(p->m_Buffer));
}
/* END MODULE */


/* MODULE::cb_FileError */
cb_Integer cb_DEFCALL cb_FileError (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  if (p->m_Size>=0) return 0;
  return p->m_Pos;
}
/* END MODULE */


/* MODULE::cb_FileClearError */
cb_Integer cb_DEFCALL cb_FileClearError (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_Integer i;
  if (p->m_Size>=0) return 0;
  i = ferror((FILE*)(p->m_Buffer)); clearerr((FILE*)(p->m_Buffer));
  p->m_Pos = 0;
  return i;
}
/* END MODULE */


/* MODULE::cb_FileFlush */
cb_Integer cb_DEFCALL cb_FileFlush (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  if ((cb_UInteger)(p->m_Size)<(cb_UInteger)(-6)) return 0;
  p->m_Pos = 0;
  if (0==fflush((FILE*)(p->m_Buffer))) return 0;
  p->m_Pos = -1; return -1;
}
/* END MODULE */


/* MODULE::cb_FileFlushAll */
cb_Integer cb_FileFlushAll (void)
{
  register cb_File_ *p = &cb_FilesArrayPtr_[cb_FilesArrayCnt_];
  while (p>cb_FilesArrayPtr_) {
    p--;
  if (p->m_Size<0) p->m_Pos = fflush((FILE*)(p->m_Buffer));
  }
  return cb_FilesArrayCnt_;
}
/* END MODULE */


/* MODULE::cb_FileRewindAll */
cb_Integer cb_FileRewindAll (void)
{
  register cb_File_ *p = &cb_FilesArrayPtr_[cb_FilesArrayCnt_];
  while (p>cb_FilesArrayPtr_) {
    p--;
    if (p->m_Size>=0) cb_cString_Seek(p,0,SEEK_SET);
    else {
      p->m_Pos = 0;
      if (p->m_Size==-10) { if (cb_cEachFile_Rewind((cb_cEachFile*)(p->m_Buffer)))  p->m_Pos = -1; }
      else if (fseek((FILE*)(p->m_Buffer),0,SEEK_SET)) p->m_Pos = -1;
    }
  }
  return cb_FilesArrayCnt_;
}
/* END MODULE */


/* MODULE::cb_FileHandle */
void* cb_DEFCALL cb_FileHandle (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  return (void*)(p->m_Buffer);
}
/* END MODULE */


/* MODULE::cb_FileNo */
cb_Integer cb_DEFCALL cb_FileNo (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  if (p->m_Size<0) return _fileno((FILE*)(p->m_Buffer));
  return -1;
}
/* END MODULE */


/* MODULE::cb_OSFileHandle */
void* cb_DEFCALL cb_OSFileHandle (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  if (p->m_Size>=0) return p->m_Buffer;
  return (void*)_get_osfhandle(_fileno((FILE*)(p->m_Buffer)));
}
/* END MODULE */


/* MODULE::cb_FileAttr */
cb_Integer cb_DEFCALL cb_FileAttr (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  struct _stat t;
  if (p->m_Size>=0) return 0;
  if (_fstat(_fileno((FILE*)(p->m_Buffer)), &t)) return t.st_mode; return INVALID_FILE_ATTRIBUTES;
}
/* END MODULE */


/* MODULE::cb_GetFileName */
const char* cb_DEFCALL cb_GetFileName (cb_File* T, void *dst)
{
  register cb_File_ *p = (cb_File_*)T;
  register const char *fName;
  if (p->m_Size>=0) return NULL;
  fName = (const char*)(p->m_Len);
  if (fName!=NULL) fName += sizeof(cb_Integer);
  else {
    if (p->m_Size!=-10) return NULL;
    fName = cb_cEachFile_Name((cb_cEachFile*)(p->m_Buffer));
  }
  if (dst==(void*)-2) return fName;
  return cb_NewStr_(fName,dst,cb_StrLen((const char*)fName));
}
/* END MODULE */


/* MODULE::cb_FileRead */
cb_UInteger cb_DEFCALL cb_FileRead (cb_File* T, void *buf, cb_UInteger n)
{
  register cb_File_ *p;
  register cb_Integer i = n;
  cb_Integer d;
  if ((cb_UInteger)(i-1)<(cb_UInteger)(-2-1)) {
  p = (cb_File_*)T;
  if (p->m_Size>=0) { if (cb_cString_Read(p,&d,buf,i)) i = d; else i = -1; }
  else { i = fread(buf,1,i,(FILE*)(p->m_Buffer)); p->m_Pos = 0; if (i!=n) if (ferror((FILE*)(p->m_Buffer))) { i = -1; p->m_Pos = -1; } }
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_FileGetC */
cb_Integer cb_DEFCALL cb_FileGetC (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_Integer i;
  char b[4];
  if (p->m_Size>=0) { if (cb_cString_Read(p,NULL,b,1)) return b[0] & 0x00ff; return -1; }
  i = fread(b,1,1,(FILE*)(p->m_Buffer)); if (i==1) return b[0] & 0x00ff; i = -1;
  return i;
}
/* END MODULE */


/* MODULE::cb_FileGetCW */
cb_Integer cb_DEFCALL cb_FileGetCW (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_Integer i;
  wchar_t b[2];
  if (p->m_Size>=0) { if (cb_cString_Read(p,NULL,b,sizeof(wchar_t))) return b[0] & 0x00ffff; return -1; }
  i = fread(b,1,sizeof(wchar_t),(FILE*)(p->m_Buffer)); if (i==sizeof(wchar_t)) return b[0] & 0x00ffff; i = -1;
  return i;
}
/* END MODULE */


/* MODULE::cb_FileGetS */
cb_Integer cb_DEFCALL cb_FileGetS (cb_File* T, char *buf, cb_Integer sze)
{
  register cb_File_ *p;
  register cb_Integer i = sze; i--;
  register char *b;
  cb_Integer i1;
  if (i>=0) {
    b = buf; if (i<=0) goto Exit0000;
    p = (cb_File_*)T;
    if (p->m_Size>=0) {
      if (cb_cString_GetLine(p,b,&i1,-1,i,FALSE)) { p->flag1_ &= cb_MAX_INTEGER; return i1; }
      p->flag1_ |= cb_MIN_INTEGER; return -1;
    }
    i = (cb_Integer)fgets(b,i,(FILE*)(p->m_Buffer));
    if (i) i = cb_StrLen(b);
    else if (ferror((FILE*)(p->m_Buffer))) { p->m_Pos = -1; return -1; }
    else { Exit0000:; *b = 0; }
    p->m_Pos = 0;
  }
  return i;
}

char* cb_DEFCALL cb_FGetS (cb_File* T, char *buf, cb_Integer sze)
{
  if (cb_FileGetS(T,buf,sze)<0) return NULL;
  return buf;
}
/* END MODULE */


/* MODULE::cb_FileGetSW */
cb_Integer cb_DEFCALL cb_FileGetSW (cb_File* T, wchar_t *buf, cb_Integer sze)
{
  register cb_File_ *p;
  register cb_Integer i = sze; i--;
  register wchar_t *b;
  cb_Integer i1;
  if (i>=0) {
    b = buf; if (i<=0) goto Exit0000;
    p = (cb_File_*)T;
    if (p->m_Size>=0) {
      if (cb_cString_GetLineW(p,b,&i1,-1,i,FALSE)) { p->flag1_ &= cb_MAX_INTEGER; return i1; }
      p->flag1_ |= cb_MIN_INTEGER; return -1;
    }
    i = (cb_Integer)fgetws(b,i,(FILE*)(p->m_Buffer));
    if (i) i = cb_StrLenW(b);
    else if (ferror((FILE*)(p->m_Buffer))) { p->m_Pos = -1; return -1; }
    else { Exit0000:; *b = 0; }
    p->m_Pos = 0;
  }
  return i;
}

wchar_t* cb_DEFCALL cb_FGetSW (cb_File* T, wchar_t *buf, cb_Integer sze)
{
  if (cb_FileGetSW(T,buf,sze)<0) return NULL;
  return buf;
}
/* END MODULE */


/* MODULE::cb_TempFile */
cb_File* cb_DEFCALL cb_TempFile (const char *sFolder, const char *sPrefix, const char *sSuffix, cb_Integer n)
{
  register char *f; f = (char*)cb_MemAllocM(0x0800); if (!f) return NULL;
  register cb_File* p; p = cb_GetTempFileName(sFolder,sPrefix,sSuffix,f,n);
  cb_MemFreeM(f);
  return p;
}
/* END MODULE */


/* MODULE::cb_FileOpen */
cb_File* cb_DEFCALL cb_FileOpen (const void *fName, cb_Integer iMode, cb_Integer iLen)
{
  register cb_File_ *p;
  register cb_Integer i;
  char sMode[8], *s;
  i = iMode;
  if (fName) if (!*(const char*)fName) {
    if (i==-1) i ^= ~_O_APPEND;
    return cb_TempFile(NULL,NULL,NULL,i);
  }
  p = cb_FreeFile_(); if (!p) return NULL;
  cb_cString_Initialize(p);
  if (!fName) { cb_cString_SetBufferSize(p,0); return p; }
  if (i==-1) i = _O_RDONLY | _O_BINARY;
  else if (i&(_O_BINARY|_O_MEMORY)) { i &= ~_O_TEXT; i |= _O_BINARY; }
  if (i & _O_MEMORY) {
    p->m_Size--; if (!cb_cString_ReadFileName(p,(const char*)fName)) { cb_cString_Terminate(p); return NULL; }
    i &= _O_APPEND | _O_BINARY | _O_TEXT; p->flag1_ |= i;
  }
  else {
    if (i & _O_APPEND) {
      sMode[0] = 'a'; if (i & _O_CREAT) cb_Remove((const char*)fName);
    }
    else if (!(i & (_O_WRONLY | _O_RDWR))) sMode[0] = 'r';
    else if (i & _O_CREAT) { Open0000:; sMode[0] = 'w'; }
    else { sMode[0] = 'r'; i |= _O_RDWR; }
    s = sMode+1;
    if ((i & (_O_BINARY|_O_TEXT))!=_O_TEXT) { sMode[1] = 'b'; s++; }
    if (i & _O_RDWR) { s[0] = '+'; s++; }
    if (i & _O_EXCL) { s[0] = 'x'; s++; }
    s[0] = 0;
    p->m_Buffer = (BYTE*)fopen((const char*)fName,sMode);
    if (p->m_Buffer==NULL) if ((i & (_O_APPEND|_O_OPEN|_O_CREAT))==_O_OPEN) {
      i = iMode; i |= _O_CREAT; if (!(i & (_O_WRONLY | _O_RDWR))) i |= _O_RDWR;
      goto Open0000;
    }
    if (!p->m_Buffer) return NULL;
    if (i & _O_TEMPORARY) p->m_Size--;
    p->m_Size--;
    i = cb_StrLen((const char*)fName)+1;
    p->m_Len = (cb_Integer)cb_NewStr_(NULL,(void*)-1,i+sizeof(cb_Integer)-1);
    *(cb_Integer*)(p->m_Len) = iLen; cb_MemCopy((void*)(p->m_Len+sizeof(cb_Integer)),fName,i);
  }
  return p;
}

cb_File* cb_DEFCALL cb_FOpen (const void *fName, const char *sMode, cb_Integer iLen)
{
  register cb_Integer i;
  register const char *s; s = sMode;
  if (!fName) {
    i = _O_CREAT | _O_MEMORY;
    goto Temp0000;
  }
  if (*(const char*)fName==0) {
    i = _O_TEMPORARY | _O_CREAT;
Temp0000:
    if (!s) { i |= _O_RDWR | _O_BINARY; goto Exit0000; }
  }
  else {
    if (!s) { i = -1; goto Exit0000; }
    i = 0;
  }
  if (s[0]=='r') s++;
  else {
    if (s[0]=='a') { i |= _O_APPEND | _O_WRONLY; s++; }
    if (s[0]=='m') { i |= _O_MEMORY; s++; }
    else {
      if (s[0]=='o') { i |= _O_OPEN; s++; if (s[0]=='w') { i |= _O_WRONLY; s++; } }
      else if (s[0]=='w') { i |= _O_CREAT | _O_WRONLY; s++; }
      if (s[0]=='t') { i |= _O_OPEN | _O_TEMPORARY | _O_WRONLY; s++; }
    }
  }
  while (s[0]) {
    if (s[0]=='b') i |= _O_BINARY;
    else if (s[0]=='+') { i &= ~_O_WRONLY; i |= _O_RDWR; }
    else if (s[0]=='x') i |= _O_EXCL;
    else if (s[0]=='s') i |= _O_SEQUENTIAL;
    else if (s[0]=='d') i |= _O_RANDOM;
    s++;
  }
  if ((i & (_O_SEQUENTIAL | _O_RDWR))==_O_RDWR) i |= _O_RANDOM;
  if ((i & (_O_BINARY | _O_MEMORY))==0) i |= _O_TEXT;
Exit0000:
  return cb_FileOpen(fName,i,iLen);
}
/* END MODULE */


/* MODULE::cb_MemFile */
cb_File* cb_DEFCALL cb_MemFile (void *ptr1, cb_Integer sze)
{
  register void *p;
  register cb_File_ *f;
  register cb_Integer s;

  f = (cb_File_*)cb_FileOpen();
  if (f) {
    p = ptr1;
    if (p) {
      cb_cString_SetBuffer(f,p,sze);
    }
  }
  return f;
}
/* END MODULE */


/* MODULE::cb_PipeOpen */
cb_File* cb_DEFCALL cb_PipeOpen (const void *fName, cb_Integer iMode)
{
  register cb_File_ *p;
  register char *s;
  char sMode[8];
  register cb_Integer i;
  if (!fName || !*(const char*)fName) return NULL;
  p = cb_FreeFile_(); if (!p) return NULL;
  cb_cString_Initialize(p);
  s = sMode+1;
  if (iMode & (_O_WRONLY | _O_RDWR)) sMode[0] = 'w';
  else sMode[0] = 'r';
  if ((iMode & (_O_BINARY|_O_TEXT))!=_O_TEXT) { sMode[1] = 'b'; s++; }
  s[0] = 0;
  p->m_Buffer = (BYTE*)_popen((const char*)fName,sMode); if (!p->m_Buffer) return NULL;
  p->m_Size = -3;
  i = cb_StrLen((const char*)fName)+1;
  p->m_Len = (cb_Integer)cb_NewStr_(NULL,(void*)-1,i+sizeof(cb_Integer)-1);
  *(cb_Integer*)(p->m_Len) = 0; cb_MemCopy((void*)(p->m_Len+sizeof(cb_Integer)),fName,i);
  return p;
}

cb_File* cb_DEFCALL cb_POpen (const void *fName, const char *sMode)
{
  register cb_Integer i;
  if (!sMode) { i = -1; goto Exit0000; }
  if (sMode[0]=='r') i = _O_RDONLY;
  else i = _O_WRONLY;
  if (sMode[1]=='b') i |= _O_BINARY; else i |= _O_TEXT;
Exit0000:
  return cb_PipeOpen(fName,i);
}
/* END MODULE */


/* MODULE::cb_FileDOpen */
cb_File* cb_DEFCALL cb_FileDOpen (void *f, cb_Integer iMode, cb_Integer iLen)
{
  register cb_File_ *p;
  register char *s;
  register void *h;
  char sMode[8];
  register cb_Integer i;
  if (!f) return NULL;
  p = cb_FreeFile_(); if (!p) return NULL;
  i = iMode; if (i==-1) i = _O_NOINHERIT;
  cb_cString_Initialize(p);
  h = (void*)_open_osfhandle((cb_Integer)f,i & (_O_APPEND | _O_TEXT | _O_NOINHERIT)); if (!h) return NULL;
  if (i & _O_APPEND) {
    sMode[0] = 'a';
  }
  else if (!(i & (_O_WRONLY | _O_RDWR))) sMode[0] = 'r';
  else if (i & _O_CREAT) { Open0000:; sMode[0] = 'w'; }
  else { sMode[0] = 'r'; i |= _O_RDWR; }
  s = sMode+1;
  if ((i & (_O_BINARY|_O_TEXT))!=_O_TEXT) { sMode[1] = 'b'; s++; }
  if (i & _O_RDWR) { s[0] = '+'; s++; }
  if (i & _O_EXCL) { s[0] = 'x'; s++; }
  s[0] = 0;
  p->m_Buffer = (BYTE*)_fdopen((cb_Integer)h,sMode);
  if (p->m_Buffer==NULL) {
    if ((i & (_O_OPEN|_O_CREAT))==_O_OPEN) {
      i = iMode; i |= _O_CREAT; if (!(i & (_O_WRONLY | _O_RDWR))) i |= _O_RDWR;
      goto Open0000;
    }
    _close((cb_Integer)h); return NULL;
  }
  p->m_Size--;
  if (i & _O_MEMORY) {
    h = cb_FreeFile_();
    if (h) {
      i  = (cb_Integer)cb_cString_ReadFile((cb_cString*)h,p);
     if (!i) cb_cString_Terminate((cb_cString*)h);
     else { cb_FileClose_(p); p = (cb_File_*)h; }
    }
  }
  else {
    p->m_Len = (cb_Integer)cb_NewStr_(NULL,(void*)-1,sizeof(cb_Integer)+0x0800); *(cb_Integer*)(p->m_Len) = 0;
    cb_GetFileNameByHandle(f,(char*)(p->m_Len+sizeof(cb_Integer)),0x0800,FILE_NAME_NORMALIZED);
  }
  return p;
}

cb_File* cb_DEFCALL cb_FDOpen (void *f, const char *sMode, cb_Integer iLen)
{
  register cb_Integer i;
  register const char *s; s = sMode; if (!s) { i = -1; goto Exit0000; }
  if (s[0]=='r') i = _O_RDONLY;
  else if (s[0]=='a') i = _O_APPEND | _O_WRONLY;
  else i = _O_WRONLY;
  if (s[1]=='b') s++; else i |= _O_TEXT;
  if (s[1]=='+') { i &= ~_O_WRONLY; i |= _O_RDWR; }
Exit0000:
  return cb_FileDOpen(f,i,iLen);
}
/* END MODULE */


/* MODULE::cb_FolderOpen */
cb_File* cb_DEFCALL cb_FolderOpen (const void *fName)
{
  register cb_File_ *p;
  p = cb_FreeFile_(); if (!p) return NULL;
  p->m_Buffer = (BYTE*)cb_cEachFile_Initialize(); if (p->m_Buffer==NULL) return NULL;
  p->m_Size=-10; p->m_Len = 0;
  if (cb_cEachFile_Open((cb_cEachFile*)(p->m_Buffer),fName,NULL)<0) { cb_FileClose_(p); return NULL; }
  return p;
}
/* END MODULE */


/* MODULE::cb_FileWrite */
cb_UInteger cb_DEFCALL cb_FileWrite (cb_File* T, const void *b, cb_UInteger n)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_UInteger i = n;
  if ((cb_UInteger)(i-1)<(cb_UInteger)(-2-1)) {
  if (p->m_Size>=0) { if (cb_cString_Write(p,b,i)==NULL) i = -1; }
  else { i = fwrite(b,1,i,(FILE*)(p->m_Buffer)); if (i==n) p->m_Pos = 0; else { i = -1; p->m_Pos = -1; } }
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_FilePutC */
cb_Integer cb_DEFCALL cb_FilePutC (cb_File* T, cb_Integer c)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_Integer i;
  if (p->m_Size>=0) { if (cb_cString_Write(p,&c,1)) return 1; return -1; }
  i = fwrite(&c,1,1,(FILE*)(p->m_Buffer)); if (i==1) { p->m_Pos = 0; return i; } p->m_Pos = -1; return -1;
}
/* END MODULE */


/* MODULE::cb_FilePutCW */
cb_Integer cb_DEFCALL cb_FilePutCW (cb_File* T, cb_Integer c)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_Integer i;
  if (p->m_Size>=0) { if (cb_cString_Write(p,&c,sizeof(wchar_t))) return 1; return -1; }
  i = fwrite(&c,1,sizeof(wchar_t),(FILE*)(p->m_Buffer)); if (i==sizeof(wchar_t)) { i = 1; p->m_Pos = 0; return i; } p->m_Pos = -1; return -1;
}
/* END MODULE */


/* MODULE::cb_FileInsert */
cb_UInteger cb_DEFCALL cb_FileInsert (cb_File* T, const void *b, cb_UInteger ofs, cb_UInteger n, cb_UInteger iRep)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_UInteger i;
  if (p->m_Size>=0) {
    i = ofs; if (i<(cb_UInteger)-10) cb_cString_Seek(p,i);
    i = n; if (i>=(cb_UInteger)-10) i = cb_StrLen((const char*)b);
    if (cb_cString_StrInsert(p,b,-1,i)) return i;
  }
  return -1;
}
/* END MODULE */


/* MODULE::cb_FileSeek */
cb_UInteger cb_DEFCALL cb_FileSeek (cb_File* T, cb_UInteger n, cb_Integer o)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_UInteger i;
  if (p->m_Size>=0) return cb_cString_Seek(p,n,o);
  if (p->m_Size==-10) {
    i = -1; if (o==SEEK_SET) if (n==0) i = cb_cEachFile_Rewind((cb_cEachFile*)(p->m_Buffer));
    p->m_Pos = i; return i;
  }
  if (!fseek((FILE*)(p->m_Buffer),n,o)) { i = ftell((FILE*)(p->m_Buffer)); if (i!=-1) { p->m_Pos = 0; return i; } }
  p->m_Pos = -1; return -1;
}

cb_Integer cb_DEFCALL cb_FSeek (cb_File* T, cb_UInteger n, cb_Integer o)
{
  if (cb_FileSeek(T,n,o)!=-1) return 0; return -1;
}
/* END MODULE */


/* MODULE::cb_FileSeek64 */
signed long long cb_DEFCALL cb_FileSeek64 (cb_File* T, signed long long n, cb_Integer o)
{
  register cb_File_ *p = (cb_File_*)T;
  register signed long long i;
  if (p->m_Size>=0) return cb_cString_Seek(p,n,o);
  if (p->m_Size==-10) {
    i = -1; if (o==SEEK_SET) if (n==0) i = cb_cEachFile_Rewind((cb_cEachFile*)(p->m_Buffer));
    p->m_Pos = i; return i;
  }
  if (!_fseeki64((FILE*)(p->m_Buffer),n,o)) { i = _ftelli64((FILE*)(p->m_Buffer)); if (i!=-1) { p->m_Pos = 0; return i; } }
  p->m_Pos = -1; return -1;
}

cb_Integer cb_DEFCALL cb_FSeek64 (cb_File* T, signed long long n, cb_Integer o)
{
  if (cb_FileSeek64(T,n,o)!=-1) return 0; return -1;
}
/* END MODULE */


/* MODULE::cb_FileTell */
cb_UInteger cb_DEFCALL cb_FileTell (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_UInteger i;
  if (p->m_Size>=0) return cb_cString_Tell(p);
  if (p->m_Size==-10) return -1;
  p->m_Pos = 0;
  i = ftell((FILE*)(p->m_Buffer)); if (i==-1) p->m_Pos = -1; return i;
}
/* END MODULE */


/* MODULE::cb_FileTell64 */
signed long long cb_DEFCALL cb_FileTell64 (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  register signed long long i;
  if (p->m_Size>=0) return cb_cString_Tell(p);
  if (p->m_Size==-10) return -1;
  p->m_Pos = 0;
  i = _ftelli64((FILE*)(p->m_Buffer)); if (i==-1) p->m_Pos = -1; return i;
}
/* END MODULE */


/* MODULE::cb_Lof */
cb_UInteger cb_DEFCALL cb_Lof (cb_File* pFile, void *pos1)
{
  register cb_UInteger i, j = cb_FileTell(pFile); if (pos1) *(cb_UInteger*)pos1 = j;
  i = cb_FileSeek(pFile, 0, SEEK_END);
  cb_FileSeek(pFile, j, SEEK_SET);
  return i;
}
/* END MODULE */


/* MODULE::cb_Lof64 */
signed long long cb_DEFCALL cb_Lof64 (cb_File* pFile, void *pos1)
{
  register signed long long i, j = cb_FileTell64(pFile); if (pos1) *(signed long long*)pos1 = j;
  i = cb_FileSeek64(pFile, 0, SEEK_END);
  cb_FileSeek64(pFile, j, SEEK_SET);
  return i;
}
/* END MODULE */


/* MODULE::cb_SetEof */
cb_UInteger cb_DEFCALL cb_SetEof (cb_File* T, cb_UInteger sze)
{
  register cb_File_ *p = (cb_File_*)T;
  register cb_UInteger i = sze;
  if (p->m_Size>=0) { if (cb_cString_SetLength(p,i)) return cb_cString_GetLength(p); return -1; }
  fflush((FILE*)(p->m_Buffer));
  if (i==-1) { i = ftell((FILE*)(p->m_Buffer)); if (i==-1) goto Error0000; }
  i |= _chsize(_fileno((FILE*)(p->m_Buffer)), i);
  if (i!=-1) p->m_Pos = 0; else { Error0000:; p->m_Pos = -1; }
  return i;
}
/* END MODULE */


/* MODULE::cb_SetEof64 */
signed long long cb_DEFCALL cb_SetEof64 (cb_File* T, signed long long sze)
{
  register cb_File_ *p = (cb_File_*)T;
  register signed long long i = sze;
  if (p->m_Size>=0) { if (cb_cString_SetLength(p,i)) return cb_cString_GetLength(p); return -1; }
  fflush((FILE*)(p->m_Buffer));
  if (i==-1) { i = _ftelli64((FILE*)(p->m_Buffer)); if (i==-1) goto Error0000; }
  i |= _chsize(_fileno((FILE*)(p->m_Buffer)), i);
  if (i!=-1) p->m_Pos = 0; else { Error0000:; p->m_Pos = -1; }
  return i;
}
/* END MODULE */


/* MODULE::cb_FolderNext */
char* cb_DEFCALL cb_FolderNext (cb_File* T,void *dst)
{
  register cb_File_ *p; p = (cb_File_*)T;
  if (p->m_Size!=-10) return NULL; return cb_cEachFile_Next((cb_cEachFile*)(p->m_Buffer),dst);
}
/* END MODULE */


/* MODULE::cb_FileTag */
void* cb_DEFCALL cb_FileTag (cb_File* T, void *ptr1)
{
  register cb_File_ *p = (cb_File_*)T;
  register void *p1 = p->UserData;
  p->UserData = ptr1;
  return p1;
}
/* END MODULE */


/* MODULE::cb_GetFileTag */
void* cb_DEFCALL cb_GetFileTag (cb_File* T)
{
  register cb_File_ *p = (cb_File_*)T;
  return p->UserData;
}
/* END MODULE */


/* MODULE::cb_InFile */
cb_Integer cb_DEFCALL cb_InFile (const char *sfName,const char *sMask)
{
  register cb_Integer SIreg,DIreg;

  do
  {
    DIreg = *sfName;
    if (DIreg) sfName++;

Mask0000:
    SIreg = *sMask;
    sMask++;

    if (SIreg!=DIreg) {
      if (SIreg=='?') {
        if (DIreg=='.') goto Mask0000;
      }
      else if (SIreg!='*') {
        if (DIreg||(SIreg!='.')) return FALSE;
      }
      else {
        while (*sfName && *sfName!='.') sfName++;
        while (*sMask && *sMask!='.') sMask++;
      }
    }

  } while(SIreg);
  return TRUE;
}
/* END MODULE */


/* MODULE::cb_FileExt */
const char* cb_DEFCALL cb_FileExt (const char *sfName)
{
  register const char* s; s = sfName;
  register cb_Integer i; i = cb_StrLen(s); s += i;

  while (s!=sfName) {
    s--; if (s[0]=='.') { s++; goto Exit0000; }
    if (s[0]=='/' || s[0]=='\\') { s = sfName; break; }
  }
  s += i;

Exit0000:
  return s;
}
/* END MODULE */


/* MODULE::cb_GetFileExt */
char* cb_DEFCALL cb_GetFileExt (const char *sfName,void *dst)
{
  register const char* s; s = sfName;
  register cb_Integer i; i = cb_StrLen(s); s += i;

  while (s!=sfName) {
    s--; if (s[0]=='.') { s++; i = cb_StrLen(s); goto Exit0000; }
    if (s[0]=='/' || s[0]=='\\') { s = sfName; break; }
  }
  s += i; i = 0;

Exit0000:
  return cb_NewStr_(s,dst,i);
}
/* END MODULE */


/* MODULE::cb_FileExtension */
char * cb_DEFCALL cb_FileExtension (const char *inFile, const char *sExt, cb_Integer bReplace, void *dst)
{
  register char *sTmp = (char*)inFile;
  register cb_Integer idx1=cb_StrLen(sTmp), i;

  for(sTmp+=idx1;idx1;idx1--) {
    sTmp--;
    if (*sTmp=='\\' || *sTmp=='/') break;
  }
  idx1 = cb_InCharRev(sTmp,'.');
  if (sExt==NULL) {
    idx1++;
    sTmp+=idx1;
    inFile = sTmp;
    sTmp = (char*)dst;
    if (idx1>0) goto Copy0000;
    if (!sTmp) return cb_EMPTYSTR;
    if (sTmp==(char*)-1) sTmp = (char*)cb_MemAllocM(sizeof(cb_Integer));
    if (sTmp) sTmp[0] = 0;
    return sTmp;
  }
  if (idx1>=0) {
    if (bReplace==0) { sTmp = (char*)dst; goto Copy0000; }
    idx1 += (cb_Integer)sTmp-(cb_Integer)inFile; sTmp = (char*)dst;
  }
  else {
    sTmp = (char*)dst;
    if (!sExt[0]) {
Copy0000:
      idx1 = cb_StrLen(inFile);
      if (sTmp) {
        if (sTmp==(char*)-1) { sTmp = (char*)cb_MemAllocM(idx1+sizeof(cb_Integer)); if (!sTmp) return NULL; }
        idx1++;
        return (char*)cb_MemMove(sTmp,inFile,idx1);
      }
      if (bReplace==0) return (char*)inFile;
      return cb_NewStr_(inFile,NULL,idx1);
    }
    idx1 = cb_StrLen(inFile);
  }
  i = cb_StrLen(sExt); sTmp = cb_NewStr_(NULL,sTmp,idx1+i); cb_MemMove(sTmp,inFile,idx1);
  i++; cb_MemMove(sTmp+idx1,sExt,i); return sTmp;
}
/* END MODULE */


/* MODULE::cb_FileTitle */
const char* cb_DEFCALL cb_FileTitle (const char *sfName)
{
  register const char* s; s = sfName;
  register cb_Integer i; i = cb_StrLen(s); s += i;

  while (s!=sfName) {
    s--;
    if (s[0]=='/' || s[0]=='\\') { s++; break; }
  }

  return s;
}
/* END MODULE */


/* MODULE::cb_GetFileTitle */
char* cb_DEFCALL cb_GetFileTitle (const char *sfName,void *dst,cb_Integer bFlag)
{
  register const char* s; s = sfName;
  register cb_Integer i; i = cb_StrLen(s); s += i;
  register const char* d; d = NULL;

  while (s!=sfName) {
    s--;
    if (s[0]=='/' || s[0]=='\\') {
      s++; i = cb_StrLen(s); if (d) if (!bFlag) i -= cb_StrLen(d);
      break;
    }
    if (!d) if (s[0]=='.') d = s;
  }

  return cb_NewStr_(s,dst,i);
}
/* END MODULE */


/* MODULE::cb_GetFilePath */
char* cb_DEFCALL cb_GetFilePath (const char *sfName,void *dst,cb_Integer iFlag)
{
  register const char* s; s = sfName; s += cb_StrLen(s);
  register cb_Integer i;

  while (s!=sfName) {
    s--;
    if (s[0]=='/' || s[0]=='\\') { s += iFlag; i = (cb_Integer)s; s = sfName; i -= (cb_Integer)s; goto Exit0000; }
  }
  i = 0;

Exit0000:
  return cb_NewStr_(s,dst,i);
}
/* END MODULE */


/* MODULE::cb_FileExist */
cb_UInteger cb_DEFCALL cb_FileExist (const char *fName, void *dst)
{
  register intptr_t hFile;
  register WIN32_FIND_DATA *Buf;
  register cb_UInteger i = 0;
  if (fName[0]!=0) {
  Buf = (WIN32_FIND_DATA*)cb_MemAllocM(sizeof(WIN32_FIND_DATA));
  if (Buf) {
    hFile = (intptr_t)FindFirstFile(fName, Buf);
    if (hFile!=(intptr_t)-1) {
      FindClose((HANDLE)hFile);
      i = (cb_UInteger)dst;
      if (i) {
        if (!cb_StrChar(Buf->cFileName, '\\')) if (!cb_StrChar(Buf->cFileName, '/')) {
          hFile = cb_StrLen(fName);
          while (hFile) {
            hFile--;
            if (fName[hFile]=='\\' || fName[hFile]=='/') {
              hFile++;
              cb_MemMove((void*)i,fName,hFile);
              i += hFile;
              break;
            }
          }
        }
        cb_StrCopy((void*)i,Buf->cFileName);
      }
      i = Buf->dwFileAttributes;
      i|=0x40000000;
    }
    cb_MemFreeM(Buf);
  }
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_FileLen */
unsigned long long cb_DEFCALL cb_FileLen (const char *fName)
{
  register intptr_t hFile;
  register WIN32_FIND_DATA *Buf;
  unsigned long long i = 0;
  if (fName[0]!=0) {
  Buf = (WIN32_FIND_DATA*)cb_MemAllocM(sizeof(WIN32_FIND_DATA));
  if (Buf) {
    hFile = (intptr_t)FindFirstFile(fName, Buf);
    if (hFile!=(intptr_t)-1) {
      ((signed int*)&i)[0] = (signed int)(Buf->nFileSizeLow);
      ((signed int*)&i)[1] = (signed int)(Buf->nFileSizeHigh);
      FindClose((HANDLE)hFile);
    }
    cb_MemFreeM(Buf);
  }
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_GetFileTime */
long long cb_DEFCALL cb_GetFileTime (const char *fName,long long *dCreate,long long *dAccess)
{
  register long long i = 0;
  register WIN32_FIND_DATA *Buf;
  register HANDLE hFile;

  if (fName[0]!=0) {
  Buf = (WIN32_FIND_DATA*)cb_MemAllocM(sizeof(WIN32_FIND_DATA));
  if (Buf) {
    hFile = FindFirstFile(fName, Buf);
    if (hFile!=INVALID_HANDLE_VALUE) {
      FindClose(hFile);
      if (dCreate) *dCreate = *(long long*)&(Buf->ftCreationTime);
      if (dAccess) *dAccess = *(long long*)&(Buf->ftLastAccessTime);
      i = *(long long*)&(Buf->ftLastWriteTime);
    }
    cb_MemFreeM(Buf);
  }
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_SetFileTime */
cb_Boolean cb_DEFCALL cb_SetFileTime (const char *fName,long long dWrite,long long dCreate,long long dAccess)
{
  register cb_Boolean i = FALSE;
  register HANDLE hFile;
  register FILETIME *pWrite, *pCreate, *pAccess;

  if (fName[0]!=0) {
    hFile = CreateFile(fName,FILE_GENERIC_READ | FILE_GENERIC_WRITE,0,NULL,OPEN_EXISTING,0,NULL);
    if (hFile!=INVALID_HANDLE_VALUE) {
      if (dWrite>0) pWrite = (FILETIME*)(&dWrite); else pWrite = NULL;
      if (dCreate>0) pCreate = (FILETIME*)(&dCreate); else pCreate = NULL;
      if (dAccess>0) pAccess = (FILETIME*)(&dAccess); else pAccess = NULL;
      i = SetFileTime(hFile,pCreate,pAccess,pWrite);
      CloseHandle(hFile);
    }
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_FileLocked */
cb_Boolean cb_DEFCALL cb_FileLocked (const char *fName)
{
  cb_File* fp1 = cb_FileOpen(fName,_O_RDWR|_O_BINARY);
  if (fp1) cb_FileClose(fp1);
  else if (cb_ISFILE(fName,NULL)) return TRUE;
  return FALSE;
}
/* END MODULE */


/* MODULE::cb_Loc */
cb_UInteger cb_DEFCALL cb_Loc (cb_File* fp, cb_Integer fplen, cb_Integer flag1)
{
  register cb_UInteger RetVar, i;
  if (flag1) { i = cb_FileTell(fp); RetVar = cb_FileSeek(fp,0,SEEK_END); }
  else RetVar = cb_FileTell(fp);
  if (flag1) cb_FileSeek(fp, i, SEEK_SET);
  if (fplen<=0) fplen = *(cb_Integer*)(((cb_cString*)fp)->m_Len);
  if (fplen>1) RetVar %= (cb_UInteger)fplen;
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_Loc64 */
long long cb_DEFCALL cb_Loc64 (cb_File* fp, cb_Integer fplen, cb_Integer flag1)
{
  register unsigned long long RetVar, i;
  if (flag1) { i = cb_FileTell64(fp); RetVar = cb_FileSeek64(fp,0,SEEK_END); }
  else RetVar = cb_FileTell64(fp);
  if (flag1) cb_FileSeek64(fp, i, SEEK_SET);
  if (fplen<=0) fplen = *(cb_Integer*)(((cb_cString*)fp)->m_Len);
  if (fplen>1) RetVar %= (cb_UInteger)fplen;
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_FStrGet */
char * cb_DEFCALL cb_FStrGet (cb_File* f, void *buf, void *iRead, cb_Integer sze)
{
  register cb_Integer i = sze;  if (i<0) i = 0;
  register char *d = (char*)buf;
  if (d==NULL || d==(char*)-1) d = cb_NewStr_(NULL,d,i);
  if (d==NULL) {
    i = -1;
  }
  else {
    if (i>0) {
      if (f==(cb_File*)-1) f = cb_StdIn;
      i = cb_FileGetS(f, d, i);
      if (i!=-1) {
        d += i; do { i--; if (i<0) break; d--; if (*d!='\n' && *d!='\r') { d++; break; } } while(1); *d = 0; i++; d -= i;
      }
      else {
        d[0] = 0;
        d = NULL; i = 0;
      }
    }
    else d[0] = 0;
  }
  if (iRead) *(cb_Integer*)iRead = i;
  return d;
}
/* END MODULE */


/* MODULE::cb_FStrPeek */
char * cb_DEFCALL cb_FStrPeek (cb_File* f, void *buf, void *iRead, cb_Integer sze)
{
  register char *i;
  register cb_UInteger pos1 = cb_FileTell(f);
  i = cb_FStrGet(f,buf,iRead,sze);
  cb_FileSeek(f,pos1,SEEK_SET);
  return i;
}
/* END MODULE */


/* MODULE::cb_FGet */
char * cb_DEFCALL cb_FGet (cb_File* f, void *b, void *iRead, cb_UInteger sze, cb_UInteger ofs1)
{
  register char *buf;
  register cb_UInteger i;
  i = sze; if (i>=(cb_UInteger)-2) { i = cb_Lof(f); if (i>=(cb_UInteger)-2 || i<ofs1) goto Error001; i -= ofs1; }
  buf = (char*)b;
  if (buf==NULL) buf = cb_TmpDynStr(i);
  else if (buf==(char*)-1) buf = (char*)cb_MemAllocM(i+sizeof(cb_Integer));
  if (buf==NULL) goto Error0000;
  if (ofs1) if (cb_FileSeek(f,ofs1,SEEK_SET)==-1) goto Error000;
  i = cb_FileRead(f, buf, i);
  if (i==-1) { Error000: if (b==(void*)-1) cb_MemFreeM(buf); Error001: buf = NULL; Error0000: i = 0; }
  else if (b==NULL || b==(void*)-1) *(short*)(buf+i) = 0;
  if (iRead) *(cb_UInteger*)iRead = i;
  return buf;
}
/* END MODULE */


/* MODULE::cb_FPeek */
char * cb_DEFCALL cb_FPeek (cb_File* f, void *b, void *iRead, cb_UInteger sze, cb_UInteger ofs1)
{
  register cb_UInteger pos1 = cb_FileTell(f);
  register char *i = cb_FGet(f,b,iRead,sze,ofs1);
  cb_FileSeek(f,pos1,SEEK_SET);
  return i;
}
/* END MODULE */


/* MODULE::cb_InputB */
char * cb_DEFCALL cb_InputB (cb_File* h,cb_UInteger sze,void *b,void *iRead,cb_UInteger ofs1)
{
  return cb_FGet(h,b,iRead,sze,ofs1);
}
/* END MODULE */


/* MODULE::cb_LoadFile */
char* cb_DEFCALL cb_LoadFile (const char *fName, void *dst, void *Sze, cb_UInteger len1, cb_UInteger ofs1)
{
  register cb_File* fp1;
  register char *RetVar = NULL;

  fp1 = cb_FileOpen(fName,_O_RDONLY | _O_BINARY);
  if (fp1) {
    RetVar = cb_FGet(fp1,dst,Sze,len1,ofs1);
    cb_FileClose(fp1);
  }

  return RetVar;
}
/* END MODULE */


/* MODULE::cb_FPut */
cb_UInteger cb_DEFCALL cb_FPut (cb_File* f, const void *buf, cb_UInteger sze, cb_UInteger ofs1, cb_Integer flag1)
{
  register cb_UInteger i, j, pos1;
  i = sze; if (i>=(cb_UInteger)-2) i = cb_StrLen((char*)buf);
  if (i) {
    if (flag1) { pos1 = cb_FileTell(f); if (pos1==-1) return -1; }
    if (ofs1) if (cb_FileSeek(f,ofs1,SEEK_SET)==-1) return -1;
    i = cb_FileWrite(f, buf, i);
    if (flag1) cb_FileSeek(f,pos1,SEEK_SET);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_SaveFile */
cb_UInteger cb_DEFCALL cb_SaveFile (const char *N, const void *B, cb_UInteger Sze)
{
  register cb_File* fp1;
  register cb_UInteger RetVar = -1;
  if ((fp1=cb_FileOpen(N,_O_WRONLY | _O_CREAT | _O_BINARY))!=0) {
    RetVar = cb_FPut(fp1,B,Sze);
    cb_FileFlush(fp1); cb_FileClose(fp1);
  }
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_FindFileInPath */
char* cb_DEFCALL cb_FindFileInPath (const char* Str1,const char* Str2,const char* sExt,void *dst)
{
  register char *sTmp = (char*)dst;
  register char *P = (char*)Str2;
  register cb_Integer i;
  register cb_Integer iLen;
  const char *sEx;
  cb_Integer i1, i2, i3;
  cb_Integer bFolder;
  if (sExt!=(const char*)-1) bFolder = FALSE;
  else { sExt++; bFolder = TRUE; }

  i = cb_StrLen(P); iLen = i;
  while (i) {
    i--;
    if (P[i]=='.') { if (sExt) if (sExt[0]!='.') sExt = NULL; i++; if (i==iLen) iLen--; break; }
    if (P[i]=='\\' || P[i]=='/') { i++; if (*(signed int*)(P+i)=='*.*') bFolder++; break; }
  }
  if (P[0]=='\\' || P[0]=='/' || P[1]==':') {
    if (!sTmp || sTmp==(char*)-1) return cb_NewStr_(P,sTmp,iLen);
    cb_MemMove(sTmp,P,iLen); sTmp[iLen] = 0; return sTmp;
  }
  P = cb_NewStr_(NULL,sTmp,0x0800);
  if (!P) {
    if (!sTmp) {
      P = cb_EMPTYSTR;
    }
    else if (sTmp!=(char*)-1) { sTmp[0] = 0; P = sTmp; }
    goto Exit0001;
  }
  sTmp = (char*)Str1;
  while (sTmp[0]!=0) {
    i = cb_InChar(sTmp,';');
    if (i) {
      if (i>0) i1 = i;
      else { i = cb_StrLen(sTmp)-1; i1 = i; i++; }
      if (i<0x0800) {
        cb_MemCopy(P,sTmp,i);
        i--;
        if (sTmp[i]!='\\' && sTmp[i]!='/') {
          i++;
          P[i] = cb_PATH_SEPARATOR;
        }
        i++;
        if (i+iLen<0x0800) {
          cb_MemCopy(P+i,Str2,iLen); i += iLen; P[i] = 0;
          if (!bFolder) { if (cb_ISFILE(P,NULL)) { i++; goto Exit0000; } }
          else if (cb_FileExist(P,NULL)) { i++; goto Exit0000; }
          if (sExt) {
            i3 = i; sEx = sExt;
            while (sEx[0]) {
              i = cb_InChar(sEx,';');
              if (i) {
                if (i<0) i = cb_StrLen(sEx);
                i2 = i3; if (sEx[0]!='.') { P[i2] = '.'; i2++; }
                if (i+i2<0x0800) {
                  cb_MemCopy(P+i2,sEx,i); P[i2+i] = 0;
                  if (!bFolder) { if (cb_ISFILE(P,NULL)) { i += i2; i++; goto Exit0000; } }
                  else if (cb_FileExist(P,NULL)) { i += i2; i++; goto Exit0000; }
                }
                sEx += i; if (sEx[0]==0) break;
              }
              sEx++;
            }
          }
        }
      }
      sTmp += i1;
    }
    sTmp++;
  }
  P[0] = 0; i = 1;

Exit0000:
  sTmp = (char*)dst;
  if (sTmp) if (sTmp!=(char*)-1) { cb_MemCopy(sTmp, P, i); cb_MemFreeM(P); P = sTmp; }

Exit0001:
  return P;
}
/* END MODULE */


/* MODULE::cb_MkDirEx */
cb_Integer cb_DEFCALL cb_MkDirEx (const char *sDir1)
{
  register cb_Integer i = cb_StrLen(sDir1)+1;
  register cb_Integer l;
  register char *Str1 = (char*)cb_MemAllocM(i);
  cb_MemCopy(Str1, sDir1, i);
  i=0;
  do {
    l=i;
    i=cb_InCharEx(Str1,cb_PATH_SEPARATOR,i);
    if (i<0) i=cb_InCharEx(Str1,'/',l);
    if (i>=0) {
      if (i==0) goto Cont0000;
      if (Str1[i-1]==':') goto Cont0000;
      Str1[i]=0;
    }
    if (!(cb_FileExist(Str1, 0) & _A_SUBDIR)) {
      l = cb_MkDir(Str1); if (l) break;
    }
    if (i<0) {
      l = 0;
      break;
    }
    Str1[i]=cb_PATH_SEPARATOR;
Cont0000:
    i++;
  }while(1);
  cb_MemFreeM(Str1);
  return l;
}
/* END MODULE */


/* MODULE::cb_GetCurrentDir */
char * cb_DEFCALL cb_GetCurrentDir (cb_Integer flag1,void *dst)
{
  register cb_Integer i;
  register char *sTmp = (char*)dst;
  if (!sTmp || (sTmp==(char*)-1)) { sTmp = cb_NewStr_(NULL,sTmp,0x0800); if (!sTmp) goto Exit0000; }
  GetCurrentDirectory(0x0800,sTmp);
  i = cb_StrLen(sTmp);
  if (i) {
    i--;
    if (sTmp[i]!='\\' && sTmp[i]!='/') {
      if (flag1>0) { i++; *((short*)(sTmp+i)) = cb_PATH_SEPARATOR; }
    }
    else { i += flag1; sTmp[i] = 0; }
  }
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_SetCurrentDir */
cb_Integer cb_DEFCALL cb_SetCurrentDir (const void *sDir,cb_Integer flag1)
{
  register cb_Integer i;
  register const char *sTmp = (const char*)sDir;
  if (flag1) if (sTmp[1]==':') { i = sTmp[0]; if (i>='a' && i<='z') i -= 32; if (i>='A' && i<='Z') cb_ChDrive(i+1-'A'); }
  return cb_ChDir(sTmp);
}
/* END MODULE */


/* MODULE::cb_GetDir */
char * cb_DEFCALL cb_GetDir (cb_Integer drv,cb_Integer flag1,void *dst)
{
  register cb_Integer i, j;
  register char *sTmp = (char*)dst;

  i = drv; if (i>0) { j = cb_GetDrive(); if (cb_ChDrive(i)) { if (!sTmp) sTmp = cb_EMPTYSTR; else if (sTmp==(char*)-1) sTmp = cb_NewStr_(NULL,sTmp,0); else sTmp[0] = 0; goto Exit0000; } }
  sTmp = cb_GetCurrentDir(flag1, sTmp);
  if (i>0) { Exit0000:; cb_ChDrive(j); }
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_GetTempDir */
char * cb_DEFCALL cb_GetTempDir (cb_Integer flag1,void *dst)
{
  register cb_Integer i;
  register char *sTmp = (char*)dst;
  if (!sTmp || (sTmp==(char*)-1)) { sTmp = cb_NewStr_(NULL,sTmp,0x0800); if (!sTmp) goto Exit0000; }
  GetTempPath (0x0800,sTmp);
  i = cb_StrLen(sTmp);
  if (i) {
    i--;
    if (sTmp[i]!='\\' && sTmp[i]!='/') {
      if (flag1) { i++; *((short*)(sTmp+i)) = cb_PATH_SEPARATOR; }
    }
    else if (!flag1)
      sTmp[i] = 0;
  }
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_GetTempFileName */
cb_File* cb_DEFCALL cb_GetTempFileName (const char *sFolder,const char *sPrefix,const char *sSuffix,void *dst,cb_Integer n)
{
  register char *sTmp = (char*)dst;
  register char *sTmp1 = (char*)sFolder;
  register cb_Integer i;
  register cb_File* fp1;

  n &= _O_APPEND | _O_CREAT | _O_OPEN | _O_TRUNC | _O_RDWR | _O_BINARY | _O_TEMPORARY;

  if (!sTmp1) sTmp1 = cb_GetTempDir(FALSE,sTmp);
  else if (!sTmp1[0]) sTmp1 = cbApp_EXEPath(FALSE,sTmp);
  i = cb_StrLen(sTmp1);
  if (sTmp1!=sTmp) sTmp1 = (char*)cb_MemMove(sTmp,sTmp1,i);
  for (;i;i--) { if (sTmp1[0]=='\\') sTmp1[0] = '/'; sTmp1++; }
  if (sTmp1[-1]!='/') { *(cb_Integer*)sTmp1 = '/'; sTmp1++; }
  if (sPrefix) { i = cb_StrLen(sPrefix); if (i) { cb_MemCopy(sTmp1, sPrefix, i); sTmp1 += i; } }
  else { sTmp1[0] = (char)cb_RandFunc('a','z'); sTmp1++; }
  if (!sSuffix) sSuffix = ".tmp";
  i = cb_Rand();
  do {
    cb_CStr(i,16,sTmp1);
    cb_StrCopy(sTmp1+cb_StrLen(sTmp1), sSuffix);
    if (!cb_FileExist(sTmp)) {
      return cb_FileOpen(sTmp,n);
    }
    i++;
  } while (i);
  return NULL;
}
/* END MODULE */


/* MODULE::cb_TempFileName */
char * cb_DEFCALL cb_TempFileName (const char *sFolder,const char *sPrefix,const char *sSuffix,void *dst)
{
  register char *sTmp = (char*)dst;
  register char *sTmp1 = (char*)sFolder;
  register cb_Integer i;

  if (!sTmp || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(NULL,sTmp,0x0800);
    if (!sTmp) { if (!dst) return cb_TempName((void*)-2,sTmp1); goto Exit0000; }
  }
  if (sTmp1==(char*)-1) { sTmp1++; i = ~_O_TEMPORARY; } else i = -1;
  if (sSuffix==(const char*)-2) sSuffix = cb_EMPTYSTR;
  else { dst = NULL; if (sSuffix==(const char*)-1) sSuffix++; }
  sTmp1 = (char*)cb_GetTempFileName(sTmp1,sPrefix,sSuffix,sTmp,i);
  if (sTmp==(char*)dst) { if (!sTmp1) sTmp[0] = 0; return sTmp1; }
  if (sTmp1) cb_FileClose((cb_File*)sTmp1);
  else sTmp[0] = 0;
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_MkTempDirEx */
char * cb_DEFCALL cb_MkTempDirEx (const char *sFolder,const char *sPrefix,void *dst,cb_Integer flag1)
{
  register cb_Integer i;
  register char *sTmp = (char*)dst;
  register char *sTmp1;
  if (!sTmp || (sTmp==(char*)-1)) { sTmp = cb_NewStr_(NULL,sTmp,0x0800); if (!sTmp) goto Exit0000; }
  sTmp1 = (char*)sFolder;
  if (sTmp1!=0 && sTmp1[0]!=0) cb_MkDirEx(sTmp1);
  i = (cb_Integer)cb_TempFileName(sTmp1,sPrefix,(const char*)-2,sTmp);
  if (i) cb_FileClose((cb_File*)i);
  i = cb_StrLen(sTmp);
  if (i>0) {
    cb_MkDir(sTmp);
    i--;
    if (sTmp[i]!='\\' && sTmp[i]!='/') {
      if (flag1) { i++; *((short*)(sTmp+i)) = cb_PATH_SEPARATOR; }
    }
    else if (!flag1)
      sTmp[i] = 0;
  }
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_SplitPath */
char * cb_DEFCALL cb_SplitPath (const void *FPath, void *dst, cb_Integer mask)
{
  register char *RetVar=(char*)dst, *sBuf;
  register cb_Integer i;
#define MysDrv_ sBuf
#define MysPath_ MysDrv_+64
#define MysName_ MysPath_+FILENAME_MAX
#define MysExt_ MysName_+FILENAME_MAX
  if (!RetVar || RetVar==(char*)-1) {
    i = cb_StrLen((const char*)FPath)+sizeof(cb_Integer);
    RetVar = cb_NewStr_(NULL,RetVar,i);
    if (!RetVar) { if (!dst) return cb_EMPTYSTR; goto Exit0000; }
  }
  sBuf = (char*)cb_MemAllocM(64+FILENAME_MAX+FILENAME_MAX+FILENAME_MAX);
  if (sBuf) {
    cb_SplitPath_((const char*)FPath,MysDrv_,MysPath_,MysName_,MysExt_);
    RetVar[0] = 0;
    if (mask & 1) cb_StrCopy(RetVar,MysDrv_);
    if (mask & 2) cb_StrCat(RetVar,MysPath_);
    if (mask & 4) cb_StrCat(RetVar,MysName_);
    if (mask & 8) cb_StrCat(RetVar,MysExt_);
    if ((mask & (2|4|8|16))==(2|16)) {
      i = cb_StrLen(RetVar) - 1;
      if (i>=0) if (RetVar[i]=='\\' || RetVar[i]=='/') RetVar[i] = 0;
    }
    cb_MemFreeM(sBuf);
  }
Exit0000:
  return RetVar;
#undef MysDrv_
#undef MysPath_
#undef MysName_
#undef MysExt_
}
/* END MODULE */


/* MODULE::cb_SetFileTitle */
char * cb_DEFCALL cb_SetFileTitle (const void *src, const void *FTitle, void *dst)
{
  register char *RetVar=(char*)src;
  register cb_Integer i = cb_StrLen(RetVar), j;
  register char *title1;
  while(i) {
    i--;
    if (RetVar[i]=='\\' || RetVar[i]=='/') { i++; break; }
  }
  RetVar = (char*)dst;
  title1 = (char*)FTitle;
  if (!title1 || !title1[0]) {
    if (!RetVar) {
      RetVar = cb_TmpDynStr(i);
      if (!RetVar) return cb_EMPTYSTR;
      goto Cont0000;
    }
    if (RetVar==(char*)-1) {
      RetVar = (char*)cb_MemAllocM(i+sizeof(cb_Integer));
      if (!RetVar) goto Exit0000;
    }
Cont0000:
    cb_MemMove(RetVar,src,i); RetVar[i] = 0;
  }
  else {
    j = cb_StrLen(title1);
    if (!RetVar) {
      RetVar = cb_TmpDynStr(i+j);
      if (!RetVar) return cb_EMPTYSTR;
      goto Cont00;
    }
    if (RetVar==(char*)-1) {
      RetVar = (char*)cb_MemAllocM(i+j+sizeof(cb_Integer));
      if (!RetVar) goto Exit0000;
    }
Cont00:
    cb_MemMove(RetVar,src,i);
    cb_MemCopy(RetVar+i,title1,j); i += j; RetVar[i] = 0;
  }
Exit0000:
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_SetFilePath */
char * cb_DEFCALL cb_SetFilePath (const void *src, const void *FPath, void *dst)
{
  register char *RetVar=(char*)src;
  register cb_Integer i = cb_StrLen(RetVar), i1 = i, j;
  register char *path1;
  while(i) {
    i--;
    if (RetVar[i]=='\\' || RetVar[i]=='/') { i++; break; }
  }
  i1 -= i;
  RetVar = (char*)dst;
  path1 = (char*)FPath;
  if (!path1 || !path1[0]) {
    if (!RetVar) {
      RetVar = cb_TmpDynStr(i1);
      if (!RetVar) return cb_EMPTYSTR;
      goto Cont0000;
    }
    if (RetVar==(char*)-1) {
      RetVar = (char*)cb_MemAllocM(i1+sizeof(cb_Integer));
      if (!RetVar) goto Exit0000;
    }
Cont0000:
    cb_StrMove(RetVar,((char*)src)+i);
  }
  else {
    j = cb_StrLen(path1) - 1;
    if (path1[j]!='\\' && path1[j]!='/') j++;
    if (!RetVar) {
      RetVar = cb_TmpDynStr(i1+j+1);
      if (!RetVar) return cb_EMPTYSTR;
      goto Cont00;
    }
    if (RetVar==(char*)-1) {
      RetVar = (char*)cb_MemAllocM(i1+j+1+sizeof(cb_Integer));
      if (!RetVar) goto Exit0000;
    }
Cont00:
    cb_StrMove(RetVar+j+1,((char*)src)+i);
    cb_MemCopy(RetVar,path1,j); RetVar[j] = cb_PATH_SEPARATOR;
  }
Exit0000:
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_FixPath */
char * cb_DEFCALL cb_FixPath (const char *Str1, void *dst)
{
  register char *sTmp = (char*)dst;
  register cb_Integer i, j;

  if (!sTmp || sTmp==(char*)-1) {
    sTmp = cb_NewStr(Str1,sTmp);
    if (!sTmp) { if (!dst) return cb_EMPTYSTR; goto Exit0000; }
  }
  else if (sTmp!=Str1) {
    cb_StrMove(sTmp, Str1);
  }
  j = 0;
  do {
    i = cb_InChar(sTmp+j, '.'); if (i<0) break;
    i += j; j = i; i++; sTmp += i; if (sTmp[0]=='.') { i++; sTmp++; }
    if (sTmp[0]!='\\' && sTmp[0]!='/' && sTmp[0]!=0) { sTmp -= i; break; }
    sTmp -= i; i -= j;
    if (j==0) {
      i++;
      j += i;
    }
    else {
      j--;
      if (sTmp[j]!='\\' && sTmp[j]!='/') {
        i += 2;
        j += i;
      }
      else {
        if (i==1) { j++; i = j; i++; }
        else {
          i = j; j = cb_InCharRev(sTmp, cb_PATH_SEPARATOR, i);
          if (j<0) j = cb_InCharRev(sTmp, '/', i);
          j++; i += 3;
        }
        if (sTmp[i]==0) { sTmp[j] = 0; break; }
        i++; cb_StrCopy(sTmp+j, sTmp+i);
      }
    }
  } while(1);
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_NormalizePath */
char * cb_DEFCALL cb_NormalizePath (const char *Str1, void *dst, const char *sBase)
{
  register char* MyPtr1; MyPtr1 = (char*)Str1;
  register char* MyPtr2; MyPtr2 = NULL;
  register cb_Integer i;

  if (MyPtr1[1]!=':' || (MyPtr1[2]!='/' && MyPtr1[2]!='\\')) {
    MyPtr2 = (char*)cb_MemAllocM(0x0800<<1);
    if (MyPtr1[0]=='/' || MyPtr1[0]=='\\') {
      if (sBase) if (sBase[1]==':') { *(cb_Integer*)MyPtr2 = (sBase[0] & (~0x20)) + (':'*256); goto Cont0000; }
      *(cb_Integer*)MyPtr2 = cb_GetDrive()+'A'+(':'*256);
Cont0000:;
      cb_StrCopy(MyPtr2+2,MyPtr1);
    }
    else {
      if (MyPtr1[1]==':') {
        cb_GetDir((MyPtr1[0]|0x20)+1-'a',1,MyPtr2);
        MyPtr1 += 2;
        goto StrLen0000;
      }
      if (sBase) {
        i = cb_StrLen(sBase);
        cb_MemCopy(MyPtr2,sBase,i);
        i--; if (MyPtr2[i]!='/') if (MyPtr2[i]!='\\') { i++; MyPtr2[i] = cb_PATH_SEPARATOR; }
        i++;
      }
      else {
        cb_GetCurrentDir(1, MyPtr2);
StrLen0000:;
        i = cb_StrLen(MyPtr2);
      }
      cb_StrCopy(MyPtr2+i,MyPtr1);
    }
  }

  MyPtr1 = (char*)dst;
  if (MyPtr1==(char*)-1) {
    if (MyPtr2) MyPtr1 = MyPtr2;
    else MyPtr1 = cb_NewStr_(Str1,(void*)-1,cb_StrLen(Str1));
  }
  else if (MyPtr1==NULL) {
    if (MyPtr2) { MyPtr1 = MyPtr2; cb_AddTmpDynStr_(MyPtr1); }
    else MyPtr1 = cb_NewStr_(Str1,NULL,cb_StrLen(Str1));
  }
  else {
    if (MyPtr2) { cb_StrCopy(MyPtr1,MyPtr2); cb_MemFreeM(MyPtr2); }
    else cb_StrMove(MyPtr1,Str1);
  }

  return MyPtr1;
}
/* END MODULE */


/* MODULE::cb_FindFirst */
char * cb_DEFCALL cb_FindFirst (const char *filespec, void *dst, cb_FIND_DATA *find1, cb_Integer maskflag)
{
  register cb_UInteger i;
  register cb_FIND_DATA *p = find1; if (p==NULL) p = &cbApp_FindData;
  register char *sTmp;
  register cb_Integer j;
  cb_Integer bPath;

  sTmp = (char*)filespec;
  if (sTmp) {
    if (!*sTmp) goto Error0000;
    if (find1==NULL) if (p->FileHandle != INVALID_HANDLE_VALUE) FindClose(p->FileHandle);
    p->FileHandle = FindFirstFile(sTmp,p);
    if (p->FileHandle != INVALID_HANDLE_VALUE) {
      bPath = maskflag; maskflag &= cb_MAX_INTEGER;
      do {
        if (!(p->dwFileAttributes & maskflag)) {
          if (sTmp[1]!=':') { cb_GetCurrentDir(1, p->sPath); if (sTmp[0]=='\\' || sTmp[0]=='/') i = 2; else i = cb_StrLen(p->sPath); }
          else if (sTmp[2]=='\\' || sTmp[2]=='/') i = 0;
          else { i = *sTmp; i &= ~32; i -= 'A'-1; cb_GetDir(i, 1, p->sPath); i = cb_StrLen(p->sPath); sTmp += 2; }
          cb_SplitPath(sTmp, p->sPath+i, 1|2);
          j = cb_StrLen(p->sPath);
          sTmp = (char*)dst;
          if (sTmp==NULL || sTmp==(char*)-1) {
            i = cb_StrLen(p->cFileName);
            if (bPath<0) i += j;
            sTmp = cb_NewStr_(NULL,sTmp,i); if (!sTmp) break;
          }
          if (bPath<0) cb_MemCopy(sTmp,p->sPath,j); else j = 0;
          cb_StrCopy(sTmp+j,p->cFileName);
          goto Exit0000;
        }
      } while(FindNextFile(p->FileHandle,p));
Error0000:
      FindClose(p->FileHandle);
      p->FileHandle = INVALID_HANDLE_VALUE;
    }
  }

  sTmp = (char*)dst;
  if (!sTmp)
    sTmp = cb_EMPTYSTR;
  else {
    if (sTmp==(char*)-1) sTmp = (char*)cb_MemAllocM(sizeof(cb_Integer));
    sTmp[0] = 0;
  }
  p->cFileName[0]=0;
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_FindNext */
char * cb_DEFCALL cb_FindNext (void *dst, cb_FIND_DATA *find1, cb_Integer maskflag)
{
  register cb_UInteger i;
  register cb_FIND_DATA *p = find1; if (p==NULL) p = &cbApp_FindData;
  register char *sTmp = (char*)dst;
  register cb_Integer j;
  cb_Integer bPath;

  if (p->FileHandle != INVALID_HANDLE_VALUE) {
    bPath = maskflag; maskflag &= cb_MAX_INTEGER;
Again0000:
    if (FindNextFile(p->FileHandle,p)) {
      if (p->dwFileAttributes & maskflag) goto Again0000;
      j = cb_StrLen(p->sPath);
      if (sTmp==NULL || sTmp==(char*)-1) {
        i = cb_StrLen(p->cFileName);
        if (bPath<0) i += j;
        sTmp = cb_NewStr_(NULL,sTmp,i); if (!sTmp) { sTmp=(char*)dst; goto Error0000; }
      }
      if (bPath<0) cb_MemCopy(sTmp,p->sPath,j); else j = 0;
      cb_StrCopy(sTmp+j,p->cFileName);
      goto Exit0000;
    }
Error0000:
    FindClose(p->FileHandle);
    p->FileHandle = INVALID_HANDLE_VALUE;
  }

  if (!sTmp)
    sTmp = cb_EMPTYSTR;
  else {
    if (sTmp==(char*)-1) sTmp = (char*)cb_MemAllocM(sizeof(cb_Integer));
    sTmp[0] = 0;
  }
  p->cFileName[0]=0;
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_FolderScan */
static cb_Integer cb_DEFCALL cb_FolderScan_ (const void *sPath1,cb_Integer (cb_CDECL *MySub1)(const void*,const char*,const cb_FIND_DATA*),const void *UserData1,cb_Integer (cb_CDECL *MySub2)(const void*,const char*,const cb_FIND_DATA*),const void *UserData2,cb_Integer bFolder)
{
  register char *TempStr1, *TempStr2;
  register cb_FIND_DATA *pFindFirst = (cb_FIND_DATA*)cb_MemAllocM(sizeof(cb_FIND_DATA)); if (!pFindFirst) return -3;
  register HANDLE RetVar;
  cb_Integer i;

  TempStr1 = NULL;

  RetVar = FindFirstFile((const char*)sPath1,pFindFirst);
  if (RetVar!=INVALID_HANDLE_VALUE) {
    do {
      TempStr1 = pFindFirst->cFileName;
      TempStr2 = pFindFirst->sPath;
      if ((pFindFirst->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)!=0) {
        if (TempStr1[0]=='.') if (TempStr1[1]==0 || *(short*)(TempStr1+1)=='.') continue;
        i = cb_InCharRev(sPath1,'\\') + 1; if (i<=0) i = cb_InCharRev(sPath1,'/') + 1;
        cb_StrCat(cb_NewStr_(sPath1,TempStr2,i),TempStr1);
        if (bFolder) {
          if (MySub2) if (bFolder<0) if (MySub2(UserData2,TempStr2,pFindFirst)) goto Error0000;
          i = cb_StrLen(TempStr2); cb_StrCopy(TempStr2+i, "\\*.*");
          if (cb_FolderScan_(TempStr2,MySub1,UserData1,MySub2,UserData2,bFolder)<=-2) goto Error0000;
          if (MySub2) if (bFolder>0) { TempStr2[i] = 0; if (MySub2(UserData2,TempStr2,pFindFirst)) goto Error0000; }
        }
      }
      else {
        i = cb_InCharRev(sPath1,'\\') + 1; if (i<=0) i = cb_InCharRev(sPath1,'/') + 1;
        cb_StrCat(cb_NewStr_(sPath1,TempStr2,i),TempStr1);
        if (MySub1(UserData1,TempStr2,pFindFirst)) {
Error0000:
          FindClose(RetVar);
          TempStr1 = (char*)-2;
          goto Exit0000;
        }
      }
    }while(FindNextFile(RetVar,pFindFirst));
    TempStr1 = (char*)1;
Exit0000:;
    FindClose(RetVar);
  }

  cb_MemFreeM(pFindFirst);
  return (cb_Integer)TempStr1;
}

cb_Integer cb_DEFCALL cb_FolderScan (const void *sPath1,cb_Integer (cb_CDECL *MySub1)(const void*,const char*,const cb_FIND_DATA*),const void *UserData1,cb_Integer (cb_CDECL *MySub2)(const void*,const char*,const cb_FIND_DATA*),const void *UserData2,cb_Integer bFolder)
{
  return cb_FolderScan_(sPath1,MySub1,UserData1,MySub2,UserData2,bFolder);
}
/* END MODULE */


/* MODULE::cb_FolderScanW */
static cb_Integer cb_DEFCALL cb_FolderScanW_ (const wchar_t *sPath1,cb_Integer (cb_CDECL *MySub1)(const void*,const wchar_t*,const cb_FIND_DATAW*),const void *UserData1,cb_Integer (cb_CDECL *MySub2)(const void*,const wchar_t*,const cb_FIND_DATAW*),const void *UserData2,cb_Integer bFolder)
{
  register wchar_t *TempStr1, *TempStr2;
  register cb_FIND_DATAW *pFindFirst = (cb_FIND_DATAW*)cb_MemAllocM(sizeof(cb_FIND_DATAW)); if (!pFindFirst) return -3;
  register HANDLE RetVar;
  cb_Integer i;

  TempStr1 = NULL;

  RetVar = FindFirstFileW(sPath1,(WIN32_FIND_DATAW*)pFindFirst);
  if (RetVar!=INVALID_HANDLE_VALUE) {
    do {
      TempStr1 = pFindFirst->cFileName;
      TempStr2 = pFindFirst->sPath;
      if ((pFindFirst->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)!=0) {
        if (TempStr1[0]==L'.') if (TempStr1[1]==0 || (TempStr1[1]==L'.' && TempStr1[2]==0)) continue;
        i = cb_InCharRevW(sPath1,'\\') + 1; if (i<=0) i = cb_InCharRevW(sPath1,'/') + 1;
        cb_StrCatW(cb_NewStrW_(sPath1,TempStr2,i),TempStr1);
        if (bFolder) {
          if (MySub2) if (bFolder<0) if (MySub2(UserData2,TempStr2,pFindFirst)) goto Error0000;
          i = cb_StrLenW(TempStr2); cb_StrCopyW(TempStr2+i, "\\*.*");
          if (cb_FolderScanW_(TempStr2,MySub1,UserData1,MySub2,UserData2,bFolder)<=-2) goto Error0000;
          if (MySub2) if (bFolder>0) { TempStr2[i] = 0; if (MySub2(UserData2,TempStr2,pFindFirst)) goto Error0000; }
        }
      }
      else {
        i = cb_InCharRevW(sPath1,'\\') + 1; if (i<=0) i = cb_InCharRevW(sPath1,'/') + 1;
        cb_StrCatW(cb_NewStrW_(sPath1,TempStr2,i),TempStr1);
        if (MySub1(UserData1,TempStr2,pFindFirst)) {
Error0000:
          FindClose(RetVar);
          TempStr1 = (wchar_t*)-2;
          goto Exit0000;
        }
      }
    }while(FindNextFileW(RetVar,(WIN32_FIND_DATAW*)pFindFirst));
    TempStr1 = (wchar_t*)1;
Exit0000:;
    FindClose(RetVar);
  }

  cb_MemFreeM(pFindFirst);
  return (cb_Integer)TempStr1;
}

cb_Integer cb_DEFCALL cb_FolderScanW (const wchar_t *sPath1,cb_Integer (cb_CDECL *MySub1)(const void*,const wchar_t*,const cb_FIND_DATAW*),const void *UserData1,cb_Integer (cb_CDECL *MySub2)(const void*,const wchar_t*,const cb_FIND_DATAW*),const void *UserData2,cb_Integer bFolder)
{
  return cb_FolderScanW_(sPath1,MySub1,UserData1,MySub2,UserData2,bFolder);
}
/* END MODULE */


/* MODULE::cb_CopyFileHandle */
cb_Integer cb_DEFCALL cb_CopyFileHandle (cb_File* fp1,cb_File* fp2,cb_Integer (cb_CDECL *MySub)(const void*,const void*,cb_File*,cb_File*,cb_Integer),const void *UserData,cb_UInteger sze)
{
#define sze_ 0x100000
  register cb_Integer i = FALSE;
  register void *tmp = cb_MemAllocM(16+sze_);
  if (tmp) {
    i = sze_;
    do {
      if ((cb_UInteger)i>sze) { i = sze; if (i<=0) { i = TRUE; break; } }
      if (cb_FileError(fp1)) { i = FALSE; break; }
      if (cb_FileEOF(fp1)) { i = TRUE; break; }
      i = cb_FileRead(fp1,tmp,i);
      if (i<=0) { i |= TRUE; break; }
      if (i!=cb_FileWrite(fp2,tmp,i)) { i = FALSE; break; }
      if (MySub) if (MySub(UserData,tmp,fp1,fp2,i)) { i = -2; break; }
      sze -= i;
    } while(1);
    cb_MemFreeM(tmp);
  }
  return i;
#undef sze_
}
/* END MODULE */


/* MODULE::cb_GetFileState */
cb_Integer cb_DEFCALL cb_GetFileState (const void *File1, cb_FIND_DATA *b)
{
  register cb_FIND_DATA *p = b; if (!p) p = (cb_FIND_DATA*)cb_MemAllocM(sizeof(cb_FIND_DATA));
  register HANDLE h;
  register cb_Integer i = INVALID_FILE_ATTRIBUTES;

  if (p) {
    h = FindFirstFile((const char*)File1,p);
    if (h!=INVALID_HANDLE_VALUE) {
      FindClose(h);

      i = p->dwFileAttributes;
    }
    if (!b) cb_MemFreeM(p);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_SetFileState */
cb_Boolean cb_DEFCALL cb_SetFileState (const void *File1, cb_FIND_DATA *b)
{
  register cb_FIND_DATA *p = b;
  if (SetFileAttributes((const char*)File1,p->dwFileAttributes)) {
    cb_SetFileTime((const char*)File1,*(long long*)(&p->ftLastWriteTime),*(long long*)(&p->ftCreationTime),*(long long*)(&p->ftLastAccessTime));
    return TRUE;
  }
  return FALSE;
}
/* END MODULE */


/* MODULE::cb_CopyFile */
cb_Integer cb_DEFCALL cb_CopyFile (const void *File1,const void *File2,cb_Integer (cb_CDECL *MySub)(const void*,const void*,cb_File*,cb_File*,cb_Integer),const void *UserData,cb_Integer bFail,cb_Integer (cb_CDECL *MyFailSub)(const void*,const void*,const void*))
{
  register cb_Integer i;
  register cb_File* fp1;
  register cb_File* fp2;
  cb_FIND_DATA *st = (cb_FIND_DATA*)cb_MemAllocM(sizeof(cb_FIND_DATA)); if (!st) return 0;
  i = (cb_Integer)File1;
  if (cb_GetFileState((const char*)i, st)==INVALID_FILE_ATTRIBUTES) { i = 0; goto Exit0000; }
  if (bFail & cb_MAX_INTEGER) {
    if (cb_GetFileState((const char*)File2, st)!=INVALID_FILE_ATTRIBUTES) {
      if (MyFailSub) {
        i = MyFailSub(UserData,(const void*)i,File2);
        if (i>0) { i = (cb_Integer)File1; goto Cont0000; }
        if (i==0) { i++; goto Exit0000; }
      }
      i = -1; goto Exit0000;
    }
  }
  if (bFail<0) {
    //todo check/create folder
  }
Cont0000:
  if ((fp1=cb_FileOpen((const void*)i,_O_RDONLY | _O_BINARY | _O_NOINHERIT))==NULL) return 0;
  if ((fp2=cb_FileOpen(File2,_O_WRONLY | _O_CREAT | _O_BINARY | _O_NOINHERIT))==NULL) { cb_FileClose(fp1); return 0; }
  i = cb_CopyFileHandle(fp1, fp2, MySub, UserData);
  cb_FileFlush(fp2); cb_FileClose(fp2); cb_FileClose(fp1);
  cb_SetFileState((const char*)File2,st);
Exit0000:
  cb_MemFreeM(st);
  return i;
}
/* END MODULE */


/* MODULE::cb_CompleteFileName */
char* cb_DEFCALL cb_CompleteFileName (const char *sFile1, const char *sFile2, void *dst, cb_Integer bFlag)
{
  register char *d = (char*)cb_MemAllocM(0x0800);
  register const char *s1 = sFile1;
  register const char *s2 = sFile2;
  register cb_Integer i;

  sFile1 = d;
  do {
Again0000:
    if (s2[0]=='\?') {
      d[0] = s1[0]; s2++; if (d[0]==0) continue;
      if (s2[0]=='.') if (!cb_StrChar(s2+1,'.')) {
        i = cb_InCharRev(s1,'.'); if (i<0) i = cb_StrLen(s1);
        s1 += i; goto Cont0000;
      }
    }
    else if (s2[0]=='*') {
      d[0] = s1[0];
      do {
        if (d[0]==0) {
          s2++; if (s2[0]==0) goto Exit0000;
          if (bFlag) goto Again0000;
          goto Exit000;
        }
        d++;
        s1++;
        d[0] = s1[0];
        if (d[0]=='.') { s2++; if (s2[0]=='.') if (!cb_StrChar(s1+1,'.')) break; s2--; }
      } while (1);
      s2++;
    }
    else {
      d[0] = s2[0]; s2++;
      if (d[0]==s1[0]) goto Chk0000;
      if ((d[0]!='/' && d[0]!='\\') || (s1[0]!='/' && s1[0]!='\\')) {
        if (!bFlag) {
Exit000:
          cb_MemFreeM((void*)sFile1);
          return cb_NewStr_(cb_EMPTYSTR,dst,0);
        }
Chk0000:
        if (d[0]==0) break;
        if (d[0]=='.') if (!cb_StrChar(s2,'.')) {
          i = cb_InCharRev(s1,'.')+1; if (i<=0) i = cb_StrLen(s1);
          s1 += i; goto Cont0000;
        }
      }
      if (s1[0]=='.') { s1++; if (!cb_StrChar(s1,'.')) s1--; goto Cont0000; }
    }
    if (s1[0]) s1++;
Cont0000:
    d++;
  } while(1);
Exit0000:
  d -= (cb_Integer)sFile1; d++; s1 = d;
  d = (char*)dst;
  if (d==NULL) d = cb_AddTmpDynStr_((void*)sFile1);
  else if (d==(char*)-1) d = (char*)sFile1;
  else { cb_MemCopy(d,sFile1,(cb_Integer)s1); cb_MemFreeM((void*)sFile1); }
  return d;
}
/* END MODULE */


/* MODULE::cb__FolderCopy */
__declspec(noinline) cb_Integer cb_CDECL cb__FolderCopy (const void *UserData, const char *Str1, const cb_FIND_DATA *pFindFirst)
{
  register cb_TFileCopy_ *p = (cb_TFileCopy_*)UserData;
  cb_StrCopy(p->fName+p->iLen1, Str1+p->iLen2);
  return cb_MkDir(p->fName);
}

/* END MODULE */


/* MODULE::cb_FileCopyMove_ */
cb_Integer cb_DEFCALL cb_FileCopyMove_ (cb_myFileCopyMoveFunc_ myFunc, const void *UserData, const char *Str1, const cb_FIND_DATA *pFindFirst)
{
  register cb_TFileCopy_ *p = (cb_TFileCopy_*)UserData;
  register char *s;
  register cb_Integer i = p->iLen1;
  if (i>=0) { s = p->fName; cb_StrCopy(s+i, Str1+p->iLen2); }
  else {
    s = (char*)cb_MemAllocM(0x0800);
    i &= 0x7FFFF; cb_MemCopy(s,p->fName,i);
    cb_CompleteFileName(Str1+p->iLen2,p->fName+i,s+i,TRUE);
  }
  i = myFunc(Str1, s, p->MySub, p->UserData, p->bFlag, p->MyFailSub)-1;
  if (s!=p->fName) cb_MemFreeM(s);
  return i;
}
/* END MODULE */


/* MODULE::cb_FolderCopyMove__ */
cb_Integer cb_DEFCALL cb_FolderCopyMove__ (cb_Integer (cb_CDECL *myFunc)(const void*,const char*,const cb_FIND_DATA*), cb_TFileCopy_ *ptr1,const void *sPath1,cb_Integer bFolder)
{
  register cb_TFileCopy_ *p = ptr1;
  register const char *s;
  register cb_Integer i;

  s = (const char*)sPath1; sPath1 = NULL; i = cb_StrLen(s);
  while(i>0) {
    i--;
    if (s[i]=='/' || s[i]=='\\') break;
    if (s[i]=='*' || s[i]=='\?') sPath1 = (const void*)1;
  }
  i = cb_StrLen(p->fName);
  if (p->fName[i-1]!='\\') if (p->fName[i-1]!='/')  if (sPath1) {
    bFolder = FALSE; while (i>0) { i--; if (p->fName[i]=='/' || p->fName[i]=='\\') { i++; break; } }
    i |= cb_MIN_INTEGER;
  }
  p->iLen1 = i;
  return cb_FolderScan(s,myFunc,p,cb__FolderCopy,p,bFolder);
}
/* END MODULE */


/* MODULE::cb_FolderCopyMove_ */
cb_Integer cb_DEFCALL cb_FolderCopyMove_ (cb_Integer (cb_DEFCALL *myFunc)(cb_TFileCopy_*,const void*,cb_Integer), const void *sPath1,const void *sPath2,cb_Integer (cb_CDECL *MySub)(const void*,const void*,cb_File*,cb_File*,cb_Integer),const void *UserData,cb_Integer bFolder)
{
  register cb_Integer i = cb_StrLen((const char*)sPath1)+1;
  register cb_TFileCopy_ *p = (cb_TFileCopy_*)cb_MemAllocM(sizeof(cb_TFileCopy_)+i);
  register char *sBuf = (char*)((cb_Integer)p+sizeof(cb_TFileCopy_)+i);
  cb_MemCopy(sBuf, sPath1, i);
  i-=2;
  if (sBuf[i]=='\\' || sBuf[i]=='/') sBuf[i] = 0;
  cb_StrCopy(p->fName,sPath2);
  i++; p->iLen2 = i;
  p->bFlag = FALSE;
  p->MySub = MySub; p->UserData = UserData;
  i = myFunc(p,sBuf,bFolder?-1:0);
  cb_MemFreeM(p);
  return i;
}
/* END MODULE */


/* MODULE::cb_FolderFileCopyMove_ */
cb_Integer cb_DEFCALL cb_FolderFileCopyMove_ (cb_Integer (cb_DEFCALL *myFunc1)(cb_TFileCopy_*,const void*,cb_Integer), cb_myFileCopyMoveFunc_ myFunc2, const void *sPath1, const void *sPath2, cb_Integer (cb_CDECL *MySub)(const void*,const void*,cb_File*,cb_File*,cb_Integer), const void *UserData, cb_Integer bFlag, cb_Integer (cb_CDECL *MyFailSub)(const void*,const void*,const void*))
{
  register cb_TFileCopy_ *p;
  register cb_Integer i;
  register char *s = (char*)sPath1; sPath1 = NULL;

  i = cb_StrLen(s);
  while(i>0) {
    i--;
    if (s[i]=='/' || s[i]=='\\') { i++; break; }
    if (s[i]=='*' || s[i]=='\?') sPath1 = (const void*)1;
  }
  if (sPath1) {
    p = (cb_TFileCopy_*)cb_MemAllocM(sizeof(cb_TFileCopy_));
    cb_StrCopy(p->fName,sPath2);
    p->iLen2 = i;
    p->bFlag = bFlag;
    p->MySub = MySub; p->UserData = UserData;
    p->MyFailSub = MyFailSub;
    i = myFunc1(p,s,FALSE);
    cb_MemFreeM(p);
    return i;
  }

  p = (cb_TFileCopy_*)s; s += i;
  sPath1 = s; s = (char*)sPath2; sPath2 = NULL;
  i = cb_StrLen(s);
  while(i>0) {
    i--;
    if (s[i]=='/' || s[i]=='\\') { i++; break; }
    if (s[i]=='*' || s[i]=='\?') sPath2 = (const void*)1;
  }
  if (sPath2) s = cb_CompleteFileName((const char*)sPath1,(const char*)s+i,(void*)-1,TRUE);

  i = myFunc2(p, s, MySub, UserData, bFlag, MyFailSub);
  if (sPath2) cb_MemFreeM(s);
  return i;
}
/* END MODULE */


/* MODULE::cb_FolderCopy_ */
__declspec(noinline) static cb_Integer cb_CDECL cb_FileCopy_ (const void *UserData, const char *Str1, const cb_FIND_DATA *pFindFirst)
{
  return cb_FileCopyMove_(cb_CopyFile,UserData,Str1,pFindFirst);
}

__declspec(noinline) cb_Integer cb_DEFCALL cb_FolderCopy_ (cb_TFileCopy_ *ptr1, const void *sPath1, cb_Integer bFolder)
{
  return cb_FolderCopyMove__(cb_FileCopy_,ptr1,sPath1,bFolder);
}
/* END MODULE */


/* MODULE::cb_FolderCopy */
cb_Integer cb_DEFCALL cb_FolderCopy (const void *sPath1, const void *sPath2, cb_Integer (cb_CDECL *MySub)(const void*,const void*,cb_File*,cb_File*,cb_Integer), const void *UserData, cb_Integer bFolder)
{
  return cb_FolderCopyMove_(cb_FolderCopy_,sPath1,sPath2,MySub,UserData,bFolder);
}
/* END MODULE */


/* MODULE::cb_FileCopy */
cb_Integer cb_DEFCALL cb_FileCopy (const void *sPath1, const void *sPath2, cb_Integer (cb_CDECL *MySub)(const void*,const void*,cb_File*,cb_File*,cb_Integer), const void *UserData, cb_Integer bFlag, cb_Integer (cb_CDECL *MyFailSub)(const void*,const void*,const void*))
{
  return cb_FolderFileCopyMove_(cb_FolderCopy_,cb_CopyFile,sPath1,sPath2,MySub,UserData,bFlag,MyFailSub);
}
/* END MODULE */


/* MODULE::cb_MoveFile */
__declspec(noinline) cb_Integer cb_DEFCALL cb_MoveFile (const void *File1,const void *File2,cb_Integer (cb_CDECL *MySub)(const void*,const void*,cb_File*,cb_File*,cb_Integer),const void *UserData,cb_Integer bFail,cb_Integer (cb_CDECL *MyFailSub)(const void*,const void*,const void*))
{
  register cb_Integer i = (cb_Integer)File1;
  if (*(const char*)(i+1)==':') if ((*(const char*)i|0x20)!=(*(const char*)File2|0x20)) {
    i = cb_CopyFile((const void*)i, File2, MySub, UserData, bFail, MyFailSub); if (i>0) if (cb_Remove((const char*)File1)) i = -4;
    return i;
  }
  if (cb_GetFileState((const char*)File2)!=INVALID_FILE_ATTRIBUTES) {
    if (bFail & cb_MAX_INTEGER) {
      if (MyFailSub) {
        i = MyFailSub(UserData,(const void*)i,File2);
        if (i>0) { i = (cb_Integer)File1; goto Cont0000; }
        if (i==0) return 1;
      }
      return -1;
    }
Cont0000:
    if (cb_Remove((const char*)File2)) return 0;
  }
  else if (bFail<0) {
    //todo check/create folder
  }
  return cb_Rename((const char*)i,(const char*)File2);
}
/* END MODULE */


/* MODULE::cb_FolderMove_ */
__declspec(noinline) static cb_Integer cb_CDECL cb_FileMove_ (const void *UserData, const char *Str1, const cb_FIND_DATA *pFindFirst)
{
  return cb_FileCopyMove_(cb_MoveFile,UserData,Str1,pFindFirst);
}

__declspec(noinline) cb_Integer cb_DEFCALL cb_FolderMove_ (cb_TFileCopy_ *ptr1, const void *sPath1, cb_Integer bFolder)
{
  return cb_FolderCopyMove__(cb_FileMove_,ptr1,sPath1,bFolder);
}
/* END MODULE */


/* MODULE::cb_FolderMove */
cb_Integer cb_DEFCALL cb_FolderMove (const void *sPath1, const void *sPath2, cb_Integer (cb_CDECL *MySub)(const void*,const void*,cb_File*,cb_File*,cb_Integer), const void *UserData, cb_Integer bFolder)
{
  return cb_FolderCopyMove_(cb_FolderMove_,sPath1,sPath2,MySub,UserData,bFolder);
}
/* END MODULE */


/* MODULE::cb_FileMove */
cb_Integer cb_DEFCALL cb_FileMove (const void *sPath1, const void *sPath2, cb_Integer (cb_CDECL *MySub)(const void*,const void*,cb_File*,cb_File*,cb_Integer), const void *UserData, cb_Integer bFlag, cb_Integer (cb_CDECL *MyFailSub)(const void*,const void*,const void*))
{
  return cb_FolderFileCopyMove_(cb_FolderMove_,cb_MoveFile,sPath1,sPath2,MySub,UserData,bFlag,MyFailSub);
}
/* END MODULE */


/* MODULE::cb_FileKill */
__declspec(noinline) cb_Integer cb_CDECL cb_FileKill (const void *UserData, const char *sPath1, const cb_FIND_DATA *pFindFirst)
{
  if (!pFindFirst) if (cb_StrChars(sPath1, "*\?")) return cb_FolderScan(sPath1,cb_FileKill,0,NULL,0,FALSE);
  return cb_Remove(sPath1);
}
/* END MODULE */


/* MODULE::cb_FileKillW */
__declspec(noinline) cb_Integer cb_CDECL cb_FileKillW (const void *UserData, const wchar_t *sPath1, const cb_FIND_DATAW *pFindFirst)
{
  if (!pFindFirst) if (cb_StrCharsW(sPath1, L"*\?")) return cb_FolderScanW(sPath1,cb_FileKillW,0,NULL,0,FALSE);
#if defined(__WATCOM_CPLUSPLUS__) || defined(__GNUC__) || defined(__GNUG__) || defined(__DMC__)
  return !DeleteFileW(sPath1);
#else
  return cb_RemoveW(sPath1);
#endif
}
/* END MODULE */


/* MODULE::cb_FileKillEx */
cb_Integer cb_DEFCALL cb_FileKillEx (const void *fName, cb_Integer iSize, const char *sPrefix)
{
#define sze_ 0x2000
  register char *s;
  register cb_Integer i;
  register void *buf;
  if (cb_StrChars(fName, "*\?")) return cb_FolderKillEx(fName,FALSE,iSize,sPrefix);

  s = (char*)cb_MemAllocM(0x0800);
  if (!sPrefix || !sPrefix[0]) goto Copy0000;
  cb_SplitPath(fName,s,1|2);
  buf = cb_TempFileName(s,sPrefix,NULL,s);
  if (buf) cb_FileClose((cb_File*)buf);
  if (cb_Rename((const char*)fName,s)) {
Copy0000:
    cb_StrCopy(s, fName);
  }
  cb_File* f;
  unsigned long long sze;
  SetFileAttributes(s,0);
  i = iSize;
  if (i) {
    if (i==-1) sze = cb_FileLen(s); else sze = i;
    f = cb_FileOpen(s,_O_RDWR | _O_BINARY);
    if (f) {
      buf = cb_MemAllocM(sze_);
      if (buf) {
        cb_MemSet(buf,'X',sze_);
        do {
          if (cb_FileWrite(f,buf,sze_)!=sze_) break;
          if ((cb_UInteger)sze_>=(cb_UInteger)sze) break;
          sze-=sze_;
        } while(1);
        cb_MemFreeM(buf);
      }
      i = -1;
      goto SetEof0000;
    }
  }
  else{
    f = cb_FileOpen(s,_O_RDWR | _O_BINARY);
    if (f) {
SetEof0000:
      cb_SetEof(f,i);
      cb_FileFlush(f); cb_FileClose(f);
    }
  }
  i = cb_Remove(s); cb_MemFreeM(s);
  return i;
#undef sze_
}
/* END MODULE */


/* MODULE::cb_FolderKill_ */
__declspec(noinline) cb_Integer cb_CDECL cb_FolderKill_ (const void *UserData, const char *Str1, const cb_FIND_DATA *pFindFirst)
{
  SetFileAttributes(Str1,0);
  return cb_RmDir(Str1);
}
/* END MODULE */


/* MODULE::cb_FolderKill */
__declspec(noinline) static cb_Integer cb_CDECL cb_FileKill_ (const void *UserData, const char *Str1, const cb_FIND_DATA *pFindFirst)
{
  SetFileAttributes(Str1,0);
  return cb_Remove(Str1);
}

cb_Integer cb_DEFCALL cb_FolderKill (const void *sPath1,cb_Integer bFolder)
{
  return cb_FolderScan(sPath1,cb_FileKill_,0,cb_FolderKill_,0,bFolder);
}
/* END MODULE */


/* MODULE::cb_FolderKillEx */
__declspec(noinline) static cb_Integer cb_CDECL cb_FileKillEx_ (const void *UserData, const char *Str1, const cb_FIND_DATA *pFindFirst)
{
  register cb_TFileCopy_ *p = (cb_TFileCopy_*)UserData;
  return cb_FileKillEx(Str1,p->iLen1,p->fName);
}

cb_Integer cb_DEFCALL cb_FolderKillEx (const void *sPath1,cb_Integer bFolder,cb_Integer iNum,const char *sPrefix)
{
  register cb_TFileCopy_ *p = (cb_TFileCopy_*)cb_MemAllocM(sizeof(cb_TFileCopy_));
  p->iLen1 = iNum;
  if (sPrefix) cb_StrCopy(p->fName, sPrefix);
  else p->fName[0] = 0;
  register cb_Integer i = cb_FolderScan(sPath1,cb_FileKillEx_,p,cb_FolderKill_,0,bFolder);
  cb_MemFreeM(p);
  return i;
}
/* END MODULE */


/* MODULE::cb_PutS */
cb_Integer cb_DEFCALL cb_PutS (const char *s)
{
  register cb_Integer i = cb_FilePutS(cb_StdOut,s);
  cb_FileFlush(cb_StdOut);
  return i;
}
/* END MODULE */


/* MODULE::cb_Swap */
void cb_DEFCALL cb_Swap (void* A1, void* B1, cb_UInteger length)
{
  register char *A = (char*)A1; register char *B = (char*)B1;
  register cb_Integer l;
  char t;
  if (length==(cb_UInteger)-1) { length = cb_StrLen(A); l = cb_StrLen(B)+1; if (l>length) length = l; }
  if ((((cb_Integer)A)&(sizeof(cb_Integer)-1))==0)
  for (;length>=sizeof(cb_Integer);length-=sizeof(cb_Integer)) {
    l = *(cb_Integer*)A;
    *(cb_Integer*)A = *(cb_Integer*)B; A+=sizeof(cb_Integer);
    *(cb_Integer*)B = l; B+=sizeof(cb_Integer);
  }
  for (;length>0;length--) {
    t = *A;
    *A = *B; A++;
    *B = t; B++;
  }
}
/* END MODULE */


/* MODULE::cb_FillWord */
void cb_DEFCALL cb_FillWord (void* ptr1,WORD val,cb_Integer iLen)
{
  register WORD* ptr2;
  ptr2 = (WORD*)ptr1;
  register WORD* ptr3;
  ptr3 = ptr2;
  ptr2 += iLen;
  while (ptr2>ptr3) {
    ptr2--;
    ptr2[0] = val;
  }
}
/* END MODULE */


/* MODULE::cb_FillLong */
void cb_DEFCALL cb_FillLong (void* ptr1,long val,cb_Integer iLen)
{
  register long* ptr2;
  ptr2 = (long*)ptr1;
  register long* ptr3;
  ptr3 = ptr2;
  ptr2 += iLen;
  while (ptr2>ptr3) {
    ptr2--;
    ptr2[0] = val;
  }
}
/* END MODULE */


/* MODULE::cb_FillInteger */
void cb_DEFCALL cb_FillInteger (void* ptr1,cb_Integer val,cb_Integer iLen)
{
  register cb_Integer* ptr2;
  ptr2 = (cb_Integer*)ptr1;
  register cb_Integer* ptr3;
  ptr3 = ptr2;
  ptr2 += iLen;
  while (ptr2>ptr3) {
    ptr2--;
    ptr2[0] = val;
  }
}
/* END MODULE */


/* MODULE::cb_FillQuad */
void cb_DEFCALL cb_FillQuad (void* ptr1,long long val,cb_Integer iLen)
{
  register long long* ptr2;
  ptr2 = (long long*)ptr1;
  register long long* ptr3;
  ptr3 = ptr2;
  ptr2 += iLen;
  while (ptr2>ptr3) {
    ptr2--;
    ptr2[0] = val;
  }
}
/* END MODULE */


/* MODULE::cb_GoSub */
void* cb_PopGoSub (void)
{
  return cb_GoSubStack[--cb_GoSubIndex];
}

cb_Integer cb_FASTCALL cb_PushGoSub (void *x)
{
  if ((cb_UInteger)cb_GoSubIndex<(cb_UInteger)0x80) { cb_GoSubStack[cb_GoSubIndex++] = x; return 1; }
  return 0;
}
/* END MODULE */


/* MODULE::cb_ReadDataInt */
cb_Integer cb_DEFCALL cb_ReadDataInt (cb_UInteger iPos)
{
  if (cb_DataPtr_) if (iPos<cb_DataCount_) return (cb_Integer)(cb_DataPtr_[iPos]);
  return 0;
}
/* END MODULE */


/* MODULE::cb_ReadDataStr */
char* cb_DEFCALL cb_ReadDataStr (cb_UInteger iPos, void *dst)
{
  register char *dst1 = (char*)dst1;
  if (cb_DataPtr_) if (iPos<cb_DataCount_) return cb_NewStr(cb_DataPtr_[iPos],dst1);
  if (!dst1) return cb_EMPTYSTR;
  return cb_NewStr_(NULL,dst1,0);
}
/* END MODULE */


/* MODULE::cb_ReAllocZ */
void* cb_DEFCALL cb_ReAllocZ (void *ptr1,cb_UInteger sze)
{
  register void *p = ptr1;
  register cb_UInteger i, j = cb_MemSizeM(p);

  p = cb_ReMemAllocM(p,sze);
  if (p) {
    i = cb_MemSizeM(p);
    if (i>j) { i-=j; j = sze; if (i>j) i = j; cb_MemSet((char*)p+j-i,0,i); }
  }

  return p;
}
/* END MODULE */


/* MODULE::cb_ReDim */
void* cb_DEFCALL cb_ReDim (cb_UInteger sze1, void *pnt1, cb_Integer flg1)
{  register void *p1 = pnt1;  register cb_UInteger i = sze1; if (i==0) { if (p1) cb_MemFreeM(p1); return NULL; }  register cb_Integer j = flg1;  if (!p1) goto Alloc0000;  if (j&1) {    if (!(j&2)) p1 = cb_ReMemAllocM(p1,i);    else p1 = cb_ReMemAllocZM(p1,i);  }
  else {    cb_MemFreeM(p1);Alloc0000:;    if (!(j&2)) p1 = cb_MemAllocM(i);    else p1 = cb_MemAllocZM(i);  }  return p1;}
/* END MODULE */


/* MODULE::cb_ReDimEx */
void* cb_DEFCALL cb_ReDimEx (cb_UInteger sze1, void *pnt1, cb_Integer flg1)
{  register void *p1 = *(void**)pnt1;
  p1 = cb_ReDim(sze1,p1,flg1);  if (p1) *(void**)pnt1 = p1;  return p1;}
/* END MODULE */


/* MODULE::cb_ReDimArrayOfPtrs */
void cb_DEFCALL cb_FreeDimArrayOfPtrs (void *ptr1, cb_Integer iNum)
{
  register cb_Integer i = iNum;
  register void **p1 = (void**)ptr1;

  if (p1) {
    i--;
    if (i<=0)
      cb_MemFreeM((void*)p1);
    else
      for (;p1[0];p1++) { cb_FreeDimArrayOfPtrs(p1[0], i); p1[0] = NULL; }
  }
}

static void* cb_DEFCALL cb_ReDimArrayOfPtrs_(void **ptr1, cb_Integer iNum, cb_Integer flg1)
{
  register cb_Integer i,j = iNum;
  register void **p1 = ptr1;

  if (p1) {
    for (i=0;i<j;i++) {
      if (!p1[0]) goto Alloc0000;
      p1++;
    }
    for(;p1[0];p1++) { cb_MemFreeM(p1[0]); p1[0] = NULL; }
  }

Alloc0000:
  j++;
  return cb_ReDim(j*sizeof(void*),p1,flg1);
}

static void* cb_DEFCALL cb_DimArrayOfPtrs_(void **ptr1, cb_Integer flag1, cb_Integer iWide, cb_Integer iNum, cb_Integer *Items)
{
  register cb_Integer i,j;
  register void **p1 = ptr1;
  void *p2;

  while(iNum>0) {
    iNum--;
    j = Items[0];

    if (!iNum) {
      return cb_ReDim(j*iWide,p1,flag1);

    }

    p1 = (void**)cb_ReDimArrayOfPtrs_(p1, j, flag1);
    if (!p1) break;

    Items++;

    for(i=0;i<j;i++) {
      p2 = cb_DimArrayOfPtrs_((void**)(p1[i]),flag1,iWide,iNum,Items);
      if (!p2) { if (p1[i]) { cb_MemFreeM(p1[i]); p1[i] = NULL; } goto Exit0000; }
      p1[i] = p2;
    }

    p1[i] = NULL;
  }

Exit0000:

  return (void*)p1;
}

__declspec(noinline) void* cb_CDECL cb_ReDimArrayOfPtrs (void **ptr1, cb_Integer flag1, cb_Integer iWide, cb_Integer iNum, ...)
{
  return cb_DimArrayOfPtrs_(ptr1,flag1,iWide,iNum,(&iNum)+1);
}
/* END MODULE */


/* MODULE::cb_GetCRC16 */
static unsigned short cb_DEFCALL cb_UpdateCRC16_ (unsigned short crc,short Octet)
{
  static  unsigned short  Crc16Table_[256] = {
    0x0000,0x1021,0x2042,0x3063,0x4084,0x50a5,0x60c6,0x70e7,
    0x8108,0x9129,0xa14a,0xb16b,0xc18c,0xd1ad,0xe1ce,0xf1ef,
    0x1231,0x0210,0x3273,0x2252,0x52b5,0x4294,0x72f7,0x62d6,
    0x9339,0x8318,0xb37b,0xa35a,0xd3bd,0xc39c,0xf3ff,0xe3de,
    0x2462,0x3443,0x0420,0x1401,0x64e6,0x74c7,0x44a4,0x5485,
    0xa56a,0xb54b,0x8528,0x9509,0xe5ee,0xf5cf,0xc5ac,0xd58d,
    0x3653,0x2672,0x1611,0x0630,0x76d7,0x66f6,0x5695,0x46b4,
    0xb75b,0xa77a,0x9719,0x8738,0xf7df,0xe7fe,0xd79d,0xc7bc,
    0x48c4,0x58e5,0x6886,0x78a7,0x0840,0x1861,0x2802,0x3823,
    0xc9cc,0xd9ed,0xe98e,0xf9af,0x8948,0x9969,0xa90a,0xb92b,
    0x5af5,0x4ad4,0x7ab7,0x6a96,0x1a71,0x0a50,0x3a33,0x2a12,
    0xdbfd,0xcbdc,0xfbbf,0xeb9e,0x9b79,0x8b58,0xbb3b,0xab1a,
    0x6ca6,0x7c87,0x4ce4,0x5cc5,0x2c22,0x3c03,0x0c60,0x1c41,
    0xedae,0xfd8f,0xcdec,0xddcd,0xad2a,0xbd0b,0x8d68,0x9d49,
    0x7e97,0x6eb6,0x5ed5,0x4ef4,0x3e13,0x2e32,0x1e51,0x0e70,
    0xff9f,0xefbe,0xdfdd,0xcffc,0xbf1b,0xaf3a,0x9f59,0x8f78,
    0x9188,0x81a9,0xb1ca,0xa1eb,0xd10c,0xc12d,0xf14e,0xe16f,
    0x1080,0x00a1,0x30c2,0x20e3,0x5004,0x4025,0x7046,0x6067,
    0x83b9,0x9398,0xa3fb,0xb3da,0xc33d,0xd31c,0xe37f,0xf35e,
    0x02b1,0x1290,0x22f3,0x32d2,0x4235,0x5214,0x6277,0x7256,
    0xb5ea,0xa5cb,0x95a8,0x8589,0xf56e,0xe54f,0xd52c,0xc50d,
    0x34e2,0x24c3,0x14a0,0x0481,0x7466,0x6447,0x5424,0x4405,
    0xa7db,0xb7fa,0x8799,0x97b8,0xe75f,0xf77e,0xc71d,0xd73c,
    0x26d3,0x36f2,0x0691,0x16b0,0x6657,0x7676,0x4615,0x5634,
    0xd94c,0xc96d,0xf90e,0xe92f,0x99c8,0x89e9,0xb98a,0xa9ab,
    0x5844,0x4865,0x7806,0x6827,0x18c0,0x08e1,0x3882,0x28a3,
    0xcb7d,0xdb5c,0xeb3f,0xfb1e,0x8bf9,0x9bd8,0xabbb,0xbb9a,
    0x4a75,0x5a54,0x6a37,0x7a16,0x0af1,0x1ad0,0x2ab3,0x3a92,
    0xfd2e,0xed0f,0xdd6c,0xcd4d,0xbdaa,0xad8b,0x9de8,0x8dc9,
    0x7c26,0x6c07,0x5c64,0x4c45,0x3ca2,0x2c83,0x1ce0,0x0cc1,
    0xef1f,0xff3e,0xcf5d,0xdf7c,0xaf9b,0xbfba,0x8fd9,0x9ff8,
    0x6e17,0x7e36,0x4e55,0x5e74,0x2e93,0x3eb2,0x0ed1,0x1ef0
  };

  register unsigned short i; i = crc;
  register unsigned short n; n = Octet;

  n ^= i;
  n &= 0x00FF;
  i >>= 8;
  i ^= Crc16Table_[n];
  return i;
}

unsigned short cb_DEFCALL cb_GetCRC16 (const void *Ptr1,cb_Integer iLen,unsigned short iNum)
{
  register unsigned short C16;
  register cb_Integer n; n = iLen;
  register const char *Str1;  Str1 = (const char*)Ptr1;

  if (n==-1) {
    n = cb_StrLen(Str1);
  }
  C16 = iNum;
  for(;n;n--) {
    C16 = cb_UpdateCRC16_(C16,Str1[0]);
    ++Str1;
  }
  return C16 ^ iNum;
}

/* END MODULE */


/* MODULE::cb_GetCRC32 */
static unsigned int cb_FASTCALL cb_UpdateCRC32_ (unsigned int crc,cb_Integer Octet)
{
  static  unsigned int  Crc32Table_[256] = {
    0x00000000,0x77073096,0xee0e612c,0x990951ba,0x076dc419,0x706af48f,0xe963a535,0x9e6495a3,
    0x0edb8832,0x79dcb8a4,0xe0d5e91e,0x97d2d988,0x09b64c2b,0x7eb17cbd,0xe7b82d07,0x90bf1d91,
    0x1db71064,0x6ab020f2,0xf3b97148,0x84be41de,0x1adad47d,0x6ddde4eb,0xf4d4b551,0x83d385c7,
    0x136c9856,0x646ba8c0,0xfd62f97a,0x8a65c9ec,0x14015c4f,0x63066cd9,0xfa0f3d63,0x8d080df5,
    0x3b6e20c8,0x4c69105e,0xd56041e4,0xa2677172,0x3c03e4d1,0x4b04d447,0xd20d85fd,0xa50ab56b,
    0x35b5a8fa,0x42b2986c,0xdbbbc9d6,0xacbcf940,0x32d86ce3,0x45df5c75,0xdcd60dcf,0xabd13d59,
    0x26d930ac,0x51de003a,0xc8d75180,0xbfd06116,0x21b4f4b5,0x56b3c423,0xcfba9599,0xb8bda50f,
    0x2802b89e,0x5f058808,0xc60cd9b2,0xb10be924,0x2f6f7c87,0x58684c11,0xc1611dab,0xb6662d3d,
    0x76dc4190,0x01db7106,0x98d220bc,0xefd5102a,0x71b18589,0x06b6b51f,0x9fbfe4a5,0xe8b8d433,
    0x7807c9a2,0x0f00f934,0x9609a88e,0xe10e9818,0x7f6a0dbb,0x086d3d2d,0x91646c97,0xe6635c01,
    0x6b6b51f4,0x1c6c6162,0x856530d8,0xf262004e,0x6c0695ed,0x1b01a57b,0x8208f4c1,0xf50fc457,
    0x65b0d9c6,0x12b7e950,0x8bbeb8ea,0xfcb9887c,0x62dd1ddf,0x15da2d49,0x8cd37cf3,0xfbd44c65,
    0x4db26158,0x3ab551ce,0xa3bc0074,0xd4bb30e2,0x4adfa541,0x3dd895d7,0xa4d1c46d,0xd3d6f4fb,
    0x4369e96a,0x346ed9fc,0xad678846,0xda60b8d0,0x44042d73,0x33031de5,0xaa0a4c5f,0xdd0d7cc9,
    0x5005713c,0x270241aa,0xbe0b1010,0xc90c2086,0x5768b525,0x206f85b3,0xb966d409,0xce61e49f,
    0x5edef90e,0x29d9c998,0xb0d09822,0xc7d7a8b4,0x59b33d17,0x2eb40d81,0xb7bd5c3b,0xc0ba6cad,
    0xedb88320,0x9abfb3b6,0x03b6e20c,0x74b1d29a,0xead54739,0x9dd277af,0x04db2615,0x73dc1683,
    0xe3630b12,0x94643b84,0x0d6d6a3e,0x7a6a5aa8,0xe40ecf0b,0x9309ff9d,0x0a00ae27,0x7d079eb1,
    0xf00f9344,0x8708a3d2,0x1e01f268,0x6906c2fe,0xf762575d,0x806567cb,0x196c3671,0x6e6b06e7,
    0xfed41b76,0x89d32be0,0x10da7a5a,0x67dd4acc,0xf9b9df6f,0x8ebeeff9,0x17b7be43,0x60b08ed5,
    0xd6d6a3e8,0xa1d1937e,0x38d8c2c4,0x4fdff252,0xd1bb67f1,0xa6bc5767,0x3fb506dd,0x48b2364b,
    0xd80d2bda,0xaf0a1b4c,0x36034af6,0x41047a60,0xdf60efc3,0xa867df55,0x316e8eef,0x4669be79,
    0xcb61b38c,0xbc66831a,0x256fd2a0,0x5268e236,0xcc0c7795,0xbb0b4703,0x220216b9,0x5505262f,
    0xc5ba3bbe,0xb2bd0b28,0x2bb45a92,0x5cb36a04,0xc2d7ffa7,0xb5d0cf31,0x2cd99e8b,0x5bdeae1d,
    0x9b64c2b0,0xec63f226,0x756aa39c,0x026d930a,0x9c0906a9,0xeb0e363f,0x72076785,0x05005713,
    0x95bf4a82,0xe2b87a14,0x7bb12bae,0x0cb61b38,0x92d28e9b,0xe5d5be0d,0x7cdcefb7,0x0bdbdf21,
    0x86d3d2d4,0xf1d4e242,0x68ddb3f8,0x1fda836e,0x81be16cd,0xf6b9265b,0x6fb077e1,0x18b74777,
    0x88085ae6,0xff0f6a70,0x66063bca,0x11010b5c,0x8f659eff,0xf862ae69,0x616bffd3,0x166ccf45,
    0xa00ae278,0xd70dd2ee,0x4e048354,0x3903b3c2,0xa7672661,0xd06016f7,0x4969474d,0x3e6e77db,
    0xaed16a4a,0xd9d65adc,0x40df0b66,0x37d83bf0,0xa9bcae53,0xdebb9ec5,0x47b2cf7f,0x30b5ffe9,
    0xbdbdf21c,0xcabac28a,0x53b39330,0x24b4a3a6,0xbad03605,0xcdd70693,0x54de5729,0x23d967bf,
    0xb3667a2e,0xc4614ab8,0x5d681b02,0x2a6f2b94,0xb40bbe37,0xc30c8ea1,0x5a05df1b,0x2d02ef8d
  };

  Octet ^= crc;
  Octet &= 0x00FF;
  crc >>= 8;
  crc ^= Crc32Table_[Octet];
  return crc;
}

unsigned int cb_DEFCALL cb_GetCRC32 (const void *Ptr1,cb_Integer iLen,unsigned int iNum)
{
  register unsigned int C32;
  register cb_Integer n; n = iLen;
  register const char *Str1;  Str1 = (const char*)Ptr1;

  if (n==-1) {
    n = cb_StrLen(Str1);
  }
  C32 = iNum;
  for(;n;n--) {
    C32 = cb_UpdateCRC32_(C32,Str1[0]);
    ++Str1;
  }
  return C32 ^ iNum;
}
/* END MODULE */


/* MODULE::cb_GetCRC64 */
static unsigned long long cb_FASTCALL cb_UpdateCRC64_ (unsigned long long crc,cb_Integer Octet)
{
  static  unsigned long long  Crc64Table_[] = {
    0x0000000000000000,0xB32E4CBE03A75F6F,0xF4843657A840A05B,0x47AA7AE9ABE7FF34,0x7BD0C384FF8F5E33,0xC8FE8F3AFC28015C,0x8F54F5D357CFFE68,0x3C7AB96D5468A107,
    0xF7A18709FF1EBC66,0x448FCBB7FCB9E309,0x0325B15E575E1C3D,0xB00BFDE054F94352,0x8C71448D0091E255,0x3F5F08330336BD3A,0x78F572DAA8D1420E,0xCBDB3E64AB761D61,
    0x7D9BA13851336649,0xCEB5ED8652943926,0x891F976FF973C612,0x3A31DBD1FAD4997D,0x064B62BCAEBC387A,0xB5652E02AD1B6715,0xF2CF54EB06FC9821,0x41E11855055BC74E,
    0x8A3A2631AE2DDA2F,0x39146A8FAD8A8540,0x7EBE1066066D7A74,0xCD905CD805CA251B,0xF1EAE5B551A2841C,0x42C4A90B5205DB73,0x056ED3E2F9E22447,0xB6409F5CFA457B28,
    0xFB374270A266CC92,0x48190ECEA1C193FD,0x0FB374270A266CC9,0xBC9D3899098133A6,0x80E781F45DE992A1,0x33C9CD4A5E4ECDCE,0x7463B7A3F5A932FA,0xC74DFB1DF60E6D95,
    0x0C96C5795D7870F4,0xBFB889C75EDF2F9B,0xF812F32EF538D0AF,0x4B3CBF90F69F8FC0,0x774606FDA2F72EC7,0xC4684A43A15071A8,0x83C230AA0AB78E9C,0x30EC7C140910D1F3,
    0x86ACE348F355AADB,0x3582AFF6F0F2F5B4,0x7228D51F5B150A80,0xC10699A158B255EF,0xFD7C20CC0CDAF4E8,0x4E526C720F7DAB87,0x09F8169BA49A54B3,0xBAD65A25A73D0BDC,
    0x710D64410C4B16BD,0xC22328FF0FEC49D2,0x85895216A40BB6E6,0x36A71EA8A7ACE989,0x0ADDA7C5F3C4488E,0xB9F3EB7BF06317E1,0xFE5991925B84E8D5,0x4D77DD2C5823B7BA,
    0x64B62BCAEBC387A1,0xD7986774E864D8CE,0x90321D9D438327FA,0x231C512340247895,0x1F66E84E144CD992,0xAC48A4F017EB86FD,0xEBE2DE19BC0C79C9,0x58CC92A7BFAB26A6,
    0x9317ACC314DD3BC7,0x2039E07D177A64A8,0x67939A94BC9D9B9C,0xD4BDD62ABF3AC4F3,0xE8C76F47EB5265F4,0x5BE923F9E8F53A9B,0x1C4359104312C5AF,0xAF6D15AE40B59AC0,
    0x192D8AF2BAF0E1E8,0xAA03C64CB957BE87,0xEDA9BCA512B041B3,0x5E87F01B11171EDC,0x62FD4976457FBFDB,0xD1D305C846D8E0B4,0x96797F21ED3F1F80,0x2557339FEE9840EF,
    0xEE8C0DFB45EE5D8E,0x5DA24145464902E1,0x1A083BACEDAEFDD5,0xA9267712EE09A2BA,0x955CCE7FBA6103BD,0x267282C1B9C65CD2,0x61D8F8281221A3E6,0xD2F6B4961186FC89,
    0x9F8169BA49A54B33,0x2CAF25044A02145C,0x6B055FEDE1E5EB68,0xD82B1353E242B407,0xE451AA3EB62A1500,0x577FE680B58D4A6F,0x10D59C691E6AB55B,0xA3FBD0D71DCDEA34,
    0x6820EEB3B6BBF755,0xDB0EA20DB51CA83A,0x9CA4D8E41EFB570E,0x2F8A945A1D5C0861,0x13F02D374934A966,0xA0DE61894A93F609,0xE7741B60E174093D,0x545A57DEE2D35652,
    0xE21AC88218962D7A,0x5134843C1B317215,0x169EFED5B0D68D21,0xA5B0B26BB371D24E,0x99CA0B06E7197349,0x2AE447B8E4BE2C26,0x6D4E3D514F59D312,0xDE6071EF4CFE8C7D,
    0x15BB4F8BE788911C,0xA6950335E42FCE73,0xE13F79DC4FC83147,0x521135624C6F6E28,0x6E6B8C0F1807CF2F,0xDD45C0B11BA09040,0x9AEFBA58B0476F74,0x29C1F6E6B3E0301B,
    0xC96C5795D7870F42,0x7A421B2BD420502D,0x3DE861C27FC7AF19,0x8EC62D7C7C60F076,0xB2BC941128085171,0x0192D8AF2BAF0E1E,0x4638A2468048F12A,0xF516EEF883EFAE45,
    0x3ECDD09C2899B324,0x8DE39C222B3EEC4B,0xCA49E6CB80D9137F,0x7967AA75837E4C10,0x451D1318D716ED17,0xF6335FA6D4B1B278,0xB199254F7F564D4C,0x02B769F17CF11223,
    0xB4F7F6AD86B4690B,0x07D9BA1385133664,0x4073C0FA2EF4C950,0xF35D8C442D53963F,0xCF273529793B3738,0x7C0979977A9C6857,0x3BA3037ED17B9763,0x888D4FC0D2DCC80C,
    0x435671A479AAD56D,0xF0783D1A7A0D8A02,0xB7D247F3D1EA7536,0x04FC0B4DD24D2A59,0x3886B22086258B5E,0x8BA8FE9E8582D431,0xCC0284772E652B05,0x7F2CC8C92DC2746A,
    0x325B15E575E1C3D0,0x8175595B76469CBF,0xC6DF23B2DDA1638B,0x75F16F0CDE063CE4,0x498BD6618A6E9DE3,0xFAA59ADF89C9C28C,0xBD0FE036222E3DB8,0x0E21AC88218962D7,
    0xC5FA92EC8AFF7FB6,0x76D4DE52895820D9,0x317EA4BB22BFDFED,0x8250E80521188082,0xBE2A516875702185,0x0D041DD676D77EEA,0x4AAE673FDD3081DE,0xF9802B81DE97DEB1,
    0x4FC0B4DD24D2A599,0xFCEEF8632775FAF6,0xBB44828A8C9205C2,0x086ACE348F355AAD,0x34107759DB5DFBAA,0x873E3BE7D8FAA4C5,0xC094410E731D5BF1,0x73BA0DB070BA049E,
    0xB86133D4DBCC19FF,0x0B4F7F6AD86B4690,0x4CE50583738CB9A4,0xFFCB493D702BE6CB,0xC3B1F050244347CC,0x709FBCEE27E418A3,0x3735C6078C03E797,0x841B8AB98FA4B8F8,
    0xADDA7C5F3C4488E3,0x1EF430E13FE3D78C,0x595E4A08940428B8,0xEA7006B697A377D7,0xD60ABFDBC3CBD6D0,0x6524F365C06C89BF,0x228E898C6B8B768B,0x91A0C532682C29E4,
    0x5A7BFB56C35A3485,0xE955B7E8C0FD6BEA,0xAEFFCD016B1A94DE,0x1DD181BF68BDCBB1,0x21AB38D23CD56AB6,0x9285746C3F7235D9,0xD52F0E859495CAED,0x6601423B97329582,
    0xD041DD676D77EEAA,0x636F91D96ED0B1C5,0x24C5EB30C5374EF1,0x97EBA78EC690119E,0xAB911EE392F8B099,0x18BF525D915FEFF6,0x5F1528B43AB810C2,0xEC3B640A391F4FAD,
    0x27E05A6E926952CC,0x94CE16D091CE0DA3,0xD3646C393A29F297,0x604A2087398EADF8,0x5C3099EA6DE60CFF,0xEF1ED5546E415390,0xA8B4AFBDC5A6ACA4,0x1B9AE303C601F3CB,
    0x56ED3E2F9E224471,0xE5C372919D851B1E,0xA26908783662E42A,0x114744C635C5BB45,0x2D3DFDAB61AD1A42,0x9E13B115620A452D,0xD9B9CBFCC9EDBA19,0x6A978742CA4AE576,
    0xA14CB926613CF817,0x1262F598629BA778,0x55C88F71C97C584C,0xE6E6C3CFCADB0723,0xDA9C7AA29EB3A624,0x69B2361C9D14F94B,0x2E184CF536F3067F,0x9D36004B35545910,
    0x2B769F17CF112238,0x9858D3A9CCB67D57,0xDFF2A94067518263,0x6CDCE5FE64F6DD0C,0x50A65C93309E7C0B,0xE388102D33392364,0xA4226AC498DEDC50,0x170C267A9B79833F,
    0xDCD7181E300F9E5E,0x6FF954A033A8C131,0x28532E49984F3E05,0x9B7D62F79BE8616A,0xA707DB9ACF80C06D,0x14299724CC279F02,0x5383EDCD67C06036,0xE0ADA17364673F59
  };

  Octet ^= (cb_Integer)crc;
  Octet &= 0x00FF;
  crc >>= 8;
  crc ^= Crc64Table_[Octet];
  return crc;
}

unsigned long long cb_DEFCALL cb_GetCRC64 (const void *Ptr1,cb_Integer iLen,unsigned long long iNum)
{
  register unsigned long long C64;
  register cb_Integer n;  n = iLen;
  register const char *Str1;  Str1 = (const char*)Ptr1;

  if (n==-1) {
    n = cb_StrLen(Str1);
  }
  C64 = iNum;
  for(;n;n--) {
    C64 = cb_UpdateCRC64_(C64,Str1[0]);
    ++Str1;
  }
  return C64 ^ iNum;
}
/* END MODULE */


/* MODULE::cb_CommandLineToArgvA */
char ** cb_DEFCALL cb_CommandLineToArgvA (cb_Integer *iArgc, void *src, void *b)
{
  static char *RetVar[1024];
  static cb_Integer iRetVar;
  register char *s;
  register cb_Integer c, i, n, o;
  char **RetVarP;
  char *s_;

  s = (char*)src;
  if (!s) {
    if (cb_CommandLinePtr) { i = iRetVar; goto Exit0001; }
    s = (char*)GetCommandLine();
  }
  else if (!b) if (!cb_CommandLinePtr) src = NULL;
  c = cb_StrLen(s)+1; i = (cb_Integer)s;
  s = cb_NewStr_(NULL,(void*)-1,c+(c>>1)+64); if (!s) { i = 0; goto Exit0001; }
  s_ = (char*)cb_MemCopy(s,(const char*)i,c);
  if (!src) { cb_CommandLinePtr = s; RetVarP = RetVar; }
  else { src = s; RetVarP = (char**)b; }
  i = 0;

  do {
    do {
      c = s[0]; if ((cb_UInteger)c>(cb_UInteger)' ') break;
      if (!c) goto Exit0000;
      s++;
    } while(1);
    if (RetVarP) { *RetVarP = s; RetVarP++; i++; }
    do {
Again0000:
      if (c=='"' || c=='`') goto Quotes000;
      if (c=='(') {
        c = ')'; goto Quotes000;
      }
      if (c=='[') {
        c = ']'; goto Quotes000;
      }
      if (c=='{') {
        c = '}';
Quotes000:
        n = 0;
        if (i==1) if (!src) s++;
        do {
        do {
Quotes0000:
          s++;
Quotes0001:
          if (!s[0]) goto Exit0000;
          if (c!='"') if (c!='`') {
            if (s[0]!=c) {
              if (s[0]=='"' || s[0]=='`') {
                o = c; c = s[0]; n |= cb_MIN_INTEGER; goto Quotes0000;
              }
              if (s[0]=='(' || s[0]=='[' || s[0]=='{') n++;
              goto Quotes0000;
            }
            if (n!=0) { n--; goto Quotes0000; }
            if (i!=1) {
              s++; c = s[0];
              if ((cb_UInteger)c>(cb_UInteger)' ') {
                if (c!='/') goto Again0000;
                goto Move0000;
              }
              goto Next000;
            }
            goto Next0000;
          }
        }while(s[0]!=c);
        s++;
        }while(s[0]==c);
        if (n<0) { c = o; n &= cb_MAX_INTEGER; goto Quotes0001; }
        if (i==1) {
          if (!src) { s--; goto Next0000; }
          c = s[0]; if ((cb_UInteger)c<=(cb_UInteger)' ') break;
          goto Move0000;
        }
      }
      else if (i==1) if (c=='/') if (s_[0]!='/') if (*(short*)(s_+1)!='/:') {
Move0000:
        cb_StrMove(s+1,s); goto Next0000;
      }
      if ((cb_UInteger)c<=(cb_UInteger)' ') break;
      s++; c = s[0];
    }while(1);
Next000:
    if (c==0) break;
Next0000:
    s[0] = 0;
    s++;
  }while(1);

Exit0000:
  s[1] = 0;
Exit0001:
  if (iArgc) *iArgc = i;
  if (src) return (char**)src;
  iRetVar = i; return RetVar;
}
/* END MODULE */


/* MODULE::cb_SocketStartup */
cb_Boolean cb_SocketStartup(void)
{
  WSADATA wsaData;

  if (!cb_SocketStartedup_) {
    if (WSAStartup(MAKEWORD(2,2), &wsaData)) return FALSE;
    cb_SocketStartedup_++;
  }
  return TRUE;
}
/* END MODULE */


/* MODULE::cb_SocketSetInfo */
cb_Integer cb_DEFCALL cb_SocketSetInfo (const char *ServerName,cb_Integer port,struct sockaddr_in *saServer,cb_Integer flag1)
{
  register unsigned long iaHost;
  register struct hostent *lpHostEntry;

  if ((unsigned long)port>=0x10000) return FALSE;
  saServer->sin_port = htons(port);
  saServer->sin_family = AF_INET;
  saServer->sin_addr.s_addr = INADDR_ANY;
  if (!ServerName) ServerName = "127.0.0.1";
  iaHost = inet_addr(ServerName);
  if (iaHost==INADDR_NONE || iaHost==INADDR_ANY) {
    lpHostEntry = gethostbyname(ServerName);
    if (lpHostEntry) iaHost = *(unsigned long*)(lpHostEntry->h_addr);
    else { if (flag1) return FALSE; iaHost = INADDR_ANY; }
  }
  saServer->sin_addr.s_addr = iaHost;
  return TRUE;
}
/* END MODULE */


/* MODULE::cb_SocketCreate */
SOCKET cb_DEFCALL cb_SocketCreate (cb_Integer tipe, cb_Integer prot)
{
  cb_Integer lngRetValue;

  if (!cb_SocketStartup()) return INVALID_SOCKET;
  lngRetValue = TRUE;
  register SOCKET sck1; sck1 = socket(AF_INET,tipe,prot);
  setsockopt(sck1, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, (const char*)&lngRetValue, sizeof(lngRetValue));
  return sck1;
}
/* END MODULE */


/* MODULE::cb_SocketConnect */
SOCKET cb_DEFCALL cb_SocketConnect (const char *ServerName,cb_Integer port,struct sockaddr_in *s,SOCKET sck)
{
  struct sockaddr_in s1;
  if (!s) {
    if (!cb_SocketSetInfo(ServerName,port,&s1,TRUE)) return INVALID_SOCKET-1; s=&s1;
  }
  register SOCKET sck1; sck1 = sck; if (sck1==INVALID_SOCKET) sck1 = cb_SocketCreate();
  if (sck1!=INVALID_SOCKET) {
    if (connect(sck1,(const struct sockaddr*)s,sizeof(struct sockaddr))==SOCKET_ERROR) {
      if (sck==INVALID_SOCKET) closesocket(sck1);
      sck1 = INVALID_SOCKET;
    }
  }
  return sck1;
}
/* END MODULE */


/* MODULE::cb_SocketListen */
SOCKET cb_DEFCALL cb_SocketListen (cb_Integer port,const char *ServerName,struct sockaddr_in *s,SOCKET sck)
{
  struct sockaddr_in s1;
  register SOCKET sck1; sck1 = sck;
  if (sck1==INVALID_SOCKET) {
    sck1 = cb_SocketCreate();
    if (sck1!=INVALID_SOCKET) {
      if (!s) { if (!cb_SocketSetInfo(ServerName,port,&s1,FALSE)) return INVALID_SOCKET-1; s=&s1; }
      if (bind(sck1,(const struct sockaddr*)s,sizeof(struct sockaddr))==SOCKET_ERROR) goto Error0000;
    }
  }
  if (sck1!=INVALID_SOCKET) {
    if (listen(sck1,SOMAXCONN)==SOCKET_ERROR) {
      if (sck==INVALID_SOCKET) {
Error0000:
        closesocket(sck1);
      }
      sck1 = INVALID_SOCKET;
    }
  }
  return sck1;
}
/* END MODULE */


/* MODULE::cb_SocketAccept */
SOCKET cb_DEFCALL cb_SocketAccept (SOCKET *sck)
{
  SOCKADDR_IN from;
  cb_Integer fromlen;
  register SOCKET sck1;
  fromlen=sizeof(from);
  sck1=accept(*sck,(LPSOCKADDR)&from,&fromlen);
  if (sck1!=INVALID_SOCKET) { closesocket(*sck); *sck=INVALID_SOCKET; }
  return sck1;
}
/* END MODULE */


/* MODULE::cb_SocketGet */
BYTE * cb_DEFCALL cb_SocketGet (SOCKET sck, void *dst, cb_Integer sze, void *buf1, cb_Integer iCode)
{
  register cb_Integer i = sze; if (i<=0) i = 4096;
  register char *sTmp = (char*)dst;
  if (sTmp==NULL || sTmp==(char*)-1) {
    sTmp = cb_NewStr_(NULL,sTmp,i); if (sTmp==NULL) goto Exit0000;
  }
  i = recv(sck,sTmp,i,iCode);
  if (buf1) *(cb_Integer*)buf1 = i;
Exit0000:
  return (BYTE*)sTmp;
}
/* END MODULE */


/* MODULE::cb_SocketPeek */
BYTE * cb_DEFCALL cb_SocketPeek (SOCKET sck, void *dst, cb_Integer sze, void *buf1)
{
  return cb_SocketGet(sck,dst,sze,buf1,MSG_PEEK);
}
/* END MODULE */


/* MODULE::cb_SocketStrGet */
char* cb_DEFCALL cb_SocketStrGet (SOCKET sck, void *dst, cb_Integer sze, cb_Integer iCode)
{
  register char *sTmp = (char*)cb_SocketGet(sck,dst,sze,&sze,iCode);
  if (sTmp) *(wchar_t*)(sTmp+sze) = 0;
  else if (!dst) sTmp = cb_EMPTYSTR;
  else if (dst!=(void*)-1) *(wchar_t*)dst = 0;
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_SocketStrPeek */
char* cb_DEFCALL cb_SocketStrPeek (SOCKET sck, void *dst, cb_Integer sze)
{
  return cb_SocketStrGet(sck,dst,sze,MSG_PEEK);
}
/* END MODULE */


/* MODULE::cb_SocketPut */
cb_Integer cb_DEFCALL cb_SocketPut (SOCKET sck, const void *sBuf, cb_Integer sze)
{
  register cb_Integer sze1 = sze; if (sze1 <= 0) sze1 = cb_StrLen((const char*)sBuf);
  if (sze1 > 0) sze1 = send(sck,(const char*)sBuf,sze1,0);
  return sze1;
}
/* END MODULE */


/* MODULE::cb_SocketStrPutW */
cb_Integer cb_DEFCALL cb_SocketStrPutW (SOCKET sck, const void *sBuf)
{
  register cb_Integer sze1 = cb_StrLenW((const wchar_t*)sBuf) << 1;
  if (sze1 > 0) sze1 = send(sck,(const char*)sBuf,sze1,0);
  return sze1;
}
/* END MODULE */


/* MODULE::cb_SocketSetTimeout */
SOCKET cb_DEFCALL cb_SocketSetTimeout (cb_Integer dwTimeout, SOCKET sck)
{
  register SOCKET sck1; sck1 = sck;
  if (sck1==INVALID_SOCKET) {
    sck1 = cb_SocketCreate();
    if (sck1==INVALID_SOCKET) goto Exit0000;
  }
  if (setsockopt(sck1, SOL_SOCKET, SO_SNDTIMEO, (const char*)&dwTimeout, sizeof(dwTimeout))) {
    if (sck==INVALID_SOCKET) closesocket(sck1);
    sck1 = INVALID_SOCKET;
  }
Exit0000:
  return sck1;
}
/* END MODULE */


/* MODULE::cb_IsInternetConnected */
cb_Integer cb_DEFCALL cb_IsInternetConnected (const char *strURL, cb_Integer Flag1)
{
  register cb_Integer RetVar;

  if (Flag1==-1) Flag1 = FLAG_ICC_FORCE_CONNECTION;
  if (strURL) if (strURL[0]!=0) {
    return InternetCheckConnection(strURL,Flag1,0);
  }
  RetVar = InternetGetConnectedState(0,0);
  if (RetVar==0) {
    RetVar=InternetCheckConnection("http://www.google.com",Flag1,0);
  }
  if (RetVar==0) {
    RetVar=InternetCheckConnection("http://www.microsoft.com/index.htm",Flag1,0);
  }
  if (RetVar==0) {
    RetVar=InternetCheckConnection("http://www.yahoo.com",Flag1,0);
  }
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_InetOpen */
HINTERNET cb_DEFCALL cb_InetOpen (const char *sAgent, const char *sProxy, cb_Integer flags)
{
  register cb_Integer i;
  register char *Buf1 = (char*)sAgent;

  if (!Buf1 || Buf1[0]==0) {
    Buf1 = (char*)cb_MemAllocM(0x0800+2);
    cbApp_EXEName(0,Buf1);
    cb_CStr((cb_Integer)cbApp_hInstance,16,Buf1+cb_StrLen(Buf1));
    sAgent = NULL;
  }
  if (sProxy==(const char*)-1) { i = INTERNET_OPEN_TYPE_DIRECT; sProxy = NULL; }
  else if (sProxy) i = INTERNET_OPEN_TYPE_PROXY;
  else i = INTERNET_OPEN_TYPE_PRECONFIG;
  i = (cb_Integer)InternetOpen(Buf1,i,sProxy,NULL,flags);
  if (!sAgent) cb_MemFreeM(Buf1);
  return (HINTERNET)i;
}
/* END MODULE */


/* MODULE::cb_InetConnectURL */
HINTERNET cb_DEFCALL cb_InetConnectURL (const char *sURL,HINTERNET hInet,cb_Integer flags)
{
  register HINTERNET h1 = hInet;

  if (!h1) if (sURL) if (sURL[0]) { h1 = cb_hInet_; if (!h1) { h1 = cb_InetOpen(); cb_hInet_ = h1; } }
  return InternetOpenUrl(h1,sURL,NULL,0,flags,0);
}
/* END MODULE */


/* MODULE::cb_InetConnectFTP */
HINTERNET cb_DEFCALL cb_InetConnectFTP (const char *sFTP,HINTERNET hInet,const char *sUserName,const char *sPassword,cb_Integer iPort,cb_Integer flags)
{
  register HINTERNET h1 = hInet;
  register cb_Integer i = iPort; if ((cb_UInteger)(i-1)>=(cb_UInteger)0x00FFFF) i = INTERNET_DEFAULT_FTP_PORT;

  if (!h1) if (sFTP) if (sFTP[0]) { h1 = cb_hInet_; if (!h1) { h1 = cb_InetOpen(); cb_hInet_ = h1; } }
  return InternetConnect(h1,sFTP,i,sUserName,sPassword,INTERNET_SERVICE_FTP,flags,0);
}
/* END MODULE */


/* MODULE::cb_InetDial */
cb_Integer cb_DEFCALL cb_InetDial (void)
{
  return cb_IsInternetConnected(NULL,INTERNET_DIAL_FORCE_PROMPT);
}
/* END MODULE */


/* MODULE::cb_InetDownload */
BYTE* cb_DEFCALL cb_InetDownload (const char *sURL,cb_Integer lBytes,cb_Integer lPos1,void* lBytesRead,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData,void* lRet,cb_Integer lBlock)
{
  register cb_Integer l2 = 0;
  register cb_Integer l3;
  register BYTE* RetVar = NULL;
  HINTERNET  h1;
  cb_Integer l1;
  cb_Integer Ret1 = FALSE;
  BYTE* bTmp;

    h1 = cb_InetConnectURL(sURL);
    if (h1) {
      if (lPos1) {
        if (InternetSetFilePointer(h1,lPos1,NULL,FILE_BEGIN,0)==-1) {
          --Ret1;
          goto ExitFunction0000;
        }
      }
      l3 = 0;
      do {
        l1 = l2+lBlock+2;
        if (l3<l1) {
          bTmp = (BYTE*)cb_ReMemAllocM(RetVar,l1+0x4000);
          if (!bTmp) break;
          RetVar = bTmp;
          l3 = l1+0x4000;
        }
        if (!InternetReadFile(h1,RetVar+l2,lBlock,(DWORD*)(&l1))) {
          break;
        }
        if (l1<=0) {
          break;
        }
        l2 += (DWORD)l1;
        if (lBytes>0) {
          if (l2>=lBytes) {
            break;
          }
        }
        if (fcallback) {
          l1 = l2;
          Ret1 = fcallback(UserData,h1,RetVar,&l1);
          l2 = l1;
          if (Ret1) break;
        }
      }while(1);
      if (l2>0) {
        if (l2+sizeof(cb_Integer)<l3) { bTmp = (BYTE*)cb_ReMemAllocM(RetVar,l2+sizeof(cb_Integer)); if (bTmp) RetVar = bTmp; }
        if (RetVar) *(short*)(RetVar+l2) = 0;
      }
      else if (RetVar) {
        cb_MemFreeM(RetVar); RetVar = NULL;
      }
ExitFunction0000:;
      InternetCloseHandle(h1);
    }
  if (lBytesRead) {
    *(cb_Integer*)lBytesRead = l2;
  }
  if (lRet) {
    *(cb_Integer*)lRet = Ret1;
  }
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_InetDownloadFile */
cb_Integer cb_DEFCALL cb_InetDownloadFile (const char *sURL,const char *fName,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData)
{
  register BYTE *MyPtr1;
  register cb_File* f1;
  register cb_Integer RetVar;
  cb_Integer iRet;
  MyPtr1=cb_InetDownload(sURL,0,0,&iRet,fcallback,UserData);
  if (!MyPtr1) {
    return 0;
  }
  if ((f1 = cb_FileOpen(fName,_O_CREAT|_O_WRONLY|_O_BINARY))==NULL) return -1;
  RetVar = cb_FileWrite(f1,MyPtr1,iRet);
  cb_FileClose(f1);
  cb_MemFreeM(MyPtr1);
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_GetWebPage */
char* cb_DEFCALL cb_GetWebPage (const char *sURL,void *dst,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData)
{
  cb_Integer dwRet;
  register char *MyPtr1 = (char*)cb_InetDownload(sURL,0,0,&dwRet,fcallback,UserData);
  register char *RetVar = (char*)dst;
  if (!MyPtr1) {
    if (!RetVar) return cb_EMPTYSTR;
    if (RetVar==(char*)-1) RetVar = (char*)cb_MemAllocM(sizeof(cb_Integer));
    RetVar[0]=0;
  }
  else {
    if (RetVar==(char*)-1) return MyPtr1;
    if (!RetVar) return cb_AddTmpDynStr_(MyPtr1);
    cb_MemCopy(RetVar,MyPtr1,dwRet+1); cb_MemFreeM(MyPtr1);
  }
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_InetGet */
char* cb_DEFCALL cb_InetGet (HINTERNET hInet,void *dst,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData, cb_TInetGet *Ptr1,cb_Integer lBlock)
{
  register cb_Integer l1 = 0, l2, l3;
  BYTE *bBuf1 = NULL, *bBuf2;
  cb_Integer l;

  if (hInet!=NULL) {
    l3 = lBlock;
    if (Ptr1) {
      bBuf1 = Ptr1->bBuf;
      if (bBuf1) { l1 = Ptr1->iSize1; l2 = Ptr1->iSize2; goto Cont0000; }
    }
    l2 = l3;
Loop0000:
    l2+=0x4000;
    bBuf2 = (BYTE*)cb_ReMemAllocM(bBuf1,l2);
    if (bBuf2) {
      bBuf1 = bBuf2;
      do {
        l=0;
        if (!InternetReadFile(hInet,bBuf1+l1,l3,(DWORD*)(&l))) {
          if (Ptr1) {
            if (GetLastError()==ERROR_IO_PENDING) {
              Ptr1->bBuf = bBuf1;
              Ptr1->iSize1 = l1;
              Ptr1->iSize2 = l2;
              return (char*)-1;
            }
          }
        }
        if (l<=0) break;
        l1+=(DWORD)l;
        if (fcallback) {
          l=l1;
          if (fcallback(UserData,hInet,bBuf1,&l)) { l1=l; break; }
          l1=l;
        }
Cont0000:
        if (l1+l3>=l2) { l2+=l3; goto Loop0000; }
      }while(1);
    }
  }
  l3 = (cb_Integer)dst;
  if (l1<=0) {
    if (!l3) { l3 = (cb_Integer)cb_EMPTYSTR; goto Exit0000; }
    if (l3==-1) l3 = (cb_Integer)cb_MemAllocM(sizeof(cb_Integer));
  }
  else if (!l3 || l3==-1) {
    l3 = (cb_Integer)bBuf1;
    if (l1+sizeof(cb_Integer)<l2) { l3 = (cb_Integer)cb_ReMemAllocM((void*)l3,l1+sizeof(cb_Integer)); if (!l3) l3 = (cb_Integer)bBuf1; }
    bBuf1 = NULL;
    if (!dst) cb_AddTmpDynStr_((void*)l3);
  }
  else {
    cb_MemCopy((void*)l3, bBuf1, l1);
  }
  ((char*)l3)[l1] = 0;
Exit0000:
  if (bBuf1) cb_MemFreeM(bBuf1);
  if (Ptr1) {
    Ptr1->bBuf = NULL;
    Ptr1->iSize1 = l1;
    Ptr1->iSize2 = 0;
  }
  return (char*)l3;
}
/* END MODULE */


/* MODULE::cb_IsValidIP */
char* cb_DEFCALL cb_IsValidIP (const char *Str1,void *dst,cb_Integer flag1)
{
  register char* strA = (char*)Str1;
  register cb_Integer i1, i2, i3, i4;
  char sBuf[24], *strB;
  do {

    if (flag1) {
    for(;strA[0]!=0;strA++) {
      if (cb_IsDigit(strA[0])) {
        goto Found0000;
      }
    }

Exit0000:
    strA = (char*)dst;
    if (strA) {
      if (strA==(char*)-1) strA = (char*)cb_MemAllocM(4);
      strA[0]=0;
      return strA;
    }
    return cb_EMPTYSTR;
    }

Found0000:;
    i2 = 0;
    i3 = 0;
    i4 = 0;
    strB = sBuf;
    for(i1=0;strA[0]!=0;i1++) {
      if (cb_IsDigit(strA[i1])) {
        ++i2;
        if (i2>3) {
          goto Error0000;
        }
        continue;
      }
      if (strA[i1]=='.') {
Chk0000:
        ++i3;
        if (i3>3) {
          goto Error0000;
        }
        i2 = 0;
        continue;
      }
      if (!flag1) {
        goto Exit0000;
      }
      if (flag1<-1) {
        if (0==cb_MemComp(strA+i1,"&#46",4)) {
          i1-=i4;
          cb_MemCopy(strB, strA+i4, i1); strB+=i1; strB[0]='.'; strB++;
          i1+=i4;
          i1+=4; if (strA[i1]==';') i1++;
          i4=i1; i1--; goto Chk0000;
        }
      }
      break;
    }

    if (i2) {
      if (i3==3) {
        if (i4) { i1-=i4; cb_MemCopy(strB, strA+i4, i1); strB[i1]=0; strA=sBuf; i1=-1; }
        return cb_Left(strA,i1,dst);
      }
    }

Error0000:
    if (flag1<=0) {
      goto Exit0000;
    }
    strA+=i1;
  } while(1);
}
/* END MODULE */


/* MODULE::cb_GetIP1 */
static char* cb_DEFCALL cb_ipligence (char *sURL,const char *Str1,cb_Integer Len1)
{
  register const char *s;
  register char *MyPtr1; MyPtr1 = sURL;
  do {
    MyPtr1++;
    s = cb_StrIStr(MyPtr1,Str1);
    if (s) { s += Len1; MyPtr1 = (char*)s; }
    else if (Len1!=40) return cb_EMPTYSTR;
    else { Str1 = ">"; Len1 = 1; }
    s = cb_IsValidIP(MyPtr1,MyPtr1,Len1==25?1:-1);
  } while(s[0]==0);
  return (char*)s;
}
char* cb_DEFCALL cb_GetIP1 (char* sURL,void *dst,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData,cb_Integer flag1)
{
  register char* RetVar;
  register cb_Integer i = flag1;
  if (i==0) RetVar = "http://checkip.dyndns.org/";
  else if (i==2) RetVar = "http://www.whatismypublicip.com/";
  else if (i>0) RetVar = "http://www.ipligence.com/";
  else RetVar = "http://myip.israel.net/";
  register char* sBuf;  sBuf = cb_GetWebPage(RetVar,(void*)-1,fcallback,UserData);
  if (sURL) cb_StrCopy(sURL, sBuf);
  if (i==0) RetVar = cb_ipligence(sBuf,"Current IP Address",18);
  else if (i==2) RetVar = cb_ipligence(sBuf,"Your Public IP Address Is",25);
  else if (i>0) RetVar = cb_ipligence(sBuf,"Your IP address is",18);
  else RetVar = cb_ipligence(sBuf,"<td colspan=2 style='text-align:center'>",40);
  if (!dst || (dst==(void*)-1)) RetVar = cb_NewStr(RetVar,dst);
  else RetVar = cb_StrCopy(dst, RetVar);
  cb_MemFreeM(sBuf);
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_GetIP2 */
char* cb_DEFCALL cb_GetIP2 (char* sURL,void *dst,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData)
{
  return cb_GetIP1(sURL,dst,fcallback,UserData,TRUE);
}
/* END MODULE */


/* MODULE::cb_GetIP3 */
char* cb_DEFCALL cb_GetIP3 (char* sURL,void *dst,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData)
{
  return cb_GetIP1(sURL,dst,fcallback,UserData,2);
}
/* END MODULE */


/* MODULE::cb_GetIP4 */
char* cb_DEFCALL cb_GetIP4 (char* sURL,void *dst,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData)
{
  return cb_GetIP1(sURL,dst,fcallback,UserData,-2);
}
/* END MODULE */


/* MODULE::cb_GetIP5 */
static char* cb_DEFCALL cb_ipchicken (char *sURL,cb_Integer flag1)
{
  register const char *s;
  register char *strA = sURL;
  register cb_Integer i;
  register char *strB;
  i = 0;
  do {
    s = cb_StrChar(strA,'\n'); if (!s) { i = 0; break; }
    if (i>=34) {
      *(char*)s = 0; strA = cb_LTrimX(strA,(void*)-2);
      if (cb_IsDigit(*strA)) { s++; i = flag1; break; }
    }
    strA = (char*)s; strA++; i++;
  } while(1);
  strA = cb_IsValidIP(strA,strA,TRUE);
  if (i>0) {
    s = cb_StrStr(s,"Address:");
    if (s) {
      s += 8; s = cb_StrChar(s,'\n');
      if (s) {
        i = (cb_Integer)cb_StrChar(s,'<');
        if (i) {
          strB = strA;
          strA += cb_StrLen(strA); strA[0] = '\t';
          strA++; i -= (cb_Integer)s;
          cb_MemCopy(strA,s,i); strA[i] = 0; cb_TrimX(strA,strA);
          strA = strB;
        }
      }
    }
  }
  return strA;
}
char* cb_DEFCALL cb_GetIP5 (char *sURL,void *dst,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData,cb_Integer flag1)
{
  register char* RetVar;
  register char* sBuf;  sBuf = cb_GetWebPage("http://www.ipchicken.com/",(void*)-1,fcallback,UserData);
  if (sURL) cb_StrCopy(sURL, sBuf);
  RetVar = cb_ipchicken(sBuf,flag1);
  if (!dst || (dst==(void*)-1)) RetVar = cb_NewStr(RetVar,dst);
  else RetVar = cb_StrCopy(dst, RetVar);
  cb_MemFreeM(sBuf);
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_GetIP6 */
static char* cb_DEFCALL cb_myipaddress (char *sURL)
{
  register const char *s;
  register char *MyPtr1 = sURL;

  s = cb_StrIStr(MyPtr1,"do not script");
  if (s) {
    s += 15; s = cb_StrChar(s,'\n');
    if (s) { s++; s = cb_LTrimX(s,(void*)-2); goto Chk0000; }
  }

  s = MyPtr1;
  do {
    s = cb_StrIStr(s,"href="); if (!s) return cb_EMPTYSTR;
    s += 7;
Chk0000:
    MyPtr1 = cb_IsValidIP(s,(void*)s,-2);
  } while(MyPtr1[0]==0);

  return MyPtr1;
}
char* cb_DEFCALL cb_GetIP6 (char* sURL,void *dst,cb_Integer (cb_CDECL *fcallback)(const void*,HINTERNET,BYTE*,cb_Integer*),const void *UserData)
{
  register char* RetVar;
  register char* sBuf;  sBuf = cb_GetWebPage("http://whatismyipaddress.com/",(void*)-1,fcallback,UserData);
  if (sURL) cb_StrCopy(sURL, sBuf);
  RetVar = cb_myipaddress(sBuf);
  if (!dst || (dst==(void*)-1)) RetVar = cb_NewStr(RetVar,dst);
  else RetVar = cb_StrCopy(dst, RetVar);
  cb_MemFreeM(sBuf);
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_QFind */
cb_Integer cb_DEFCALL cb_QFind (cb_UInteger s, const void *a, cb_Integer iMax, cb_UInteger es)
{
  register cb_UInteger i = iMax;
  register cb_UInteger j;
  register cb_Integer iLow = 0;
  register cb_Integer iHigh;

  if ((cb_Integer)es<=0) es = sizeof(cb_UInteger*);
  while (iLow!=i) {
    iHigh = i; i += iLow;
Again0000:;
    i >>= 1;
    j = (cb_UInteger)a; j += es*i; j = *(cb_UInteger*)j;
    if (s==j) {
      return i;
    }
    if (s>j) {
      if (iLow!=i) {
        iLow = i; i += iHigh;
        goto Again0000;
      }
      return i+(cb_MIN_INTEGER | 1);
    }
  }
  return i | cb_MIN_INTEGER;
}
/* END MODULE */


/* MODULE::cb_QFindStr */
cb_Integer cb_DEFCALL cb_QFindStr (const void* s, const void *a, cb_Integer iMax, cb_UInteger es, cb_Integer l)
{
  register cb_UInteger i = iMax;
  register cb_UInteger j;
  register cb_Integer iLow = 0;
  register cb_Integer iHigh;

  if ((cb_Integer)es<=0) es = sizeof(const char*);
  if (l<=0) l = cb_StrLen((const char*)s)+1;
  while (iLow!=i) {
    iHigh = i; i += iLow;
Again0000:;
    i >>= 1;
    j = es; j *= i; j += (cb_Integer)a;
    j = cb_MemComp(s,*(const char**)j,l);
    if (j==0) {
      return i;
    }
    if (j<(cb_UInteger)cb_MIN_INTEGER) {
      if (iLow!=i) {
        iLow = i; i += iHigh;
        goto Again0000;
      }
      return i+(cb_MIN_INTEGER | 1);
    }
  }
  return i | cb_MIN_INTEGER;
}
/* END MODULE */


/* MODULE::cb_QFindAny */
cb_Integer cb_DEFCALL cb_QFindAny (const void *s, const void *a, cb_Integer iMax, cb_Integer (cb_CDECL*cmp)(const void*,const void*,const void*,cb_Integer), const void *UserData)
{
  register cb_UInteger i = iMax;
  register cb_Integer iLow = 0;
  register cb_Integer j;
  register cb_Integer iHigh;

  while (iLow!=i) {
    iHigh = i; i += iLow;
Again0000:;
    i >>= 1;
    j = cmp(UserData,s,a,i);
    if (j==0) {
      return i;
    }
    if (j>0) {
      if (iLow!=i) {
        iLow = i; i += iHigh;
        goto Again0000;
      }
      return i+(cb_MIN_INTEGER | 1);
    }
  }
  return i | cb_MIN_INTEGER;
}
/* END MODULE */


/* MODULE::cb_QSort */
#define cb_QSort_min(a, b)  (a) < (b) ? a : b

/*
 * Qsort routine from Bentley & McIlroy's "Engineering a Sort Function".
 */
#define cb_QSort_swapcode(TYPE, parmi, parmj, n) {     \
  long i = (n) / sizeof (TYPE);       \
  register TYPE *pi = (TYPE *) (parmi);     \
  register TYPE *pj = (TYPE *) (parmj);     \
  do {             \
    register TYPE  t = *pi;    \
    *pi++ = *pj;        \
    *pj++ = t;        \
        } while (--i > 0);        \
}

#define cb_QSort_SWAPINIT(a, es) swaptype = ((char *)a - (char *)0) % sizeof(long) || \
  es % sizeof(long) ? 2 : es == sizeof(long)? 0 : 1;

static inline void cb_QSort_swapfunc(void *a, void *b, cb_Integer n, cb_Integer swaptype)
{
  if(swaptype <= 1)
    cb_QSort_swapcode(long, a, b, n)
  else
    cb_QSort_swapcode(char, a, b, n)
}

#define cb_QSort_swap(a, b)          \
  if (swaptype == 0) {        \
    long t = *(long *)(a);      \
    *(long *)(a) = *(long *)(b);    \
    *(long *)(b) = t;      \
  } else            \
    cb_QSort_swapfunc(a, b, es, swaptype)

#define cb_QSort_vecswap(a, b, n)   if ((n) > 0) cb_QSort_swapfunc(a, b, n, swaptype)

static inline char *cb_QSort_med3(char *a, char *b, char *c, cb_Integer (cb_CDECL*cmp)(const void*,const void*,const void*), const void *UserData)
{
  return cmp(UserData, a, b) < 0 ?
         (cmp(UserData, b, c) < 0 ? b : (cmp(UserData, a, c) < 0 ? c : a ))
              :(cmp(UserData, b, c) > 0 ? b : (cmp(UserData, a, c) < 0 ? a : c ));
}

void cb_DEFCALL cb_QSort (void *a, cb_UInteger n, cb_UInteger es, cb_Integer (cb_CDECL*cmp)(const void*,const void*,const void*), const void *UserData)
{
  char *pa, *pb, *pc, *pd, *pl, *pm, *pn;
  cb_Integer d, r, swaptype, swapcnt;

loop:  cb_QSort_SWAPINIT(a, es);
  swapcnt = 0;
  if (n < 7) goto InsertionSort0000;
  pm = (char*)a + (n / 2) * es;
  if (n > 7) {
    pl = (char*)a;
    pn = (char*)a + (n - 1) * es;
    if (n > 40) {
      d = (n / 8) * es;
      pl = cb_QSort_med3(pl, pl + d, pl + 2 * d, cmp, UserData);
      pm = cb_QSort_med3(pm - d, pm, pm + d, cmp, UserData);
      pn = cb_QSort_med3(pn - 2 * d, pn - d, pn, cmp, UserData);
    }
    pm = cb_QSort_med3(pl, pm, pn, cmp, UserData);
  }
  cb_QSort_swap(a, pm);
  pa = pb = (char*)a + es;

  pc = pd = (char*)a + (n - 1) * es;
  for (;;) {
    while (pb <= pc && (r = cmp(UserData, pb, a)) <= 0) {
      if (r == 0) {
        swapcnt = 1;
        cb_QSort_swap(pa, pb);
        pa += es;
      }
      pb += es;
    }
    while (pb <= pc && (r = cmp(UserData, pc, a)) >= 0) {
      if (r == 0) {
        swapcnt = 1;
        cb_QSort_swap(pc, pd);
        pd -= es;
      }
      pc -= es;
    }
    if (pb > pc)
      break;
    cb_QSort_swap(pb, pc);
    swapcnt = 1;
    pb += es;
    pc -= es;
  }
  if (swapcnt == 0) {  /* Switch to insertion sort */
InsertionSort0000:
    for (pm = (char*)a + es; pm < (char *) a + n * es; pm += es)
      for (pl = pm; pl > (char *) a && cmp(UserData, pl - es, pl) > 0;
           pl -= es)
        cb_QSort_swap(pl, pl - es);
    return;
  }

  pn = (char*)a + n * es;
  r = cb_QSort_min(pa - (char *)a, pb - pa);
  cb_QSort_vecswap(a, pb - r, r);
  r = cb_QSort_min(pd - pc, pn - pd - (cb_Integer)es);
  cb_QSort_vecswap(pb, pn - r, r);
  if ((r = pb - pa) > (cb_Integer)es)
    cb_QSort(a, r / es, es, cmp, UserData);
  if ((r = pd - pc) > (cb_Integer)es) {
    /* Iterate rather than recurse to save stack space */
    a = pn - r;
    n = r / es;
    goto loop;
  }
/*    cb_QSort(pn - r, r / es, es, cmp);*/
}
/* END MODULE */


/* MODULE::cb_SendKeys */
static void cb_DEFCALL cb_SendKeysOneKey (BYTE k, cb_Integer flag=0,HWND hWnd=NULL);
static void cb_DEFCALL cb_SendKeysOneKey (BYTE k, cb_Integer flag,HWND hWnd)
{
  HWND hWin;
  if (hWnd) {
    hWin = GetForegroundWindow();
    if (hWin!=hWnd) { SetForegroundWindow(hWnd); SetFocus(hWnd); }
  }
  if ((flag & 1)==0) {
    keybd_event(k,0,KEYEVENTF_EXTENDEDKEY,0);
  }
  if ((flag & 2)==0) {
    keybd_event(k,0,KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP,0);
  }
}
static void cb_DEFCALL cb_SendKeysChar (BYTE k,HWND hWnd=NULL);
static void cb_DEFCALL cb_SendKeysChar (BYTE k,HWND hWnd)
{
  register cb_Integer flag=0;

  /* Select Case k */
  if (k==92) {
    k=VK_OEM_5;
    goto EndSelect_0;
  }
  if (k==46) {
    k=VK_OEM_PERIOD;
    goto EndSelect_0;
  }
  if (k==58) {
    flag=VK_SHIFT;
    k=VK_OEM_1;
    goto EndSelect_0;
  }
  if (k==63) {
    flag=VK_SHIFT;
    k=VK_OEM_2;
    goto EndSelect_0;
  }
  if (k==126) {
    k=VK_RETURN;
  }
  else  // case else
  {
    if (k>=65 && k<=90) {
      flag=VK_SHIFT;
    }
    else if (k>=97 && k<=122) {
      k&= ~(32);
    }
  }
  EndSelect_0:;  /* k */
  if (flag) {
    cb_SendKeysOneKey(flag,2,hWnd);
  }
  if (k) {
    cb_SendKeysOneKey(k,0,hWnd);
  }
  if (flag) {
    cb_SendKeysOneKey(flag,1,hWnd);
  }
}
static void cb_DEFCALL cb_SendKeysShiftUp (cb_Integer flag,HWND hWnd=NULL);
static void cb_DEFCALL cb_SendKeysShiftUp (cb_Integer flag,HWND hWnd)
{
  if ((flag & VK_SHIFT)) {
    cb_SendKeysOneKey(VK_SHIFT,1,hWnd);
  }
  if ((flag & VK_CONTROL)) {
    cb_SendKeysOneKey(VK_CONTROL,1,hWnd);
  }
  if ((flag & VK_MENU)) {
    cb_SendKeysOneKey(VK_MENU,1,hWnd);
  }
}
static cb_Integer cb_DEFCALL cb_SendKeysIsShiftKey (cb_Integer k)
{
  /* Select Case k */
  if (k=='+') {
    k=VK_SHIFT;
    goto Shift0000;
  }
  if (k=='^') {
    k=VK_CONTROL;
    goto Shift0000;
  }
  if (k=='%') {
    k=VK_MENU;
Shift0000:;
    return k;
  }
  /* End Select: k */
  return 0;
}
static cb_Integer cb_DEFCALL cb_SendKeysGetNum (const char *Str1, cb_Integer Pos1)
{
  register char *Str2;
  register cb_Integer i;
  Str1 += Pos1;
  Str2 = cb_LTrimX(Str1,(void*)-2);
  if (Str2[0]=='(') { Str2++; Str2[cb_StrLen(Str2)-1]=0; }
  else if (Str2[0]=='=') Str2++;
  else if ((char*)Str1==Str2) return -1;
  Str2 = cb_TrimX(Str2,Str2);
  if (Str2[0]!='"') return cb_AtoL(Str2);
  Str2++; Str2[cb_StrLen(Str2)-1]=0;
  i = (cb_Integer)FindWindow(NULL, Str2);
  if (i<=0) i = (cb_Integer)FindWindow(Str2,NULL);
  return i;
}
static void cb_DEFCALL cb_SendKeysPause (const char *Str1, cb_Integer Pos1)
{
  register cb_Integer i = cb_SendKeysGetNum(Str1,Pos1);
  if (i>0) Sleep(i);
}
static cb_Integer cb_DEFCALL cb_SendKeysExStr1 (const char *Str2,char *dst,cb_Integer *flag1,cb_Integer flag2,cb_Integer *bRepeat,HWND *hWnd)
{
  register cb_Integer i;
  register cb_Integer i1 = 0;
  register char *Str1;
  cb_Integer k;
  i = cb_InChar(Str2+i1+1,'}');
  if (i<0) {
    return i1;
  }
Again0000:;
  i1++;
  Str1 = cb_TrimX(cb_Left(Str2+i1,i,dst),dst);
  if (Str1[0]==0) {
    i1+=i;
    i=0;
    do {
      ++i;
      /* Select Case Str2[i1+i] */
      if ((Str2[i1+i]==0) || (Str2[i1+i]=='{')) {
        return i1;
      }
      if (Str2[i1+i]=='}') {
        do { cb_SendKeysOneKey('}',0,*hWnd); if (!*bRepeat) break; *bRepeat--; }while(1);
        *hWnd = NULL;
        i--;
        goto Again0000;
      }
      /* End Select: Str2[i1+i] */
    }while(1);
  }
  /* Select Case 0 */
  if ((0==cb_MemIComp("insert",Str1,6+1)) || (0==cb_MemIComp("ins",Str1,3+1))) {
    k=VK_INSERT;
    goto EndSelect_1;
  }
  if ((0==cb_MemIComp("delete",Str1,6+1)) || (0==cb_MemIComp("del",Str1,3+1))) {
    k=VK_DELETE;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("home",Str1,4+1)) {
    k=VK_HOME;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("end",Str1,3+1)) {
    k=VK_END;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("pgup",Str1,4+1)) {
    k=VK_PRIOR;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("pgdn",Str1,4+1)) {
    k=VK_NEXT;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("up",Str1,2+1)) {
    k=VK_UP;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("down",Str1,4+1)) {
    k=VK_DOWN;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("left",Str1,4+1)) {
    k=VK_LEFT;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("right",Str1,5+1)) {
    k=VK_RIGHT;
    goto EndSelect_1;
  }
  if ((0==cb_MemIComp("backspace",Str1,9+1)) || (0==cb_MemIComp("bksp",Str1,4+1))) {
    k=VK_BACK;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("tab",Str1,3+1)) {
    k=VK_TAB;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("enter",Str1,5+1)) {
    k=VK_RETURN;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("esc",Str1,3+1)) {
    k=VK_ESCAPE;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("help",Str1,4+1)) {
    k=VK_HELP;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("prtsc",Str1,5+1)) {
    k=VK_SNAPSHOT;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("win",Str1,3+1)) {
    k=VK_LWIN;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("capslock",Str1,8+1)) {
    k=VK_CAPITAL;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("numlock",Str1,7+1)) {
    k=VK_NUMLOCK;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f1",Str1,2+1)) {
    k=VK_F1;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f2",Str1,2+1)) {
    k=VK_F2;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f3",Str1,2+1)) {
    k=VK_F3;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f4",Str1,2+1)) {
    k=VK_F4;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f5",Str1,2+1)) {
    k=VK_F5;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f6",Str1,2+1)) {
    k=VK_F6;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f7",Str1,2+1)) {
    k=VK_F7;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f8",Str1,2+1)) {
    k=VK_F8;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f9",Str1,2+1)) {
    k=VK_F9;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f10",Str1,3+1)) {
    k=VK_F10;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f11",Str1,3+1)) {
    k=VK_F11;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f12",Str1,3+1)) {
    k=VK_F12;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f13",Str1,3+1)) {
    k=VK_F13;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f14",Str1,3+1)) {
    k=VK_F14;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f15",Str1,3+1)) {
    k=VK_F15;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("f16",Str1,3+1)) {
    k=VK_F16;
    goto EndSelect_1;
  }
  if (0==cb_MemIComp("shift",Str1,5+1)) {
    k=VK_SHIFT;
    goto Shift0000;
  }
  if ((0==cb_MemIComp("ctrl",Str1,4+1)) || (0==cb_MemIComp("control",Str1,7+1))) {
    k=VK_CONTROL;
    goto Shift0000;
  }
  if ((0==cb_MemIComp("alt",Str1,3+1))||(0==cb_MemIComp("menu",Str1,4+1))) {
    k=VK_MENU;
Shift0000:
    if (!(flag2&k)) (*flag1) |= k;
    goto Exit0000;
  }
  if (0==cb_MemIComp("repeat",Str1,6)) {
    k = cb_SendKeysGetNum(Str1,6) - 1;
    if (k>0) *bRepeat = k;
    goto Exit0000;
  }
  if ((0==cb_MemIComp("pause",Str1,5)) || (0==cb_MemIComp("sleep",Str1,5))) {
    cb_SendKeysPause(Str1,5);
    goto Exit0000;
  }
  if (0==cb_MemIComp("wait",Str1,4)) {
    cb_SendKeysPause(Str1,4);
    goto Exit0000;
  }
  if (0==cb_MemIComp("setfocus",Str1,8)) {
    k = cb_SendKeysGetNum(Str1,8);
    if (k>0) *hWnd = (HWND)k;
  }
  else  // case else
  {
    goto Exit0000;
  }
  EndSelect_1:;  /* 0 */
  do { cb_SendKeysOneKey(k,0,*hWnd); if (!*bRepeat) break; *bRepeat--; }while(1);
  *hWnd = NULL;
Exit0000:;
  return i1+i;
}
static cb_Integer cb_DEFCALL cb_SendKeys_ (const char *Str1, cb_Integer Pos1, cb_Integer flag2, char *dst, cb_Integer p=FALSE, HWND hWnd=NULL);
static cb_Integer cb_DEFCALL cb_SendKeys_ (const char *Str1, cb_Integer Pos1, cb_Integer flag2, char *dst, cb_Integer p, HWND hWnd)
{
  register cb_Integer i1=Pos1;
  register cb_Integer i2;
  cb_Integer flag1=0;
  cb_Integer bRepeat=0;
  BYTE k;

  do {
    k=Str1[i1];
    if (!k) break;
    i2=cb_SendKeysIsShiftKey(k);
    if (i2) {
      if (!(flag2&i2)) {
        flag1|=i2;
        /*do {*/ cb_SendKeysOneKey(i2,2,hWnd); //if (!bRepeat) break; bRepeat--; }while(1);
      }
      goto Incr0000;
    }
    /* Select Case k */
    if (p) goto CaseElse0000;
    if (k=='{') {
      i1+=cb_SendKeysExStr1(Str1+i1,dst,&flag1,flag2,&bRepeat, &hWnd);
      goto ChkShift0000;
    }
    if (Pos1 && k==')') {
      i1++;
      break;
    }
    if (k=='(' && (flag1 || bRepeat || hWnd)) {
      do { i2=cb_SendKeys_(Str1, i1, flag1, dst, p, hWnd); if (!bRepeat) break; bRepeat--; }while(1);
      i1=i2; hWnd = NULL; continue;
    }
    // case else
CaseElse0000:
      do { cb_SendKeysChar(k, hWnd); if (!bRepeat) break; bRepeat--; }while(1);
ChkShift0000:;
      if (flag1) {
        cb_SendKeysShiftUp(flag1,hWnd);
        flag1=0;
      }
      hWnd = NULL;
    /* End Select: k */
Incr0000:
    i1++;
  }while(1);
  if (flag1) {
    cb_SendKeysShiftUp(flag1,hWnd);
  }
  return i1;
}
void cb_DEFCALL cb_SendKeys (const char *Str1, cb_Integer w, cb_Integer p)
{
  char *dst = (char*)cb_MemAllocM(0x10000);
  cb_SendKeys_(Str1, 0, 0, dst, p);
  cb_MemFreeM(dst);
  if (w) cb_KeyPressed(-2,w-1);
}
/* END MODULE */


/* MODULE::cb_CreateWave */
static void cb_DEFCALL cb_PrepareWaveHeader_ (cb_Twave_header* Header,cb_UInteger nSamples,cb_UInteger nChannels,cb_UInteger SamplesPerSecond,cb_UInteger BitsPerSample)
{
  cb_UInteger BlkAlign; BlkAlign=nChannels*BitsPerSample/8;
  cb_UInteger DataLength; DataLength=nSamples*BlkAlign;
  Header[0].riff='FFIR';
  Header[0].rl=DataLength+36;
  Header[0].typ='EVAW';
  Header[0].fmt=' tmf';
  Header[0].csize=16;
  Header[0].tag=1;
  Header[0].nchan=(short)nChannels;
  Header[0].sps=SamplesPerSecond;
  Header[0].avgbps=SamplesPerSecond*BlkAlign;
  Header[0].bla=(short)BlkAlign;
  Header[0].bps=(short)BitsPerSample;
  Header[0].data='atad';
  Header[0].dl=DataLength;
}

char * cb_DEFCALL cb_CreateWave (double freq,cb_UInteger duration,double Vol,void *sze,void *cArray,cb_UInteger sps)
{
  cb_Integer iReturnVar;
  wave_16bit_1chan *ton;
  PCHAR  bArray;
  cb_Twave_header  header;
  cb_UInteger nSamples;
  double  w;
  double  A;
  cb_UInteger i;
  nSamples=sps*duration/1000;
  w=atan(1.0)*8.0*(double)freq/(double)sps;
  if (Vol>100.0) A=Vol;
  else A=((double)Vol)*32767.0/100.0;
  ton = (wave_16bit_1chan*) cb_MemAllocM(nSamples * sizeof(wave_16bit_1chan)); if (!ton) return NULL;
  for(i=0;i<nSamples;i+=1) {
    ton[i].a=(cb_Integer)(A*sin(w*i));
  }
  cb_PrepareWaveHeader_(&header,nSamples,1,sps,16);
  iReturnVar=sizeof(header)+header.dl;
  if (cArray==NULL || cArray==(void*)-1) {
    bArray = cb_NewStr_(NULL,cArray,iReturnVar);
  }
  else {
    bArray = (PCHAR)cArray;
  }
  if (bArray) {
    cb_MemCopy(bArray,&header,sizeof(header));
    cb_MemCopy(bArray+sizeof(header),ton,header.dl);
  }
  if (sze) *(cb_Integer*)sze = iReturnVar;
  cb_MemFreeM(ton);
  return bArray;
}
/* END MODULE */


/* MODULE::cb_CreatePluckedStringWave */
// Karplus plucked string alogrithm
short * cb_DEFCALL cb_CreatePluckedStringWave (double freq, cb_UInteger duration, double Vol, void *dst, void *Written, cb_UInteger sps)
{
  register cb_Integer i = (cb_Integer)((double)sps / freq);
  register double *buf1 = (double*)cb_MemAllocM(i*sizeof(double)); if (buf1==NULL) return NULL;
  register double *buf2 = (double*)dst;
  duration *= sps; duration /= 1000;
  if (buf2==NULL || buf2==(double*)-1) {
    buf2 = (double*)cb_NewStr_(NULL,buf2,duration*sizeof(short)); if (buf2==NULL) { cb_MemFreeM(buf1); return NULL; }
    dst = buf2;
  }
  register short *buf3 = (short*)buf2;
  cb_Integer N = i;

  cb_Randomize((cb_UInteger)time(0));

  while (i>0) {
    i--;
    buf1[i] = (double)(cb_Rand() * (1.0/(double)RAND_MAX) - .5);
  }

  if (Written) *(cb_Integer*)Written = duration;
  double *buf = buf1;
  buf2 = buf1;
  i = 0;
  if (Vol<=100.0) Vol = (double)(Vol * 32767.0 / 100.0);
  for (; duration>0; duration--) {
    buf3[0] = (short)(buf1[0] * Vol);
    i++;
    if (i < N) buf2++;
    else { buf2=buf; i=0; }
    buf1[0] = (buf1[0] + buf2[0]);
    buf1=buf2;
  }
  cb_MemFreeM(buf);
  return (short*)dst;
}
/* END MODULE */


/* MODULE::cb_MIDIOutOpenDevice */
HMIDIOUT cb_DEFCALL cb_MIDIOutOpenDevice (cb_Integer h)
{
  register HMIDIOUT h1;
  MIDIOUTCAPS outcaps;
  if (midiOutGetDevCaps(h, &outcaps, sizeof(outcaps))!=0) h = 0;
  midiOutOpen(&h1,h,0,0,CALLBACK_NULL);
  return h1;
}
void cb_DEFCALL cb_MIDIOutCloseDevice (cb_Integer flag1)
{
  if (flag1 || cb_MIDIMSGQuoeCnt_ != -1) { KillTimer(0, cb_idMIDIOutTimer); cb_MIDIMSGQuoeCnt_ = -1; }
  if (cb_hMIDIOutDevice) { midiOutClose(cb_hMIDIOutDevice); cb_hMIDIOutDevice = NULL; }
}
/* END MODULE */


/* MODULE::cb_MIDIOutMsgEx */
static void CALLBACK cb_MIDIOutTimerProc_ (HWND hWnd, UINT Msg, UINT_PTR wParam, DWORD lParam)
{
  register cb_Integer i;
  register clock_t t=GetTickCount();
  register cb_Integer flag1 = FALSE;

  for (i=cb_MIDIMSGQuoeCnt_;i>0;i--) {
    Msg = cb_MIDIMSGQuoeBuf_[i].Msg;
    if (Msg != (cb_UInteger)-1) {
      if (cb_MIDIMSGQuoeBuf_[i].EndTime > t)
        flag1++;
      else {
        if ((Msg & 0x00F0) == 0x0090) midiOutShortMsg(cb_hMIDIOutDevice, Msg & (~0x0010));
        cb_MIDIMSGQuoeBuf_[i].Msg = -1;
      }
    }
  }
  if (!flag1) cb_MIDIOutCloseDevice(TRUE);
}
__declspec(noinline) void cb_CDECL cb_MIDIOutMsgEx (HMIDIOUT h, cb_Integer (cb_CDECL *f)(HMIDIOUT,cb_Integer,cb_Integer,cb_Integer), cb_Integer NumMsgs, cb_Integer flag1, cb_UInteger Msg, ...)
{
  register cb_UInteger M;
  register cb_Integer i1;
  register cb_UInteger *Ns = &Msg;
  cb_Integer flag2 = flag1 & 0x000F;
  cb_Integer l1;
  cb_Integer l2 = 0;

  if (!h) {
    if (!cb_hMIDIOutDevice) cb_hMIDIOutDevice = cb_MIDIOutOpenDevice();
    h = cb_hMIDIOutDevice;
  }

  for(i1=NumMsgs;i1>0;i1--) {
    M = Ns[0];
    if (!(M & 0x00F0)) M |= 0x0090;
    if ((M & 0x00F0)==0x0090) if (!(M & 0x7FFF0000)) M &= (~0x0010);
    Ns++;
    l1 = Ns[0];
    Ns++;
    midiOutShortMsg(h, M);
    if (flag2==1) {
      if (f) if (f(h,NumMsgs-i1,M,l1)) { h = NULL; goto MIDI0000; }
      if (l1>0) Sleep(l1);
MIDI0000:
      if ((M & 0x00F0)==0x0090) midiOutShortMsg(h, M&(~0x0010));
      if (h==NULL) goto Exit0000;
    }
    else if (flag2==2) {
      if (l2 < l1) l2 = l1;
    }
    else if ((l1>0) && ((M & 0x00F0)==0x0090)) {
      i1 = (cb_MIDIMSGQuoeCnt_+1) & (0x1000-1);
      cb_MIDIMSGQuoeBuf_[i1].Msg = M & 0x00007FFF;
      cb_MIDIMSGQuoeBuf_[i1].EndTime = GetTickCount() + l1;
      if (cb_MIDIMSGQuoeCnt_!=-1)
        cb_MIDIMSGQuoeCnt_ = i1;
      else {
        cb_MIDIMSGQuoeCnt_ = i1; cb_idMIDIOutTimer = SetTimer(0, 0, cb_MIDIOutTimerInterval, (TIMERPROC)cb_MIDIOutTimerProc_);
      }
    }
  }
  if (flag2==2) {
    if (l2>0) Sleep(l2);
    for(i1=NumMsgs;i1>0;i1--) {
      M = Ns[0];
      Ns++;
      Ns++;
      if (!(M & 0x00F0)) continue;
      if ((M & 0x00F0)!=0x0090) continue;
      if (!(M & 0x7FFF0000)) continue;
      midiOutShortMsg(h, M & (~0x0010));
    }
  }
Exit0000:
  if (flag1&0x0010) {
    if (cb_MIDIMSGQuoeCnt_==-1) cb_MIDIOutCloseDevice();
  }
}
/* END MODULE */


/* MODULE::cb_MIDIOutMsg */
void cb_DEFCALL cb_MIDIOutMsg (cb_UInteger Note, clock_t l1, cb_UInteger inst, cb_UInteger Vel, cb_UInteger Ch, cb_Integer flag1, HMIDIOUT h, cb_Integer (cb_CDECL *f)(HMIDIOUT,cb_Integer,cb_Integer,cb_Integer))
{
  if (inst<128) cb_MIDIOutMsgEx(h, NULL, 1, flag1 & 0x0F, ((inst&0x007F)<<8)|0x00C0|(Ch&0x000F), 0);
  cb_MIDIOutMsgEx(h, f, 1, flag1, ((Vel&0x007F)<<16)|((Note&0x007F)<<8)|(Ch&0x00FF), l1);
}
/* END MODULE */


/* MODULE::cb_PackMIDIMsg */
cb_UInteger cb_DEFCALL cb_PackMIDIMsg (cb_UInteger Note, cb_UInteger Vel, cb_UInteger Ch, cb_UInteger ct)
{
  if (ct>0x09||Ch>0x0090) {
    if  (Vel>0x007F && Note==0) Note = Vel;
    if  (Note > 0x007F) Vel = (Note & 0x3F80) << 1;
  }
  return ((Vel&0x007F)<<16)|((Note&0x007F)<<8)|((ct&0x0F)<<4)|(Ch&0x000F);
}
/* END MODULE */


/* MODULE::cb_GenerateINIFileName */
char* cb_DEFCALL cb_GenerateINIFileName (void *dst,const char *sExt,const char *fName)
{
  register char *s = (char*)dst;
  if (s==(char*)-1) s = (char*)cb_MemAllocM(0x0800+2);
  else if (s==NULL) s = cb_TmpDynStr(0x0800);
  register const char *fn = fName;
  register cb_Integer i, n;
  if ((cb_UInteger)(sExt-1)>=(cb_UInteger)(-1-1)) { if (sExt==NULL) sExt = ".ini"; else sExt = ".cfg"; }
  if (!fn || fn[0]==0) {
    cbApp_EXEName(2,s);
    cb_StrCat(s,sExt);
  }
  else {
    i = cb_StrLen(fn); n = i;
    do { if (i<=0) goto Exit0000; i--; if (fn[i]=='\\' || fn[i]=='/') { Exit0000:; i = n; break; } } while (fn[i]!='.');
    if (fn[0]=='\\' || fn[0]=='/' || fn[1]==':') { if (i>0) cb_MemMove(s,fn,i); }
    else { cbApp_EXEPath(1,s); n = cb_StrLen(s); if (i>0) cb_MemMove(s+n,fn,i); i += n; }
    cb_StrMove(s+i,sExt);
  }
  return s;
}
/* END MODULE */


/* MODULE::cb_ReadINISection */
char* cb_DEFCALL cb_ReadINISection (const char *sSection,const char *fName,void* dst, cb_Integer flag1)
{
  register char *RetVar = (char*)dst;
  register char *sBuf = RetVar;
  register cb_Integer i;
  char *fn;
  cb_Integer Num1;
  if (!sBuf || sBuf==(char*)-1) sBuf = (char*)cb_MemAllocM(0x40000);
  if (sBuf) {
    sBuf[0] = 0;
    fn = (char*)fName;
    if (!fn || fn[0]==0) {
      fn = cb_GenerateINIFileName((void*)-1); fName = NULL;
    }
    Num1=GetPrivateProfileSection(sSection,sBuf,0x40000-1,fn);
    RetVar = cb_NewStr(sBuf,dst,Num1);
    if (!dst || dst==(void*)-1) cb_MemFreeM(sBuf); if (!fName) cb_MemFreeM(fn);
    if (!RetVar) { RetVar = (char*)dst; goto Chk0000; }
    if (flag1) {
      i = 0;
      do {
        i+=cb_StrLen(RetVar+i);
        if (i>=Num1) break;
        RetVar[i]='\n';
        i++;
      }while(1);
    }
    ((short*)(RetVar+Num1))[0]=0;
    goto Exit0000;
  }
Chk0000:
  if (!RetVar) RetVar = cb_EMPTYSTR;
  else if (RetVar==(char*)-1) RetVar = cb_NewStr_(NULL,(void*)-1,0);
  else RetVar[0] = 0;
Exit0000:
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_ReadINIKey */
char* cb_DEFCALL cb_ReadINIKey (const char *sSection,const char *sKey,const char *sDefault,const char *fName,void* dst)
{
  register char *sBuf = (char*)cb_MemAllocM(0x4000);
  register cb_Integer Num1;
  register char *fn = (char*)fName;
  if (!fn || fn[0]==0) {
    fn = cb_GenerateINIFileName((void*)-1); fName = NULL;
  }
  Num1=GetPrivateProfileString(sSection,sKey,sDefault,sBuf,0x4000-1,fn);
  if (!fName) cb_MemFreeM(fn);
  fn = (char*)dst;
  if (fn==(char*)-1) fn = sBuf;
  else if (fn==NULL) fn = cb_AddTmpDynStr_(sBuf);
  cb_NewStr(sBuf,fn,Num1);
  if (fn!=sBuf) cb_MemFreeM(sBuf);
  return fn;
}
/* END MODULE */


/* MODULE::cb_ReadINIInt */
cb_Integer cb_DEFCALL cb_ReadINIInt (const char *strSection,const char *strKey,cb_Integer lDefault,const char *fName)
{
  register cb_Integer i;
  register char *fn = (char*)fName;
  if (!fn || fn[0]==0) {
    fn = cb_GenerateINIFileName((void*)-1); fName = NULL;
  }
  i = GetPrivateProfileInt(strSection,strKey,lDefault,fn);
  if (!fName) cb_MemFreeM(fn);
  return i;
}
/* END MODULE */


/* MODULE::cb_ReadINILLong */
long long cb_DEFCALL cb_ReadINILLong (const char *strSection,const char *strKey,long long lDefault,const char *fName)
{
  char  sBuf[128];
  cb_CStrL(lDefault,10,sBuf);
  return (long long)cb_AtoULLBase(cb_ReadINIKey(strSection,strKey,sBuf,fName,sBuf));
}
/* END MODULE */


/* MODULE::cb_ReadINIDouble */
double cb_DEFCALL cb_ReadINIDouble (const char *strSection,const char *strKey,double dblDefault,const char *fName)
{
  char  sBuf[160];
  cb_CStrDbl(dblDefault,sBuf);
  return cb_AtoD(cb_ReadINIKey(strSection,strKey,sBuf,fName,sBuf),NULL);
}
/* END MODULE */


/* MODULE::cb_WriteINISection */
void cb_DEFCALL cb_WriteINISection (const char *strSection,const char *strValue,const char *fName)
{
  register char *fn = (char*)fName;
  if (!fn || fn[0]==0) {
    fn = cb_GenerateINIFileName((void*)-1); fName = NULL;
  }
  WritePrivateProfileSection(strSection,strValue,fn);
  if (!fName) cb_MemFreeM(fn);
}
/* END MODULE */


/* MODULE::cb_WriteINIKey */
void cb_DEFCALL cb_WriteINIKey (const char *strSection,const char *strKey,const char *strValue,const char *fName)
{
  register char *fn = (char*)fName;
  if (!fn || fn[0]==0) {
    fn = cb_GenerateINIFileName((void*)-1); fName = NULL;
  }
  WritePrivateProfileString(strSection,strKey,strValue,fn);
  if (!fName) cb_MemFreeM(fn);
}
/* END MODULE */


/* MODULE::cb_WriteINIInt */
void cb_DEFCALL cb_WriteINIInt (const char *strSection,const char *strKey,cb_Integer lValue,const char *fName)
{
  char  sBuf[80];
  cb_CStr(lValue,10,sBuf);
  cb_WriteINIKey(strSection,strKey,sBuf,fName);
}
/* END MODULE */


/* MODULE::cb_WriteINILLong */
void cb_DEFCALL cb_WriteINILLong (const char *strSection,const char *strKey,long long lValue,const char *fName)
{
  char  sBuf[128];
  cb_CStrL(lValue,10,sBuf);
  cb_WriteINIKey(strSection,strKey,sBuf,fName);
}
/* END MODULE */


/* MODULE::cb_WriteINIDouble */
void cb_DEFCALL cb_WriteINIDouble (const char *strSection,const char *strKey,double dblValue,const char *fName)
{
  char  sBuf[160];
  cb_CStrDbl(dblValue,sBuf);
  cb_WriteINIKey(strSection,strKey,sBuf,fName);
}
/* END MODULE */


/* MODULE::cb_GetINISectionName */
char* cb_DEFCALL cb_GetINISectionName (cb_Integer Ndx,const char *fName,cb_Integer Num1,void *dst)
{
  register char *RetVar = (char*)dst; if (!RetVar) RetVar = cb_EMPTYSTR; else if (RetVar!=(char*)-1) RetVar[0] = 0;
  register char *sBuf;
  register cb_Integer i;
  char *fn = (char*)fName;
  char *sBuf1;
  cb_File* FP1;
  cb_Integer sze1, sze2, i1, i2;
  if (!fn || fn[0]==0) {
    fn = cb_GenerateINIFileName((void*)-1); fName = NULL;
  }
  if ((FP1=cb_FileOpen(fn))!=NULL) {
    sBuf = (char*)cb_MemAllocM(0x20000);
    if (sBuf!=NULL) {
      sze1 = 0;
      sze2 = 0x10000;
      i1 = 0; i2 = 0;
      do {
        sBuf[0]=0;
        if (!cb_FStrGet(FP1,sBuf,NULL,0x10000-1)) break;
        if (sBuf[0]==0) break;
        sBuf1 = cb_LTrimX(sBuf,(void*)-2);
        if (sBuf1[0]=='[') {
          i1++;
          if (i1>Ndx) {
            sBuf1 = cb_LTrimX(sBuf1+1,(void*)-2);
            i = cb_InChar(sBuf1,']');
            cb_RTrimX(cb_NewStr(sBuf1,sBuf,i),sBuf);
            i = cb_StrLen(sBuf)+1;
            RetVar = (char*)dst;
            if (!RetVar || RetVar==(char*)-1) {
              if ((sze1+i)>sze2) { sze2 += 0x10000; sBuf = (char*)cb_ReMemAllocM(sBuf, sze2); }
              RetVar = sBuf+0x10000;
            }
            cb_MemCopy(RetVar+sze1, sBuf, i);
            sze1 += i;
            i2++; if (i2>=Num1) break;
          }
        }
      }while(1);
      RetVar = (char*)dst;
      if (!RetVar || RetVar==(char*)-1) RetVar = cb_NewStr_(sBuf+0x10000, RetVar, sze1);
      else RetVar[sze1] = 0;
      cb_MemFreeM(sBuf);
    }
    cb_FileClose(FP1);
  }
  if (!fName) cb_MemFreeM(fn);
  if (RetVar==(char*)-1) RetVar = cb_NewStr_(NULL,(void*)-1,0);
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_GetINIKeyName */
char* cb_DEFCALL cb_GetINIKeyName (const char *strSec,cb_Integer Ndx,const char *fName,void *dst,cb_Integer Num1)
{
  register char *RetVar = (char*)dst; if (!RetVar) RetVar = cb_EMPTYSTR; else if (RetVar!=(char*)-1) RetVar[0] = 0;
  register char *sBuf;
  register cb_Integer i;
  char *fn = (char*)fName;
  cb_Integer sze1, sze2, i1, i2, i3;
  char *sBuf1;
  cb_File* FP1;
  if (!fn || fn[0]==0) {
    fn = cb_GenerateINIFileName((void*)-1); fName = NULL;
  }
  if ((FP1=cb_FileOpen(fn))!=NULL) {
    sBuf = (char*)cb_MemAllocM(0x50000);
    if (sBuf!=NULL) {
      if (!strSec||!strSec[0]) strSec = cb_GetINISectionName(0);
      cb_ReadINISection(strSec, fn, sBuf);
      sze1 = 0;
      sze2 = 0x10000;
      i1 = 0; i2 = 0; i3 = 0;
      do {
        sBuf1 = cb_LTrimX(sBuf+i3,(void*)-2);
        if (sBuf1[0]!=';') {
          i = cb_InChar(sBuf1,'=');
          if (i>=0) {
            i1++;
            if (i1>Ndx) {
              cb_RTrimX(cb_NewStr_(sBuf1,sBuf,i),sBuf);
              i += (cb_Integer)sBuf1; i -= (cb_Integer)sBuf; i++; i3 = i;
              i = cb_StrLen(sBuf)+1;
              RetVar = (char*)dst;
              if (!RetVar || RetVar==(char*)-1) {
                if ((sze1+i)>sze2) {
                  sze2 += 0x10000;
                  sBuf1 = (char*)cb_ReMemAllocM(sBuf, sze2); if (!sBuf1) break;
                  sBuf = sBuf1;
                }
                RetVar = sBuf+0x40000;
              }
              cb_MemCopy(RetVar+sze1, sBuf, i);
              sze1 += i;
              i2++; if (i2>=Num1) break;
            }
          }
        }
        i3 += cb_StrLen(sBuf+i3) + 1;
      }while(sBuf[i3]);
      RetVar = (char*)dst;
      if (!RetVar || RetVar==(char*)-1) RetVar = cb_NewStr_(sBuf+0x40000, RetVar, sze1);
      else RetVar[sze1] = 0;
      cb_MemFreeM(sBuf);
    }
    cb_FileClose(FP1);
  }
  if (!fName) cb_MemFreeM(fn);
  if (RetVar==(char*)-1) RetVar = cb_NewStr_(NULL,(void*)-1,0);
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_GetINIKeyLine */
char* cb_DEFCALL cb_GetINIKeyLine (const char *strSec,const char *strKey,const char *fName,void *dst)
{
  register char *RetVar = (char*)dst; if (!RetVar) RetVar = cb_EMPTYSTR; else if (RetVar!=(char*)-1) RetVar[0] = 0;
  register char *sBuf;
  register cb_Integer i, i1;
  char *fn = (char*)fName;
  char *sBuf1;
  cb_File* FP1;
  if (!fn || fn[0]==0) {
    fn = cb_GenerateINIFileName((void*)-1); fName = NULL;
  }
  if ((FP1=cb_FileOpen(fn))!=NULL) {
    sBuf = (char*)cb_MemAllocM(0x50000);
    if (sBuf!=NULL) {
      cb_ReadINISection(strSec, fn, sBuf);
      i1 = 0;
      do {
        sBuf1 = cb_LTrimX(sBuf+i1,(void*)-2);
        if (sBuf1[0]!=';') {
          i = cb_InChar(sBuf1,'=');
          if (i>=0) {
            cb_RTrimX(cb_NewStr_(sBuf1,sBuf,i),sBuf);
            if (0==cb_StrComp(sBuf,strKey)) {
              cb_TrimX(sBuf+i,sBuf);
              i = cb_StrLen(sBuf);
              RetVar = (char*)dst;
              if (!RetVar || RetVar==(char*)-1) RetVar = cb_NewStr_(sBuf, RetVar, i);
              else cb_MemCopy(RetVar, sBuf, i+1);
              break;
            }
            i += (cb_Integer)sBuf1; i -= (cb_Integer)sBuf; i++; i1 = i;
          }
        }
        i1 += cb_StrLen(sBuf+i1) + 1;
      }while(sBuf[i1]);
      cb_MemFreeM(sBuf);
    }
    cb_FileClose(FP1);
  }
  if (!fName) cb_MemFreeM(fn);
  if (RetVar==(char*)-1) RetVar = cb_NewStr_(NULL,(void*)-1,0);
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_GetTopParent */
HWND cb_DEFCALL cb_GetTopParent (HWND hWnd, cb_Integer flag1)
{
  register HWND hWnd1 = hWnd, hWnd2;
  do {
    hWnd2 = GetParent(hWnd1);
    if (!hWnd2) break;
    if (!flag1) {
      if (GetWindowLongPtr(hWnd1,GWL_EXSTYLE) & WS_EX_MDICHILD) break;
      if (GetWindow(hWnd1, GW_OWNER)==hWnd2) break;
    }
    hWnd1 = hWnd2;
  }while(1);
  return hWnd1;
}
/* END MODULE */


/* MODULE::cb_EnumAllWindows_ */
BOOL CALLBACK cb_EnumAllWindows_ (HWND hWnd,LPARAM lParam)
{
  register HWND hWnd1 = hWnd;
  register cb_Integer id1 = ((cb_TGetProcessWindow*)lParam)->idProc;
  DWORD idProc;

  if (!id1) goto Set0000;
  GetWindowThreadProcessId(hWnd1,&idProc);
  if (id1==(cb_Integer)idProc) {
Set0000:
    id1 = ((cb_TGetProcessWindow*)lParam)->flag1;
    if ((id1&(1|2))!=0) hWnd1 = cb_GetTopParent(hWnd1,id1&2);
    if ((id1&4)!=0) if (!IsWindowVisible(hWnd1)) return TRUE;
    id1 = ((cb_TGetProcessWindow*)lParam)->iNum;
    if (((cb_TGetProcessWindow*)lParam)->func1) {
      if (!((cb_TGetProcessWindow*)lParam)->func1(((cb_TGetProcessWindow*)lParam)->UserData, hWnd1, (const void*)lParam)) goto Exit0000;
      id1--;
    }
    else {
      id1--;
      if (id1<=0) {
Exit0000:
        ((cb_TGetProcessWindow*)lParam)->hWnd = hWnd1;
        return 0;
      }
    }
    ((cb_TGetProcessWindow*)lParam)->iNum = id1;
  }
  return TRUE;
}
/* END MODULE */


/* MODULE::cb_GetChildWindow */
HWND cb_DEFCALL cb_GetChildWindow (HWND hWnd, cb_Integer flag1, cb_Boolean (cb_CDECL *func1)(const void*,HWND,const void*), const void *UserData, cb_Integer iNum)
{
  cb_TGetProcessWindow t1;

  t1.hWnd = NULL;
  if (hWnd) {
    if (hWnd==(HWND)-1) hWnd = GetDesktopWindow();
    t1.idProc = 0;
    t1.func1 = func1;
    t1.UserData = UserData;
    t1.iNum = iNum;
    if (flag1) t1.flag1 = 4;
    else t1.flag1 = 0;
    EnumChildWindows(hWnd, cb_EnumAllWindows_, (LPARAM)&t1);
  }
  return t1.hWnd;
}
/* END MODULE */


/* MODULE::cb_GetProcessWindow */
HWND cb_DEFCALL cb_GetProcessWindow (cb_Integer dwProcess, cb_Integer flag1, cb_Boolean (cb_CDECL *func1)(const void*,HWND,const void*), const void *UserData)
{
  cb_TGetProcessWindow t1;

  if (dwProcess==-1) { dwProcess = cbApp_ProcessId; if (!dwProcess) dwProcess = GetCurrentProcessId(); }
  t1.hWnd = NULL;
  t1.idProc = dwProcess;
  t1.func1 = func1;
  t1.UserData = UserData;
  t1.iNum = 0;
  t1.flag1 = flag1;
  EnumWindows(cb_EnumAllWindows_, (LPARAM)&t1);
  return t1.hWnd;
}
/* END MODULE */


/* MODULE::cb_GetWindowProcess */
cb_Integer cb_DEFCALL cb_GetWindowProcess (HWND hWnd)
{
  DWORD id = 0;

  if ((cb_UInteger)((cb_Integer)hWnd-1)>=(cb_UInteger)-2) hWnd = GetDesktopWindow();
  GetWindowThreadProcessId(hWnd, &id);
  return id;
}
/* END MODULE */


/* MODULE::cb_GetProcessFileName */
static char * cb_DEFCALL cb_ReplacePathSystem_ (void *np,const char *Str1)
{
  register char *Buff = (char*)np;

    if (!Str1 || Str1[0]==0)
      Buff[0] = 0;
    else {
      cb_GetSystemDir(1,Buff);
      cb_StrCat(Buff,Str1);
    }
  return Buff;
}

char * cb_DEFCALL cb_GetProcessFileName (cb_Integer idProc, const char *sExe, void *dst)
{
  register HANDLE hProcess;
  register char *sBuf = (char*)dst;

  if (sBuf && sBuf!=(char*)-1) sBuf[0] = 0;
  else { sBuf = cb_NewStr_(NULL,sBuf,0x0800); if (!sBuf) goto Exit0000; }

  if (idProc==-1) {
    GetModuleFileNameA(0, sBuf, 0x0800-1);
  }
  else {
    hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, idProc);
    GetModuleFileNameExA(hProcess, 0, sBuf, 0x0800-1);
    if (hProcess) CloseHandle(hProcess);
    else cb_ReplacePathSystem_(sBuf,sExe);
  }
Exit0000:
  return sBuf;
}
/* END MODULE */


/* MODULE::cb_ProcessKill */
static HANDLE cb_DEFCALL cb_SetTokenPrivilages (const char *Str1)
{
  HANDLE ReturnVar;
  HANDLE   hToken;
  cb_Integer i;
  TOKEN_PRIVILEGES tp;
  ReturnVar = 0;
  i = cb_GetWindowsVersion();
  /* Select Case i */
  if (i==VER_PLATFORM_WIN32_WINDOWS) {
    goto EndSelect_0;
  }
  if (i==VER_PLATFORM_WIN32_NT) {
    if (OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,&hToken)) {
      if (LookupPrivilegeValue(cb_EMPTYSTR,Str1,&tp.Privileges[0].Luid)) {
        tp.PrivilegeCount = 1;
        tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        if (AdjustTokenPrivileges(hToken,FALSE,&tp,0,0,0)) {
          ReturnVar = hToken;
        }
      }
    }
  }
  EndSelect_0:;  /* i */
  return ReturnVar;
}

cb_Integer cb_DEFCALL cb_ProcessKill (cb_Integer dwProcess,cb_Integer iCode)
{
  register HANDLE   hToken, hProcess;
  register cb_Integer i;
  hToken = cb_SetTokenPrivilages("SeDebugPrivilege");
  hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_TERMINATE,0,dwProcess);
  i = TerminateProcess(hProcess,iCode);
  CloseHandle(hProcess);
  CloseHandle(hToken);
  return i;
}
/* END MODULE */


/* MODULE::cb__ProcessKillEx */
cb_Integer cb_DEFCALL cb__ProcessKillEx (cb_Integer idProc,const char *sExeName,cb_Integer bKillTree,cb_Integer iCode,PROCESSENTRY32 *tPE,char *sModName,cb_Integer (cb_CDECL *proc)(const void*,PROCESSENTRY32*,const char*,cb_Integer),const void *UserData)
{
  register PROCESSENTRY32 *tPE1;
  register cb_Integer i;
  register cb_Integer j = -1;
  HANDLE lSnapShotP;

  lSnapShotP = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
  if (lSnapShotP!=INVALID_HANDLE_VALUE) {
    tPE1 = (PROCESSENTRY32*)cb_MemAllocM(sizeof(PROCESSENTRY32));
    tPE1->dwSize = sizeof(PROCESSENTRY32);
    if (Process32First(lSnapShotP,tPE1))
    do {
      if (tPE) cb_MemCopy(tPE,tPE1,sizeof(PROCESSENTRY32));
      i = tPE1->th32ProcessID;
      if (sExeName==(const char*)-1) {
        if (idProc==-1) goto proc0000;
        if (bKillTree) { if (tPE1->th32ParentProcessID==idProc) goto proc0000; }
        else if (i==idProc) { cb__ProcessKillEx(i,(const char*)-1,123,iCode,tPE1,NULL,proc,UserData); goto proc0000; }
      }
      else if (sExeName) {
          cb_GetProcessFileName(i,tPE1->szExeFile,sModName);
          if (0==cb_StrIComp(sExeName,sModName)) {
            if (bKillTree>-10) goto KillProc0000;
            if (i!=idProc) { j = i; break; }
          }
      }
      else if (bKillTree==123) {
        if (tPE1->th32ParentProcessID==idProc) goto KillProc000;
      }
      else if (i==idProc) {
KillProc0000:;
        if (bKillTree>0) {
KillProc000:;
          cb__ProcessKillEx(i,NULL,123,iCode,tPE1,NULL,proc,UserData);
        }
        if (proc) {
          if (!sExeName || bKillTree>0) {
proc0000:
            cb_GetProcessFileName(i,tPE1->szExeFile,sModName);
          }
          j = proc(UserData,tPE1,sModName,bKillTree);
          if (j) {
            if (j<0) break;
            goto Cont0000;
          }
          if (sExeName==(const char*)-1) continue;
        }
        if (bKillTree<0) { j = i; break; }
        j = cb_ProcessKill(i,iCode);
Cont0000:
        if (j==123) break;
        if (bKillTree!=123) if (!sExeName || sExeName[0]==0) break;
      }
    } while (Process32Next(lSnapShotP,tPE1));
    cb_MemFreeM(tPE1);
    CloseHandle(lSnapShotP);
  }
  return j;
}
/* END MODULE */


/* MODULE::cb_ProcessKillEx */
cb_Integer cb_DEFCALL cb_ProcessKillEx (cb_Integer idProc,const char *sExeName,cb_Integer bKillTree,cb_Integer iCode,cb_Integer (cb_CDECL *proc)(const void*,PROCESSENTRY32*,const char*,cb_Integer),const void *UserData)
{
  register char *sModName = (char*)cb_MemAllocM(0x0800+2);
  register cb_Integer i = cb__ProcessKillEx(idProc,sExeName,bKillTree,iCode,NULL,sModName,proc,UserData);
  cb_MemFreeM(sModName);
  return i;
}
/* END MODULE */


/* MODULE::cb_GetParentProcessFileName */
char * cb_DEFCALL cb_GetParentProcessFileName (cb_Integer id,const char *sExe,void *dst)
{
  register char *strtmp = (char*)sExe;
  register cb_Integer i = id;
  register char *sModName = (char*)cb_MemAllocM(0x0800+2);
  PROCESSENTRY32 tPE;

  if (i==-1) if (!strtmp || strtmp[0]==0) i = GetCurrentProcessId();
  i = cb__ProcessKillEx(i,strtmp,-1,0,&tPE,sModName,NULL,0);
  cb_MemFreeM(sModName);
  strtmp = (char*)dst;
  if (i!=-1) return cb_GetProcessFileName(tPE.th32ParentProcessID,NULL,strtmp);
  if (!strtmp) return cb_EMPTYSTR;
  if (strtmp==(char*)-1) strtmp = (char*)cb_MemAllocM(sizeof(cb_Integer));
  strtmp[0] = 0; return strtmp;
}
/* END MODULE */


/* MODULE::cbApp_PrevInstance */
cb_Integer cb_DEFCALL cbApp_PrevInstance (void)
{
  register cb_Integer i;
  register char *sBuf1 = cbApp_EXEName(3,(void*)-1);
  if (sBuf1[0]==0) { cb_MemFreeM(sBuf1); return 0; }
  register char *sModName; sModName = (char*)cb_MemAllocM(0x0800+2);

  i = GetCurrentProcessId();
  i = cb__ProcessKillEx(i,sBuf1,-10,0,NULL,sModName,NULL,0);
  cb_MemFreeM(sModName);
  cb_MemFreeM(sBuf1);
  if (i==-1) i = 0;
  return i;
}
/* END MODULE */


/* MODULE::cb_EnumProcesses */
cb_Integer cb_DEFCALL cb_EnumProcesses (cb_Integer id,cb_Integer (cb_CDECL *proc)(const void*,PROCESSENTRY32*,const char*,cb_Integer),const void *UserData)
{
  register cb_Integer i = id;
  register char *sModName = (char*)cb_MemAllocM(0x0800+2);

  i = cb__ProcessKillEx(i,(const char*)-1,FALSE,0,NULL,sModName,proc,UserData);
  cb_MemFreeM(sModName);
  return i;
}
/* END MODULE */


/* MODULE::cb_ResumeSuspendProcess */
cb_Integer cb_ResumeSuspendThread (cb_Integer dwOwnerPID, cb_Boolean bSuspend)
{
  register HANDLE hThreadSnap;
  register HANDLE h1;
  register cb_Integer i = -1;
  THREADENTRY32 te32;

  hThreadSnap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);

  if (hThreadSnap != INVALID_HANDLE_VALUE) {
    te32.dwSize = sizeof(THREADENTRY32);

    if (Thread32First(hThreadSnap, &te32)) {
      do {
        if (te32.th32OwnerProcessID == dwOwnerPID) {
          h1 = OpenThread(THREAD_SUSPEND_RESUME, FALSE, te32.th32ThreadID);
          i = -1;
          if (h1) {
            if ((bSuspend&1)!=0) i = SuspendThread(h1);
            else i = ResumeThread(h1);
            CloseHandle(h1);
          }
          if (!(bSuspend&2)) break;
        }
      } while(Thread32Next(hThreadSnap, &te32));
    }

    CloseHandle(hThreadSnap);
  }

  return i;
}

cb_Integer cb_DEFCALL cb_ResumeSuspendProcess (cb_Integer id,const char *sExe,cb_Boolean bSuspend)
{
  register char *strtmp = (char*)sExe;
  register cb_Integer i = id;
  register char *sModName = (char*)cb_MemAllocM(0x0800+2);

  if (!i) if (!strtmp || strtmp[0]==0) i = GetCurrentProcessId();
  i = cb__ProcessKillEx(i,strtmp,-1,0,NULL,sModName,NULL,0);
  cb_MemFreeM(sModName);
  if (i!=-1) {
    i = cb_ResumeSuspendThread(i, bSuspend);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_IsUserAdmin */
cb_Boolean cb_DEFCALL cb_IsUserAdmin (void)
{
  cb_Boolean b;
  SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;
  PSID AdministratorsGroup;

  b = AllocateAndInitializeSid(
    &NtAuthority,
    2,
    SECURITY_BUILTIN_DOMAIN_RID,
    DOMAIN_ALIAS_RID_ADMINS,
    0, 0, 0, 0, 0, 0,
    &AdministratorsGroup);

  if (b) {
    if (!CheckTokenMembership(NULL, AdministratorsGroup, &b)) b = FALSE;
    FreeSid(AdministratorsGroup);
  }

  return b;
}
/* END MODULE */


/* MODULE::cb_PackLZ */
BYTE * cb_DEFCALL cb_PackLZ (const void *S, cb_UInteger SLen, void *DLen, void *D, cb_Integer level, const char *sPass, cb_Integer iSize, cb_Integer iNum)
{
  register BYTE *tmp = (BYTE*)D;
  register cb_UInteger i = SLen;
  SizeT sze, Len1;

  if (i==0 || i==(cb_UInteger)-1) { i = cb_StrLen((const char*)S); if (i==0) goto exit0000; i++; }
  if (!tmp || tmp==(BYTE*)-1) goto New0000;
  if (tmp==S) {
    tmp = (BYTE*)-1;
New0000:
    tmp = (BYTE*)cb_NewStr_(NULL,tmp,i+LZMA_PROPS_SIZE+256); if (!tmp) goto exit0000; goto Size0000;
  }
  if (DLen) {
    sze = *(cb_UInteger*)DLen-LZMA_PROPS_SIZE-sizeof(unsigned int);
  }
  else {
Size0000:
    sze = i+LZMA_PROPS_SIZE+256-LZMA_PROPS_SIZE-sizeof(unsigned int);
  }
  ((unsigned long*)tmp)[0] = i;
  Len1 = LZMA_PROPS_SIZE;
  i = LzmaCompress(
      tmp+sizeof(unsigned int)+LZMA_PROPS_SIZE, &sze,
      (unsigned char*)S, i,
      tmp+sizeof(unsigned int), &Len1,
      level,
      0, -1, -1, -1, -1, -1
    );
  if (S==D) { if (i==SZ_OK) cb_MemCopy(D,tmp,sze+sizeof(unsigned int)+LZMA_PROPS_SIZE); cb_MemFreeM(tmp); tmp = (BYTE*)D; }
  if (i==SZ_OK) {
    if (sPass) {
      i = iSize;
      if (i==(cb_UInteger)-1) i = sze;
      else {
        if (i==0) i = 0x4000;
        if (i>sze) i = sze;
      }
      if (sPass[0]) cb_XorStr(tmp+sizeof(unsigned int),sPass,tmp+sizeof(unsigned int),i);
      if (iNum) {
        if (iNum<0) iNum = 3;
        cb_RolStr(tmp+sizeof(unsigned int),iNum,tmp+sizeof(unsigned int),i);
      }
    }
    sze += sizeof(unsigned int)+LZMA_PROPS_SIZE;
  }
  else {
    if (D==(void*)-1) cb_MemFreeM(tmp);
    tmp = NULL;
exit0000:
    sze = 0;
  }
  if (DLen) *(cb_UInteger*)DLen = sze;
  return tmp;
}
/* END MODULE */


/* MODULE::cb_UnPackLZ */
BYTE * cb_DEFCALL cb_UnPackLZ (const void *S, cb_UInteger SLen, void *DLen, void *D, const char *sPass, cb_Integer iSize, cb_Integer iNum)
{
  register BYTE *tmp = (BYTE*)D;
  register BYTE *tmp1 = (BYTE*)S;
  register cb_UInteger i = ((unsigned int*)tmp1)[0];
  SizeT sze = i;

  if (tmp==tmp1) tmp = (BYTE*)-1;
  if (!tmp || tmp==(BYTE*)-1) { tmp = (BYTE*)cb_NewStr_(NULL,tmp,i); if (!tmp) goto exit0000; tmp[i] = 0; }
  tmp1 += sizeof(unsigned int);
  if (sPass) {
    i = iSize;
    if (i==(cb_UInteger)-1)
      i = SLen;
    else {
      if (i==0) i = 0x4000;
      if (i>SLen) i = SLen;
    }
    if (iNum<0) iNum = 3;
    tmp1 = (BYTE*)cb_RorStr(tmp1,iNum,tmp1-sizeof(unsigned int)!=S?(void*)-1:tmp1,i);
    if (sPass[0]) cb_XorStr(tmp1,sPass,tmp1,i);
  }
  i = LzmaUncompress(
      tmp, &sze,
      tmp1+LZMA_PROPS_SIZE, &SLen,
      tmp1, LZMA_PROPS_SIZE
    );
  if (S==D) { if (i==SZ_OK) cb_MemCopy(D,tmp,sze); cb_MemFreeM(tmp); tmp = (BYTE*)D; }
  else if (sPass) cb_MemFreeM(tmp1);
  if (i!=SZ_OK) {
    if (D==(void*)-1) cb_MemFreeM(tmp);
    tmp = NULL;
exit0000:
    sze = 0;
  }
  if (DLen) *(cb_UInteger*)DLen = sze;
  return tmp;
}
/* END MODULE */


/* MODULE::cb_PackLZ4 */
BYTE * cb_DEFCALL cb_PackLZ4 (const void *S, cb_UInteger SLen, void *DLen, void *D, cb_Integer level, const char *sPass, cb_Integer iSize, cb_Integer iNum)
{
  register BYTE *tmp;
  register cb_Integer i = SLen;
  register cb_Integer sze;

  if (i<=0) { i = cb_StrLen((const char*)S); if (i<=0) { tmp = NULL; goto exit0000; } i++; }
  tmp = (BYTE*)D;
  if (!tmp || tmp==(BYTE*)-1) goto New0000;
  if (tmp==S) {
    tmp = (BYTE*)-1;
New0000:
    tmp = (BYTE*)cb_NewStr_(NULL,tmp,i+256); if (!tmp) goto exit0000; goto Size0000;
  }
  if (DLen) {
    sze = (*(cb_UInteger*)DLen) - sizeof(signed int);
  }
  else {
Size0000:
    sze = i+256-sizeof(signed int);
  }
  ((signed int*)tmp)[0] = i;
  sze = LZ4_compress_limitedOutput((const char*)S, (char*)(tmp+sizeof(signed int)), i, sze);
  if (S==D) { if (sze>0) cb_MemCopy(D,tmp,sze+sizeof(signed int)); cb_MemFreeM(tmp); tmp = (BYTE*)D; }
  if (sze>0) {
    if (sPass) {
      i = iSize;
      if (i==-1) i = sze;
      else {
        if (i==0) i = 0x4000;
        if (i>sze) i = sze;
      }
      if (sPass[0]) cb_XorStr(tmp+sizeof(signed int),sPass,tmp+sizeof(signed int),i);
      if (iNum) {
        if (iNum<0) iNum = 3;
        cb_RolStr(tmp+sizeof(signed int),iNum,tmp+sizeof(signed int),i);
      }
    }
    sze += sizeof(signed int);
  }
  else {
    if (D==(void*)-1) cb_MemFreeM(tmp);
exit0000:
    sze = 0;
  }
  if (DLen) *(cb_UInteger*)DLen = (cb_UInteger)sze;
  return tmp;
}
/* END MODULE */


/* MODULE::cb_UnPackLZ4 */
BYTE * cb_DEFCALL cb_UnPackLZ4 (const void *S, cb_UInteger SLen, void *DLen, void *D, const char *sPass, cb_Integer iSize, cb_Integer iNum)
{
  register BYTE *tmp;
  register BYTE *tmp1 = (BYTE*)S;
  register cb_Integer i = ((signed int*)tmp1)[0];
  cb_Integer sze;

  if (i<=0) goto exit000;
  tmp = (BYTE*)D; if (tmp==tmp1) tmp = (BYTE*)-1;
  if (!tmp || tmp==(BYTE*)-1) { tmp = (BYTE*)cb_NewStr_(NULL,tmp,i); if (!tmp) goto exit0000; tmp[i] = 0; }
  tmp1 += sizeof(signed int);
  if (sPass) {
    sze = i;
    i = iSize;
    if (i==-1)
      i = SLen;
    else {
      if (i==0) i = 0x4000;
      if ((cb_UInteger)i>SLen) i = SLen;
    }
    if (iNum<0) iNum = 3;
    tmp1 = (BYTE*)cb_RorStr(tmp1,iNum,tmp1-sizeof(signed int)!=S?(void*)-1:tmp1,i);
    if (sPass[0]) cb_XorStr(tmp1,sPass,tmp1,i);
    i = sze;
  }
  i = LZ4_decompress_fast((const char*)tmp1, (char*)tmp, i);
  if (S==D) { if (i>0) cb_MemCopy(D,tmp,sze); cb_MemFreeM(tmp); tmp = (BYTE*)D; }
  else if (sPass) cb_MemFreeM(tmp1);
  if (i<=0) {
    if (D==(void*)-1) cb_MemFreeM(tmp);
exit000:
    tmp = NULL;
exit0000:
    i = 0;
  }
  if (DLen) *(cb_Integer*)DLen = i;
  return tmp;
}
/* END MODULE */


/* MODULE::cb_PackZ */
BYTE * cb_DEFCALL cb_PackZ (const void *S, cb_UInteger SLen, void *DLen, void *D, cb_Integer level, const char *sPass, cb_Integer iSize, cb_Integer iNum)
{
  register BYTE *tmp = (BYTE*)D;
  register cb_UInteger i = SLen;
  unsigned long sze;

  if (i==0 || i==-1) { i = cb_StrLen((const char*)S); if (i==0) goto exit0000; i++; }
  if (!tmp || tmp==(BYTE*)-1) goto New0000;
  if (tmp==S) {
    tmp = (BYTE*)-1;
New0000:
    tmp = (BYTE*)cb_NewStr_(NULL,tmp,i+256); if (!tmp) goto exit0000; goto Size0000;
  }
  if (DLen) {
    sze = (*(cb_UInteger*)DLen) - sizeof(unsigned int);
  }
  else {
Size0000:
    sze = i + 256 - sizeof(unsigned int);
  }
  ((unsigned int*)tmp)[0] = (unsigned int)i;
  i = compress2(tmp+sizeof(unsigned int), &sze, (BYTE*)S, i, level);
  if (S==D) { if (i==Z_OK) cb_MemCopy(D,tmp,sze+sizeof(unsigned int)); cb_MemFreeM(tmp); tmp = (BYTE*)D; }
  if (i==Z_OK) {
    if (sPass) {
      i = iSize;
      if (i==(cb_UInteger)-1) i = sze;
      else {
        if (i==0) i = 0x4000;
        if (i>sze) i = sze;
      }
      if (sPass[0]) cb_XorStr(tmp+sizeof(unsigned int),sPass,tmp+sizeof(unsigned int),i);
      if (iNum) {
        if (iNum<0) iNum = 3;
        cb_RolStr(tmp+sizeof(unsigned int),iNum,tmp+sizeof(unsigned int),i);
      }
    }
    sze += sizeof(unsigned int);
  }
  else {
    if (D==(void*)-1) cb_MemFreeM(tmp);
    tmp = NULL;
exit0000:
    sze = 0;
  }
  if (DLen) *(cb_UInteger*)DLen = sze;
  return tmp;
}
/* END MODULE */


/* MODULE::cb_UnPackZ */
BYTE * cb_DEFCALL cb_UnPackZ (const void *S, cb_UInteger SLen, void *DLen, void *D, const char *sPass, cb_Integer iSize, cb_Integer iNum)
{
  register BYTE *tmp = (BYTE*)D;
  register BYTE *tmp1 = (BYTE*)S;
  register cb_UInteger i = ((unsigned int*)tmp1)[0];
  unsigned long sze;

  if (tmp==tmp1) tmp = (BYTE*)-1;
  if (!tmp || tmp==(BYTE*)-1) { tmp = (BYTE*)cb_NewStr_(NULL,tmp,i); if (!tmp) goto exit0000; tmp[i] = 0; }
  sze = i;
  tmp1 += sizeof(unsigned int);
  if (sPass) {
    i = iSize;
    if (i==(cb_UInteger)-1)
      i = SLen;
    else {
      if (i==0) i = 0x4000;
      if (i>SLen) i = SLen;
    }
    if (iNum<0) iNum = 3;
    tmp1 = (BYTE*)cb_RorStr(tmp1,iNum,tmp1-sizeof(unsigned int)!=S?(void*)-1:tmp1,i);
    if (sPass[0]) cb_XorStr(tmp1,sPass,tmp1,i);
  }
  i = uncompress(tmp, &sze, tmp1, SLen);
  if (S==D) { if (i==Z_OK) cb_MemCopy(D,tmp,sze); cb_MemFreeM(tmp); tmp = (BYTE*)D; }
  else if (sPass) cb_MemFreeM(tmp1);
  if (i!=Z_OK) {
    if (D==(void*)-1) cb_MemFreeM(tmp);
    tmp = NULL;
exit0000:
    sze = 0;
  }
  if (DLen) *(cb_UInteger*)DLen = sze;
  return tmp;
}
/* END MODULE */


/* MODULE::cb_GDIPLoadResource */
HBITMAP cb_DEFCALL cb_GDIPLoadResource (const char *sFile)
{
#ifdef __cplusplus
  #define MY1_(x) Gdiplus::x
  #define MY2_(x) Gdiplus::DllExports::x
#else
  #define MY1_(x) x
  #define MY2_(x) x
#endif
#if defined(__GNUC__) || defined(__GNUG__)
  register cb_Integer lRes;
  register wchar_t *sBuf;
  HBITMAP hBmp = NULL;
  MY1_(GdiplusStartupInput) tSI;
  ULONG lGDIP;
  MY1_(GpBitmap)* hBitmap1;

  cb_MemSet(&tSI,0,sizeof(tSI));
  tSI.GdiplusVersion = 1;
  lRes = MY1_(GdiplusStartup(&lGDIP,&tSI,NULL));
  if (lRes==0) {
    sBuf = (wchar_t*)cb_MemAllocM(0x0800*sizeof(wchar_t));
    cb_AnsiToUnicode(sFile,sBuf);
    lRes = MY2_(GdipCreateBitmapFromFile(sBuf,&hBitmap1));
    cb_MemFreeM(sBuf);
    if (lRes==0) {
      lRes = MY2_(GdipCreateHBITMAPFromBitmap(hBitmap1,&hBmp,0));
      MY2_(GdipDisposeImage(hBitmap1));
    }
    MY1_(GdiplusShutdown(lGDIP));
  }
  return hBmp;
#else
  return NULL;
#endif
  #undef MY2_
  #undef MY1_
}
/* END MODULE */


/* MODULE::cb_GDIPSaveImage */
#if defined(__GNUC__) || defined(__GNUG__)
cb_Integer cb_DEFCALL cb_GDIPGetEncoderClsid_ (const wchar_t *format, CLSID *pClsid)
{
#ifdef __cplusplus
    #define MY1_(x) Gdiplus::x
    #define MY2_(x) Gdiplus::DllExports::x
#else
    #define MY1_(x) x
    #define MY2_(x) x
#endif

  register cb_Integer i;
  UINT_PTR num = 0;  // number of image encoders
  UINT_PTR size = 0;  // size of the image encoder array in bytes
  MY1_(ImageCodecInfo) *pImageCodecInfo;

  MY2_(GdipGetImageEncodersSize(&num, &size));
  if (size==0) return -1;

  pImageCodecInfo = (MY1_(ImageCodecInfo)*)cb_MemAllocM(size);
  if (pImageCodecInfo==NULL) return -1;

  MY2_(GdipGetImageEncoders(num, size, pImageCodecInfo));

  i = num;
  do {
    --i;
    if (i<0) break;
    if (cb_StrCompW(pImageCodecInfo[i].MimeType, format)==0) {
      *pClsid = pImageCodecInfo[i].Clsid;
      break;
    }
  } while(1);

  cb_MemFreeM(pImageCodecInfo);

  return i;
  #undef MY2_
  #undef MY1_
}
#endif

void * cb_DEFCALL cb_GDIPSaveImage (HBITMAP hBmp, const char *sFile, cb_Integer Tipe, cb_Integer Quality)
{
#if defined(__GNUC__) || defined(__GNUG__)
#ifdef __cplusplus
  #define MY1_(x) Gdiplus::x
  #define MY2_(x) Gdiplus::DllExports::x
#else
  #define MY1_(x) x
  #define MY2_(x) x
#endif
  register cb_Integer lRes;
  register const wchar_t *MyPtr1;
  register wchar_t *sBuf;
  MY1_(GdiplusStartupInput) tSI;
  ULONG lGDIP;
  MY1_(GpBitmap)* hBitmap1;
  CLSID encoderClsid;

  cb_MemSet(&tSI,0,sizeof(tSI));
  tSI.GdiplusVersion = 1;
  lRes = MY1_(GdiplusStartup(&lGDIP,&tSI,NULL));
  if (lRes==0) {
    lRes = Tipe;
    if (lRes==2) {
PNG0000:
      MyPtr1 = L"image/png";
    }
    else if (lRes==3) {
GIF0000:
      MyPtr1 = L"image/gif";
    }
    else {
      if (lRes!=1) {
        lRes = cb_StrLen(sFile)-4;
        if (lRes>0) {
          if (0==cb_MemIComp(sFile+lRes, ".png", 5)) goto PNG0000;
          if (0==cb_MemIComp(sFile+lRes, ".gif", 5)) goto GIF0000;
        }
      }
      MyPtr1 = L"image/jpeg";
    }

    lRes = cb_GDIPGetEncoderClsid_(MyPtr1, &encoderClsid);
    if (lRes>=0) {
      lRes = MY2_(GdipCreateBitmapFromHBITMAP(hBmp, NULL, &hBitmap1));
      if (lRes==0) {
        sBuf = (wchar_t*)cb_MemAllocM(0x0800*sizeof(wchar_t));
        cb_AnsiToUnicode(sFile, sBuf);
        lRes = MY2_(GdipSaveImageToFile(hBitmap1, sBuf, &encoderClsid, /*&tParams*/ NULL));
        cb_MemFreeM(sBuf);
        MY2_(GdipDisposeImage(hBitmap1));
      }
    }
    MY1_(GdiplusShutdown(lGDIP));
  }
  if (lRes) return NULL;
  return (void*)TRUE;
  #undef MY2_
  #undef MY1_
#else
  return NULL;
#endif
}
/* END MODULE */


/* MODULE::cb_SaveJPGFile */
void * cb_DEFCALL cb_SaveJPGFile (const char *F, const void *image, cb_UInteger w, cb_UInteger h, cb_Integer flg1, void *pSize)
{
  if (pSize) *(cb_Integer*)pSize = 0;
  return NULL;
}
/* END MODULE */


/* MODULE::cb_SaveGIFFile */
void * cb_DEFCALL cb_SaveGIFFile (const char *F, const void *image, cb_UInteger w, cb_UInteger h, cb_Integer flg1, void *pSize)
{
  if (pSize) *(cb_Integer*)pSize = 0;
  return NULL;
}
/* END MODULE */


/* MODULE::cb_DecodePNG */
cb_UInteger cb_DEFCALL cb_lodepng_decode (const unsigned char*,cb_UInteger,unsigned char**,cb_UInteger*,cb_UInteger*,cb_Integer);
void cb_DEFCALL cb_lodepng_free (void*);
HBITMAP cb_DEFCALL cb_DecodePNG (const void *buffer, cb_UInteger buffersize, cb_Integer flg1, const char *sFile)
{
  register BYTE *p;
  unsigned char* image = NULL;
  cb_UInteger width, height;
  DIBSECTION Bmp1;
  register HBITMAP hBmp = (HBITMAP)cb_lodepng_decode((const unsigned char*)buffer, buffersize, &image, &width, &height, flg1 & 0x3F);
  if (image) {
    if (!hBmp) {
      if (flg1<0) {
        if (sFile) { ((cb_Integer*)sFile)[0] = width; ((cb_Integer*)sFile)[1] = height; }
        return (HBITMAP)image;
      }
      Bmp1.dsBm.bmWidth = width;
      Bmp1.dsBm.bmHeight = height;
      Bmp1.dsBm.bmPlanes = 1;
      p = (BYTE*)cb_SaveBMP((HBITMAP)-1,(HDC)image,sFile,NULL,(void*)-1,cb_MIN_INTEGER,flg1 & 0x3f,&Bmp1);
      if (p) {
        if (flg1 > 0x3f)
          hBmp = (HBITMAP)p;
        else {
          hBmp = cb_CreateBMPFromDIB(p+sizeof(BITMAPFILEHEADER));
          cb_MemFreeM(p);
        }
      }
    }
    else hBmp = NULL;
    cb_lodepng_free(image);
  }
  else hBmp = NULL;
  return hBmp;
}
/* END MODULE */


/* MODULE::cb_LoadPNGResource */
HBITMAP cb_DEFCALL cb_LoadPNGResource (const char *F)
{
  register unsigned char* buffer;
  cb_UInteger buffersize;
  register HBITMAP hBmp = NULL;

  buffer = (unsigned char*)cb_LoadFile(F, (void*)-1, &buffersize); /*load the image file with given filename*/
  if (buffer) {
    hBmp = cb_DecodePNG(buffer, buffersize);
    cb_MemFreeM(buffer);
  }
  return hBmp;
}
/* END MODULE */


/* MODULE::cb_SavePNGFile */
cb_UInteger cb_DEFCALL cb_lodepng_encode(const unsigned char*,unsigned char**,cb_UInteger*,cb_UInteger,cb_UInteger,cb_Integer);

void * cb_DEFCALL cb_SavePNGFile (const char *F, const void *image, cb_UInteger w, cb_UInteger h, cb_Integer flg1, void *pSize)
{
  unsigned char* buffer = NULL;
  cb_UInteger buffersize;
  register cb_Integer error = cb_lodepng_encode((const unsigned char*)image,&buffer,&buffersize,w,h,flg1);

  if (!F || !F[0]) {
    if (error) { cb_MemFreeM(buffer); buffer = NULL; buffersize = 0; }
  }
  else {
    if (!error) error = cb_SaveFile(F, buffer, buffersize); else { buffersize = 0; error = -1; }
    cb_MemFreeM(buffer);
    if (error==-1) buffer = NULL;
  }
  if (pSize) *(cb_UInteger*)pSize = buffersize;
  return buffer;
}
/* END MODULE */


/* MODULE::cb_GetLabelAddress */
__declspec(noinline) void cb_STDCALL cb_GetLabelAddress (void *ptr1)
{
  *(void**)ptr1 = *(&ptr1-1);
}
/* END MODULE */


/* MODULE::cb_LoadDllFunc */
const void* cb_DEFCALL cb_LoadDllFunc (const char *FuncName, const char *DllName, void *lpAddr, HMODULE *hInst)
{
  register HMODULE hInst1; if (hInst) hInst1 = *hInst; else hInst1 = NULL;
  register const void *lpAddr1;

  lpAddr1 = NULL;
    if (hInst1==NULL) {
      hInst1 = LoadLibraryA(DllName); if (hInst1==NULL) goto Exit0000;
    if (hInst) *hInst = hInst1;
  }
  else if (lpAddr)
    lpAddr1 = *((const void**)lpAddr);

  if (lpAddr1==NULL) {
    lpAddr1 = (void*)GetProcAddress(hInst1,FuncName);
Exit0000:
    if (lpAddr) *((const void**)lpAddr) = lpAddr1;
  }

  return lpAddr1;
}
/* END MODULE */


/* MODULE::cb_CallAnyFunction */
__declspec(noinline) cb_Integer cb_DEFCALL cb_CallAnyFunction (const void *lpAddr, cb_Integer nArgs, const void *Args)
{
  if (!lpAddr) return 0;
  typedef cb_Integer ( *cb_CallDllType_)(void);

  register cb_Integer i;
  register const void **argtable = (const void**)Args;
  volatile const void *arg;
  for(i = nArgs;i > 0;) {
    i--;
    arg = argtable[i];
#if defined(__GNUC__) || defined(__GNUG__) || defined(__TINYC__)
    __asm__("pushl %0" : : "r" (arg));
#else
    __asm{push arg}
#endif
  }
  return ((cb_CallDllType_)lpAddr)();
}
/* END MODULE */


/* MODULE::cb_CallDllStd */
cb_Integer cb_DEFCALL cb_CallDllStd (const char *FuncName, const char *DllName, void *lpAddr, HMODULE *hInst, cb_Integer nArgs, const cb_Integer argtable[])
{
  register const void *lpAddr1 = cb_LoadDllFunc(FuncName,DllName,lpAddr,hInst); if (!lpAddr1) return -123;
  return cb_CallAnyFunction(lpAddr1,nArgs,argtable);
}
/* END MODULE */


/* MODULE::cb_CallDllCdecl */
__declspec(noinline) cb_Integer cb_CDECL cb_CallDllCdecl (cb_Integer nArgs, void *lpAddr, HMODULE *hInst, const char *FuncName, const char *DllName, ...)
{
  return cb_CallDllStd(FuncName, DllName, lpAddr, hInst, nArgs, ((cb_Integer*)&DllName)+1);
}
/* END MODULE */


/* MODULE::cb_CallDll */
__declspec(noinline) cb_Integer cb_CDECL cb_CallDll (cb_Integer nArgs, const char *FuncName, const char *DllName, ...)
{
  register const void *lpAddr;
  HMODULE hInst;
  hInst = GetModuleHandle(DllName);
  if (hInst==NULL) {
    hInst = LoadLibraryA(DllName);
    if (hInst) {
      cb_DllCyclesCnt_=(cb_DllCyclesCnt_+1) & cb_DllCyclesMax_;
      if (cb_DllCyclesBuf_[cb_DllCyclesCnt_]) FreeLibrary(cb_DllCyclesBuf_[cb_DllCyclesCnt_]);
      cb_DllCyclesBuf_[cb_DllCyclesCnt_] = hInst;
    }
  }
  lpAddr = cb_LoadDllFunc(FuncName,DllName,NULL,&hInst); if (!lpAddr) return -123;
  return cb_CallAnyFunction(lpAddr, nArgs, ((const cb_Integer*)&DllName)+1);
}
/* END MODULE */


/* MODULE::cb_Command */
char * cb_DEFCALL cb_Command (cb_Integer iStart, void *dst, cb_Integer iCnt)
{
  register cb_Integer i1 = iStart;
  register cb_Integer i2 = iCnt;
  register char *RetVar;
  if (i2<=0) {
    if (i1<0) { i1 &= 1; goto Cont000; }
    if (i2<0) { Cont000:; i2 = cbApp_Argc; if (i1>=i2) goto Exit000; goto Cont0000; }
    i2++;
  }
  if (i1<0) i1 = 1;
  i2 += i1;
  if (i2>cbApp_Argc) {
Exit000:
    RetVar = cb_EMPTYSTR;
    goto Exit0000;
  }
Cont0000:
  i2--;
  if (i1==i2) {
    RetVar = cbApp_Argv[i1];
Exit0000:
    i1 = (cb_Integer)dst;
    if (!i1 || i1==-2) i1 = (cb_Integer)RetVar;
    else i1 = (cb_Integer)cb_NewStr_(RetVar,(void*)i1,cb_StrLen(RetVar));
  }
  else {
    RetVar = (char*)cb_MemAllocM(((i2+1-i1) * 0x400)+4); if (RetVar==NULL) return NULL;
    RetVar[0] = 0;
    do {
      cb_StrCat(RetVar, cbApp_Argv[i1]);
      if (i1 >= i2) break;
      i1++;
      cb_StrCat(RetVar, " ");
    }while(1);
    i1 = (cb_Integer)cb_NewStr_(RetVar,dst,cb_StrLen(RetVar));
  cb_MemFreeM(RetVar);
  }
  return (char*)i1;
}
/* END MODULE */


/* MODULE::cbApp_EXEName */
char * cb_DEFCALL cbApp_EXEName (cb_Integer flag1, void *dst)
{
  register cb_Integer i;
  register char *sTmp = (char*)dst;
  register cb_Integer i1, i2;

  if (cbApp_EXEBuf_[0])
    i = cb_StrLen(cbApp_EXEBuf_);
  else
    i = GetModuleFileName(GetModuleHandle(0),cbApp_EXEBuf_,sizeof(cbApp_EXEBuf_)-1);
  if (i<=0) {
    if (!sTmp) return cb_EMPTYSTR;
    i1 = 0; if (sTmp==(char*)-1) goto New0000;
  }
  else {
    i1 = i;
    if ((flag1&2)!=0) i = 0;
    else while(i) { i--; if (cbApp_EXEBuf_[i]=='\\' || cbApp_EXEBuf_[i]=='/') { i++; break; } }
    if ((flag1&1)==0) {
      i2 = i1;
      do {
        i2--;
        if (cbApp_EXEBuf_[i2]=='.') { i1 = i2; break; }
      }while(i2>i);
    }
    i1-=i;
    if (!sTmp || sTmp==(char*)-1) {
New0000:
      sTmp = cb_NewStr_(cbApp_EXEBuf_+i,sTmp,i1);
      if (!sTmp) if (!dst) return cb_EMPTYSTR;
    }
    else { cb_MemCopy(sTmp,cbApp_EXEBuf_+i,i1); sTmp[i1] = 0; }
  }
  return sTmp;
}
/* END MODULE */


/* MODULE::cbApp_EXEPath */
char * cb_DEFCALL cbApp_EXEPath (cb_Integer flag1,void *dst)
{
  register cb_Integer i;
  register char *sTmp = (char*)dst;

  if (cbApp_EXEBuf_[0])
    i = cb_StrLen(cbApp_EXEBuf_);
  else
    i = GetModuleFileName(GetModuleHandle(0),cbApp_EXEBuf_,sizeof(cbApp_EXEBuf_)-1);
  while(i) { i--; if (cbApp_EXEBuf_[i]=='\\' || cbApp_EXEBuf_[i]=='/') { i += flag1; break; } }
  if (i<=0) {
    if (!sTmp) goto EmptyStr0000;
    i = 0; if (sTmp==(char*)-1) goto New0000;
  }
  else if (!sTmp || sTmp==(char*)-1) {
New0000:
    sTmp = cb_NewStr_(cbApp_EXEBuf_,sTmp,i);
    if (!sTmp) {
      if (dst) goto Exit0000;
EmptyStr0000:
      return cb_EMPTYSTR;
    }
  }
  else cb_MemCopy(sTmp,cbApp_EXEBuf_,i);
  sTmp[i] = 0;
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_GenErrorMsg */
char * cb_DEFCALL cb_GenErrorMsg (const char *Str1,cb_Integer iNum,void *dst)
{
  register cb_Integer i = 0; if (Str1) i = cb_StrLen(Str1);
  register char *sTmp = (char*)dst;
  register cb_Integer n;
  if (sTmp) { n = 0x0600 - 1; if (sTmp==(char*)-1) sTmp = (char*)cb_MemAllocM(0x0600); }
  if (!sTmp) { sTmp = cbApp_Error.Description; n = sizeof(cbApp_Error.Description) - 1; }
  if (iNum) cbApp_Error.Number = iNum;
  else cbApp_Error.Number = GetLastError();
  if (i>=n) {
    i = n;
    n = 0;
  }
  if (i) cb_MemMove(sTmp,Str1,i);
  if (i<n) {
    n -= i;
    n--;
    if (n) {
      sTmp[i] = ' '; i++;
      FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM,0,cbApp_Error.Number,LANG_NEUTRAL,sTmp+i,n,0);
    }
  }
  sTmp[i+n] = 0;
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_KeyPressed */
cb_Integer cb_DEFCALL cb_KeyPressed (cb_Integer flag1, cb_Integer e, cb_Integer Start1, cb_Integer w)
{
  register cb_Integer i;

  i = flag1; if (i>0) { if ((GetKeyState(i) & 0x8000)==0) i = 0; return i; }
  do {
    for (i=Start1;i<VK_SHIFT;i++) if (GetKeyState(i) & 0x8000) goto Pressed0000;
    for (i=VK_MENU+1;i<0x00FF;i++) if (GetKeyState(i) & 0x8000) goto Pressed0000;
    if (flag1!=-1) {
    i = 0;
    if (GetKeyState(VK_SHIFT) & 0x8000) i |= VK_SHIFT;
    if (GetKeyState(VK_CONTROL) & 0x8000) i = VK_CONTROL;
    if (GetKeyState(VK_MENU) & 0x8000) i |= VK_MENU;
    if (!i) {
      if (flag1!=-3) break;
    }
    else {
Pressed0000:
      if (flag1!=-2) {
        break;
      }
    }
    }
    if (e) cb_DoEvents();
    Sleep(w);
  } while(1);
  return i;
}
/* END MODULE */


/* MODULE::cb_RunEx */
char * cb_DEFCALL cb_ReadConsoleBuf (HANDLE hFile,cb_Integer (cb_CDECL *subCapture)(const void*,char*,DWORD,DWORD),const void *UserData,DWORD dwProc,cb_Integer *pRet)
{
  register char *consbuf; consbuf = NULL;
  register cb_Integer iRet;
  cb_Integer iRead; iRead=0;
  if (PeekNamedPipe(hFile, NULL, 0, NULL, (DWORD*)&iRead, NULL)) {
    iRet = iRead;
    if (iRet>0) {
      consbuf = cb_NewStr_(NULL,subCapture?(void*)-1:NULL,iRet);
      if (consbuf) {
        ReadFile(hFile, consbuf, iRet, (DWORD*)&iRead, NULL);
        consbuf[iRead] = 0;
      }
    }
  }
  if (subCapture) {
    if (consbuf) { iRet = subCapture(UserData, consbuf, iRead, dwProc); cb_MemFreeM(consbuf); consbuf=NULL; }
    else iRet = subCapture(UserData, cb_EMPTYSTR, 0, dwProc);
    if (pRet) pRet[0] = iRet;
  }
  else if (!consbuf) consbuf = cb_EMPTYSTR;
  return consbuf;
}
cb_Integer cb_DEFCALL cb_RunEx (const char *sExe, const char *sCmdLine, cb_UInteger iShowHide, const char *sWorkDir, cb_Integer WaitState, cb_Integer (cb_CDECL *subCaptureOut)(const void*,char*,DWORD,DWORD), const void *UserDataOut, char* (cb_CDECL *subCaptureIn)(const void*,HANDLE,DWORD), const void *UserDataIn, DWORD *dwProc, DWORD *dwThread, HANDLE *hPipeOut, HANDLE *hPipeIn, cb_Integer flags)
{
  STARTUPINFO si;
  PROCESS_INFORMATION pi;
  SECURITY_ATTRIBUTES sec;
  register cb_Integer iRet;
  register char *MyPtr1 = (char*)sCmdLine;
  clock_t t1, t2;
  cb_Integer i;

  if (MyPtr1!=NULL) {
    iRet = cb_StrLen(MyPtr1)+1;
    MyPtr1=(char*)cb_MemAllocM(iRet+1024+1); if (MyPtr1==NULL) return -2;
    sCmdLine = (const char*)cb_MemCopy(MyPtr1, sCmdLine, iRet);
    if (sExe==(const char*)-1) {
      for(iRet = (cb_Integer)MyPtr1;*(unsigned char*)iRet<=' ';iRet++) {
        if (*(char*)iRet==0) { cb_MemFreeM(MyPtr1); return 0; }
      }
      i = *(char*)iRet;
      if (i=='"' || i=='`') {
        iRet++; sExe = (const char*)iRet;
        for(;*(char*)iRet!=0;iRet++) {
          if (*(char*)iRet==i) goto Cont0001;
        }
        goto Cont0000;
      }
      sExe = (const char*)iRet;
      for(;*(unsigned char*)iRet>' ';iRet++);
      if (*(char*)iRet==0) {
Cont0000:
        sExe = NULL;
      }
      else {
Cont0001:
        *(char*)iRet = 0; iRet++; sCmdLine = (const char*)iRet;
      }
    }
  }

  HANDLE hReadPipeOut; hReadPipeOut = NULL;
  HANDLE hWritePipeOut; hWritePipeOut = NULL;
  HANDLE hReadPipeIn; hReadPipeIn = NULL;
  HANDLE hWritePipeIn; hWritePipeIn = NULL;

  cb_MemSet(&si,0,sizeof(si));
  cb_MemSet(&sec,0,sizeof(sec));
  sec.nLength = sizeof(sec);
  sec.bInheritHandle = 1;
  if (subCaptureOut) {
    if (0==CreatePipe(&hReadPipeOut, &hWritePipeOut, &sec, 0)) goto Error0000;
    si.hStdOutput = hWritePipeOut;
    SetHandleInformation(hReadPipeOut, HANDLE_FLAG_INHERIT, 0);
  }
  else si.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
  if (hPipeIn) {
    if (0==CreatePipe(&hReadPipeIn, &hWritePipeIn, &sec, 0)) {
      if (hReadPipeIn) CloseHandle(hReadPipeIn);
      if (hWritePipeIn) CloseHandle(hWritePipeIn);
Error0000:
      if (hReadPipeOut) CloseHandle(hReadPipeOut);
      if (hWritePipeOut) CloseHandle(hWritePipeOut);
      if (MyPtr1) cb_MemFreeM(MyPtr1);
      return -1;
    }
    *hPipeIn = si.hStdInput = hReadPipeIn;
    SetHandleInformation(hWritePipeIn, HANDLE_FLAG_INHERIT, 0);
  }
  else si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
  si.hStdError = si.hStdOutput;
  si.cb = sizeof(si);
  si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
  si.wShowWindow = iShowHide;
  cb_MemSet(&pi,0,sizeof(pi));
  if (sWorkDir) if (sWorkDir[0]==0) sWorkDir = NULL;
  if (flags==-1) flags = NORMAL_PRIORITY_CLASS;
  iRet = CreateProcess(sExe,(char*)sCmdLine,NULL,NULL,TRUE,flags,NULL,sWorkDir,&si,&pi);
  if (MyPtr1) cb_MemFreeM(MyPtr1);
  if (hWritePipeOut) CloseHandle(hWritePipeOut);
  if (hReadPipeIn) CloseHandle(hReadPipeIn);
  CloseHandle(pi.hThread);
  if (!iRet)
    WaitState=TRUE;
  else {
    if (dwProc) *dwProc = pi.dwProcessId;
    if (dwThread) *dwThread = pi.dwThreadId;
    if (hPipeOut) *hPipeOut = hReadPipeOut;
    WaitForInputIdle(pi.hProcess,5000);
    if (WaitState) {
      if (pi.hProcess) {
        t1 = GetTickCount();
        do {
          iRet = WaitForSingleObject(pi.hProcess,1);
          if ((cb_UInteger)subCaptureOut>1) {
            t2 = GetTickCount(); t2 -= t1;
            if (t2<(clock_t)WaitState) i = subCaptureOut(UserDataOut, NULL, t2, pi.dwProcessId);
            else { t1 = t2; cb_ReadConsoleBuf(hReadPipeOut, subCaptureOut, UserDataOut, pi.dwProcessId, &i); }
            if (i==-1) {
KillProcess0000:
              cb_ProcessKillEx(pi.dwProcessId,NULL,TRUE);
              goto Exit0000;
            }
            if (i==-2) {
              MyPtr1 = (char*)OpenThread(THREAD_SUSPEND_RESUME, FALSE, pi.dwThreadId);
              if (MyPtr1) {
                if (SuspendThread((HANDLE)MyPtr1)!=(DWORD)-1) {
                  do {
                    i = subCaptureOut(UserDataOut, NULL, -1, pi.dwProcessId);
                    if (i==-1) { CloseHandle((HANDLE)MyPtr1); goto KillProcess0000; }
                  } while(i==-2);
                  ResumeThread((HANDLE)MyPtr1);
                }
                CloseHandle((HANDLE)MyPtr1);
              }
            }
          }
          if (subCaptureIn) {
            MyPtr1 = subCaptureIn(UserDataIn, hWritePipeIn, pi.dwProcessId);
            if (MyPtr1) if (MyPtr1[0]) WriteFile(hWritePipeIn, MyPtr1, cb_StrLen(MyPtr1), (DWORD*)&i, 0);
          }
          if (iRet==WAIT_OBJECT_0) { GetExitCodeProcess(pi.hProcess, (DWORD*)&i); iRet=i; pi.dwProcessId = 0; break; }
          else if (iRet!=WAIT_TIMEOUT) break;
        }while(1);
        if ((cb_UInteger)subCaptureOut>1) cb_ReadConsoleBuf(hReadPipeOut, subCaptureOut, UserDataOut, pi.dwProcessId);
      }
    }
  }
Exit0000:
  CloseHandle(pi.hProcess);
  if (hReadPipeOut) if (WaitState || !hPipeOut) CloseHandle(hReadPipeOut);
  if (hWritePipeIn) if (WaitState || !hPipeIn) CloseHandle(hWritePipeIn);
  return iRet;
}
/* END MODULE */


/* MODULE::cb_Run */
cb_Integer cb_DEFCALL cb_Run (const char *sExe, const char *sCmdLine, cb_Integer iShowHide, const char *sWorkDir, cb_Integer WaitState)
{
  return cb_RunEx(sExe,sCmdLine,iShowHide,sWorkDir,WaitState);
}
/* END MODULE */


/* MODULE::cb_GetOSName */
char* cb_DEFCALL cb_GetOSName (void *dst)
{
  static char pszOS[2048];

  if (!pszOS[0]) {

  SYSTEM_INFO si = {0};
  cb_GetWindowsVersion();
  GetSystemInfo(&si);
  cb_StrCopy(pszOS, "Microsoft Windows");
  if (VER_PLATFORM_WIN32_NT==cb_osinfoex.dwPlatformId &&
    cb_osinfoex.dwMajorVersion>4) {
      // Test for the specific product.
    if (cb_osinfoex.dwMajorVersion==6) {
      if (cb_osinfoex.dwMinorVersion==0) {
        if (cb_osinfoex.wProductType==VER_NT_WORKSTATION)
          cb_StrCat(pszOS, " Vista ");
        else cb_StrCat(pszOS, " Server 2008 ");
      }
      if (cb_osinfoex.dwMinorVersion==1) {
        if (cb_osinfoex.wProductType==VER_NT_WORKSTATION)
          cb_StrCat(pszOS, " 7 ");
        else cb_StrCat(pszOS, " Server 2008 R2 ");
      }

    }

    else if (cb_osinfoex.dwMajorVersion==5 && cb_osinfoex.dwMinorVersion==2) {
      if (GetSystemMetrics(SM_SERVERR2))
        cb_StrCat(pszOS, " Server 2003 R2, ");
      else if (cb_osinfoex.wSuiteMask & VER_SUITE_STORAGE_SERVER)
        cb_StrCat(pszOS, " Storage Server 2003");
      else if (cb_osinfoex.wSuiteMask & VER_SUITE_WH_SERVER)
        cb_StrCat(pszOS, " Home Server");
      else if (cb_osinfoex.wProductType==VER_NT_WORKSTATION &&
        si.wProcessorArchitecture==PROCESSOR_ARCHITECTURE_AMD64)
        cb_StrCat(pszOS, " XP Professional x64 Edition");
      else cb_StrCat(pszOS, "Server 2003, ");

      // Test for the server type.
      if (cb_osinfoex.wProductType!=VER_NT_WORKSTATION) {
        if (si.wProcessorArchitecture==PROCESSOR_ARCHITECTURE_IA64) {
          if (cb_osinfoex.wSuiteMask & VER_SUITE_DATACENTER)
            cb_StrCat(pszOS, "Datacenter Edition for Itanium-based Systems");
          else if (cb_osinfoex.wSuiteMask & VER_SUITE_ENTERPRISE)
            cb_StrCat(pszOS, "Enterprise Edition for Itanium-based Systems");
        }

        else if (si.wProcessorArchitecture==PROCESSOR_ARCHITECTURE_AMD64) {
          if (cb_osinfoex.wSuiteMask & VER_SUITE_DATACENTER)
            cb_StrCat(pszOS, "Datacenter x64 Edition");
          else if (cb_osinfoex.wSuiteMask & VER_SUITE_ENTERPRISE)
            cb_StrCat(pszOS, "Enterprise x64 Edition");
          else cb_StrCat(pszOS, "Standard x64 Edition");
        }

        else {
          if (cb_osinfoex.wSuiteMask & VER_SUITE_COMPUTE_SERVER)
            cb_StrCat(pszOS, "Compute Cluster Edition");
          else if (cb_osinfoex.wSuiteMask & VER_SUITE_DATACENTER)
            cb_StrCat(pszOS, "Datacenter Edition");
          else if (cb_osinfoex.wSuiteMask & VER_SUITE_ENTERPRISE)
            cb_StrCat(pszOS, "Enterprise Edition");
          else if (cb_osinfoex.wSuiteMask & VER_SUITE_BLADE)
            cb_StrCat(pszOS, "Web Edition");
          else cb_StrCat(pszOS, "Standard Edition");
        }
      }
    }

    else if (cb_osinfoex.dwMajorVersion==5 && cb_osinfoex.dwMinorVersion==1) {
      cb_StrCat(pszOS, "XP ");
      if (cb_osinfoex.wSuiteMask & VER_SUITE_PERSONAL)
        cb_StrCat(pszOS, "Home Edition");
      else cb_StrCat(pszOS, "Professional");
    }

    else if (cb_osinfoex.dwMajorVersion==5 && cb_osinfoex.dwMinorVersion==0) {
      cb_StrCat(pszOS, "2000 ");
      if (cb_osinfoex.wProductType==VER_NT_WORKSTATION)
        cb_StrCat(pszOS, "Professional");
      else {
        if (cb_osinfoex.wSuiteMask & VER_SUITE_DATACENTER)
          cb_StrCat(pszOS, "Datacenter Server");
        else if (cb_osinfoex.wSuiteMask & VER_SUITE_ENTERPRISE)
          cb_StrCat(pszOS, "Advanced Server");
        else cb_StrCat(pszOS, "Server");
      }
    }

    // Include service pack (if any) and build number.
    if (cb_osinfoex.szCSDVersion[0]) {
      cb_StrCat(pszOS, " ");
      cb_StrCat(pszOS, cb_osinfoex.szCSDVersion);
    }

    char buf[80];

    cb_snprintf(buf, 80, " (build %d)", cb_osinfoex.dwBuildNumber);
    cb_StrCat(pszOS, buf);

    if (cb_osinfoex.dwMajorVersion>=6) {
       if (si.wProcessorArchitecture==PROCESSOR_ARCHITECTURE_AMD64)
          cb_StrCat(pszOS, ", 64-bit");
       else if (si.wProcessorArchitecture==PROCESSOR_ARCHITECTURE_INTEL)
          cb_StrCat(pszOS, ", 32-bit");
    }

  }

  }

  if (dst) return cb_StrCopy(dst,pszOS);
  return pszOS;
}
/* END MODULE */


/* MODULE::cb_WhereXY */
cb_Integer cb_DEFCALL cb_WhereXY (cb_Integer *y)
{
  CONSOLE_SCREEN_BUFFER_INFO  csbiInfo = {0};
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut,&csbiInfo);
  if (y) y[0] = csbiInfo.dwCursorPosition.Y;
  return csbiInfo.dwCursorPosition.X;
}
/* END MODULE */


/* MODULE::cb_WhereY */
cb_Integer cb_DEFCALL cb_WhereY (void)
{
  cb_Integer y;
  cb_WhereXY(&y);
  return y;
}
/* END MODULE */


/* MODULE::cb_GetConColsRows */
cb_Integer cb_DEFCALL cb_GetConColsRows (cb_Integer *y)
{
  CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut,&csbiInfo);
  if (y) y[0] = csbiInfo.dwSize.Y;
  return csbiInfo.dwSize.X;
}
/* END MODULE */


/* MODULE::cb_GetConRows */
cb_Integer cb_DEFCALL cb_GetConRows (void)
{
  cb_Integer y;
  cb_GetConColsRows(&y);
  return y;
}
/* END MODULE */


/* MODULE::cb_Locate */
void cb_DEFCALL cb_Locate (cb_Integer y,cb_Integer x)
{
  cb_Integer x1, y1; if (x<0 || y<0) x1 = cb_WhereXY(&y1);
  if (x<0) x = x1;
  if (y<0) y = y1;
  COORD Coord1;
  Coord1.X = x;
  Coord1.Y = y;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleCursorPosition(cbApp_hStdOut,Coord1);
}
/* END MODULE */


/* MODULE::cb_Cls */
void cb_DEFCALL cb_Cls (COLORREF colr1)
{
  register COLORREF fg = colr1;
  register DWORD dwSize;
  COORD Coord1 = {0};
  DWORD dwWritten;
  CONSOLE_SCREEN_BUFFER_INFO csbiInfo = {0};
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut, &csbiInfo);
  dwSize = csbiInfo.dwSize.X * csbiInfo.dwSize.Y;
  FillConsoleOutputCharacterA(cbApp_hStdOut, ' ', dwSize, Coord1, &dwWritten);
  if (fg==(COLORREF)-1) { fg = cbApp_BackColor; fg <<= 4; fg |= cbApp_BackColor; }
  FillConsoleOutputAttribute(cbApp_hStdOut, fg, dwSize, Coord1, &dwWritten);
  SetConsoleCursorPosition(cbApp_hStdOut,Coord1);
}
/* END MODULE */


/* MODULE::cb_SetConColor */
void cb_DEFCALL cb_SetConColor (COLORREF colr1)
{
  cbApp_ForeColor = colr1 & 0x0F;
  cbApp_BackColor = colr1 >> 4;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleTextAttribute (cbApp_hStdOut,colr1);
}
/* END MODULE */


/* MODULE::cb_SetConCharColor */
void cb_DEFCALL cb_SetConCharColor (cb_UInteger chr1, cb_Integer x,cb_Integer y,cb_Integer cnt1,COLORREF color1)
{
  cb_Integer x1, y1; if (x<0 || y<0) x1 = cb_WhereXY(&y1);
  COORD Coord1;
  if (x<0) Coord1.X =x1; else Coord1.X = x;
  if (y<0) Coord1.Y = y1; else Coord1.Y = y;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  x1 = cnt1; if (x1<=0) x1 = 1;
  if (color1==(COLORREF)-2)
    FillConsoleOutputAttribute(cbApp_hStdOut, chr1 & 0x00FF, x1, Coord1, (DWORD*)&cnt1);
  else {
    if (color1<=0xffff) FillConsoleOutputAttribute(cbApp_hStdOut, color1, x1, Coord1, (DWORD*)&cnt1);
    FillConsoleOutputCharacterA(cbApp_hStdOut, chr1 & 0x00FF, x1, Coord1, (DWORD*)&cnt1);
  }
}
/* END MODULE */


/* MODULE::cb_SetCCCStr */
void cb_DEFCALL cb_SetCCCStr (const void *str1,cb_Integer x,cb_Integer y,cb_Integer cnt1,COLORREF color1)
{
  register const char *strtmp = (const char*)str1;
  cb_Integer x1, y1; if (x<0 || y<0) x1 = cb_WhereXY(&y1);
  COORD Coord1;
  if (x<0) Coord1.X =x1; else Coord1.X = x;
  if (y<0) Coord1.Y = y1; else Coord1.Y = y;
  x1 = cnt1; if (x1<=0) x1 = cb_StrLen(strtmp);
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  if (color1==(COLORREF)-2)
    WriteConsoleOutputAttribute(cbApp_hStdOut,(const WORD*)strtmp,x1,Coord1,(DWORD*)&cnt1);
  else {
    if (color1<=0xffff) FillConsoleOutputAttribute(cbApp_hStdOut, color1, x1, Coord1, (DWORD*)&cnt1);
    WriteConsoleOutputCharacterA(cbApp_hStdOut,strtmp,x1,Coord1,(DWORD*)&cnt1);
  }
}
/* END MODULE */


/* MODULE::cb_SetCCCLine */
void cb_DEFCALL cb_SetCCCLine (const void *str1,cb_Integer x,cb_Integer y,COLORREF color1)
{
  register const char *strtmp = (const char*)str1;
  cb_Integer x1, y1; if (x<0 || y<0) x1 = cb_WhereXY(&y1);
  CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
  COORD Coord1;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut,&csbiInfo);
  if (x<0) x = x1; csbiInfo.dwSize.X-=x;
  if (y<0) y = y1;
  cb_SetCCCStr(strtmp,x,y,csbiInfo.dwSize.X,color1);
  if (color1!=(COLORREF)-2) {
    x1 = cb_StrLen(strtmp);
    if (csbiInfo.dwSize.X>x1) {
      x+=csbiInfo.dwSize.X; csbiInfo.dwSize.X-=x1;
      Coord1.X = x; Coord1.Y = y;
      FillConsoleOutputCharacterA(cbApp_hStdOut,' ',csbiInfo.dwSize.X,Coord1,(DWORD*)&x);
      if (color1<=0xffff) FillConsoleOutputAttribute(cbApp_hStdOut,color1,csbiInfo.dwSize.X,Coord1,(DWORD*)&x);
    }
  }
}
/* END MODULE */


/* MODULE::cb_GetConKey */
cb_Integer cb_DEFCALL cb_GetConKey (cb_Integer bRead)
{
  register cb_Integer i; i = _kbhit();
  if (i && bRead) { i = _getch(); if (i==0 || i==0xE0) i = (((cb_UInteger)_getch()) << 8) | 0xE0; }
  return i;
}
/* END MODULE */


/* MODULE::cb_InKey */
char* cb_DEFCALL cb_InKey (void *dst)
{
  register cb_Integer i; i = cb_GetConKey(TRUE);
  register char *strtmp; strtmp = (char*)dst;
  if (!strtmp || strtmp==(char*)-1) {
    strtmp = cb_NewStr_(NULL,strtmp,0); if (!strtmp) { if (dst) return NULL; return cb_EMPTYSTR; }
  }
  *(__int32*)strtmp = i;
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_Pause */
void cb_DEFCALL cb_Pause (const char *sMsg)
{
  if (!sMsg) sMsg = "\nPress any key to continue ...\n";
  cb_FilePutS(cb_StdOut,sMsg);
#if defined(__GNUG__) || defined(__GNUC__)
  cb_FileFlush(cb_StdOut);
#endif
  do;while(cb_GetConKey(TRUE));
  do;while(!cb_GetConKey(TRUE));
}
/* END MODULE */


/* MODULE::cb_ShiftKeyPressed */
cb_Integer cb_ShiftKeyPressed (void)
{
  register cb_Integer i = 0; if (cb_KeyPressed(VK_SHIFT)) i |= 1; if (cb_KeyPressed(VK_CONTROL)) i |= 2; if (cb_KeyPressed(VK_MENU)) i |= 4;
  return i;
}
/* END MODULE */


/* MODULE::cb_GetLastError */
char * cb_DEFCALL cb_GetLastError (cb_Integer iError, void *dst)
{
  register cb_Integer iErr = iError;
  register char *sBuffer = (char*)dst;

  if (!iErr) iErr = GetLastError();
  if (iErr) {
    if (!sBuffer || sBuffer==(char*)-1) { sBuffer = cb_NewStr_(NULL,sBuffer,0x0600); if (!sBuffer) goto Exit0000; }
    FormatMessage (FORMAT_MESSAGE_FROM_SYSTEM, 0, iErr, LANG_NEUTRAL, sBuffer, 0x0600-1, 0);
  }
  else if (!sBuffer) sBuffer = cb_EMPTYSTR;
  else if (sBuffer==(char*)-1) sBuffer = cb_NewStr_(NULL,(void*)-1,0);
  else sBuffer[0] = 0;
Exit0000:
  return sBuffer;
}
/* END MODULE */


/* MODULE::cb_PlaySound */
cb_Integer cb_DEFCALL cb_PlaySound (const char *sfName, const char *rcid, cb_Integer iFlags)
{
  register cb_Integer i = iFlags; if (i==-1) i = SND_ASYNC;
  register HMODULE hMod = NULL;
  if (rcid && (sfName==NULL || sfName[0]==0)) {
    sfName = rcid; hMod = cbApp_hInstance; if (!hMod) hMod = GetModuleHandle(NULL);
    i |= SND_RESOURCE | SND_NODEFAULT | SND_NOWAIT;
  }
  else if (i&SND_MEMORY) i |= SND_NODEFAULT | SND_NOWAIT;
  else i |= SND_FILENAME | SND_NODEFAULT | SND_NOWAIT;
  return PlaySound(sfName, hMod, i);
}
/* END MODULE */


/* MODULE::cb_Sound */
cb_Integer cb_DEFCALL cb_Sound (double Freq,cb_UInteger Dura,double Vol,cb_Integer Sync,cb_UInteger sps)
{
  register void *dst = cb_CreateWave(Freq,Dura,Vol,NULL,(void*)-1,sps);
  register cb_Integer i = 0;
  if (dst) {
    i = PlaySound((const char*)dst, NULL, Sync|SND_MEMORY|SND_NODEFAULT|SND_NOWAIT);
    cb_MemFreeM(dst);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_GetWindowsDir */
char * cb_DEFCALL cb_GetWindowsDir (cb_Integer flag1, void *dst)
{
  register char *strtmp = (char*)dst;
  register cb_Integer i;
  if (!strtmp || strtmp==(char*)-1) { strtmp = cb_NewStr_(NULL,strtmp,0x0800); if (!strtmp) { if (!dst) strtmp = cb_EMPTYSTR; goto Exit0000; } }
  GetWindowsDirectory (strtmp,0x0800);
  i = cb_StrLen(strtmp) - 1;
  if (strtmp[i]!='\\') {
    if (flag1) { i++; *((short*)(strtmp+i)) = '\\'; }
  }
  else if (!flag1)
    strtmp[i] = 0;
Exit0000:
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_GetSystemDir */
char * cb_DEFCALL cb_GetSystemDir (cb_Integer flag1, void *dst)
{
  register char *strtmp = (char*)dst;
  register cb_Integer i;
  if (!strtmp || strtmp==(char*)-1) { strtmp = cb_NewStr_(NULL,strtmp,0x0800); if (!strtmp) { if (!dst) strtmp = cb_EMPTYSTR; goto Exit0000; } }
  GetSystemDirectory (strtmp,0x0800);
  i = cb_StrLen(strtmp) - 1;
  if (strtmp[i]!='\\') {
    if (flag1) { i++; *((short*)(strtmp+i)) = '\\'; }
  }
  else if (!flag1)
    strtmp[i] = 0;
Exit0000:
  return strtmp;
}
/* END MODULE */


/* MODULE::cb_GetWindowsVersion */
cb_Integer cb_DEFCALL cb_GetWindowsVersion (void)
{
  if (!cb_osinfoex.dwOSVersionInfoSize) {
    cb_osinfoex.dwOSVersionInfoSize = sizeof(cb_osinfoex);
    GetVersionEx((OSVERSIONINFO*)(&cb_osinfoex));
  }
  return cb_osinfoex.dwPlatformId;
}
/* END MODULE */


/* MODULE::cb_NameOfComputer */
char * cb_DEFCALL cb_NameOfComputer (void)
{
  static char Str1[0x200]; if (Str1[0]) return Str1;
  DWORD     l;
  l = sizeof(Str1)-1;
  GetComputerNameA(Str1,&l);
  return Str1;
}
/* END MODULE */


/* MODULE::cb_NameOfUser */
char * cb_DEFCALL cb_NameOfUser (void)
{
  static char Str1[0x200]; if (Str1[0]) return Str1;
  DWORD     l;
  l = sizeof(Str1)-1;
  GetUserNameA(Str1,&l);
  return Str1;
}
/* END MODULE */


/* MODULE::cb_GetSpecialFolder */
char * cb_DEFCALL cb_GetSpecialFolder (cb_Integer nFolder, void *dst, cb_Boolean bFlag)
{
  register char *RetVar = (char*)dst; if (!RetVar || RetVar==(char*)-1) { RetVar = cb_NewStr_(NULL,RetVar,0x0800); if (!RetVar) { if (!dst) RetVar = cb_EMPTYSTR; goto Exit0000; } }
  register cb_Integer i; i = nFolder; if (bFlag) i |= CSIDL_FLAG_CREATE;
  if (!SHGetFolderPath(NULL,i,NULL,SHGFP_TYPE_CURRENT,RetVar)) RetVar[0]=0;
Exit0000:
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_GetDrives */
char * cb_DEFCALL cb_GetDrives (cb_Integer flag1,void *dst)
{
  register cb_Integer iCnt;
  register ULONG i;
  register char *MyPtr1;

  MyPtr1 = (char*)dst;
  if (MyPtr1==NULL || MyPtr1==(char*)-1) {
    MyPtr1 = cb_NewStr_(NULL,MyPtr1,96); if (!MyPtr1) { if (dst) return NULL; return cb_EMPTYSTR; }
    dst = MyPtr1;
  }
  i = GetLogicalDrives();
  for(iCnt=0;i;iCnt++) {
    if ((i & 1)!=0) {
      MyPtr1[0] = iCnt+'A';
      ++MyPtr1;
      if (flag1>=1) {
        MyPtr1[0] = ':';
        ++MyPtr1;
      }
      if (flag1>=2) {
        MyPtr1[0] = '\\';
        ++MyPtr1;
      }
      MyPtr1[0] = '\0';
      ++MyPtr1;
    }
    i >>= 1;
  }
  ((short*)MyPtr1)[0] = 0;
  return (char*)dst;
}
/* END MODULE */


/* MODULE::cb_GetRegString */
char * cb_DEFCALL cb_GetRegString (HKEY hKey, const char *sKey, const char *sValueName, void *dst)
{
  register BYTE *Buf;
  register cb_Integer i;
  DWORD BufLen;
  if (RegOpenKeyEx(hKey,sKey,0,KEY_QUERY_VALUE,&hKey)!=ERROR_SUCCESS) return NULL;
  Buf = (BYTE*)cb_MemAllocM(0x4000); if (!Buf) return NULL;
  BufLen = 0x4000-1;
  i = RegQueryValueEx(hKey,sValueName,NULL,NULL,Buf,&BufLen);
  RegCloseKey(hKey);
  if (i!=ERROR_SUCCESS)
    i = 0;
  else {
    i = (cb_Integer)dst;
    if (i==0 || i==-1) i = (cb_Integer)cb_NewStr_(Buf,(void*)i,BufLen);
    else { cb_MemCopy((void*)i,Buf,BufLen); ((char*)i)[BufLen] = 0; }
  }
  cb_MemFreeM(Buf);
  return (char*)i;
}
/* END MODULE */


/* MODULE::cb_SetRegString */
void cb_DEFCALL cb_SetRegString (HKEY hK, const char *sKey, const char *sVar, const char *sValue)
{
  HKEY  hKey;
  DWORD  Result;
  if (RegCreateKeyEx(hK,sKey,0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL)==ERROR_SUCCESS) {
    if (sValue && sValue[0]) Result = cb_StrLen(sValue)+1; else { sValue = NULL; Result = 0; }
    RegSetValueEx(hKey,sVar,0,REG_SZ,(const BYTE*)sValue,Result);
    RegCloseKey(hKey);
  }
}
/* END MODULE */


/* MODULE::cb_GetRegInt */
cb_Integer cb_DEFCALL cb_GetRegInt (HKEY hK,const char *sKey, const char *sValueName)
{
  HKEY  hKey = NULL;
  DWORD Result = 0;
  DWORD sze = sizeof(DWORD);
  if (RegOpenKeyEx(hK,sKey,0,KEY_QUERY_VALUE,&hKey)==ERROR_SUCCESS) {
    RegQueryValueEx(hKey,sValueName,NULL,NULL,(BYTE*)(&Result),&sze);
    RegCloseKey(hKey);
  }
  return Result;
}
/* END MODULE */


/* MODULE::cb_SetRegInt */
void cb_DEFCALL cb_SetRegInt (HKEY hK, const char *sKey, const char *sVar, cb_Integer iValue)
{
  HKEY  hKey;
  if (RegCreateKeyEx(hK,sKey,0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,0,&hKey,NULL)==ERROR_SUCCESS) {
    RegSetValueEx(hKey,sVar,0,REG_DWORD,(const BYTE*)&iValue,sizeof(cb_Integer));
    RegCloseKey(hKey);
  }
}
/* END MODULE */


/* MODULE::cb_GetRegLLong */
long long cb_DEFCALL cb_GetRegLLong (HKEY hKey, const char *sKey, const char *sValueName)
{
  register char *sBuf = cb_GetRegString(hKey, sKey, sValueName, (void*)-1);
  register long long i = cb_AtoULLBase(sBuf);
  cb_MemFreeM(sBuf);
  return i;
}
/* END MODULE */


/* MODULE::cb_SetRegLLong */
void cb_DEFCALL cb_SetRegLLong (HKEY hKey, const char *sKey, const char *VarName, long long Value)
{
  char sBuf[160];
  cb_SetRegString(hKey, sKey, VarName, cb_CStrL(Value, 10, sBuf));
}
/* END MODULE */


/* MODULE::cb_GetRegDouble */
double cb_DEFCALL cb_GetRegDouble (HKEY hKey, const char *sKey, const char *sValueName)
{
  static char sBuf[4096];
  return cb_AtoD(cb_GetRegString(hKey, sKey, sValueName, sBuf),NULL);
}
/* END MODULE */


/* MODULE::cb_SetRegDouble */
void cb_DEFCALL cb_SetRegDouble (HKEY hKey, const char *sKey, const char *VarName, double Value)
{
  char sBuf[160];
  cb_SetRegString(hKey, sKey, VarName, cb_CStrDbl(Value, sBuf));
}
/* END MODULE */


/* MODULE::cb_DeleteRegNode */
static cb_Boolean cb_DEFCALL cb_DeleteRegNode_ (HKEY hKeyRoot, LPSTR lpSubKey, char *szName)
{
    LPSTR lpEnd;
    LONG lResult;
    DWORD dwSize;
    HKEY hKey;
    lResult = RegDeleteKey(hKeyRoot, lpSubKey);

    if (lResult == ERROR_SUCCESS)
        return TRUE;

    lResult = RegOpenKeyEx(hKeyRoot, lpSubKey, 0, KEY_READ, &hKey);

    if (lResult != ERROR_SUCCESS)
    {
        if (lResult == ERROR_FILE_NOT_FOUND) return TRUE;
        return FALSE;
    }
    lpEnd = lpSubKey + cb_StrLen(lpSubKey);

    if (*(lpEnd - 1) != '\\')
    {
        *lpEnd = '\\';
        lpEnd++;
        *lpEnd = '\0';
    }
    do {
        dwSize = MAX_PATH;
        lResult = RegEnumKeyEx(hKey, 0, szName, &dwSize, NULL, NULL, NULL, NULL );
        if (lResult != ERROR_SUCCESS) break;
        cb_StrCopy(lpEnd, szName);
    }while(cb_DeleteRegNode_(hKeyRoot, lpSubKey, szName));
    RegCloseKey(hKey);
    lResult = RegDeleteKey(hKeyRoot, lpSubKey);

    if (lResult == ERROR_SUCCESS) return TRUE;

    return FALSE;
}

cb_Boolean cb_DEFCALL cb_DeleteRegNode (LPCSTR lpSubKey, HKEY hKeyRoot)
{
    char *sBuf1 = (char*)cb_MemAllocM(MAX_PATH*0x80), sBuf2[MAX_PATH+0x80];

    cb_StrCopy(sBuf1, lpSubKey);
    register cb_Boolean n = cb_DeleteRegNode_(hKeyRoot, sBuf1, sBuf2);
    cb_MemFreeM(sBuf1);
    return n;
}
/* END MODULE */


/* MODULE::cb_GetConCharColor */
WORD cb_DEFCALL cb_GetConCharColor (cb_Integer x,cb_Integer y,cb_Integer flg1)
{
  DWORD len1;
  COORD Coord1;
  WORD  Attr1;
  WORD Char1 = 0;
  cb_Integer x1, y1; if (x<0 || y<0) x1 = cb_WhereXY(&y1);
  if (x<0) Coord1.X = x1; else Coord1.X = x;
  if (y<0) Coord1.Y = y1; else Coord1.Y = y;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  if (!(flg1&1)) ReadConsoleOutputCharacterA(cbApp_hStdOut,(char*)&Char1,1,Coord1,&len1);
  if (!(flg1&2)) {
    ReadConsoleOutputAttribute(cbApp_hStdOut,&Attr1,1,Coord1,&len1);
    if (!flg1) return (Attr1<<4) + Char1;
    return Attr1;
  }
  return Char1;
}
/* END MODULE */


/* MODULE::cb_GetCCCStr */
char* cb_DEFCALL cb_GetCCCStr (cb_Integer x,cb_Integer y,cb_Integer cnt1,cb_Integer flg1, void *len1,void *dst)
{
  register char *sTmp = (char*)dst;
  register DWORD *i1, i2;
  cb_Integer x1, y1;
  DWORD len2;
  COORD Coord1;

  if (cnt1<=0) cnt1 = 1;
  if (!sTmp || sTmp==(char*)-1) { sTmp = (char*)cb_MemAllocM((cnt1<<1)+sizeof(cb_Integer)); if (!sTmp) goto Exit0000; }
  i1 = (DWORD*)len1; if (!i1) i1 = &len2;
  i1[0] = 0;
  if (x<0 || y<0) x1 = cb_WhereXY(&y1);
  if (x<0) Coord1.X =x1; else Coord1.X = x;
  if (y<0) Coord1.Y = y1; else Coord1.Y = y;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  if (!flg1) { ReadConsoleOutputCharacterA(cbApp_hStdOut,sTmp,cnt1,Coord1,i1); i2 = i1[0]; }
  else { ReadConsoleOutputAttribute(cbApp_hStdOut,(WORD*)sTmp,cnt1,Coord1,i1); i2 = i1[0]; i2 <<= 1; }
  if (!dst) { i1 = (DWORD*)cb_NewStr_(sTmp,NULL,i2); cb_MemFreeM(sTmp); return (char*)i1; }
  sTmp[i2]=0;
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_GetCCCLine */
char* cb_DEFCALL cb_GetCCCLine (cb_Integer y,cb_Integer x,cb_Integer flg1,void *len1,void *dst)
{
  CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut,&csbiInfo);
  if (x<0) x = csbiInfo.dwCursorPosition.X; csbiInfo.dwSize.X-=x;
  return cb_GetCCCStr(x,y,csbiInfo.dwSize.X,flg1,len1,dst);
}
/* END MODULE */


/* MODULE::cb_SetConColsRows */
cb_Integer cb_DEFCALL cb_SetConColsRows (cb_Integer x, cb_Integer y)
{
  CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut,&csbiInfo);
  if (x>0) { csbiInfo.dwSize.X = x; csbiInfo.srWindow.Right = x-1; }
  if (y>0) { csbiInfo.dwSize.Y = y; csbiInfo.srWindow.Bottom = y-1; }
  SetConsoleScreenBufferSize(cbApp_hStdOut,csbiInfo.dwSize);
  return SetConsoleWindowInfo(cbApp_hStdOut,TRUE,&csbiInfo.srWindow);
}
/* END MODULE */


/* MODULE::cb_GetConCursor */
cb_Integer cb_DEFCALL cb_GetConCursor (cb_Integer *b1)
{
  CONSOLE_CURSOR_INFO cci = {0};
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleCursorInfo(cbApp_hStdOut,&cci);
  if (b1) *b1 = cci.bVisible;
  return cci.dwSize;
}
/* END MODULE */


/* MODULE::cb_GetConCursorVisible */
cb_Integer cb_DEFCALL cb_GetConCursorVisible (void)
{
  cb_Integer b1;
  cb_GetConCursor(&b1);
  return b1;
}
/* END MODULE */


/* MODULE::cb_SetConCursor */
void cb_DEFCALL cb_SetConCursor (cb_Integer b1,cb_Integer b2)
{
  CONSOLE_CURSOR_INFO cci = {0};
  if (b1>=0) cci.dwSize = b1; else cci.dwSize = cb_GetConCursor(&cci.bVisible);
  if (b2!=-2) cci.bVisible = b2; else if (b1>=0) cb_GetConCursor(&cci.bVisible);
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleCursorInfo(cbApp_hStdOut,&cci);
}
/* END MODULE */


/* MODULE::cb_SetConHeight */
void cb_DEFCALL cb_SetConHeight (cb_Integer NewHeight)
{
  CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut,&csbiInfo);
  if (NewHeight>csbiInfo.dwMaximumWindowSize.Y) {
    csbiInfo.srWindow.Bottom=csbiInfo.dwMaximumWindowSize.Y-1;
  }
  else {
    csbiInfo.srWindow.Bottom=NewHeight-1;
  }
  csbiInfo.srWindow.Bottom += csbiInfo.srWindow.Top;
  SetConsoleWindowInfo(cbApp_hStdOut,TRUE,&csbiInfo.srWindow);
}
/* END MODULE */


/* MODULE::cb_GetConHeight */
cb_Integer cb_DEFCALL cb_GetConHeight (void)
{
  CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut,&csbiInfo);
  return csbiInfo.srWindow.Bottom-csbiInfo.srWindow.Top+1;
}
/* END MODULE */


/* MODULE::cb_SetConWidth */
void cb_DEFCALL cb_SetConWidth (cb_Integer NewWidth)
{
  CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut,&csbiInfo);
  if (NewWidth>csbiInfo.dwMaximumWindowSize.X) {
    csbiInfo.srWindow.Right=csbiInfo.dwMaximumWindowSize.X-1;
  }
  else {
    csbiInfo.srWindow.Right=NewWidth-1;
  }
  csbiInfo.srWindow.Right += csbiInfo.srWindow.Left;
  SetConsoleWindowInfo(cbApp_hStdOut,TRUE,&csbiInfo.srWindow);
}
/* END MODULE */


/* MODULE::cb_GetConWidth */
cb_Integer cb_DEFCALL cb_GetConWidth (void)
{
  CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
  if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(cbApp_hStdOut,&csbiInfo);
  return csbiInfo.srWindow.Right-csbiInfo.srWindow.Left+1;
}
/* END MODULE */


/* MODULE::cb_SetConFullScreen */
void cb_DEFCALL cb_SetConFullScreen (cb_Integer NewVal)
{
  DWORD     lpModeFlags;
  COORD     Coord1;
  if (GetConsoleDisplayMode(&lpModeFlags)) {
    if ((lpModeFlags & CONSOLE_FULLSCREEN_HARDWARE)!=0) {
      if (NewVal) return;
      lpModeFlags = CONSOLE_WINDOWED_MODE;
    }
    else {
      if (!NewVal) return;
      lpModeFlags = CONSOLE_FULLSCREEN_MODE;
    }
    if (cbApp_hStdOut==INVALID_HANDLE_VALUE) cbApp_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleDisplayMode(cbApp_hStdOut,lpModeFlags,&Coord1);
  }
}
/* END MODULE */


/* MODULE::cb_GetConFullScreen */
cb_Integer cb_DEFCALL cb_GetConFullScreen (void)
{
  DWORD     lpModeFlags;
  if (GetConsoleDisplayMode(&lpModeFlags)) {
    return (lpModeFlags & CONSOLE_FULLSCREEN_HARDWARE);
  }
  return 0;
}
/* END MODULE */


/* MODULE::cb_comInitialize */
HRESULT cb_comInitialize (void)
{
  register HRESULT i = S_OK;
  if (!cb_comWasInitialization) {
    i = OleInitialize(NULL);
    if (i==S_OK) cb_comWasInitialization++;
    else if (i==S_FALSE) { OleUninitialize(); i = S_OK; }
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_comAutoWrap */
cb_Integer cb_DEFCALL cb_comAutoWrap (IDispatch *pDisp, cb_Integer autoType, wchar_t *wszName, VARIANT *pList, cb_Integer iParamCnt, VARIANT *pvResult)
{
  register HRESULT hr;
  DISPPARAMS dp;
  DISPID dispidNamed;
  DISPID dispID;
  EXCEPINFO ExcepBuf;

  if (!pDisp) {
    hr = -1; goto Error0000;
  }

  if (autoType==-1) {
    autoType = DISPATCH_PROPERTYGET|DISPATCH_METHOD;
    dispID = DISPID_NEWENUM;
  }
  else {
#ifdef __cplusplus
    hr = pDisp->GetIDsOfNames(IID_NULL, &wszName, 1, LOCALE_USER_DEFAULT, &dispID);
#else
    hr = pDisp->lpVtbl->GetIDsOfNames(pDisp, &IID_NULL, &wszName, 1, LOCALE_USER_DEFAULT, &dispID);
#endif
    if (FAILED(hr)) {
      goto Error0000;
    }
  }

  cb_MemSet(&dp, 0, sizeof(dp));

  dp.cArgs = iParamCnt;
  dp.rgvarg = pList;

  if ((autoType & DISPATCH_PROPERTYPUT)!=0) {
    dispidNamed = DISPID_PROPERTYPUT;
    dp.cNamedArgs = 1;
    dp.rgdispidNamedArgs = &dispidNamed;
  }

  cb_MemSet(&ExcepBuf, 0, sizeof(ExcepBuf));

#ifdef __cplusplus
  hr = pDisp->Invoke(dispID, IID_NULL, LOCALE_SYSTEM_DEFAULT, autoType, &dp, pvResult, &ExcepBuf, NULL);
#else
  hr = pDisp->lpVtbl->Invoke(pDisp, dispID, &IID_NULL, LOCALE_SYSTEM_DEFAULT, autoType, &dp, pvResult, &ExcepBuf, NULL);
#endif
  if (FAILED(hr)) {
Error0000:
    cb_comError = (cb_Integer)hr;
  }

  return (cb_Integer)hr;
}
/* END MODULE */


/* MODULE::cb_comGetTmp */
cb_comObject* cb_comGetTmp (void)
{
  cb_comTmpCnt_ &= (sizeof(cb_comTmpBuf_)/sizeof(cb_comTmpBuf_[0]))-1;
  cb_comClear(&cb_comTmpBuf_[cb_comTmpCnt_]);
  return &cb_comTmpBuf_[cb_comTmpCnt_++];
}
/* END MODULE */


/* MODULE::cb_comAutoWrapEx */
__declspec(noinline) cb_comObject* cb_CDECL cb_comAutoWrapEx (cb_Integer autoType, cb_comObject *pObjGet, cb_comObject *pObjBase, cb_Integer iProp, ...)
{
  register cb_Integer i1, i2, i, c;
  VARIANT rVal = {0}, *pVal, *Ptr1;
  wchar_t *wszName, *MyPtr1;
  const char **a;

  static VARIANT PropListBuf[64];
  static VARIANT ParamListBuf[64];
  static wchar_t* ParamListTmpDynStr[64];

  cb_comError = 0;
  if (S_OK!=cb_comInitialize()) { cb_comError--; goto Error0001; }

  VariantCopy(&rVal,pObjBase);
  Ptr1 = &PropListBuf[0];
  a = (const char**)&iProp; a++;
  i1=0;
  while(i1<iProp) {
    wszName = (wchar_t*)(a[0]); a++; c=(cb_Integer)(a[0]); a++;
    cb_MemCopy(Ptr1, &rVal, sizeof(VARIANT));
    VariantInit(&rVal);
    i2=c;
    while (i2>0) {
      i2--;
      VariantInit(&ParamListBuf[i2]);
      i = (cb_Integer)(a[0]); a++;
      if (i==VT_I8) { ParamListBuf[i2].llVal = *(long long*)a; a++; }
      else if (i==VT_UI8) { ParamListBuf[i2].ullVal = *(unsigned long long*)a; a++; }
      else if (i==VT_R8) { ParamListBuf[i2].dblVal = *(double*)a; a++; }
      else if (i==VT_LPSTR) {
        MyPtr1 = cb_AnsiToUnicode(a[0],(void*)-1);
        ParamListBuf[i2].bstrVal = SysAllocString(MyPtr1);
        ParamListTmpDynStr[i2] = MyPtr1;
        i = VT_BSTR;
      }
      else if (i==VT_BOOL) ParamListBuf[i2].boolVal = *(VARIANT_BOOL*)a;
      else if (i!=VT_ERROR) ParamListBuf[i2].intVal = *(cb_Integer*)a;
      else ParamListBuf[i2].scode = *(SCODE*)a;
      ParamListBuf[i2].vt = i;
Cont0000:
      a++;
    }
    i2=c;
    i1++;
    if (i1<iProp) {
      i = DISPATCH_PROPERTYGET|DISPATCH_METHOD;
      goto rVal0000;
    }
    i = autoType;
    if ((i & DISPATCH_PROPERTYGET)!=0) {
      pVal = pObjGet;
      if (pVal==(VARIANT*)-1) { pVal = cb_comGetTmp(); pObjGet = pVal; }
      else if (pVal==NULL) { rVal0000:; pVal = &rVal; }
    }
    else pVal = NULL;
    i = cb_comAutoWrap(Ptr1->pdispVal, i, wszName, ParamListBuf, i2, pVal);
    while (i2>0) {
      i2--;
      if (ParamListTmpDynStr[i2]) {
        SysFreeString(ParamListBuf[i2].bstrVal);
        ParamListBuf[i2].bstrVal = NULL;
        cb_MemFreeM(ParamListTmpDynStr[i2]);
        ParamListTmpDynStr[i2] = NULL;
      }
      VariantClear(&ParamListBuf[i2]);
    }
    Ptr1++;
    if (FAILED(i)) break;
  }

  while (i1>0) { i1--; Ptr1--; VariantClear(Ptr1); } VariantClear(&rVal);
Error0001:
  return pObjGet;
}
/* END MODULE */


/* MODULE::cb_comClearTmp */
void cb_comClearTmp (void)
{
  register cb_Integer i = sizeof(cb_comTmpBuf_)/sizeof(cb_comTmpBuf_[0]);
  do { i--; cb_comClear(&cb_comTmpBuf_[i]); } while(i);
  cb_comTmpCnt_ = 0;
}
/* END MODULE */


/* MODULE::cb_comCreate */
cb_Integer cb_DEFCALL cb_comCreate (cb_comObject *pObj, const wchar_t *szName)
{
  VARIANT rVal = {0};
  CLSID clsid;

  register HRESULT hr = cb_comInitialize();

  if (hr==S_OK) {

  hr = CLSIDFromProgID(szName, &clsid);
  if (!FAILED(hr)) {

#ifdef __cplusplus
    hr = CoCreateInstance(clsid, NULL, CLSCTX_LOCAL_SERVER|CLSCTX_INPROC_SERVER, IID_IDispatch, (void**)&rVal.pdispVal);
#else
    hr = CoCreateInstance(&clsid, NULL, CLSCTX_LOCAL_SERVER|CLSCTX_INPROC_SERVER, &IID_IDispatch, (void**)&rVal.pdispVal);
#endif

    if (!FAILED(hr)) {
      rVal.vt = VT_DISPATCH;
      VariantCopy(pObj, &rVal);
    }

  }

  }

  cb_comError = (cb_Integer)hr;

  return (cb_Integer)hr;
}
/* END MODULE */


/* MODULE::cb_comQuery */
cb_Integer cb_DEFCALL cb_comQuery (cb_comObject *pObj, const void *p, const void *id)
{
  register IUnknown *pUnk = (IUnknown*)p;
  register HRESULT hr;
  VARIANT rVal = {0};

  hr = cb_comInitialize();

  if (hr==S_OK) {

  if (!pUnk) {
    pUnk = (IUnknown*)(pObj->pdispVal);
    if (!pUnk) { hr = -1; goto Error0000; }
#ifdef __cplusplus
    pUnk->AddRef();
#else
    IUnknown_AddRef(pUnk);
#endif
    if (id==(const void*)-1) return (cb_Integer)pUnk;
  }

  rVal.vt = VT_DISPATCH;

  if (!id) id = &IID_IDispatch;
#ifdef __cplusplus
  hr = pUnk->QueryInterface(*(const IID*)id, (void**)&rVal.pdispVal);
  if (!p) pUnk->Release();
#else
  hr = IUnknown_QueryInterface(pUnk, (REFIID)id, (void**)&rVal.pdispVal);
  if (!p) IUnknown_Release(pUnk);
#endif

  if (!FAILED(hr)) {
    VariantCopy(pObj, &rVal);
  }

  }

Error0000:
  cb_comError = (cb_Integer)hr;

  return (cb_Integer)hr;
}
/* END MODULE */


/* MODULE::cb_comGet */
cb_Integer cb_DEFCALL cb_comGetMoniker (cb_comObject *pObj, const wchar_t *wszName, const void *id)
{
  VARIANT rVal = {0};
  IBindCtx *vCtx;
  IMoniker *vMon;
  ULONG flag1;
  register HRESULT hr = CreateBindCtx(0, &vCtx);

  if (hr==S_OK) {
    hr = MkParseDisplayName(vCtx, wszName, &flag1, &vMon);
    if (hr==S_OK) {
      rVal.vt = VT_DISPATCH;
      if (!id) id = &IID_IDispatch;
#ifdef __cplusplus
      hr = vMon->BindToObject(vCtx, NULL, *(const IID*)id, (void**)&rVal.pdispVal);
#else
      hr = vMon->lpVtbl->BindToObject(vMon, vCtx, NULL, (REFIID)id, (void**)&rVal.pdispVal);
#endif
      if (hr==S_OK) {
        VariantCopy(pObj, &rVal);
      }
#ifdef __cplusplus
      vMon->Release();
#else
      vMon->lpVtbl->Release(vMon);
#endif
    }
#ifdef __cplusplus
    vCtx->Release();
#else
    vCtx->lpVtbl->Release(vCtx);
#endif
  }

  cb_comError = (cb_Integer)hr;

  return (cb_Integer)hr;
}

cb_Integer cb_DEFCALL cb_comGet (cb_comObject *pObj, const wchar_t *szName, const void *id, cb_Integer flag1)
{
  CLSID clsid;
  IUnknown *pUnk;

  register HRESULT hr = cb_comInitialize();

  if (hr==S_OK) {

  hr = CLSIDFromProgID(szName, &clsid);

  if (FAILED(hr)) return cb_comGetMoniker(pObj, szName, id);

#ifdef __cplusplus
  hr = GetActiveObject(clsid, NULL, &pUnk);
#else
  hr = GetActiveObject(&clsid, NULL, &pUnk);
#endif

  if (!FAILED(hr)) {
    hr = cb_comQuery(pObj, pUnk, id);
#ifdef __cplusplus
    if (flag1) pUnk->Release();
#else
    if (flag1) pUnk->lpVtbl->Release(pUnk);
#endif
  }

  }

  cb_comError = (cb_Integer)hr;

  return (cb_Integer)hr;
}
/* END MODULE */


/* MODULE::cb_comSetEvents */
cb_Integer cb_DEFCALL cb_comSetEvents (const void* ptr1,REFIID id,const void* pDisp,void* dwCookie,cb_Integer dw1)
{
  register IUnknown* pUnk = (IUnknown*)ptr1; if (!pUnk) return S_FALSE;
  register HRESULT hr;
  IConnectionPointContainer* pcpc;
  IConnectionPoint* pcp;
  DWORD eventCookie;

#ifdef __cplusplus
  hr = pUnk->QueryInterface(IID_IConnectionPointContainer,(void**)&pcpc);
#else
  hr = IUnknown_QueryInterface(pUnk,&IID_IConnectionPointContainer,(void**)&pcpc);
#endif
  if (SUCCEEDED(hr)) {
#ifdef __cplusplus
    hr = pcpc->FindConnectionPoint(id,&pcp);
#else
    hr = IConnectionPointContainer_FindConnectionPoint(pcpc,id,&pcp);
#endif
    if (SUCCEEDED(hr)) {
#ifdef __cplusplus
      if (dw1)
        hr = pcp->Unadvise(dw1);
      else {
        if (!dwCookie) dwCookie = &eventCookie;
        hr = pcp->Advise((IUnknown*)pDisp,(DWORD*)dwCookie);
      }
      pcp->Release();
#else
      if (dw1)
        hr = IConnectionPoint_Unadvise(pcp,dw1);
      else {
        if (!dwCookie) dwCookie = &eventCookie;
        hr = IConnectionPoint_Advise(pcp,(IUnknown*)pDisp,(DWORD*)dwCookie);
      }
      IConnectionPoint_Release(pcp);
#endif
    }
#ifdef __cplusplus
    pcpc->Release();
#else
    IConnectionPointContainer_Release(pcpc);
#endif
  }
  cb_comError = (cb_Integer)hr;
  return (cb_Integer)hr;
}
/* END MODULE */


/* MODULE::cb_comAtlAxTerm */
void cb_DEFCALL cb_comAtlAxTerm (void)
{
  if (cb_comhAtlAx) {
    if (cb_comAtlAxWinInit) {
      if (cb_comAtlAxGetControl) {
        cb_comAtlAxGetControl = NULL;
      }
      cb_comAtlAxWinInit = NULL;
    }
    FreeLibrary(cb_comhAtlAx);
    cb_comhAtlAx = NULL;
  }
}
/* END MODULE */


/* MODULE::cb_comAtlAxInit */
cb_Integer cb_DEFCALL cb_comAtlAxInit (void)
{
  if (cb_comAtlAxGetControl==0) {
    if (!cb_comhAtlAx) {
      cb_comhAtlAx = LoadLibraryA("atl.dll");
      if (!cb_comhAtlAx) return -1;
    }
    if (!cb_comAtlAxWinInit) {
      cb_comAtlAxWinInit = (cb_comsubAtlAxWinInit)GetProcAddress(cb_comhAtlAx, "AtlAxWinInit");
      if (!cb_comAtlAxWinInit) return -1;
    }
    cb_comAtlAxGetControl = (cb_comsubAtlAxGetControl)GetProcAddress(cb_comhAtlAx, "AtlAxGetControl");
    if (!cb_comAtlAxGetControl) return -1;
    cb_comAtlAxWinInit();
  }
  return 0;
}
/* END MODULE */


/* MODULE::cb_comGetActiveX */
cb_Integer cb_DEFCALL cb_comGetActiveX (cb_comObject *pObj, HWND hWnd, const void *id, void *ptr1)
{
  register cb_Integer hr = -1;
  IUnknown *pUnk;
  if (hWnd) if (!cb_comAtlAxInit()) {
    pUnk = NULL;
    cb_comAtlAxGetControl(hWnd, &pUnk);
    if (pUnk) {
      hr = cb_comQuery(pObj, pUnk, id);
      if (ptr1) *(IUnknown**)ptr1 = pUnk;
#ifdef __cplusplus
      else pUnk->Release();
#else
      else IUnknown_Release(pUnk);
#endif

    }
  }
  cb_comError = hr;
  return hr;
}
/* END MODULE */


/* MODULE::cb_comVarToLng */
long cb_DEFCALL cb_comVarToLng (cb_comObject *v)
{
  if (v) return (long)(v->lVal);
  return 0;
}
/* END MODULE */


/* MODULE::cb_comVarToLLng */
long long cb_DEFCALL cb_comVarToLLng (cb_comObject *v)
{
  if (v) return (long long)(v->llVal);
  return 0;
}
/* END MODULE */


/* MODULE::cb_comVarToSng */
float cb_DEFCALL cb_comVarToSng (cb_comObject *v)
{
  if (v) return (float)(v->fltVal);
  return 0.0;
}
/* END MODULE */


/* MODULE::cb_comVarToDbl */
double cb_DEFCALL cb_comVarToDbl (cb_comObject *v)
{
  if (v) return (double)(v->dblVal);
  return 0.0;
}
/* END MODULE */


/* MODULE::cb_comVarToStr */
char* cb_DEFCALL cb_comVarToStr (cb_comObject *v, void *dst)
{
  register const wchar_t *strtmp; if (v) if (v->vt==VT_BSTR) { strtmp = v->bstrVal; goto Exit0000; }
  strtmp = (const wchar_t*)cb_EMPTYSTR;
Exit0000:
  return cb_UnicodeToAnsi(strtmp,dst);
}
/* END MODULE */


/* MODULE::cb_comVarToStrEx */
char* cb_DEFCALL cb_comVarToStrEx (cb_comObject *v, void *dst)
{
  register cb_Integer i;
  register const wchar_t *strtmp;
  if (v) {
    i = v->vt; if (i==VT_BSTR) { strtmp = v->bstrVal; goto Exit0000; }
    if (i==VT_I4 || i==VT_UI4) return cb_CStr(v->lVal,10,dst);
    if (i==VT_I8 || i==VT_UI8) return cb_CStrL(v->llVal,10,dst);
  }
  strtmp = (const wchar_t*)cb_EMPTYSTR;
Exit0000:
  return cb_UnicodeToAnsi(strtmp,dst);
}
/* END MODULE */


/* MODULE::cb_comStrToVarCopy */
void* cb_DEFCALL cb_comStrToVarCopy (cb_comObject *v, const char *src)
{
  register wchar_t *s = cb_AnsiToUnicode(src,(void*)-1);
  v->bstrVal = SysAllocString(s);
  cb_MemFreeM(s);
  v->vt = VT_BSTR;
  return v->bstrVal;
}
/* END MODULE */


/* MODULE::cb_comForEach */
cb_Integer cb_DEFCALL cb_comInitForEach (IEnumVARIANT **pDisp, cb_comObject *pGroup)
{
  register cb_Integer hr;
  VARIANT TempVar_;

  VariantInit(&TempVar_);
  hr = cb_comAutoWrap(pGroup[0].pdispVal, -1, NULL, NULL, 0, &TempVar_);
  if (!FAILED(hr)) {
  if (TempVar_.vt==VT_DISPATCH) {
#ifdef __cplusplus
    hr = TempVar_.pdispVal->QueryInterface(IID_IEnumVARIANT, (void**)pDisp);
#else
    hr = TempVar_.pdispVal->lpVtbl->QueryInterface(TempVar_.pdispVal, &IID_IEnumVARIANT, (void**)pDisp);
#endif
  }
  else if (TempVar_.vt==VT_UNKNOWN) {
#ifdef __cplusplus
    hr = TempVar_.punkVal->QueryInterface(IID_IEnumVARIANT, (void**)pDisp);
#else
    hr = TempVar_.punkVal->lpVtbl->QueryInterface(TempVar_.punkVal, &IID_IEnumVARIANT, (void**)pDisp);
#endif
  }
  else hr = -1;
  VariantClear(&TempVar_);
  }
  cb_comError = hr;
  return hr;
}

cb_Integer cb_DEFCALL cb_comForEach (IEnumVARIANT* pDisp, cb_comObject *obj)
{
  register cb_Integer hr;
  ULONG num1;
  if (!pDisp) { hr = -1; goto Exit1111; }
#ifdef __cplusplus
  hr = pDisp->Next(1, obj, &num1);
#else
  hr = pDisp->lpVtbl->Next(pDisp, 1, obj, &num1);
#endif
  if (FAILED(hr)) goto Exit0000;
  if (obj[0].vt!=VT_DISPATCH || num1==0) {
    hr = -1;
Exit0000:
#ifdef __cplusplus
    pDisp->Release();
#else
    pDisp->lpVtbl->Release(pDisp);
#endif
Exit1111:
    cb_comClear(obj);
  }
  cb_comError = hr;
  return hr;
}
/* END MODULE */


/* MODULE::cb_comCreateSafeArray */
__declspec(noinline) SAFEARRAY* cb_CDECL cb_comCreateSafeArray (cb_Integer vt1, cb_Integer iWidth, ...)
{
  register cb_Integer *p1 = &iWidth, i, j;
  SAFEARRAYBOUND sab[16];


  for (i=0;i<iWidth;i++) {
    p1++;
    j = p1[0];
    sab[i].lLbound = j;
    p1++;
    j = p1[0];
    sab[i].cElements = j;
  }
  j = vt1;
  p1 = (cb_Integer*)SafeArrayCreate(j>0?j:VT_VARIANT, i, sab);

  cb_comError = p1 ? 0 : -1;
  return (SAFEARRAY*)p1;
}
/* END MODULE */


/* MODULE::cb_comReDimSafeArray */
__declspec(noinline) HRESULT cb_CDECL cb_comReDimSafeArray (SAFEARRAY *arr, cb_Integer iWidth, ...)
{
  register cb_Integer *p1 = &iWidth, i, j;
  SAFEARRAYBOUND sab[16] = {0};

  if (iWidth<=0) iWidth = SafeArrayGetDim(arr);
  for (i=0;i<iWidth;i++) {
    p1++;
    j = p1[0];
    sab[i].lLbound = j;
    p1++;
    j = p1[0] - j;
    j++;
    sab[i].cElements = j;
  }
  return (cb_comError = SafeArrayRedim(arr, sab));
}
/* END MODULE */


/* MODULE::cb_comGetElement */
__declspec(noinline) HRESULT cb_CDECL cb_comGetElement (SAFEARRAY *arr, VARIANT *tmp, cb_Integer iWidth, ...)
{
  register cb_Integer *p1 = &iWidth, i=iWidth, j;
  LONG indices[16];

  while (i>0) {
    i--;
    p1++;
    j = p1[0];
    indices[i] = j;
  }
  VariantInit(tmp);
  return (cb_comError = SafeArrayGetElement(arr, indices, tmp));
}
/* END MODULE */


/* MODULE::cb_comPutElement */
__declspec(noinline) HRESULT cb_CDECL cb_comPutElement (SAFEARRAY *arr, cb_Integer vt1, cb_Integer iWidth, ...)
{
  register cb_Integer *p1 = &iWidth, i=iWidth, j;
  VARIANT tmp;
  LONG indices[16];

  while (i>0) {
    i--;
    p1++;
    j = p1[0];
    indices[i] = j;
  }
  VariantInit(&tmp);
  p1++;
  if (vt1<=0) SafeArrayGetVartype(arr, (VARTYPE*)&vt1);
  i = vt1;

  if (i==VT_VARIANT) {
    VariantCopy(&tmp, (VARIANT*)p1);
  }
  else {
    if (i==VT_I8) tmp.llVal = *(long long*)p1;
    else if (i==VT_UI8) tmp.ullVal = *(unsigned long long*)p1;
    else if (i==VT_R8) tmp.dblVal = *(double*)p1;
    else if (i==VT_LPSTR) {
      i = (cb_Integer)cb_AnsiToUnicode(*(const char**)p1,(void*)-1);
      tmp.bstrVal = SysAllocString((wchar_t*)i);
      cb_MemFreeM((void*)i);
      i = VT_BSTR;
      j = -1;
    }
    else if (i==VT_BOOL) tmp.boolVal = *(VARIANT_BOOL*)p1;
    else tmp.lVal = p1[0];
    tmp.vt = i;
  }

  i = SafeArrayPutElement(arr, indices, &tmp);
  if (j<0) SysFreeString(tmp.bstrVal);
  cb_comError = i;
  return i;
}
/* END MODULE */


/* MODULE::cb_comSafeArray_ */
__declspec(noinline) HRESULT cb_CDECL cb_comSafeArray_ (SAFEARRAY **ptr1, cb_Integer vt1, cb_Integer iNum, ...)
{
  register cb_Integer *p1 = &iNum;
  register SAFEARRAY *arr = ptr1[0];
  register cb_Integer i, j = iNum;

  if (!arr) {
    arr = cb_comCreateSafeArray(vt1,1,0,j);
    if (!arr) {
Error0000:
      cb_comError = -1; return -1;
    }
  }
  p1++;
  for (;j>0;j--) {
    i = p1[0];
    p1++;
    if (i==VT_VARIANT) { if (cb_comPutElement(arr,i,1,*(VARIANT*)p1)<0) { Error0001: if (!ptr1[0]) SafeArrayDestroy(arr); ptr1[0] = NULL; goto Error0000; } p1=(cb_Integer*)((cb_Integer)p1+sizeof(VARIANT)); }
    else if (i==VT_I8 || i==VT_UI8) { if (cb_comPutElement(arr,i,1,*(long long*)p1)<0) goto Error0001; p1=(cb_Integer*)((cb_Integer)p1+sizeof(long long)); }
    else if (i==VT_R8) { if (cb_comPutElement(arr,i,1,*(double*)p1)<0) goto Error0001; p1=(cb_Integer*)((cb_Integer)p1+sizeof(double)); }
    else { if (cb_comPutElement(arr,i,1,p1[0])<0) goto Error0001; p1++; }
  }
  ptr1[0] = arr;
  cb_comError = 0;
  return 0;
}
/* END MODULE */


/* MODULE::cb_DoEvents */
cb_Integer cb_DEFCALL cb_DoEvents (HWND hWnd, cb_Integer FilterMin, cb_Integer FilterMax)
{
  MSG Msg;

  while(PeekMessage(&Msg,hWnd,FilterMin,FilterMax,PM_REMOVE)) {
    if (Msg.message==WM_QUIT) return -1;
    TranslateMessage(&Msg);
    DispatchMessage(&Msg);
  }
  return FALSE;
}
/* END MODULE */


/* MODULE::cb_WaitEvents */
cb_Integer cb_DEFCALL cb_WaitEvents (cb_UInteger Milliseconds, cb_Integer *flag1, HWND hWnd, cb_Integer FilterMin, cb_Integer FilterMax)
{
  cb_UInteger i1 = cb_Clock(); i1 += Milliseconds;

  while(!cb_DoEvents(hWnd,FilterMin,FilterMax)) {
    if (flag1) if (flag1[0]) return TRUE;
    if (cb_Clock() >= i1) return FALSE;
    Sleep(cb_WAITEVENTS_INTERVAL_);
  }
  return -1;
}
/* END MODULE */


/* MODULE::cb_AppActivate */
HWND cb_DEFCALL cb_AppActivate (const char *Z, cb_Integer flg1)
{
  register HWND hWnd1;
  register DWORD Thread1, Thread2;
  HWND hWnd2;
  char  Buffer[512];

  hWnd1 = GetForegroundWindow();
  while(hWnd1) {
    Buffer[0] = 0;
    GetWindowText(hWnd1,Buffer,sizeof(Buffer)-1);
    if (cb_StrIStr(Buffer,Z)) {
      if (IsIconic(hWnd1)) ShowWindow(hWnd1, SW_RESTORE);
      SetForegroundWindow(hWnd1);
      if (flg1) {
        hWnd2 = GetForegroundWindow();
        if (hWnd1!=hWnd2) {
          Thread1 = GetWindowThreadProcessId(hWnd1,NULL);
          Thread2 = GetWindowThreadProcessId(hWnd2,NULL);
          if (Thread1!=Thread2) {
            AttachThreadInput(Thread2, Thread1, 1);
            SetForegroundWindow(hWnd1);
            AttachThreadInput(Thread2, Thread1, 0);
          }
        }
      }
      break;
    }
    hWnd1 = GetNextWindow(hWnd1,GW_HWNDNEXT);
  }
  return hWnd1;
}
/* END MODULE */


/* MODULE::cb_FindFirstWin */
HWND cb_DEFCALL cb_FindFirstWin (const char *Str1, cb_Integer flag1)
{
  register HWND hWnd;
  if ((flag1&2)==0) hWnd=FindWindow(Str1,NULL); else hWnd=FindWindow(NULL,Str1);
  if (hWnd) {
    if ((flag1&(4|8))!=0) hWnd = cb_GetTopParent(hWnd,flag1&8);
    if ((flag1&1)!=0)
    SetForegroundWindow(hWnd);
  }
  return hWnd;
}
/* END MODULE */


/* MODULE::cb_SetWndRTF */
static DWORD CALLBACK cb_StreamRTFIn (cb_typeStreamRTF *hFile,BYTE *pBuffer,LONG NumBytes,LONG *pBytesRead)
{
  pBytesRead[0]=0;
  if (hFile->b2<NumBytes) NumBytes=hFile->b2;
  if (NumBytes==0) return TRUE;
  cb_MemCopy(pBuffer,hFile->b1,NumBytes);
  hFile->b1+=NumBytes;
  hFile->b2-=NumBytes;
  pBytesRead[0]=NumBytes;
  return FALSE;
}
cb_Integer cb_DEFCALL cb_SetWndRTF (cb_Integer flags1,HWND hWin,const char *pBuffer,cb_Integer iLen)
{
  cb_typeStreamRTF  hFile;  cb_MemSet(&hFile, 0, sizeof(hFile));
  EDITSTREAM  editstream;  cb_MemSet(&editstream, 0, sizeof(editstream));
  if (flags1==-1) flags1 = SF_RTF | SFF_SELECTION;
  if (!(flags1&SFF_SELECTION)) SendMessage(hWin,WM_SETTEXT,0,(LPARAM)cb_EMPTYSTR);
  hFile.b1=(char*)pBuffer;
  hFile.b2=iLen; if (hFile.b2<=0) hFile.b2=cb_StrLen(pBuffer);
  editstream.dwCookie=(DWORD)&hFile;
  editstream.pfnCallback=(EDITSTREAMCALLBACK)&cb_StreamRTFIn;
  return SendMessage(hWin,EM_STREAMIN,(WPARAM)flags1,(LPARAM)&editstream);
}
/* END MODULE */


/* MODULE::cb_GetWndRTF */
static DWORD CALLBACK cb_StreamRTFOut (cb_typeStreamRTF *hFile,BYTE *pBuffer,LONG NumBytes,LONG *pBytesWritten)
{
  if (NumBytes==0) return TRUE;
  pBytesWritten[0]=0;
  register char *b1 = (char*)cb_ReMemAllocM(hFile->b1,hFile->b2+NumBytes);
  if (!b1) { hFile->b2 |= cb_MIN_INTEGER; return TRUE; }
  hFile->b1 = b1;
  cb_MemCopy(b1+hFile->b2,pBuffer,NumBytes);
  hFile->b2+=NumBytes;
  pBytesWritten[0]=NumBytes;
  return FALSE;
}
char* cb_DEFCALL cb_GetWndRTF (cb_Integer flags1, HWND hWin, void *dst, void *iRead)
{
  register char *p1;
  register cb_Integer i;
  cb_typeStreamRTF  hFile;  cb_MemSet(&hFile, 0, sizeof(hFile));
  EDITSTREAM  editstream;  cb_MemSet(&editstream, 0, sizeof(editstream));
  if (flags1==-1) flags1 = SF_RTF | SFF_SELECTION;
  editstream.dwCookie=(DWORD)&hFile;
  editstream.pfnCallback=(EDITSTREAMCALLBACK)&cb_StreamRTFOut;
  SendMessage(hWin,EM_STREAMOUT,(WPARAM)flags1,(LPARAM)&editstream);
  i = hFile.b2;
  if (iRead) *(cb_Integer*)iRead = i;
  i &= cb_MAX_INTEGER;
  p1 = hFile.b1;
  if (!dst || dst==(void*)-1) {
    i = (cb_Integer)cb_NewStr_(p1,dst,i); if (p1) cb_MemFreeM(p1);
    return (char*)i;
  }
    if (p1) {
      cb_MemCopy(dst,p1,i); cb_MemFreeM(p1); p1 = (char*)dst;
    }
    else {
      p1 = (char*)dst;
    }
    p1[i] = 0;
  return p1;
}
/* END MODULE */


/* MODULE::cb_RTFBoxLoadFile */
cb_Integer cb_DEFCALL cb_RTFBoxLoadFile (HWND hWnd, const char *sFile, cb_Integer flags1, cb_UInteger len1, cb_UInteger ofs1)
{
  cb_UInteger iFileLen = -1;
  register char *Buff = cb_LoadFile(sFile, (void*)-1, &iFileLen, len1, ofs1);
  if (!Buff) {
    if (iFileLen==(cb_UInteger)-1) return -1;
    return -2;
  }
  iFileLen = cb_SetWndRTF(flags1,hWnd,Buff,(cb_Integer)iFileLen);
  if ((flags1&SFF_SELECTION)==0) SendMessage(hWnd,EM_SETMODIFY,FALSE,0);
  cb_MemFreeM(Buff);
  return (cb_Integer)iFileLen;
}
/* END MODULE */


/* MODULE::cb_RTFBoxSaveFile */
cb_Integer cb_DEFCALL cb_RTFBoxSaveFile (HWND hWnd, const char *sFile,cb_Integer flags1)
{
  cb_Integer iRead; iRead = -1;
  register char *Buff = cb_GetWndRTF(flags1,hWnd,(void*)-1,&iRead);
  if (Buff) { if (iRead>0) iRead = (cb_Integer)cb_SaveFile(sFile, Buff, iRead); cb_MemFreeM(Buff); }
  return iRead;
}
/* END MODULE */


/* MODULE::cb_AddWndText */
cb_Integer cb_DEFCALL cb_AddWndText (HWND hWnd, const char *sText, cb_Integer flag1)
{
  register cb_Integer iLen;
  cb_Integer nChars1, nChars2;
  if ((flag1&2)!=0) SendMessage(hWnd, EM_GETSEL, (WPARAM)&nChars1, (LPARAM)&nChars2);
  iLen = GetWindowTextLength(hWnd);
  SendMessage(hWnd, EM_SETSEL, (WPARAM)iLen, (LPARAM)iLen);
  iLen = SendMessage(hWnd, EM_REPLACESEL, flag1&TRUE, (LPARAM)sText);
  if ((flag1&2)!=0) SendMessage(hWnd, EM_SETSEL, (WPARAM)nChars1, (LPARAM)nChars2);
  return iLen;
}
/* END MODULE */


/* MODULE::cb_InsertWndText */
cb_Integer cb_DEFCALL cb_InsertWndText (HWND hWnd, const char *sText, cb_Integer flag1)
{
  register cb_Integer RetVar;
  cb_Integer nChars1, nChars2;
  if ((flag1&2)==0) {
    SendMessage(hWnd, EM_GETSEL, (WPARAM)&nChars1, (LPARAM)&nChars2);
    SendMessage(hWnd, EM_SETSEL, (WPARAM)nChars1, (LPARAM)nChars1);
    if (nChars2>nChars1) { RetVar = cb_StrLen(sText); nChars1 += RetVar; nChars2 += RetVar; }
  }
  RetVar = SendMessage(hWnd, EM_REPLACESEL, flag1&TRUE, (LPARAM)sText);
  if ((flag1&2)==0) SendMessage(hWnd, EM_SETSEL, (WPARAM)nChars1, (LPARAM)nChars2);
  return RetVar;
}
/* END MODULE */


/* MODULE::cb_GetWndText */
char * cb_DEFCALL cb_GetWndText (cb_Integer flag1, HWND hWnd, void *dst, void *iRead)
{
  register char *sTmp;
  register cb_Integer tmpint, i;
  cb_Integer i1, i2;

  tmpint = SendMessage(hWnd,WM_GETTEXTLENGTH,0,0);
  if (flag1) {
    SendMessage(hWnd,EM_GETSEL,(WPARAM)&i1,(LPARAM)&i2);
    i = i2;
    i -= i1;
    if (i<=0) {
      tmpint = 0;
      sTmp = (char*)dst;
      if (!sTmp) sTmp = cb_EMPTYSTR;
      else if (sTmp==(char*)-1) sTmp = cb_NewStr_(NULL,(void*)-1,0);
      else sTmp[0] = 0;
      goto Exit0000;
    }
    sTmp = (char*)cb_MemAllocM(tmpint+2);
  }
  else {
    sTmp = (char*)dst;
    if (!sTmp||sTmp==(char*)-1) {
      sTmp = cb_NewStr_(NULL,sTmp,tmpint);
      if (!sTmp) { tmpint = -1; goto Exit0000; }
    }
  }
  sTmp[0] = 0;
  SendMessage(hWnd,WM_GETTEXT,tmpint + 1,(LPARAM)sTmp);
  if (flag1) {
    tmpint = i;
    cb_MemCopy(sTmp,sTmp+i1,tmpint);
    i = (cb_Integer)sTmp;
    sTmp = (char*)dst;
    if (!sTmp||sTmp==(char*)-1) {
      sTmp = cb_NewStr_((const void*)i,sTmp,tmpint);
      if (!sTmp) { tmpint = -1; goto Exit0001; }
    }
    else {
      cb_MemCopy(sTmp,(const void*)i,tmpint);
      sTmp[tmpint] = 0;
    }
Exit0001:
    cb_MemFreeM((void*)i);
  }
Exit0000:
  if (iRead) *(cb_Integer*)iRead = tmpint;
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_EditBoxLoadFile */
cb_Integer cb_DEFCALL cb_EditBoxLoadFile (HWND hWnd, const char *sFile, cb_Integer flag1, cb_UInteger len1, cb_UInteger ofs1)
{
  cb_UInteger iFileLen = -1;
  register char *Buff = cb_LoadFile(sFile, (void*)-1, &iFileLen, len1, ofs1);
  if (!Buff) {
    if (iFileLen==(cb_UInteger)-1) return -1;
    return -2;
  }
  if (flag1) SendMessage(hWnd,EM_REPLACESEL,TRUE,(LPARAM)Buff);
  else if (SendMessage(hWnd,WM_SETTEXT,0,(LPARAM)Buff)!=TRUE) iFileLen = (cb_UInteger)-1;
  cb_MemFreeM(Buff);
  return (cb_Integer)iFileLen;
}
/* END MODULE */


/* MODULE::cb_EditBoxSaveFile */
cb_Integer cb_DEFCALL cb_EditBoxSaveFile (HWND hWnd, const char *sFile,cb_Integer flag1)
{
  cb_Integer iRead; iRead = -1;
  register char *Buff = cb_GetWndText(flag1,hWnd,(void*)-1,&iRead);
  if (Buff) { if (iRead>0) iRead = (cb_Integer)cb_SaveFile(sFile, Buff, iRead + 1); cb_MemFreeM(Buff); }
  return iRead;
}
/* END MODULE */


/* MODULE::cb_LoadRes */
LPVOID cb_DEFCALL cb_LoadRes (const char *ResName, const char *ResType, void *ResSize)
{
  register HRSRC hRes;
  register HMODULE hMod = cbApp_hInstance; if (!hMod) hMod = GetModuleHandle(NULL);
  if (!ResType) ResType = RT_RCDATA;
  else if (ResType==(const char*)-1) ResType = RT_BITMAP;
  hRes = FindResource(hMod,ResName,ResType);
  if (hRes==NULL) return NULL;
  if (ResSize) *((DWORD*)ResSize) = SizeofResource(hMod,hRes);
  return LockResource(LoadResource(hMod,hRes));
}
/* END MODULE */


/* MODULE::cb_IconToBitmap */
HBITMAP cb_DEFCALL cb_IconToBitmap (HICON hIcon, cb_Integer flag1, HDC *pDC)
{
  register HBITMAP h1 = (HBITMAP)hIcon;
  ICONINFO b;

  if (!GetIconInfo((HICON)h1,&b)) {
IconCursor0000:
    h1 = cb_IconCursorToBitmap(h1,NULL,NULL,flag1?TRUE:TRUE|cb_MIN_INTEGER,pDC);
  }
  else {
    DeleteObject(b.hbmMask);
    if (!b.hbmColor) goto IconCursor0000;
    if (flag1) if (!DestroyIcon((HICON)h1)) DestroyCursor((HCURSOR)h1);
    h1 = b.hbmColor;
  }
  return h1;
}
/* END MODULE */


/* MODULE::cb_SetWndImage */
HBITMAP cb_DEFCALL cb_SetWndImage (HWND hWnd,void *h1,cb_Integer bDel,cb_Integer tipe,cb_Integer msg1)
{
  if ((cb_UInteger)((cb_Integer)hWnd-1)>=(cb_UInteger)-2) hWnd = GetDesktopWindow();
  register cb_Integer bm; bm = SendMessage(hWnd,msg1,(WPARAM)tipe,(LPARAM)h1);
  if (bm) {
    if (bDel>0) goto Del0000;
    if (bDel<0) if (tipe!=IMAGE_ICON) if (tipe!=IMAGE_CURSOR) {
Del0000:
      if (!DeleteObject((HBITMAP)bm)) if (!DestroyIcon((HICON)bm)) DestroyCursor((HCURSOR)bm);
      bm = 0;
    }
  }
  return (HBITMAP)bm;
}
/* END MODULE */


/* MODULE::cb_DIBBitsNum */
cb_Integer cb_DEFCALL cb_DIBBitsNum (const void *Ptr1)
{
  register cb_UInteger i = cb_DIBPlanes(Ptr1) * cb_DIBBitCount(Ptr1);
  if (i<=1) i = 1; else if (i<=4) i = 4; else if (i<=8) i = 8; else if (i<=16) i = 16; else if (i<=24) i = 24; else i = 32;
  return i;
}
/* END MODULE */


/* MODULE::cb_DIBColorsNum */
cb_Integer cb_DEFCALL cb_DIBColorsNum (const void *Ptr1)
{
  register cb_UInteger i = cb_DIBClrUsed(Ptr1); if (!i) { i = cb_DIBBitCount(Ptr1); if (i<=16) i = 1 << i; else i = 0; }
  return i;
}
/* END MODULE */


/* MODULE::cb_DIBBitsOffset */
cb_Integer cb_DEFCALL cb_DIBBitsOffset (const void *Ptr1)
{
  return sizeof(BITMAPINFOHEADER) + (sizeof(RGBQUAD) * cb_DIBColorsNum(Ptr1));
}
/* END MODULE */


/* MODULE::cb_DIBRowLength */
cb_Integer cb_DEFCALL cb_DIBRowLength (const void *Ptr1)
{
  register cb_UInteger i = cb_DIBWidth(Ptr1); i *= cb_DIBBitCount(Ptr1); i += 0x1F; i &= ~0x1F; i >>= 3;
  return i;
}
/* END MODULE */


/* MODULE::cb_CreateBMPFromBits */
HBITMAP cb_DEFCALL cb_CreateBMPFromBits (const void *picFile)
{
  BYTE *rawBits;
  cb_Integer i;
  BYTE *xDIB = (BYTE*)picFile;
  void *buf;
  HBITMAP dibSection = CreateDIBSection(NULL, (BITMAPINFO*)xDIB, DIB_RGB_COLORS, &buf, NULL, 0);
  rawBits = (BYTE*)buf;
  i = cb_DIBBitsSize(xDIB);
  xDIB = cb_DIBBits(xDIB);
  for (; i > 0; i--) *rawBits++ = *xDIB++;
  return dibSection;
}
/* END MODULE */


/* MODULE::cb_CreateNewBMP */
HBITMAP cb_DEFCALL cb_CreateNewBMP (cb_UInteger width, cb_UInteger height, cb_Integer bitCount, void *dst)
{
  BITMAPINFO pbmi;
  pbmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  pbmi.bmiHeader.biWidth = width;
  pbmi.bmiHeader.biHeight = height;
  pbmi.bmiHeader.biPlanes = 1;
  pbmi.bmiHeader.biBitCount = bitCount;
  pbmi.bmiHeader.biCompression = BI_RGB;
  pbmi.bmiHeader.biSizeImage = 0;
  pbmi.bmiHeader.biXPelsPerMeter = 0;
  pbmi.bmiHeader.biYPelsPerMeter = 0;
  pbmi.bmiHeader.biClrUsed = 0;
  pbmi.bmiHeader.biClrImportant = 0;
  void *rawBits;
  HBITMAP hBmp = CreateDIBSection(NULL, &pbmi, DIB_RGB_COLORS, &rawBits, NULL, 0);
  if (dst) *(void**)dst = rawBits;
  return hBmp;
}
/* END MODULE */


/* MODULE::cb_CreateBMPFromDIB */
HBITMAP cb_DEFCALL cb_CreateBMPFromDIB (const void *Ptr1, HDC hDC, HWND hWnd)
{
  register BITMAPINFOHEADER *t1 = (BITMAPINFOHEADER*)Ptr1;
  register HDC h1 = hDC; if (!h1) h1 = GetDC(hWnd);
  register cb_Integer i; i = t1->biHeight; if (i<0) i = 0-i;
  HBITMAP b1 = CreateCompatibleBitmap(h1,t1->biWidth,i);
  if (!hDC) ReleaseDC(hWnd,h1);
  #define BitsSize_(x) (x->biClrUsed*sizeof(RGBQUAD))
  SetDIBits(NULL,b1,0,i,(char*)t1+sizeof(BITMAPINFOHEADER)+BitsSize_(t1),(BITMAPINFO*)t1,DIB_RGB_COLORS);
  return b1;
  #undef BitsSize_
}
/* END MODULE */


/* MODULE::cb_StretchBitmap */
HBITMAP cb_DEFCALL cb_StretchBitmap (HBITMAP hBmp, cb_Integer W, cb_Integer H, HWND hWnd, HDC *pDC, cb_Integer flag1)
{
  register HDC h1, h2;
  register HBITMAP b1, b2;
  register HDC hDC;
  HBITMAP hBmpOld1, hBmpOld2;
  RECT rc1;
  BITMAP Bmp1;

  if (!GetObject(hBmp, sizeof(Bmp1), &Bmp1)) return NULL;
  if (hWnd) {
    if (W<=0) { GetClientRect(hWnd,&rc1); W = rc1.right; if (H<=0) H = rc1.bottom; }
    else if (H<=0) { GetClientRect(hWnd,&rc1); H = rc1.bottom; }
  }
  else {
    if (W<=0) W = Bmp1.bmWidth;
    if (H<=0) H = Bmp1.bmHeight;
  }
  hDC = GetDC(hWnd);
  b1 = CreateCompatibleBitmap(hDC,W,H);
  h1 = CreateCompatibleDC(hDC);
  h2 = CreateCompatibleDC(hDC);
  ReleaseDC(hWnd,hDC);
  hBmpOld1 = (HBITMAP)SelectObject(h1,b1);
  hBmpOld2 = (HBITMAP)SelectObject(h2,hBmp);
  if (W==Bmp1.bmWidth && H==Bmp1.bmHeight) {
    if ((flag1&(cb_MIN_INTEGER|1))==1) { b2 = hBmp; hBmp = b1; b1 = b2; } else BitBlt(h1,0,0,W,H,h2,0,0,SRCCOPY);
  }
  else {
    if ((flag1&2)==0) SetStretchBltMode(h1,HALFTONE);
    StretchBlt(h1,0,0,W,H,h2,0,0,Bmp1.bmWidth,Bmp1.bmHeight,SRCCOPY);
  }
  SelectObject(h2,hBmpOld2); DeleteDC(h2);
  if ((flag1&(cb_MIN_INTEGER|1))==1) DeleteObject(hBmp);
  if (pDC) { *pDC = h1; return hBmpOld1; }
  SelectObject(h1,hBmpOld1); DeleteDC(h1);
  return b1;
}
/* END MODULE */


/* MODULE::cb_LoadImageResource */
HBITMAP cb_DEFCALL cb_LoadImageResource (const void *Ptr1, cb_Integer Res, cb_Integer W, cb_Integer H, cb_Integer flags, cb_Integer tipe)
{
  register const char *F = (const char*)Ptr1;
  register cb_Integer i, tipe1 = tipe;
  register cb_Integer j;

  if (F) {
    if (!Res) {
      i = cb_StrLen(F)-4;
      if (i>0) {
        if (0==cb_MemIComp(F+i,".png",5)) return cb_LoadPNGResource(F);
        if (0==cb_MemIComp(F+i,".jpg",5) || 0==cb_MemIComp(F+i,".gif",5))
          return cb_GDIPLoadResource(F);
      }
      if (tipe1==-1) {
        if (i<=0) goto Image0000;
        if (0==cb_MemIComp(F+i,".ico",5)) tipe1 = IMAGE_ICON;
        else if (0==cb_MemIComp(F+i,".cur",5)) tipe1 = IMAGE_CURSOR;
        else {
Image0000:
          tipe1 = IMAGE_BITMAP;
        }
      }
      Res = (cb_Integer)F;
      F = NULL;
      i = LR_LOADFROMFILE;
      goto Load0000;
    }
    if (Res==-1) {
      return cb_CreateBMPFromDIB(F);
    }
    if (F[0]==0) F = NULL;
    F = (const char*)GetModuleHandle(F);
  }
  i = 0;

Load0000:
  j = flags;
  if (j==-1) j = LR_CREATEDIBSECTION;
  i |= j;
  return (HBITMAP)LoadImage((HINSTANCE)F,(LPSTR)Res,tipe1,W,H,i);
}
/* END MODULE */


/* MODULE::cb_LoadCursor */
HCURSOR cb_DEFCALL cb_LoadCursor (const char *F, cb_Integer Res, cb_Integer W, cb_Integer H, cb_Integer flags)
{
  return (HCURSOR)cb_LoadImageResource(F, Res, W, H, flags, IMAGE_CURSOR);
}
/* END MODULE */


/* MODULE::cb_LoadIcon */
HICON cb_DEFCALL cb_LoadIcon (const char *F, cb_Integer Res, cb_Integer W, cb_Integer H, cb_Integer flags)
{
  return (HICON)cb_LoadImageResource(F, Res, W, H, flags, IMAGE_ICON);
}
/* END MODULE */


/* MODULE::cb_RotateBitmap */
// GetRotatedBitmapNT - Create a new bitmap with rotated image
// Returns - Returns new bitmap with rotated image
// hBitmap - Bitmap to rotate
// radians - Angle of rotation in radians - radian = (2*pi *degree)/360 or degree * 0.017453
// clrBack - Color of pixels in the resulting bitmap that do
// not get covered by source pixels
HBITMAP cb_DEFCALL cb_RotateBitmap (HBITMAP hBitmap, double radians, COLORREF clrBack, HDC *pDC)
{
  // Create a memory DC compatible with the display
  HDC sourceDC, destDC;
  sourceDC = CreateCompatibleDC(NULL);
  destDC = CreateCompatibleDC(NULL);

  // Get logical coordinates
  BITMAP bm;
  GetObject(hBitmap, sizeof(bm), &bm);

  double cosine = cos(radians);
  double sine = sin(radians);

  // Compute dimensions of the resulting bitmap
  // First get the coordinates of the 3 corners other than origin
  cb_Integer x1 = (cb_Integer)(bm.bmHeight * sine);
  cb_Integer y1 = (cb_Integer)(bm.bmHeight * cosine);
  cb_Integer x2 = (cb_Integer)(bm.bmWidth * cosine + bm.bmHeight * sine);
  cb_Integer y2 = (cb_Integer)(bm.bmHeight * cosine - bm.bmWidth * sine);
  cb_Integer x3 = (cb_Integer)(bm.bmWidth * cosine);
  cb_Integer y3 = (cb_Integer)(-bm.bmWidth * sine);

  cb_Integer minx = cb_Min(0,cb_Min(x1, cb_Min(x2,x3)));
  cb_Integer miny = cb_Min(0,cb_Min(y1, cb_Min(y2,y3)));
  cb_Integer maxx = cb_Max(0,cb_Max(x1, cb_Max(x2,x3)));
  cb_Integer maxy = cb_Max(0,cb_Max(y1, cb_Max(y2,y3)));

  cb_Integer w = maxx - minx;
  cb_Integer h = maxy - miny;

  // Create a bitmap to hold the result
  HBITMAP hBmp = CreateCompatibleBitmap(NULL, w, h);

  hBitmap = (HBITMAP)SelectObject(sourceDC, hBitmap);
  hBmp = (HBITMAP)SelectObject(destDC, hBmp);

  // Draw the background color before we change mapping mode
  HBRUSH hbrBack = CreateSolidBrush(clrBack);
  hbrBack = (HBRUSH)SelectObject(destDC, hbrBack);
  PatBlt(destDC, 0, 0, w, h, PATCOPY);
  DeleteObject(SelectObject(destDC, hbrBack));

  // We will use world transform to rotate the bitmap
  SetGraphicsMode(destDC, GM_ADVANCED);
  XFORM xform;
  xform.eM11 = cosine;
  xform.eM12 = -sine;
  xform.eM21 = sine;
  xform.eM22 = cosine;
  xform.eDx = (float)-minx;
  xform.eDy = (float)-miny;

  SetWorldTransform(destDC, &xform);

  // Now do the actual rotating - a pixel at a time
  BitBlt(destDC, 0, 0, bm.bmWidth, bm.bmHeight, sourceDC, 0, 0, SRCCOPY);

  // Restore DCs
  SelectObject(sourceDC, hBitmap); DeleteDC(sourceDC);
  if (pDC) *pDC = destDC;
  else { hBmp = (HBITMAP)SelectObject(destDC, hBmp); DeleteDC(destDC); }

  return hBmp;
}
/* END MODULE */


/* MODULE::cb_GetImage */
HBITMAP cb_DEFCALL cb_GetImage (const char *sFile,cb_Integer Res,void *W,void *H,cb_Integer tipe)
{
  if (!sFile) if (!Res) return NULL;
  BITMAP Bmp1;
  register HBITMAP hBmp = cb_LoadImageResource(sFile,Res,0,0,LR_CREATEDIBSECTION,tipe);

  if (hBmp) {
    if (*(cb_Integer*)W<0 || *(cb_Integer*)H<0) {
      if (GetObject(hBmp,sizeof(Bmp1),&Bmp1)) {
        if (*(cb_Integer*)W<0) *(cb_Integer*)W = Bmp1.bmWidth; if (*(cb_Integer*)H<0) *(cb_Integer*)H = Bmp1.bmHeight;
      }
    }
  }
  return hBmp;
}
/* END MODULE */


/* MODULE::cb_SetImage */
HBITMAP cb_DEFCALL cb_SetImage (HWND hWnd, const char *sFile, cb_Integer Res, cb_Integer W, cb_Integer H, cb_Integer t, cb_Integer tipe, cb_Integer flag1, cb_Integer msg1)
{
  RECT rc;
  register HBITMAP hBmp;

  if ((cb_UInteger)((cb_Integer)hWnd-1)>=(cb_UInteger)-2) hWnd = GetDesktopWindow();
  if (!Res) if (!sFile || sFile[0]==0) { hBmp = NULL; goto Set0000; }
  if (W<0) { GetClientRect(hWnd,&rc); W = rc.right; if (H<0) H = rc.bottom; }
  else if (H<0) { GetClientRect(hWnd,&rc); H = rc.bottom; }
  hBmp = (HBITMAP)(t&TRUE);
  if (hBmp) hBmp = (HBITMAP)(LR_LOADTRANSPARENT);
  if ((t&2)!=0) hBmp = (HBITMAP)(LR_CREATEDIBSECTION | (cb_Integer)hBmp);
  hBmp = cb_LoadImageResource(sFile,Res,W,H,(cb_Integer)hBmp,tipe);
  if (hBmp) {
Set0000:
    if (!flag1) cb_SetWndImage(hWnd,hBmp,-1,tipe,msg1);
  }
  return hBmp;
}
/* END MODULE */


/* MODULE::cb_SetImageButton */
HBITMAP cb_DEFCALL cb_SetImageButton (HWND hWnd,const char *sFile,cb_Integer Res,cb_Integer t)
{
  return cb_SetImage(hWnd,sFile,Res,0,0,t,IMAGE_BITMAP,FALSE,BM_SETIMAGE);
}
/* END MODULE */


/* MODULE::cb_SetIcon */
HBITMAP cb_DEFCALL cb_SetIcon (HWND hWnd, const char *sFile, cb_Integer Res, cb_Integer W, cb_Integer H, cb_Integer t)
{
  return cb_SetImage(hWnd,sFile,Res,W,H,t,IMAGE_ICON);
}
/* END MODULE */


/* MODULE::cb_SetIconButton */
HBITMAP cb_DEFCALL cb_SetIconButton (HWND hWnd,const char *sFile,cb_Integer Res,cb_Integer t)
{
  return cb_SetImage(hWnd,sFile,Res,0,0,t,IMAGE_ICON,FALSE,BM_SETIMAGE);
}
/* END MODULE */


/* MODULE::cb_PutBitmap */
HBITMAP cb_DEFCALL cb_PutBitmap (const void *Ptr1, HWND hWnd, cb_Integer X, cb_Integer Y, cb_Integer W, cb_Integer H, cb_Integer iTrans, HDC *ph1, HDC *ph2, cb_Integer flag1)
{
  register BITMAPINFOHEADER *t1 = (BITMAPINFOHEADER*)Ptr1;
  register HDC h2 = NULL;
  if (ph2) h2 = *ph2;
  register HDC h1 = NULL; if (ph1) h1 = *ph1;
  register HWND hWin; hWin = hWnd;
  if (!h1) {
    if (hWin==(HWND)-1) { hWin = GetDesktopWindow(); hWnd = hWin; }
    h1 = GetDC(hWin); if (ph1) *ph1 = h1;
  }
  if (!h2) { h2 = CreateCompatibleDC(h1); if (ph2) *ph2 = h2; }
  HBITMAP b1 = cb_CreateBMPFromDIB(t1,h1,NULL);
  HGDIOBJ hOld; hOld = SelectObject(h2,b1);
  HDC hDC;
  HBITMAP hBmp;
  BLENDFUNCTION bfn;
  RECT rcClient;
  cb_Integer x1, y1, h_;

  if (W<=0) {
    if ((cb_UInteger)((cb_Integer)hWin-1)>=(cb_UInteger)-2) hWin = GetDesktopWindow();
    GetClientRect(hWin, &rcClient); W = rcClient.right; H = rcClient.bottom;
  }
  else if (H<=0) {
    if ((cb_UInteger)((cb_Integer)hWin-1)>=(cb_UInteger)-2) hWin = GetDesktopWindow();
    GetClientRect(hWin,&rcClient); H = rcClient.bottom;
  }
  if (iTrans>0) {
    hBmp = CreateCompatibleBitmap(h1,W,H);
    hDC = CreateCompatibleDC(h1);
    hBmp = (HBITMAP)SelectObject(hDC,hBmp);
    x1 = 0; y1 = 0;
  }
  else {
    hDC = h1;
    x1 = X; y1 = Y;
  }
  if ((flag1&2)==0) SetStretchBltMode(hDC,HALFTONE);
  h_ = t1->biHeight; if (h_<0) h_ = 0-h_;
  StretchBlt(hDC,x1,y1,W,H,h2,0,0,t1->biWidth,h_,SRCCOPY);
  if (iTrans>0) {
    bfn.BlendOp = AC_SRC_OVER; bfn.BlendFlags = 0;
    bfn.SourceConstantAlpha = iTrans; bfn.AlphaFormat = AC_SRC_ALPHA;
    AlphaBlend(h1,X,Y,W,H,hDC,0,0,W,H,bfn); // Display bitmap
    hBmp = (HBITMAP)SelectObject(hDC,hBmp); DeleteDC(hDC); DeleteObject(hBmp);
  }
  if ((flag1&1)==0) { DeleteObject(b1); b1 = NULL; }
  SelectObject(h2,hOld);
  if (!ph2) DeleteDC(h2);
  if (!ph1||!ph1[0]) ReleaseDC(hWnd,h1);
  return b1;
}
/* END MODULE */


/* MODULE::cb_DrawBMP */
HBITMAP cb_DEFCALL cb_DrawBMP (HBITMAP hBmp, HDC hDC, HDC *pDC, cb_Integer lLeft, cb_Integer lTop, cb_Integer lWidth, cb_Integer lHeight, cb_Integer flag1, cb_Integer iTrans, cb_Integer Style)
{
  register HDC hDC1 = hDC, MemHDC;
  register HBITMAP hBmp1 = NULL, hBmpOld = hBmp;
  BLENDFUNCTION bfn;
  BITMAP Bmp1;

  if (pDC) {
    MemHDC = *pDC; if (MemHDC) { if (flag1) goto Stretch0000; if (iTrans>0) goto Trans0000; goto BitBlt0000; }
  }
  MemHDC = CreateCompatibleDC(hDC1); hBmpOld = (HBITMAP)SelectObject(MemHDC,hBmpOld);
  if (flag1) {
Stretch0000:
    if (GetObject(hBmp, sizeof(Bmp1), &Bmp1)) {
      if (iTrans>0 || pDC) {
        hBmp1 = CreateCompatibleBitmap(hDC1,lWidth,lHeight); hDC1 = CreateCompatibleDC(hDC1);
        hBmp1 = (HBITMAP)SelectObject(hDC1,hBmp1);
      }
      if ((flag1&2)==0) SetStretchBltMode(hDC1,HALFTONE);
      StretchBlt(hDC1,lLeft,lTop,lWidth,lHeight,MemHDC,0,0,Bmp1.bmWidth,Bmp1.bmHeight,Style);
      goto Trans000;
    }
  }
  else {
    if (iTrans>0) {
      hBmp1 = CreateCompatibleBitmap(hDC1,lWidth,lHeight); hDC1 = CreateCompatibleDC(hDC1);
      hBmp1 = (HBITMAP)SelectObject(hDC1,hBmp1);
    }
BitBlt0000:
    BitBlt(hDC1,lLeft,lTop,lWidth,lHeight,MemHDC,0,0,Style);
Trans000:
    if (hBmp1) {
      SelectObject(MemHDC,hBmpOld); DeleteDC(MemHDC);
      MemHDC = hDC1; hBmpOld = hBmp1;
      if (iTrans>0) {
Trans0000:
        hDC1 = hDC;
        bfn.BlendOp = AC_SRC_OVER; bfn.BlendFlags = 0;
        bfn.SourceConstantAlpha = iTrans; bfn.AlphaFormat = AC_SRC_ALPHA;
        AlphaBlend(hDC1,lLeft,lTop,lWidth,lHeight,MemHDC,0,0,lWidth,lHeight,bfn);
      }
    }
  }
  if (pDC) { *pDC = MemHDC; return hBmpOld; }
  hDC1 = (HDC)SelectObject(MemHDC,hBmpOld); DeleteDC(MemHDC);
  if (hBmp1) DeleteObject((HBITMAP)hDC1);
  return hBmp;
}
/* END MODULE */


/* MODULE::cb_DrawBitmap */
HBITMAP cb_DEFCALL cb_DrawBitmap (HBITMAP hBmp, void *hdcD, cb_Integer lLeft, cb_Integer lTop, cb_Integer lWidth, cb_Integer lHeight, cb_Integer flag1, cb_Integer iTrans, HDC hDC, HDC *pDC, cb_Integer Style)
{
  register HDC hdcDest;
  register HWND hWnd;
  RECT tRect;

  if (hDC) {
    hWnd = (HWND)hdcD;
    hdcDest = hDC;
  }
  else if (hdcD==(void*)-1) {
    hWnd = GetDesktopWindow();
    hdcDest = GetDC(hWnd);
  }
  else if (GetObjectType(hdcD)==OBJ_DC) {
    hdcDest = (HDC)hdcD;
    hWnd = NULL;
  }
  else {
    hWnd = (HWND)hdcD;
    hdcDest = GetDC(hWnd);
  }
  if (lWidth<=0) {
    if (!hWnd) hWnd = WindowFromDC(hdcDest);
    GetClientRect(hWnd,&tRect);
    lWidth = tRect.right-lLeft;
    if (lHeight<=0) lHeight = tRect.bottom-lTop;
  }
  else if (lHeight<=0) {
    if (!hWnd) hWnd = WindowFromDC(hdcDest);
    GetClientRect(hWnd,&tRect);
    lHeight = tRect.bottom-lTop;
  }
  hBmp = cb_DrawBMP(hBmp,hdcDest,pDC,lLeft,lTop,lWidth,lHeight,flag1,iTrans,Style);
  if (!hDC) if (hdcDest!=(HDC)hdcD) ReleaseDC(hWnd,hdcDest);
  return hBmp;
}
/* END MODULE */


/* MODULE::cb_DrawTransparentBMP */
void cb_DEFCALL cb_DrawTransparentBMP (HBITMAP picSource,HDC hDC,cb_Integer lLeft,cb_Integer lTop,cb_Integer lWidth,cb_Integer lHeight,cb_Integer lMaskColor,cb_Integer flag1,HPALETTE lhPal)
{
#define lhdcMask lhdcSrc
#define lhbmMask lhbmSrc
  register HDC      lhdcColor;
  register HDC      lhdcSrc;
  register HBITMAP lhbmSrc;
  register HBITMAP  lhbmColor;
  HPALETTE  lhPalOld;
  cb_Integer w, h;
  BITMAP Bmp1;

  if (flag1) {
    if (GetObject(picSource, sizeof(Bmp1), &Bmp1)) {
      if ((flag1&2)==0) SetStretchBltMode(hDC,HALFTONE);
      w = Bmp1.bmWidth; h = Bmp1.bmHeight;
      goto Start0000;
    }
  }
  w = 0; h = 0;
Start0000:
  lhdcSrc = CreateCompatibleDC(hDC);
  lhbmSrc = (HBITMAP)SelectObject(lhdcSrc,picSource);
  lhbmColor = CreateCompatibleBitmap(hDC,lWidth,lHeight);
  lhdcColor = CreateCompatibleDC(hDC);
  lhbmColor = (HBITMAP)SelectObject(lhdcColor,lhbmColor);
  if (lhPal) { lhPalOld = SelectPalette(lhdcColor,lhPal,TRUE); RealizePalette(lhdcColor); }
  SetBkColor(lhdcColor,GetBkColor(lhdcSrc));
  SetTextColor(lhdcColor,GetTextColor(lhdcSrc));
  if (!flag1) BitBlt(lhdcColor,0,0,lWidth,lHeight,lhdcSrc,0,0,SRCCOPY);
  else StretchBlt(lhdcColor,0,0,lWidth,lHeight,lhdcSrc,0,0,w,h,SRCCOPY);
  SelectObject(lhdcSrc,lhbmSrc); DeleteDC(lhdcSrc);
  lhbmMask = CreateBitmap(lWidth,lHeight,1,1,0);
  lhdcMask = CreateCompatibleDC(hDC);
  lhbmMask = (HBITMAP)SelectObject(lhdcMask,lhbmMask);
  SetBkColor(lhdcColor,lMaskColor);
  SetTextColor(lhdcColor,0xFFFFFFFF);
  if (!flag1) BitBlt(lhdcMask,0,0,lWidth,lHeight,lhdcColor,0,0,SRCCOPY);
  else StretchBlt(lhdcMask,0,0,lWidth,lHeight,lhdcColor,0,0,w,h,SRCCOPY);
  SetTextColor(lhdcColor,0);
  SetBkColor(lhdcColor,0xFFFFFFFF);
  if (!flag1) {
    BitBlt(lhdcColor,0,0,lWidth,lHeight,lhdcMask,0,0,0x00220326);
    BitBlt(hDC,lLeft,lTop,lWidth,lHeight,lhdcMask,0,0,SRCAND);
    BitBlt(hDC,lLeft,lTop,lWidth,lHeight,lhdcColor,0,0,SRCPAINT);
  }
  else {
    StretchBlt(lhdcColor,0,0,lWidth,lHeight,lhdcMask,0,0,w,h,0x00220326);
    StretchBlt(hDC,lLeft,lTop,lWidth,lHeight,lhdcMask,0,0,w,h,SRCAND);
    StretchBlt(hDC,lLeft,lTop,lWidth,lHeight,lhdcColor,0,0,w,h,SRCPAINT);
  }
  if (lhPal) { SelectPalette(lhdcColor,lhPalOld,TRUE); RealizePalette(lhdcColor); }
  lhbmColor = (HBITMAP)SelectObject(lhdcColor,lhbmColor); DeleteDC(lhdcColor); DeleteObject(lhbmColor);
  lhbmMask = (HBITMAP)SelectObject(lhdcMask,lhbmMask); DeleteDC(lhdcMask); DeleteObject(lhbmMask);
#undef lhbmMask
#undef lhdcMask
}
/* END MODULE */


/* MODULE::cb_DrawTransparentBitmap */
void cb_DEFCALL cb_DrawTransparentBitmap (HBITMAP picSource,void *hdcDest,cb_Integer lLeft,cb_Integer lTop,cb_Integer lWidth,cb_Integer lHeight,cb_Integer lMaskColor,cb_Integer flag1,HDC hDC,HPALETTE lhPal)
{
  register HDC lhdcDest;
  register HWND hWnd;
  RECT tRect;

  if (hDC) {
    hWnd = (HWND)hdcDest;
    lhdcDest = hDC;
  }
  else if (hdcDest==(void*)-1) {
    hWnd = GetDesktopWindow();
    goto GetDC0000;
  }
  else if (GetObjectType(hdcDest)==OBJ_DC) {
    lhdcDest = (HDC)hdcDest;
    hWnd = NULL;
  }
  else {
    hWnd = (HWND)hdcDest;
GetDC0000:
    lhdcDest = GetDC(hWnd);
  }
  if (lWidth<=0) {
    if (!hWnd) hWnd = WindowFromDC(lhdcDest);
    GetClientRect(hWnd,&tRect);
    lWidth = tRect.right-lLeft;
    if (lHeight<=0) lHeight = tRect.bottom-lTop;
  }
  else if (lHeight<=0) {
    if (!hWnd) hWnd = WindowFromDC(lhdcDest);
    GetClientRect(hWnd,&tRect);
    lHeight = tRect.bottom-lTop;
  }
  cb_DrawTransparentBMP(picSource,(HDC)hdcDest,lLeft,lTop,lWidth,lHeight,lMaskColor,flag1,lhPal);
  if (!hDC) if (lhdcDest!=(HDC)hdcDest) ReleaseDC(hWnd,lhdcDest);
}
/* END MODULE */


/* MODULE::cb_GetBmpBits */
COLORREF* cb_DEFCALL cb_GetBmpBits (HBITMAP hBmp, cb_Integer w, cb_Integer h, HWND hWnd, HDC hDC)
{
  register cb_UInteger i;
  register HDC h_;
  register COLORREF *lpBits = (COLORREF*)hDC; if (!lpBits) lpBits = (COLORREF*)GetDC(hWnd);
  h_ = CreateCompatibleDC((HDC)lpBits); if (!hDC) ReleaseDC(hWnd,(HDC)lpBits);
  HBITMAP hBmpOld = (HBITMAP)SelectObject(h_,hBmp);
  BITMAPINFOHEADER b;

  b.biSizeImage = 0; b.biXPelsPerMeter = 0; b.biYPelsPerMeter = 0; b.biClrUsed = 0; b.biClrImportant = 0;
  b.biSize = sizeof(BITMAPINFOHEADER);
  b.biPlanes = 1;
  b.biBitCount = 32;
  b.biCompression = BI_RGB;
  i = h; b.biHeight = i; if ((cb_Integer)i<0) h = -i;
  i = w; b.biWidth = i; i *= 32; i += 0x1F; i &= ~0x1F; i >>= 3; i *= h;
  lpBits = (COLORREF*)cb_MemAllocM(i);
  GetDIBits(h_,hBmp,0,h,lpBits,(PBITMAPINFO)&b,DIB_RGB_COLORS);
  SelectObject(h_,hBmpOld); DeleteDC(h_);
  return lpBits;
}
/* END MODULE */


/* MODULE::cb_ConvertRGBA */
void cb_DEFCALL cb_ConvertRGBA (const void *ptr1, void *ptr2, cb_Integer sze)
{
  register const cb_UInteger *p1 = (const cb_UInteger*)ptr1;
  register cb_UInteger *p2 = (cb_UInteger*)ptr2;
  register cb_Integer i = sze; i>>=2;

  for (;i>0;i--) {
    *p2 = ((*p1&0xff)<<16) | (*p1&0xff00) | ((*p1&0xff0000)>>16) | (*p1&0xff000000);
    p1++; p2++;
  }
}
/* END MODULE */


/* MODULE::cb_SaveBMP */
void* cb_DEFCALL cb_SaveBMP (HBITMAP hBmp,HDC hDC,const char *szFile,void *pSize,void *dst,cb_Integer flg1,cb_Integer depth,void *depthFound)
{
  DIBSECTION Bmp1;
  register LPBYTE lpBits;
  register DWORD cb;
  register DWORD dwClrUsed;
  HANDLE hf;
  BITMAPFILEHEADER hdr;
  PBITMAPINFOHEADER pbih;
  DWORD dwRet;

  lpBits = NULL;
  if (hBmp==(HBITMAP)-1) { cb = depth; cb_MemCopy(&Bmp1,depthFound,sizeof(DIBSECTION)); depthFound = NULL; goto Cont000; }
  cb = GetObject(hBmp,sizeof(Bmp1),(LPSTR)&Bmp1);
  if (cb) {
    dwClrUsed = depth;
    if (dwClrUsed>0) cb = dwClrUsed;
    else if (cb==sizeof(DIBSECTION)) cb = Bmp1.dsBmih.biPlanes*Bmp1.dsBmih.biBitCount;
    else cb = Bmp1.dsBm.bmPlanes*Bmp1.dsBm.bmBitsPixel;
Cont000:
    if (cb==1) {
      dwClrUsed = 1;
      goto Cont0000;
    }
    if (cb<=4) {
      dwClrUsed = 4;
      goto Cont0000;
    }
    if (cb<=8) {
      dwClrUsed = 8;
      goto Cont0000;
    }
    if (cb<=16) {
      dwClrUsed = 16;
Cont0000:
      cb = 1<<dwClrUsed;
      pbih=(PBITMAPINFOHEADER)cb_MemAllocM(sizeof(BITMAPINFOHEADER)+(sizeof(RGBQUAD)*cb));
    }
    else {
      if (cb<=24) dwClrUsed = 24;
      else dwClrUsed = 32;
      cb = 0;
      pbih=(PBITMAPINFOHEADER)cb_MemAllocM(sizeof(BITMAPINFO));
    }
    if (depthFound) *(DWORD*)depthFound = dwClrUsed;
    if (!pbih) { cb = 0; goto Exit1111; }
    pbih->biClrUsed = cb;
    pbih->biSize = sizeof(BITMAPINFOHEADER);
    pbih->biWidth = Bmp1.dsBm.bmWidth;
    if (flg1>=0) pbih->biHeight = Bmp1.dsBm.bmHeight;
    else { flg1 &= 0xff; pbih->biHeight = 0-Bmp1.dsBm.bmHeight; }
    pbih->biPlanes = Bmp1.dsBm.bmPlanes;
    pbih->biBitCount = dwClrUsed;
    pbih->biCompression = BI_RGB;
    cb *= sizeof(RGBQUAD); cb += sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
    hdr.bfOffBits = cb;
    cb = Bmp1.dsBm.bmWidth; cb *= dwClrUsed; cb += 0x1F; cb &= ~0x1F; cb >>= 3; cb *= Bmp1.dsBm.bmHeight;
    pbih->biSizeImage = cb;
    pbih->biClrImportant = 0; pbih->biXPelsPerMeter = 0; pbih->biYPelsPerMeter = 0;
    hdr.bfType = 0x4d42;
    hdr.bfReserved1 = 0;
    hdr.bfReserved2 = 0;
    if (!szFile || !szFile[0] || flg1>0) {
      lpBits=(LPBYTE)dst;
      if (flg1>0) {
        if (!lpBits || (lpBits==(LPBYTE)-1)) {
          lpBits = (LPBYTE)cb_MemAllocM(cb);
          if (!lpBits) goto Exit0000;
        }
        GetDIBits(hDC,hBmp,0,Bmp1.dsBm.bmHeight,lpBits,(PBITMAPINFO)pbih,DIB_RGB_COLORS);
        if (flg1==2) dwClrUsed = (DWORD)cb_SavePNGFile(szFile,(const void*)lpBits,(cb_UInteger)Bmp1.dsBm.bmWidth,(cb_UInteger)Bmp1.dsBm.bmHeight,dwClrUsed,(cb_Integer*)(&hdr.bfOffBits));
        else if (flg1==3) dwClrUsed = (DWORD)cb_SaveGIFFile(szFile,(const void*)lpBits,(cb_UInteger)Bmp1.dsBm.bmWidth,(cb_UInteger)Bmp1.dsBm.bmHeight,dwClrUsed,(cb_Integer*)(&hdr.bfOffBits));
        else dwClrUsed = (DWORD)cb_SaveJPGFile(szFile,(const void*)lpBits,(cb_UInteger)Bmp1.dsBm.bmWidth,(cb_UInteger)Bmp1.dsBm.bmHeight,dwClrUsed,(cb_Integer*)(&hdr.bfOffBits));
        cb = hdr.bfOffBits;
        if (!dst || (dst==(void*)-1)) cb_MemFreeM(lpBits);
        lpBits = (LPBYTE)dwClrUsed;
        if (lpBits) if (!szFile || !szFile[0])
          if (!dst) { dst = cb_NewStr_(lpBits, NULL, cb); cb_MemFreeM(lpBits); lpBits = (LPBYTE)dst; }
          else if (dst!=(void*)-1) { cb_MemCopy(dst,lpBits,cb); cb_MemFreeM(lpBits); lpBits = (LPBYTE)dst; }
      }
      else {
        dwClrUsed = hdr.bfOffBits;
        cb += dwClrUsed; hdr.bfSize = cb;
        if (!lpBits || (lpBits==(LPBYTE)-1)) {
          lpBits = (LPBYTE)cb_NewStr_(NULL,lpBits,cb);
          if (!lpBits) goto Exit0000;
        }
        cb_MemCopy(lpBits,&hdr,sizeof(BITMAPFILEHEADER));
        lpBits += sizeof(BITMAPFILEHEADER);
        cb_MemCopy(lpBits,pbih,sizeof(BITMAPINFOHEADER));
        lpBits += sizeof(BITMAPINFOHEADER);
        if (hBmp!=(HBITMAP)-1) {
          dwClrUsed -= sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
          GetDIBits(hDC,hBmp,0,Bmp1.dsBm.bmHeight,lpBits+dwClrUsed,(PBITMAPINFO)pbih,DIB_RGB_COLORS);
          if (dwClrUsed) cb_MemCopy(lpBits,pbih+sizeof(BITMAPINFOHEADER),dwClrUsed);
        }
        else {
          cb_ConvertRGBA(hDC,lpBits,cb-(sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)));
        }
        lpBits -= sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
      }
    }
    else {
      hf = CreateFile(szFile,GENERIC_READ | GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,(HANDLE)NULL);
      if (hf==INVALID_HANDLE_VALUE) {
Exit0000:
        cb = 0;
      }
      else {
        dwClrUsed = hdr.bfOffBits;
        hdr.bfSize = dwClrUsed+cb;
        lpBits=(LPBYTE)dst;
        if (!lpBits) {
          lpBits = (LPBYTE)cb_MemAllocM(cb);
          if (!lpBits) { cb = 0; goto CloseHandle0000; }
        }
        else {
          if (lpBits==(LPBYTE)-1) {
            lpBits = (LPBYTE)cb_MemAllocM(hdr.bfSize);
            if (!lpBits) { cb = 0; goto CloseHandle0000; }
          }
          cb_MemCopy(lpBits,&hdr,sizeof(BITMAPFILEHEADER));
          cb_MemCopy(lpBits+sizeof(BITMAPFILEHEADER),pbih,sizeof(BITMAPINFOHEADER));
          lpBits += dwClrUsed;
        }
        WriteFile(hf,&hdr,sizeof(BITMAPFILEHEADER),&dwRet,NULL);
        WriteFile(hf,pbih,sizeof(BITMAPINFOHEADER),&dwRet,NULL);
        if (hBmp!=(HBITMAP)-1) {
          GetDIBits(hDC,hBmp,0,Bmp1.dsBm.bmHeight,lpBits,(PBITMAPINFO)pbih,DIB_RGB_COLORS);
          dwClrUsed -= sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
          if (dwClrUsed) WriteFile(hf,pbih+sizeof(BITMAPINFOHEADER),dwClrUsed,&dwRet,NULL);
          dwClrUsed += sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
        }
        else {
          cb_ConvertRGBA(hDC,lpBits,cb);
        }
        WriteFile(hf,lpBits,cb,&dwRet,NULL);
        cb += dwClrUsed;
        if (!dst) cb_MemFreeM(lpBits);
        else lpBits -= dwClrUsed;
CloseHandle0000:
        CloseHandle(hf);
      }
    }
    cb_MemFreeM(pbih);
  }
Exit1111:
  if (pSize) *(cb_Integer*)pSize = cb;
  return lpBits;
}
/* END MODULE */


/* MODULE::cb_SaveBitmap */
void* cb_DEFCALL cb_SaveBitmap (HBITMAP hBmp,const char *szFile,void *pSize,void *dst,cb_Integer flg1,HWND hWnd,cb_Integer depth,void *depthFound)
{
  register HDC hDC;
  register void *lpBits;

  hDC = GetDC(hWnd);
  lpBits = cb_SaveBMP(hBmp, hDC, szFile, pSize, dst, flg1, depth, depthFound);
  ReleaseDC(hWnd,hDC);
  return lpBits;
}
/* END MODULE */


/* MODULE::cb_SaveImage */
void* cb_DEFCALL cb_SaveImage (void *hBmp,const char *szFile,void *pSize,void *dst,cb_Integer flg1,cb_Integer depth,void *depthFound)
{
  register cb_Integer flag1;
  register HDC hDC;
  register HWND hWnd;
  void *lpBits;

  flag1 = GetObjectType(hBmp);
  if (flag1==OBJ_BITMAP) {
    hDC = GetDC(NULL);
    flag1 = TRUE; hWnd = NULL;
  }
  else {
    if (flag1==OBJ_DC) { hDC = (HDC)hBmp; flag1 = FALSE; hWnd = NULL; }
    else { hWnd = (HWND)hBmp; hDC = GetDC(hWnd); flag1 = TRUE; }
    hBmp = (void*)GetCurrentObject(hDC,OBJ_BITMAP);
  }
  lpBits = cb_SaveBMP((HBITMAP)hBmp, hDC, szFile, pSize, dst, flg1, depth, depthFound);
  if (flag1) {
    ReleaseDC(hWnd,hDC);
  }
  return lpBits;
}
/* END MODULE */


/* MODULE::cb_SavePicture */
void* cb_DEFCALL cb_SavePicture (void *hBmp,const char *szFile,void *pSize,void *dst,cb_Integer flg1,cb_Integer depth,void *depthFound)
{
  register cb_Integer flag1 = flg1, i;

  if (flag1==-1) {
    flag1++;
    if (szFile) {
      i = cb_StrLen(szFile)-4;
      if (i>0) {
        if (0==cb_MemIComp(szFile+i, ".jpg", 5)) flag1 = 1;
        else if (0==cb_MemIComp(szFile+i, ".png", 5)) flag1 = 2|cb_MIN_INTEGER;
        else if (0==cb_MemIComp(szFile+i, ".gif", 5)) flag1 = 3;
      }
    }
  }
  return cb_SaveImage(hBmp,szFile,pSize,dst,flag1,depth, depthFound);
}
/* END MODULE */


/* MODULE::cb_SaveGIF */
void * cb_DEFCALL cb_SaveGIF (void *hBmp, const char *F, const void *buf, cb_Integer Res, void *pSize)
{
  register BITMAPINFOHEADER *t1;
  register char *buf1;
  register cb_Integer h1;

  if (!hBmp) if (Res) hBmp = cb_LoadImageResource(NULL, Res, 0, 0, 0, -1);
  if (hBmp) return cb_GDIPSaveImage((HBITMAP)hBmp, F, 3);
  buf1 = (char*)buf;
  if (!buf1) return NULL;
  buf1 += sizeof(BITMAPFILEHEADER);
  t1 = (BITMAPINFOHEADER*)buf1;
  register DWORD dwClrUsed = t1->biClrUsed;
  buf1 += sizeof(BITMAPINFOHEADER); buf1 += dwClrUsed*sizeof(RGBQUAD);
  h1 = t1->biHeight; if (h1<0) h1 = 0-h1;
  return cb_SaveGIFFile(F,buf1,t1->biWidth,h1,dwClrUsed,pSize);
}
/* END MODULE */


/* MODULE::cb_SaveJPG */
void * cb_DEFCALL cb_SaveJPG (void *hBmp, const char *F, const void *buf, cb_Integer Res, void *pSize)
{
  register BITMAPINFOHEADER *t1;
  register char *buf1;
  register cb_Integer h1;

  if (!hBmp) if (Res) hBmp = cb_LoadImageResource(NULL, Res, 0, 0, 0, -1);
  if (hBmp) return cb_GDIPSaveImage((HBITMAP)hBmp, F, 1);
  buf1 = (char*)buf;
  if (!buf1) return NULL;
  buf1 += sizeof(BITMAPFILEHEADER);
  t1 = (BITMAPINFOHEADER*)buf1;
  register DWORD dwClrUsed = t1->biClrUsed;
  buf1 += sizeof(BITMAPINFOHEADER); buf1 += dwClrUsed*sizeof(RGBQUAD);
  h1 = t1->biHeight; if (h1<0) h1 = 0-h1;
  return cb_SaveJPGFile(F,buf1,t1->biWidth,h1,dwClrUsed,pSize);
}
/* END MODULE */


/* MODULE::cb_SavePNG */
void * cb_DEFCALL cb_SavePNG (void *hBmp, const char *F, const void *buf, cb_Integer Res, void *pSize)
{
  register BITMAPINFOHEADER *t1;
  register char *buf1;
  register cb_Integer h1;

  if (!hBmp) if (Res) hBmp = cb_LoadImageResource(NULL, Res, 0, 0, 0, -1);
  if (hBmp) return cb_SaveBitmap((HBITMAP)hBmp, F, pSize, NULL, 2);
  buf1 = (char*)buf;
  if (!buf1) return NULL;
  buf1 += sizeof(BITMAPFILEHEADER);
  t1 = (BITMAPINFOHEADER*)buf1;
  register DWORD dwClrUsed = t1->biClrUsed;
  buf1 += sizeof(BITMAPINFOHEADER); buf1 += dwClrUsed*sizeof(RGBQUAD);
  h1 = t1->biHeight; if (h1<0) h1 = 0-h1;
  return cb_SavePNGFile(F,buf1,t1->biWidth,h1,dwClrUsed,pSize);
}
/* END MODULE */


/* MODULE::cb_PutImage */
HBITMAP cb_DEFCALL cb_PutImage (HWND hWnd,const char *sFile,cb_Integer Res,cb_Integer flag1,cb_Integer iTrans,HDC hDC,HDC *pDC)
{
  static cb_Integer f1; if (f1) return NULL;
  f1++;
  RECT rc;
  if ((flag1&1)==0) GetClientRect(hWnd,&rc); else { rc.right = 0; rc.bottom = 0; }
  register cb_Integer t = 0; if ((flag1&2)!=0) t = LR_LOADTRANSPARENT;
  register HBITMAP hBmp;
   hBmp = cb_LoadImageResource(sFile,Res,rc.right,rc.bottom,LR_CREATEDIBSECTION|t,IMAGE_BITMAP);
  if (hBmp) hBmp = cb_DrawBitmap(hBmp,hWnd,0,0,rc.right,rc.bottom,flag1&1,iTrans,hDC,pDC,SRCCOPY);
  f1--;
  return hBmp;
}
/* END MODULE */


/* MODULE::cb_LogToPhys */
cb_Boolean cb_DEFCALL cb_LogToPhys (HWND hWnd,POINT *p)
{
  register HMODULE h;
  if (cb_LogToPhysFuncPtr_==NULL) {
    h = GetModuleHandle("user32"); if (h==NULL) goto exit0000;
    *(void**)&cb_LogToPhysFuncPtr_ = (void*)GetProcAddress(h,"LogicalToPhysicalPointForPerMonitorDPI");
    if (cb_LogToPhysFuncPtr_==NULL) { exit0000:; *(void**)&cb_LogToPhysFuncPtr_ = cb_INVALID; return -1; }
  }
  else if (cb_LogToPhysFuncPtr_==cb_INVALID) return -1;
  return cb_LogToPhysFuncPtr_(hWnd,p);
}
/* END MODULE */


/* MODULE::cb_PhysToLog */
cb_Boolean cb_DEFCALL cb_PhysToLog (HWND hWnd,POINT *p)
{
  register HMODULE h;
  if (cb_PhysToLogFuncPtr_==NULL) {
    h = GetModuleHandle("user32"); if (h==NULL) goto exit0000;
    *(void**)&cb_PhysToLogFuncPtr_ = (void*)GetProcAddress(h,"PhysicalToLogicalPointForPerMonitorDPI");
    if (cb_PhysToLogFuncPtr_==NULL) { exit0000:; *(void**)&cb_PhysToLogFuncPtr_ = cb_INVALID; return -1; }
  }
  else if (cb_PhysToLogFuncPtr_==cb_INVALID) return -1;
  return cb_PhysToLogFuncPtr_(hWnd,p);
}
/* END MODULE */


/* MODULE::cb_WndShot */
HBITMAP cb_DEFCALL cb_WndShot (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,HDC hDC,HDC *pDC)
{
  register HWND hWin;
  RECT rc1;
  if (W<=0 || H<=0) {
    hWin = hWnd; if ((cb_UInteger)((cb_Integer)hWin-1)>=(cb_UInteger)-2) hWin = GetDesktopWindow();
    GetClientRect(hWin,&rc1);
    cb_LogToPhys(hWin,(POINT*)&rc1); cb_LogToPhys(hWin,((POINT*)&rc1)+1);
    if (W<=0) W = rc1.right-rc1.left;
    if (H<=0) H = rc1.bottom-rc1.top;
  }
  register HDC hSrc = hDC;
  if (!hSrc) {
    hWin = hWnd; if (hWin==(HWND)-1) hWin = NULL;
    hSrc = GetDC(hWin);
  }
  register HDC hMem; hMem = CreateCompatibleDC(hSrc);
  register HBITMAP hBmp; hBmp = CreateCompatibleBitmap(hSrc,W,H);
  hBmp = (HBITMAP)SelectObject(hMem,hBmp);
  BitBlt(hMem,0,0,W,H,hSrc,X,Y,SRCCOPY);
  if (!hDC) ReleaseDC(hWin,hSrc);
  if (pDC) *pDC = hMem;
  else { hBmp = (HBITMAP)SelectObject(hMem,hBmp); DeleteDC(hMem); }
  return hBmp;
}
/* END MODULE */


/* MODULE::cb_GetBitmapWidth */
cb_Integer cb_DEFCALL cb_GetBitmapWidth (HBITMAP hBmp, void *H)
{
  BITMAP Bmp1;

  Bmp1.bmWidth = 0; Bmp1.bmHeight = 0;
  GetObject(hBmp,sizeof(Bmp1),&Bmp1);
  if (H) *(cb_Integer*)H = Bmp1.bmHeight;
  return Bmp1.bmWidth;
}
/* END MODULE */


/* MODULE::cb_GetBitmapHeight */
cb_Integer cb_DEFCALL cb_GetBitmapHeight (HBITMAP hBmp)
{
  cb_Integer H;

  cb_GetBitmapWidth(hBmp,&H);
  return H;
}
/* END MODULE */


/* MODULE::cb_GetTextSize */
cb_Integer cb_DEFCALL cb_GetTextSize (const char *Str1,void *H,HWND hWnd,HFONT hFnt,HDC hDC)
{
  SIZE sze;
  register HFONT oldhFnt;
  register HDC hDrawDC;

  cb_MemSet(&sze,0,sizeof(SIZE));
  if (Str1) {
    hDrawDC = hDC; if (!hDrawDC) hDrawDC = GetDC(hWnd);
    oldhFnt = hFnt; if (oldhFnt) oldhFnt = (HFONT)SelectObject(hDrawDC,oldhFnt);
    GetTextExtentPoint32(hDrawDC,Str1,cb_StrLen(Str1),&sze);
    if (oldhFnt) SelectObject(hDrawDC,oldhFnt);
    if (!hDC) ReleaseDC(hWnd,hDrawDC);
  }
  if (H) *(cb_Integer*)H = sze.cy;
  return sze.cx;
}
/* END MODULE */


/* MODULE::cb_LBLoadFile */
cb_Integer cb_DEFCALL cb_LBLoadFile (HWND hWnd, const char *sFile, cb_Integer iReset, cb_Integer Index, cb_Integer iOpr)
{
  register cb_File *fp;
  register cb_Integer buflen, i, b;
  char Buff[4096];

  if ((fp=cb_FileOpen(sFile))==NULL) {
    return -1;
  }
  b = IsWindowVisible(hWnd); if (b) SendMessage(hWnd,WM_SETREDRAW,FALSE,0);
  if (iReset) {
    SendMessage(hWnd,iReset,0,0);
  }
  i = 0;
  while(!cb_FileEOF(fp)) {
    *Buff = 0; if (cb_FileGetS(fp,Buff,4096)<0) break;
    buflen = cb_StrLen(Buff);
    while(buflen>0) {
      buflen--;
      if (Buff[buflen]!='\n') if (Buff[buflen]!='\r') {
        buflen++; Buff[buflen] = 0;
        if (Index>=0) { i = SendMessage(hWnd,iOpr,Index,(LPARAM)Buff); Index++; }
        else i = SendMessage(hWnd,iOpr, 0,(LPARAM)Buff);
        break;
      }
    }
  }
  if (b) { SendMessage(hWnd,WM_SETREDRAW,TRUE,0); cb_Redraw(hWnd); }
  cb_FileClose(fp);
  return i;
}
/* END MODULE */


/* MODULE::cb_CBLoadFile */
cb_Integer cb_DEFCALL cb_CBLoadFile (HWND hWnd, const char *sFile, cb_Integer iReset)
{
  return cb_LBLoadFile(hWnd,sFile,iReset,-1,CB_ADDSTRING);
}
/* END MODULE */


/* MODULE::cb_CBLBInsertFile */
cb_Integer cb_DEFCALL cb_CBLBInsertFile (HWND hWnd, const char *sFile, cb_Integer Index, cb_Integer iMsg1, cb_Integer iMsg2, cb_Integer iMsg3)
{
  register cb_Integer ndx = Index;
  if (ndx<0) {
    if (ndx==-1) ndx = SendMessage(hWnd,iMsg2,0,0);
    else { ndx = iMsg3; if (ndx!=-1) ndx = SendMessage(hWnd,ndx,0,0)-1; }
  }
  return cb_LBLoadFile(hWnd,sFile,FALSE,ndx,iMsg1);
}
/* END MODULE */


/* MODULE::cb_LBInsertFile */
cb_Integer cb_DEFCALL cb_LBInsertFile (HWND hWnd, const char *sFile, cb_Integer Index)
{
  return cb_CBLBInsertFile(hWnd,sFile,Index,LB_INSERTSTRING,LB_GETCURSEL,LB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_CBInsertFile */
cb_Integer cb_DEFCALL cb_CBInsertFile (HWND hWnd, const char *sFile, cb_Integer Index)
{
  return cb_CBLBInsertFile(hWnd,sFile,Index,CB_INSERTSTRING,CB_GETCURSEL,CB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_LBSaveFile */
cb_Integer cb_DEFCALL cb_LBSaveFile (HWND hWnd, const char *sFile, cb_Integer iStart, cb_Integer iNum, cb_UInteger iGet)
{
  register cb_Integer i, j;
  register char *Buff;
  cb_File *fp;

  i = -1;
  if ((fp=cb_FileOpen(sFile,_O_CREAT|_O_BINARY|_O_WRONLY))!=NULL) {
  Buff = (char*)cb_MemAllocM(0x2000);
  if (Buff) {
    i = iStart;
    j = iNum;
    if (j<=0) j=0x7FFFFFFF;
    else if (j!=0x7FFFFFFF) j+=i;
    do {
      *Buff = 0; if (SendMessage(hWnd,iGet, (WPARAM)i,(LPARAM)Buff)==LB_ERR) break;
      if (*Buff) { if (cb_FilePutS(fp,Buff)<0) break; cb_FileWrite(fp,"\r\n",2); }
      i++;
    }while(i<j);
    cb_MemFreeM(Buff);
  }
  cb_FileFlush(fp); cb_FileClose(fp);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_CBLBCopy */
cb_Integer cb_DEFCALL cb_CBLBCopy (HWND hWnd2, HWND hWnd1, cb_Integer iStart2, cb_Integer iNum, cb_Integer iStart1, cb_Integer iMsg1, cb_Integer iMsg2, cb_Integer iMsg3, cb_Integer iMsg4, cb_Integer iMsg5, cb_Integer iMsg6, cb_Integer iMsg7)
{
  register cb_Integer i, j, h;
  void *Buff;
  cb_Integer d, iCnt;

  i = -1;
  Buff = cb_MemAllocM(0x2000);
  if (Buff) {
    SendMessage(hWnd2,WM_SETREDRAW,FALSE,0);
    iCnt = SendMessage(hWnd1,iMsg4,0,0);
    j = iStart1;
    if (j==-1) j = SendMessage(hWnd1,iMsg3,0,0);
    h = iNum;
    if (h<=0) h=0x7FFFFFFF;
    else if (h!=0x7FFFFFFF) h+=j;
    i = iStart2;
    if (i==-1) i = SendMessage(hWnd2,iMsg3,0,0);
    else if (i==-2) i = SendMessage(hWnd2,iMsg4,0,0);
    else if (i<0) { SendMessage(hWnd2,iMsg7,0,0); i = 0; }
    while(j<iCnt) {
      d = (cb_Integer)SendMessage(hWnd1,iMsg1,(WPARAM)j,(LPARAM)Buff);
      if (d<0) break;
      d = (cb_Integer)SendMessage(hWnd1,iMsg2,(WPARAM)j,0);
      SendMessage(hWnd2,iMsg5,(WPARAM)i,(LPARAM)Buff);
      SendMessage(hWnd2,iMsg6,(WPARAM)i,(LPARAM)d);
      i++;
      j++;
      if (j>=h) break;
    }
    SendMessage(hWnd2,WM_SETREDRAW,TRUE,0); cb_Redraw(hWnd2);
    cb_MemFreeM(Buff);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_LBCopy */
cb_Integer cb_DEFCALL cb_LBCopy (HWND hWnd2, HWND hWnd1, cb_Integer iStart1, cb_Integer iNum, cb_Integer iStart2)
{
  return cb_CBLBCopy(hWnd2,hWnd1,iStart2,iNum,iStart1,LB_GETTEXT,LB_GETITEMDATA,LB_GETCURSEL,LB_GETCOUNT,LB_INSERTSTRING,LB_SETITEMDATA,LB_RESETCONTENT);
}
/* END MODULE */


/* MODULE::cb_CBCopy */
cb_Integer cb_DEFCALL cb_CBCopy (HWND hWnd2, HWND hWnd1, cb_Integer iStart1, cb_Integer iNum, cb_Integer iStart2)
{
  return cb_CBLBCopy(hWnd2,hWnd1,iStart2,iNum,iStart1,CB_GETLBTEXT,CB_GETITEMDATA,CB_GETCURSEL,CB_GETCOUNT,CB_INSERTSTRING,CB_SETITEMDATA,CB_RESETCONTENT);
}
/* END MODULE */


/* MODULE::cb_CBLBDeleteInsertStr */
cb_Integer cb_DEFCALL cb_CBLBDeleteInsertStr (HWND hWnd, const void *src, cb_Integer Index, cb_Integer iMsg1, cb_Integer iMsg2, cb_Integer iMsg3)
{
  register cb_Integer ndx = Index;
  if (ndx<0) {
    if (ndx==-1) ndx = SendMessage(hWnd,iMsg2,0,0);
    else { ndx = iMsg3; if (ndx!=-1) ndx = SendMessage(hWnd,ndx,0,0)-1; }
  }
  return SendMessage(hWnd,iMsg1,ndx,(LPARAM)src);
}
/* END MODULE */


/* MODULE::cb_LBDeleteStr */
cb_Integer cb_DEFCALL cb_LBDeleteStr (HWND hWnd, cb_Integer Index)
{
  return cb_CBLBDeleteInsertStr(hWnd,NULL,Index,LB_DELETESTRING,LB_GETCURSEL,LB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_CBDeleteStr */
cb_Integer cb_DEFCALL cb_CBDeleteStr (HWND hWnd, cb_Integer Index)
{
  return cb_CBLBDeleteInsertStr(hWnd,NULL,Index,CB_DELETESTRING,CB_GETCURSEL,CB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_LBInsertStr */
cb_Integer cb_DEFCALL cb_LBInsertStr (HWND hWnd, const void *src, cb_Integer Index)
{
  return cb_CBLBDeleteInsertStr(hWnd,src,Index,LB_INSERTSTRING,LB_GETCURSEL,-1);
}
/* END MODULE */


/* MODULE::cb_CBInsertStr */
cb_Integer cb_DEFCALL cb_CBInsertStr (HWND hWnd, const void *src, cb_Integer Index)
{
  return cb_CBLBDeleteInsertStr(hWnd,src,Index,CB_INSERTSTRING,CB_GETCURSEL,-1);
}
/* END MODULE */


/* MODULE::cb_LBGetData */
DWORD cb_DEFCALL cb_LBGetData (HWND hWnd, cb_Integer Index)
{
  return cb_CBLBDeleteInsertStr(hWnd,NULL,Index,LB_GETITEMDATA,LB_GETCURSEL,LB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_LBSetData */
cb_Boolean cb_DEFCALL cb_LBSetData (HWND hWnd, cb_Integer iData, cb_Integer Index)
{
  return (cb_Boolean)cb_CBLBDeleteInsertStr(hWnd,(const void*)iData,Index,LB_SETITEMDATA,LB_GETCURSEL,LB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_CBGetData */
DWORD cb_DEFCALL cb_CBGetData (HWND hWnd, cb_Integer Index)
{
  return cb_CBLBDeleteInsertStr(hWnd,NULL,Index,CB_GETITEMDATA,CB_GETCURSEL,CB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_CBSetData */
cb_Boolean cb_DEFCALL cb_CBSetData (HWND hWnd, cb_Integer iData, cb_Integer Index)
{
  return (cb_Boolean)cb_CBLBDeleteInsertStr(hWnd,(const void*)iData,Index,CB_SETITEMDATA,CB_GETCURSEL,CB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_CBLBGetText */
char * cb_DEFCALL cb_CBLBGetText (HWND hWnd, cb_Integer Index, void *dst, cb_Integer iMsg1, cb_Integer iMsg2, cb_Integer iMsg3, cb_Integer iMsg4)
{
  register HWND hWin = hWnd;
  register char *sTmp; sTmp = (char*)dst;
  register cb_Integer ndx = Index;

  if (ndx<0) if (ndx==-1) ndx = SendMessage(hWin,iMsg3,0,0); else ndx = SendMessage(hWin,iMsg4,0,0)-1;
  if (!sTmp||sTmp==(char*)-1) {
    sTmp = cb_NewStr_(NULL,sTmp,SendMessage(hWin,iMsg1,ndx,0));
    if (!sTmp) goto Exit0000;
  }
  sTmp[0] = 0;
  SendMessage(hWin,iMsg2,ndx,(LPARAM)sTmp);
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_LBGetText */
char * cb_DEFCALL cb_LBGetText (HWND hWnd, cb_Integer ndx, void *dst)
{
  return cb_CBLBGetText(hWnd,ndx,dst,LB_GETTEXTLEN,LB_GETTEXT,LB_GETCURSEL,LB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_CBGetText */
char * cb_DEFCALL cb_CBGetText (HWND hWnd, cb_Integer ndx, void *dst)
{
  return cb_CBLBGetText(hWnd,ndx,dst,CB_GETLBTEXTLEN,CB_GETLBTEXT,CB_GETCURSEL,CB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_CBLBSetText */
cb_Integer cb_DEFCALL cb_CBLBSetText (HWND hWnd, const void *src, cb_Integer Index, cb_Integer flag1, cb_Integer iMsg1, cb_Integer iMsg2, cb_Integer iMsg3, cb_Integer iMsg4, cb_Integer iMsg5, cb_Integer iMsg6, cb_Integer iMsg7, cb_Integer iMsg8, cb_Integer iMsg9)
{
  register cb_Integer ndx = Index;
  register cb_Integer i, j = SendMessage(hWnd,iMsg4,0,0), h;
  if (ndx<0) if (ndx==-1) ndx = j; else ndx = SendMessage(hWnd,iMsg3,0,0)-1;
  i = SendMessage(hWnd,iMsg6,ndx,0);
  cb_Integer n; n = SendMessage(hWnd,iMsg8,0,0);
  if (flag1>0) {
    if (flag1>TRUE || IsWindowVisible(hWnd)) SendMessage(hWnd,WM_SETREDRAW,FALSE,0);
    else flag1 = -1;
  }
  h = SendMessage(hWnd,iMsg1,ndx,(LPARAM)src);
  SendMessage(hWnd,iMsg7,ndx,i);
  ndx++;
  SendMessage(hWnd,iMsg2,ndx,0);
  if (j<=n) SendMessage(hWnd,iMsg9,n,0);
  if (flag1) { SendMessage(hWnd,iMsg5,j,0); if (flag1>0) { SendMessage(hWnd,WM_SETREDRAW,TRUE,0); cb_Redraw(hWnd); } }
  return h;
}
/* END MODULE */


/* MODULE::cb_LBSetText */
cb_Integer cb_DEFCALL cb_LBSetText (HWND hWnd, const void *src, cb_Integer ndx, cb_Integer flag1)
{
  return cb_CBLBSetText(hWnd,src,ndx,flag1,LB_INSERTSTRING,LB_DELETESTRING,LB_GETCOUNT,LB_GETCURSEL,LB_SETCURSEL,LB_GETITEMDATA,LB_SETITEMDATA,LB_GETTOPINDEX,LB_SETTOPINDEX);
}
/* END MODULE */


/* MODULE::cb_CBSetText */
cb_Integer cb_DEFCALL cb_CBSetText (HWND hWnd, const void *src, cb_Integer ndx, cb_Integer flag1)
{
  return cb_CBLBSetText(hWnd,src,ndx,flag1?-1:0,CB_INSERTSTRING,CB_DELETESTRING,CB_GETCOUNT,CB_GETCURSEL,CB_SETCURSEL,CB_GETITEMDATA,CB_SETITEMDATA,CB_GETTOPINDEX,CB_SETTOPINDEX);
}
/* END MODULE */


/* MODULE::cb_LBGetIndex */
cb_Integer cb_DEFCALL cb_LBGetIndex (HWND hWnd, const void *src, cb_Integer bFlag, cb_Integer Index)
{
  if (!src) return SendMessage(hWnd,LB_GETCURSEL,0,0);
  if (!bFlag) return SendMessage(hWnd,LB_FINDSTRINGEXACT,Index,(LPARAM)src);
  return SendMessage(hWnd,LB_FINDSTRING,Index,(LPARAM)src);
}
/* END MODULE */


/* MODULE::cb_CBGetIndex */
cb_Integer cb_DEFCALL cb_CBGetIndex (HWND hWnd, const void *src, cb_Integer bFlag, cb_Integer Index)
{
  if (!src) return SendMessage(hWnd,CB_GETCURSEL,0,0);
  if (SendMessage(hWnd,CB_GETCOUNT,0,0)<=0) return -1;
  if (!bFlag) return ComboBox_FindStringExact(hWnd,Index,(LPCTSTR)src);
  return ComboBox_FindString(hWnd,Index,(LPCTSTR)src);
}
/* END MODULE */


/* MODULE::cb_CBLBGetIndexData */
cb_Integer cb_DEFCALL cb_CBLBGetIndexData (HWND hWnd, cb_Integer iNum, cb_Integer iMsg1, cb_Integer iMsg2)
{
  register cb_Integer i, j = SendMessage(hWnd,iMsg2,0,0);
  for (i=0;i<j;i++) {
    if (SendMessage(hWnd, iMsg1, i, 0)==iNum) return i;
  }
  return -1;
}
/* END MODULE */


/* MODULE::cb_LBGetIndexData */
cb_Integer cb_DEFCALL cb_LBGetIndexData (HWND hWnd, cb_Integer iNum)
{
  return cb_CBLBGetIndexData(hWnd, iNum, LB_GETITEMDATA, LB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_CBGetIndexData */
cb_Integer cb_DEFCALL cb_CBGetIndexData (HWND hWnd, cb_Integer iNum)
{
  return cb_CBLBGetIndexData(hWnd, iNum, CB_GETITEMDATA, CB_GETCOUNT);
}
/* END MODULE */


/* MODULE::cb_LVWGetText */
char * cb_DEFCALL cb_LVWGetText (HWND hWnd, cb_Integer Index, cb_Integer iSub, void *dst)
{
  register char *sTmp;
  LVITEM lvItm; cb_MemSet(&lvItm,0,sizeof(lvItm));

  if (Index<0) lvItm.iItem = SendMessage(hWnd,LVM_GETITEMCOUNT,0,0)-1;
  else lvItm.iItem = Index;
  lvItm.iSubItem = iSub;
  lvItm.mask = LVIF_TEXT;
  lvItm.cchTextMax = 0x8000;
  sTmp = (char*)dst;
  if (sTmp && (cb_Integer)sTmp!=-1) sTmp[0]=0;
  else sTmp = cb_NewStr_(NULL,sTmp,0x8000);
  lvItm.pszText = sTmp;
  if (SendMessage(hWnd,LVM_GETITEM,0,(LPARAM)&lvItm)>0) if (sTmp!=lvItm.pszText) {
    if (!dst) sTmp = lvItm.pszText;
    else cb_StrCopy(sTmp,lvItm.pszText);
  }
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_LVWSetText */
cb_Integer cb_DEFCALL cb_LVWSetText (HWND hWnd, const char *Str1, cb_Integer Index, cb_Integer iSub)
{
  LVITEM lvItm; cb_MemSet(&lvItm,0,sizeof(lvItm));

  if (Index<0) lvItm.iItem = SendMessage(hWnd,LVM_GETITEMCOUNT,0,0)-1;
  else lvItm.iItem = Index;
  lvItm.iSubItem = iSub;
  lvItm.mask = LVIF_TEXT;
  lvItm.pszText = (char*)Str1;
  return SendMessage(hWnd,LVM_SETITEM,0,(LPARAM)&lvItm);
}
/* END MODULE */


/* MODULE::cb_LVWInsertStr */
cb_Integer cb_DEFCALL cb_LVWInsertStr (HWND hWnd, const char *Str1, cb_Integer Index)
{
  LVITEM lvItm; cb_MemSet(&lvItm,0,sizeof(lvItm));

  lvItm.iItem = Index;
  lvItm.mask = LVIF_TEXT;
  lvItm.pszText = (char*)Str1;
  return SendMessage(hWnd,LVM_INSERTITEM,0,(LPARAM)&lvItm);
}
/* END MODULE */


/* MODULE::cb_LVWGetData */
cb_Integer cb_DEFCALL cb_LVWGetData (HWND hWnd, cb_Integer Index)
{
  LVITEM lvItm; cb_MemSet(&lvItm,0,sizeof(lvItm));

  if (Index<0) lvItm.iItem = SendMessage(hWnd,LVM_GETITEMCOUNT,0,0)-1;
  else lvItm.iItem = Index;
  lvItm.mask = LVIF_PARAM;
  SendMessage(hWnd,LVM_GETITEM,0,(LPARAM)&lvItm);
  return lvItm.lParam;
}
/* END MODULE */


/* MODULE::cb_LVWSetData */
cb_Integer cb_DEFCALL cb_LVWSetData (HWND hWnd, cb_Integer iData, cb_Integer Index)
{
  LVITEM lvItm; cb_MemSet(&lvItm,0,sizeof(lvItm));

  if (Index<0) lvItm.iItem = SendMessage(hWnd,LVM_GETITEMCOUNT,0,0)-1;
  else lvItm.iItem = Index;
  lvItm.mask = LVIF_PARAM;
  lvItm.lParam = iData;
  return SendMessage(hWnd,LVM_SETITEM,0,(LPARAM)&lvItm);
}
/* END MODULE */


/* MODULE::cb_GetWndPixel */
COLORREF cb_DEFCALL cb_GetWndPixel (HWND hWnd,cb_Integer X,cb_Integer Y,HDC hDC)
{
 register HDC DrawHDC = hDC;
 if (!DrawHDC) DrawHDC = GetDC(hWnd);
 cb_Integer i=GetPixel(DrawHDC,X,Y);
 if (!hDC) ReleaseDC(hWnd,DrawHDC);
 return i;
}
/* END MODULE */


/* MODULE::cb_IsInRect */
cb_Boolean cb_DEFCALL cb_IsInRect (HWND hWin, cb_Integer x, cb_Integer y)
{
  RECT rc1;
  POINT pt1;
  if (x==cb_MIN_INTEGER)
    GetCursorPos(&pt1);
  else {
    if (y==cb_MIN_INTEGER) GetCursorPos(&pt1); else pt1.y = y;
    pt1.x = x;
  }
  GetWindowRect(hWin,&rc1);
  return PtInRect(&rc1,pt1);
}
/* END MODULE */


/* MODULE::cb_SetWndOnTop */
cb_Boolean cb_DEFCALL cb_SetWndOnTop (HWND hWnd, cb_Integer Top, cb_Integer flags)
{
  register cb_Integer flags1 = flags, Top1 = Top;
  if (flags1==-1) {
    if (Top1>0) flags1 = SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW;
    else flags1 = SWP_NOMOVE|SWP_NOSIZE|SWP_NOSENDCHANGING|SWP_NOACTIVATE;
  }
  if (Top1!=0) Top1 = (cb_Integer)HWND_TOPMOST; else Top1 = (cb_Integer)HWND_NOTOPMOST;
  return SetWindowPos(hWnd,(HWND)Top1,0,0,0,0,flags1);
}
/* END MODULE */


/* MODULE::cb_BringToFront */
cb_Boolean cb_DEFCALL cb_BringToFront (HWND hWnd, cb_Integer Top, cb_Integer flags)
{
  register cb_Integer flags1 = flags, Top1 = Top;
  if (flags1==-1) {
    if (Top1>=0) flags1 = SWP_NOSIZE|SWP_NOMOVE|SWP_NOSENDCHANGING|SWP_NOOWNERZORDER;
    else flags1 = SWP_NOMOVE|SWP_NOSIZE|SWP_NOOWNERZORDER|SWP_SHOWWINDOW;
  }
  if (Top1!=0) Top1 = (cb_Integer)HWND_TOP; else Top1 = (cb_Integer)HWND_BOTTOM;
  return SetWindowPos(hWnd,(HWND)Top1,0,0,0,0,flags1);
}
/* END MODULE */


/* MODULE::cb_SetWndTransparency */
cb_Boolean cb_DEFCALL cb_SetWndTransparency (HWND hWnd, cb_Integer iTrans)
{
  register LONG_PTR iRet = GetWindowLongPtr(hWnd,GWL_EXSTYLE);
  if (iTrans<0) {
    if (iRet&WS_EX_LAYERED) {
      iRet &= ~WS_EX_LAYERED; SetWindowLongPtr(hWnd, GWL_EXSTYLE, iRet);
      return RedrawWindow(hWnd, 0, 0, RDW_ERASE | RDW_FRAME | RDW_INVALIDATE | RDW_ALLCHILDREN);
    }
    return iTrans;
  }
  if (!(iRet&WS_EX_LAYERED)) { iRet |= WS_EX_LAYERED; SetWindowLongPtr(hWnd,GWL_EXSTYLE,iRet); }
  if (iTrans > 255) iTrans = 255;
  return (cb_Boolean)SetLayeredWindowAttributes(hWnd, 0, iTrans, LWA_ALPHA);
}
/* END MODULE */


/* MODULE::cb_SetWndPos */
void cb_DEFCALL cb_SetWndPos (HWND hWnd, cb_Integer X, cb_Integer Y, cb_Integer W, cb_Integer H, HWND hWndP, cb_Integer bPaint)
{
  RECT r;
  register HWND hWnd1 = hWnd, hWnd2;
  register cb_Integer b = FALSE;
  if (W<0) {
    GetWindowRect(hWnd1, &r); b++;
    W = r.right - r.left;
  }
  if (H<0) {
    if (!b) { GetWindowRect(hWnd1, &r); b++; }
    H = r.bottom - r.top;
  }
  if (X==cb_MIN_INTEGER) {
    if (!b) GetWindowRect(hWnd1, &r);
    hWnd2 = hWndP;
    if (hWnd2) goto Screen0000;
    hWnd2 = GetParent(hWnd1);
    if (hWnd2) {
      hWnd1 = GetWindow(hWnd1, GW_OWNER);
Screen0000:
      if (hWnd1!=hWnd2) {
        ScreenToClient(hWnd2, (LPPOINT)&r);
      }
    }
    X = r.left;
    if (Y==cb_MIN_INTEGER) goto Y0000;
  }
  else if (Y==cb_MIN_INTEGER) {
    if (!b) GetWindowRect(hWnd1, &r);
    hWnd2 = hWndP;
    if (hWnd2) goto Screen1111;
    hWnd2 = GetParent(hWnd1);
    if (hWnd2) {
      hWnd1 = GetWindow(hWnd1, GW_OWNER);
Screen1111:
      if (hWnd1!=hWnd2) {
        ScreenToClient(hWnd2, (LPPOINT)&r);
      }
    }
Y0000:
    Y = r.top;
  }
  MoveWindow(hWnd,X,Y,W,H,bPaint);
}
/* END MODULE */


/* MODULE::cb_SetChildPos */
void cb_DEFCALL cb_SetChildPos (HWND hWnd, cb_Integer X, cb_Integer Y, cb_Integer W, cb_Integer H, cb_Integer bPaint)
{
  cb_SetWndPos(hWnd, X, Y, W, H, GetParent(hWnd), bPaint);
}
/* END MODULE */


/* MODULE::cb_GetWndLeft */
cb_Integer cb_DEFCALL cb_GetWndLeft (HWND hWnd, RECT *rc1, HWND hParent)
{
  register HWND hWnd1 = hWnd, hWnd2;
  if ((cb_UInteger)((cb_Integer)hWnd1-1)>=(cb_UInteger)-2) return 0;
  RECT r;
  if (!rc1) rc1=&r;
  GetWindowRect(hWnd1, rc1);
  hWnd2 = hParent;
  if (hWnd2) goto Screen0000;
  hWnd2 = GetParent(hWnd1);
  if (hWnd2) {
    hWnd1 = GetWindow(hWnd1, GW_OWNER);
Screen0000:
    if (hWnd1!=hWnd2) {
      ScreenToClient(hWnd2, (LPPOINT)rc1);
    }
  }
  return rc1->left;
}
/* END MODULE */


/* MODULE::cb_GetWndTop */
cb_Integer cb_DEFCALL cb_GetWndTop (HWND hWnd, HWND hParent)
{
  register HWND hWnd1 = hWnd, hWnd2;
  if ((cb_UInteger)((cb_Integer)hWnd1-1)>=(cb_UInteger)-2) return 0;
  RECT r; GetWindowRect(hWnd1, &r);
  hWnd2 = hParent;
  if (hWnd2) goto Screen0000;
  hWnd2 = GetParent(hWnd1);
  if (hWnd2) {
    hWnd1 = GetWindow(hWnd1, GW_OWNER);
Screen0000:
    if (hWnd1!=hWnd2) {
      ScreenToClient(hWnd2, (LPPOINT)&r);
    }
  }
  return r.top;
}
/* END MODULE */


/* MODULE::cb_GetWndWidth */
cb_Integer cb_DEFCALL cb_GetWndWidth (HWND hWnd, cb_Integer flag1, void *H)
{
  RECT r; cb_MemSet(&r,0,sizeof(r));

  if ((cb_UInteger)((cb_Integer)hWnd-1)>=(cb_UInteger)-2) hWnd = GetDesktopWindow();
  if (!flag1) GetWindowRect(hWnd, &r); else GetClientRect(hWnd, &r);
  if (H) *(cb_Integer*)H = r.bottom - r.top;
  return r.right - r.left;
}
/* END MODULE */


/* MODULE::cb_GetWndHeight */
cb_Integer cb_DEFCALL cb_GetWndHeight (HWND hWnd, cb_Integer flag1)
{
  cb_Integer H;

  cb_GetWndWidth(hWnd,flag1,&H);
  return H;
}
/* END MODULE */


/* MODULE::cb_GetMouseX */
cb_Integer cb_DEFCALL cb_GetMouseX (void *y, HWND hWin)
{
  POINT pt = {0};
  GetCursorPos(&pt);
  if (hWin) ScreenToClient(hWin,&pt);
  if (y) *(cb_Integer*)y = pt.y;
  return pt.x;
}
/* END MODULE */


/* MODULE::cb_GetMouseY */
cb_Integer cb_DEFCALL cb_GetMouseY (HWND hWin)
{
  cb_Integer y;
  return cb_GetMouseX(&y,hWin);
}
/* END MODULE */


/* MODULE::cb_SetMouseX */
void cb_DEFCALL cb_SetMouseX (cb_Integer x, cb_Integer y, HWND hWin)
{
  RECT rc;
  cb_Integer x1, y1; if (x<0||y<0) x1 = cb_GetMouseX(&y1,hWin);
  if (x<0) rc.left = x1; else rc.left = x;
  if (y<0) rc.top = y1; else rc.top = y;
  if (hWin) ClientToScreen(hWin,(LPPOINT)&rc);
  SetCursorPos(rc.left,rc.top);
}
/* END MODULE */


/* MODULE::cb_CenterWnd */
cb_Integer cb_DEFCALL cb_CenterWnd (HWND hWnd, HWND hWndP, cb_Integer iWidth, cb_Integer iHeight)
{
  RECT wRect, wRectP;
  register cb_Integer i;
  register cb_Integer x;
  register cb_Integer y;

  if (hWndP==NULL) {
    hWndP = GetWindow(hWnd, GW_OWNER);
    if (!hWndP) goto Desktop0000;
  }
  else if (hWndP==(HWND)-1) {
Desktop0000:
    hWndP = GetDesktopWindow();
  }
  GetWindowRect(hWndP, &wRectP);
  GetWindowRect(hWnd, &wRect);
  x = iWidth;
  if (x==cb_MIN_INTEGER) {
    i = wRectP.right - wRectP.left;
    x = wRect.right - wRect.left;
    x = ((i-x) / 2) + wRectP.left;
  }
  else if (x==(cb_MIN_INTEGER | 1)) {
    x = cb_GetWndLeft(hWnd);
  }
  y = iHeight;
  if (y==cb_MIN_INTEGER) {
    i = wRectP.bottom - wRectP.top;
    y = wRect.bottom - wRect.top;
    y = ((i-y) / 2) + wRectP.top;
  }
  else if (y==(cb_MIN_INTEGER | 1)) {
    y = cb_GetWndTop(hWnd);
  }
  SetWindowPos(hWnd, NULL, x, y, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOZORDER);
  return x;
}
/* END MODULE */


/* MODULE::cb_GetDesktopScale */
cb_Integer cb_DEFCALL cb_GetDesktopScale (cb_Integer n)
{
  register HDC hDC = GetDC(HWND_DESKTOP);
  register cb_Integer i = GetDeviceCaps(hDC, n);
  ReleaseDC(HWND_DESKTOP, hDC);
  return i;
}
/* END MODULE */


/* MODULE::cb_MakeFont */
HFONT cb_DEFCALL cb_MakeFont (const char *sFont, double PointSize, cb_Integer iBold, cb_Boolean bItalic, cb_Boolean bUnderline, cb_Boolean bStrikeOut, cb_Integer iCharSet, cb_Integer iDegrees)
{
  register double CyPixels = cb_GetDesktopScale(LOGPIXELSY); CyPixels *= PointSize; CyPixels /= 72.0;
  register cb_Integer i = iDegrees; i *= 10;
  if (iBold<0) iBold = 0; else if (iBold==0) iBold = FW_NORMAL; else if (iBold<100) iBold = FW_BOLD;
  return CreateFont(0 - (cb_Integer)CyPixels, 0,
    i,i,
    iBold,
    bItalic,bUnderline,bStrikeOut,
    iCharSet,
    OUT_TT_PRECIS,
    CLIP_DEFAULT_PRECIS,
    DEFAULT_QUALITY,
    FF_DONTCARE,sFont);
}
/* END MODULE */


/* MODULE::cb_SetWndColors */
HBRUSH cb_DEFCALL cb_SetWndColors (HDC hDC,cb_UInteger uMsg,COLORREF BkColr,COLORREF TxtColr,HBRUSH* hBrush,HWND hWnd)
{
  register HDC hDC1;
  register HBRUSH hBrush2;

  if (TxtColr==CLR_INVALID) {
    if (BkColr==CLR_INVALID) return NULL;
    hDC1 = hDC; if (!hDC1) hDC1 = GetDC(hWnd);
  }
  else {
    hDC1 = hDC; if (!hDC1) hDC1 = GetDC(hWnd);
    SetTextColor(hDC1,TxtColr);
    if (BkColr==CLR_INVALID) {
      if (uMsg==WM_CTLCOLORSTATIC) BkColr = GetSysColor(COLOR_BTNFACE);
      else if (uMsg==WM_CTLCOLORSCROLLBAR) BkColr = GetSysColor(COLOR_SCROLLBAR);
      else BkColr = GetBkColor(hDC1);
    }
  }
  if (hBrush) {
    hBrush2 = hBrush[0];
    if (hBrush2) goto Exit0000;
  }
  else {
    hBrush = &cbApp_hBrush;
    hBrush2 = cbApp_hBrush;
    if (hBrush2) DeleteObject(hBrush2);
  }
  hBrush2 = CreateSolidBrush(BkColr);
  hBrush[0] = hBrush2;
Exit0000:
  SetBkColor(hDC1,BkColr);
  if (!hDC) ReleaseDC(hWnd,hDC1);
  return hBrush2;
}
/* END MODULE */


/* MODULE::cb_FLBDir */
void cb_DEFCALL cb_FLBDir (HWND hWnd,const char* sPat,const char* dirPath,WPARAM wParam,cb_Integer flag1)
{
  register cb_Integer i, i1, i2, iLen;
  char *tmp = (char*)cb_MemAllocM(0x8000); if (!tmp) return;
  if (dirPath) cb_StrCopy(tmp, dirPath); else tmp[0] = 0;
  i2 = cb_StrLen(tmp);
  if (i2) if (tmp[i2-1]!='\\') if (tmp[i2-1]!='/') { *(short*)(tmp+i2)='\\'; i2++; }
  i1 = i2;
  SendMessage(hWnd,LB_RESETCONTENT,0,0);
  if (wParam==-1) wParam = DDL_ARCHIVE | DDL_SYSTEM | DDL_HIDDEN | DDL_READONLY | DDL_READWRITE;
  iLen = cb_StrLen(sPat);
  for(i=0;i<iLen;i++) {
    if (sPat[i]!=';') {
      tmp[i1] = sPat[i];
      ++i1;
    }
    else {
Again0000:;
      tmp[i1] = '\0';
      SendMessage(hWnd,LB_DIR,wParam,(LPARAM)(tmp));
      i1 = i2;
    }
  }
  if (i1>i2) {
    goto Again0000;
  }
  if (flag1) {
    i = SendMessage(hWnd,LB_GETCOUNT,0,0);
    while(i>0) {
      i--;
      SendMessage(hWnd,LB_GETTEXT,(WPARAM)i,(LPARAM)tmp);
      if (tmp[0]=='[') {
        i1 = cb_StrLen(tmp)-2; cb_MemCopy(tmp,tmp+1,i1); tmp[i1] = 0;
        SendMessage(hWnd,LB_DELETESTRING,(WPARAM)i,(LPARAM)tmp);
        SendMessage(hWnd,LB_INSERTSTRING,(WPARAM)i,(LPARAM)tmp);
      }
    }
  }
  cb_MemFreeM(tmp);
}
/* END MODULE */


/* MODULE::cb_FLBGetText */
char* cb_DEFCALL cb_FLBGetText (HWND hWnd,cb_Integer Ndx,void *dst,const char* dirPath)
{
  register char *sMsg = (char*)dst;
  if (!sMsg || sMsg==(char*)-1) { sMsg = (char*)cb_MemAllocM(0x2000); if (!sMsg) { if (dst) return NULL; return cb_EMPTYSTR; } }
  register cb_Integer idx; idx = Ndx; if (idx < 0) idx = SendMessage(hWnd,LB_GETCURSEL,0,0);
  register char *sDir; sDir = (char*)dirPath;
  cb_Integer i;

  sMsg[0] = 0;
  SendMessage(hWnd,LB_GETTEXT,(WPARAM)idx,(LPARAM)sMsg);
  if (sMsg[0]=='[') { idx = cb_StrLen(sMsg)-2; cb_MemCopy(sMsg,sMsg+1,idx); sMsg[idx] = 0; }
  if (!sDir || sDir[0]==0) {
    if (dst) return sMsg;
    sDir = cb_NewTempStr(sMsg); goto Free0000;
  }
  if (*(short*)sMsg=='.') {
    idx = -1;
    goto Left0000;
  }
  idx = cb_StrLen(sDir)-1;
  if (*(short*)sMsg=='..') if (sMsg[2]==0) {
    if (sDir[idx]!='\\') if (sDir[idx]!='/') idx=-1;
    i = idx;
    idx = cb_InCharRev(sDir,'\\',idx); if (idx<0) idx = cb_InCharRev(sDir,'/',i);
Left0000:
    sDir = cb_Left(sDir,idx,dst);
    goto EndSelect_0;
  }
  if (sDir[idx]!='\\') if (sDir[idx]!='/') {
    cb_StrMove(sMsg+1,sMsg); sMsg[0]='\\';
  }
  sDir = cb_StrJoin(dst,sDir,sMsg,NULL);
EndSelect_0:
  if (!dst || dst==(void*)-1) { Free0000:; cb_MemFreeM(sMsg); }
  return sDir;
}
/* END MODULE */


/* MODULE::cb_DCBFill */
cb_Integer cb_DEFCALL cb_DCBFill (HWND hWnd)
{
  register cb_Integer i1;
  register cb_Integer i2;
  register cb_Integer i3;
  char *sBuf;
  char sType[512];
  char sVol[256];
  char sDrives[80];

  cb_GetDrives(2,sDrives);
  SendMessage(hWnd, CB_RESETCONTENT, 0, 0);
  i3 = 0;
  i1 = 0;
  do {
    i2 = cb_StrLen(sDrives+i1);
    if (i2==0) {
      break;
    }
    sBuf = sDrives+i1;
    cb_MemCopy(sType,sBuf,2);
    sVol[0] = 0;
    sType[2] = '\0';
    GetVolumeInformation(sBuf,sVol,sizeof(sVol),NULL,NULL,NULL,sType+2,sizeof(sType)-2);
    if (sVol[0]!=0) {
      cb_StrCat(sVol,", ");
      goto Ok0000;
    }
    if (sType[2]) {
Ok0000:;
      cb_StrInsert(sVol," [",0,sVol);
      cb_StrInsert(sType+2,sVol,0,sType+2);
      cb_StrCat(sType+2,"]");
    }
    SendMessage(hWnd,CB_ADDSTRING,0,(LPARAM)sType);
    i1 += i2;
    ++i1;
    ++i3;
  }while(1);
  cb_GetCurrentDir(0,sType); cb_Left(sType,1,sType);
  SendMessage(hWnd,CB_SELECTSTRING,0,(LPARAM)sType);
  return i3;
}
/* END MODULE */


/* MODULE::cb_DCBGetText */
char* cb_DEFCALL cb_DCBGetText (HWND hWnd,cb_Integer Ndx,void* sBuf,cb_Integer iNum)
{
  char sDrive[1024];
  cb_CBGetText(hWnd,Ndx,sDrive);
  return cb_Left(sDrive,iNum,sBuf);
}
/* END MODULE */


/* MODULE::cb_GetMenuItem */
char * cb_DEFCALL cb_GetMenuItem (HMENU hMnu, cb_Integer id, void *dst, cb_Integer bPos, void *flags1, cb_Integer tipe)
{
  register char *sTmp;
  register cb_Integer i;
  MENUITEMINFO c1; cb_MemSet(&c1,0,sizeof(c1));

  c1.cbSize=sizeof(c1);
  c1.fMask=MIIM_TYPE;
  i = tipe; if (i<0) i = MFT_STRING;
  c1.fType=i;
  GetMenuItemInfo(hMnu,id,bPos,&c1);
  sTmp = (char*)dst;
  if (!(i&MFT_BITMAP)) if (tipe) {
    if (!sTmp || sTmp==(char*)-1) {
      sTmp = cb_NewStr_(NULL,sTmp,c1.cch);
      if (!sTmp) { if (!dst) return cb_EMPTYSTR; goto Exit0000; }
    }
    c1.cch++;
    c1.dwTypeData=sTmp;
    sTmp[0]=0;
  }
  c1.fMask=MIIM_TYPE;
  c1.fType=i;
  if (flags1) c1.fMask|=MIIM_STATE;
  GetMenuItemInfo(hMnu,id,bPos,&c1);
  if (flags1) *(cb_UInteger*)flags1 = c1.fState;
  if (i&MFT_BITMAP) *(HBITMAP*)sTmp = (HBITMAP)LOWORD(c1.dwTypeData);
  else if (!tipe) *(HBITMAP*)sTmp = c1.hbmpItem;
Exit0000:
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_SetMenuItem */
cb_Boolean cb_DEFCALL cb_SetMenuItem (HMENU hMnu, const char *Str1, cb_Integer id, cb_Integer bPos, HBITMAP hBmp, cb_Integer tipe, cb_Integer flags)
{
  register cb_Integer i=id, j=bPos;
  MENUITEMINFO c1; cb_MemSet(&c1,0,sizeof(c1));

  c1.cbSize=sizeof(c1);
  if (i<0) { c1.fMask=MIIM_DATA; c1.dwItemData = (UINT_PTR)j; i &= 0x7fffffff; j = TRUE; }
  else if (j>1) { c1.fMask=MIIM_ID; c1.wID=i; i = j; }
  if (flags!=-1) { c1.fMask|=MIIM_STATE; c1.fState = flags; }
  if (Str1) {
    if (tipe==-1) {
      c1.fMask|=MIIM_BITMAP; c1.hbmpItem = (HBITMAP)Str1;
    }
    else {
      c1.fMask|=MIIM_FTYPE | MIIM_STRING;
      if ((tipe & MFT_BITMAP)!=0) { c1.fType|=MFT_BITMAP; c1.dwTypeData = (char*)Str1; }
      else if (Str1[0]==0 || *(short*)Str1=='-') c1.fType=MFT_SEPARATOR;
      else { c1.fType=MFT_STRING; c1.dwTypeData=(char*)Str1; }
      c1.fType|=tipe;
    }
  }
  if (hBmp) {
    c1.fMask|=MIIM_BITMAP;
    c1.hbmpItem = hBmp;
  }
  return SetMenuItemInfo(hMnu,i,j,&c1);
}
/* END MODULE */


/* MODULE::cb_GetMenuData */
DWORD cb_DEFCALL cb_GetMenuData (HMENU hMnu, cb_Integer id, cb_Integer bPos)
{
  MENUITEMINFO c1; cb_MemSet(&c1,0,sizeof(c1));

  c1.cbSize=sizeof(c1);
  c1.fMask=MIIM_DATA;
  GetMenuItemInfo(hMnu,id,bPos,&c1);
  return c1.dwItemData;
}
/* END MODULE */


/* MODULE::cb_SetMenuData */
cb_Boolean cb_DEFCALL cb_SetMenuData (HMENU hMnu, DWORD dwItemData, cb_Integer id, cb_Integer bPos)
{
  MENUITEMINFO c1; cb_MemSet(&c1,0,sizeof(c1));

  c1.cbSize=sizeof(c1);
  c1.fMask=MIIM_DATA; c1.dwItemData = dwItemData;
  return SetMenuItemInfo(hMnu,id,bPos,&c1);
}
/* END MODULE */


/* MODULE::cb_ShowPopupMenu */
cb_Integer cb_DEFCALL cb_ShowPopupMenu (HMENU hMnu, HWND hWnd, cb_UInteger dwFlags, cb_Integer x, cb_Integer y)
{
  register cb_Integer x1 = x;
  cb_Integer y1;

  if (x1<0 || y<0) {
    x = cb_GetMouseX(&y1);
    if (x1<0) x1 = x;
    if (y<0) y = y1;
  }
  if (hWnd==NULL) hWnd = GetActiveWindow();
  if (dwFlags==(cb_UInteger)-1) dwFlags = TPM_LEFTALIGN | TPM_TOPALIGN;
  return TrackPopupMenu(hMnu,dwFlags,x1,y,0,hWnd,NULL);
}
/* END MODULE */


/* MODULE::cb_ShowWindow */
cb_Integer cb_DEFCALL cb_ShowWindow (HWND hWnd, cb_Integer b, cb_Integer c)
{
  register cb_Integer i = b;

  if (i==0) i = SW_HIDE;
  else if (c<0) i = SW_SHOWNA;
  else if (i==1) { i = c ? SW_SHOWNORMAL : SW_SHOWNOACTIVATE; }
  else if (i==2) { i = c ? SW_SHOWMINIMIZED : SW_MINIMIZE; }
  else if (i==3) { i = c ? SW_SHOWMAXIMIZED : SW_MAXIMIZE; }
  else { i = c ? SW_SHOW : SW_SHOWNA; }
  return ShowWindow(hWnd,i);
}
/* END MODULE */


/* MODULE::cb_GetWindowState */
cb_Integer cb_DEFCALL cb_GetWindowState (HWND hWnd)
{
  if (IsMaximized(hWnd)) return 2;
  if (IsMinimized(hWnd)) return 1;
  return 0;
}
/* END MODULE */


/* MODULE::cb_GetWndScale */
cb_Integer cb_DEFCALL cb_GetWndScale (void *Y, HWND hWnd, cb_Integer x1, cb_Integer y1)
{
  RECT rc = {0, 0, 4, 8};

  MapDialogRect(hWnd, &rc);
  if (Y) *(cb_Integer*)Y = rc.bottom/y1;
  return rc.right/x1;
}
/* END MODULE */


/* MODULE::cb_OpenDrawSession */
HDC cb_DEFCALL cb_OpenDrawSession (HWND hWnd, HANDLE *dst, cb_Integer flag1)
{
  register HBITMAP  hBmp;
  register HDC  hdcDest, hDC;
  RECT rc;
  hBmp = (HBITMAP)SendMessage(hWnd,STM_GETIMAGE,0,0);
  hDC = GetDC(hWnd);
  if (hBmp==NULL) {
    GetClientRect(hWnd,&rc);
    hBmp = CreateCompatibleBitmap(hDC,rc.right,rc.bottom);
  }
  hdcDest = CreateCompatibleDC(hDC);
  ReleaseDC(hWnd,hDC);
  hBmp = (HBITMAP)SelectObject(hdcDest,hBmp);
  if (dst) *dst = (HANDLE)hBmp; else SetPropA(hWnd,"cb_bmpOld",(HANDLE)hBmp);
  if (flag1) SetPropA(hWnd,"cb_hdcDest",(HANDLE)hdcDest);
  return hdcDest;
}

HBITMAP cb_DEFCALL cb_CloseDrawSession (HWND hWnd, HDC hdcDest, HANDLE src, cb_Integer bDel)
{
  register HBITMAP  hBmp;
  if (src) hBmp = (HBITMAP)src; else hBmp = (HBITMAP)RemovePropA(hWnd,"cb_bmpOld");
  if (!hdcDest) hdcDest = (HDC)RemovePropA(hWnd,"cb_hdcDest");
  hBmp = (HBITMAP)SelectObject(hdcDest,hBmp); DeleteDC(hdcDest);
  return cb_SetWndImage(hWnd,hBmp,bDel);
}
/* END MODULE */


/* MODULE::cb_GetToolTip */
char * cb_DEFCALL cb_GetToolTip (HWND hWnd, HWND hWndTool, void *dst, HWND hWndPrnt)
{
  TOOLINFO ti;
  register char *sTmp;
  register HWND hWndP, hWndT;

  cb_MemSet(&ti,0,sizeof(ti));
  ti.lpszText = (LPTSTR)cb_MemAllocM(0x8192);
  if (!ti.lpszText) return NULL;
  ti.lpszText[0]=0;
  sTmp = (char*)dst;
  hWndP = hWndPrnt;
  if (hWndP==NULL) {
    hWndP = GetParent(hWnd);
    if (hWndP==NULL || hWndP==GetWindow(hWnd, GW_OWNER)) goto Exit0000;
  }
  hWndT = hWndTool;
  if (hWndT) {
    ti.cbSize = sizeof(ti);
    ti.hwnd = hWndP;
    ti.uId = (cb_UInteger)hWnd;
    SendMessage(hWndT,TTM_GETTOOLINFO,0,(LPARAM)&ti);
  }
Exit0000:;
  if (!sTmp || sTmp==(char*)-1) sTmp = cb_NewStr_(ti.lpszText,sTmp,cb_StrLen(ti.lpszText));
  else cb_StrCopy(sTmp,ti.lpszText);
  cb_MemFreeM(ti.lpszText);
  return sTmp;
}
/* END MODULE */


/* MODULE::cb_CreateToolTip */
HWND cb_DEFCALL cb_CreateToolTip (HWND hWnd, DWORD flags1)
{
  if (hWnd==NULL) { hWnd = GetActiveWindow(); if (hWnd==NULL) return NULL; }
  if (flags1==(DWORD)-1) flags1 = WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP;
  register HWND A; A = CreateWindowEx(0,TOOLTIPS_CLASS,NULL,flags1,0,0,0,0,hWnd,0,cbApp_hInstance,0);
  return A;
}
/* END MODULE */


/* MODULE::cb_SetToolTip */
HWND cb_DEFCALL cb_SetToolTip (HWND hWnd, const char *sText, HWND hWndTool, HWND hWndPrnt, cb_Integer iInitial, cb_Integer iPause, DWORD flags1)
{  TOOLINFO ti;
  register HWND hWndT, hWndP = hWndPrnt;
  register cb_Integer i;

  if (hWndP==NULL) { hWndP = GetParent(hWnd); if (hWndP==NULL || hWndP==GetWindow(hWnd, GW_OWNER)) return NULL; }
  hWndT = hWndTool;
  cb_MemSet(&ti,0,sizeof(ti));
  ti.cbSize = sizeof(ti);
  ti.hwnd = hWndP;
  ti.uId = (cb_UInteger)hWnd;
  if (hWndT==NULL) {
      if (sText) hWndT = cb_CreateToolTip(hWndP, flags1);
      if (hWndT==NULL) return NULL;
      goto New0000;
  }
  if (SendMessage(hWndT,TTM_GETTOOLINFO,0,(LPARAM)&ti)) if (sText) {
    if (sText==(const char*)-1) goto ChkTime0000;
    if (cb_StrLen(sText)<80) {
      i = TTM_SETTOOLINFO;
      goto SendMsg0000;
    }
  }
  SendMessage(hWndT,TTM_DELTOOL,0,(LPARAM)&ti);
  if (sText) {
New0000:
    i = TTM_ADDTOOL;
SendMsg0000:
    ti.uFlags = TTF_SUBCLASS | TTF_IDISHWND;
    ti.lpszText = (char*)sText;
    SendMessage(hWndT,i,0,(LPARAM)&ti);
ChkTime0000:
  if (!iInitial) { iInitial--; goto Initial0000; }
  if (iInitial>0) {
Initial0000:
    SendMessage(hWndT,TTM_SETDELAYTIME,TTDT_INITIAL,iInitial);
  }
  if (!iPause) { iPause--; goto Pause0000; }
  if (iPause>0) {
Pause0000:
    SendMessage(hWndT,TTM_SETDELAYTIME,TTDT_AUTOPOP,iPause);
  }
  }
  return hWndT;
}
/* END MODULE */


/* MODULE::cb_DelToolTip */
void cb_DEFCALL cb_DelToolTip (HWND hWnd, HWND hWndTool, HWND hWndPrnt)
{
  TOOLINFO ti;
  register HWND hWndT, hWndP;

  hWndP = hWndPrnt; if (hWndP==NULL) { hWndP = GetParent(hWnd); if (hWndP==NULL) return; if (hWndP==GetWindow(hWnd, GW_OWNER)) return; }
  hWndT = hWndTool; if (hWndT==NULL) { return; }
  cb_MemSet(&ti,0,sizeof(ti));
  ti.cbSize = sizeof(ti);
  ti.hwnd = hWndP;
  ti.uId = (cb_UInteger)hWnd;
    SendMessage(hWndT,TTM_DELTOOL,0,(LPARAM)&ti);}
/* END MODULE */


/* MODULE::cb_Clw */
void cb_DEFCALL cb_Clw (HWND hWnd, COLORREF iClr, cb_Integer iTrans, HBRUSH hBrush, HDC hDC, RECT *rc1)
{
  register HBRUSH hBrush1 = hBrush;
  register HDC hDC1 = hDC, hDC2;
  register HBITMAP hBmp1;
  register HWND hWin = hWnd;
  BLENDFUNCTION bfn;
  cb_Integer x, y;
  RECT rc2;

  if ((cb_UInteger)((cb_Integer)hWin-1)>=(cb_UInteger)-2) {
    hWin = GetDesktopWindow(); if (hWnd) hWnd = hWin;
  }
  if (rc1) cb_MemCopy(&rc2,rc1,sizeof(rc2)); else GetClientRect(hWin,&rc2);
  if (!hDC1) hDC1 = GetDC(hWnd);
  if (!hBrush1) {
    if (iClr==CLR_INVALID) { hBrush1 = (HBRUSH)GetClassLongPtr(hWin,GCLP_HBRBACKGROUND); hBrush = (HBRUSH)1; }
    else hBrush1 = CreateSolidBrush(iClr);
  }
  if (iTrans>0) {
    x = rc2.left; rc2.left = 0; rc2.right -= x; y = rc2.top; rc2.top = 0; rc2.bottom -= y;
    hBmp1 = CreateCompatibleBitmap(hDC1,rc2.right,rc2.bottom);
    hDC2 = CreateCompatibleDC(hDC1);
    hBmp1 = (HBITMAP)SelectObject(hDC2,hBmp1);
  }
  else {
    hDC2 = hDC1;
  }
  FillRect(hDC2,&rc2,hBrush1);
  if (iTrans>0) {
    bfn.BlendOp = AC_SRC_OVER; bfn.BlendFlags = 0; bfn.SourceConstantAlpha = iTrans; bfn.AlphaFormat = 0;
    AlphaBlend(hDC1,x,y,rc2.right,rc2.bottom,hDC2,0,0,rc2.right,rc2.bottom,bfn); // Display bitmap
    hBmp1 = (HBITMAP)SelectObject(hDC2,hBmp1); DeleteDC(hDC2); DeleteObject(hBmp1);
  }
  if (!hDC) ReleaseDC(hWnd,hDC1);
  if (!hBrush) DeleteObject((HANDLE)hBrush1);
}
/* END MODULE */


/* MODULE::cb_PrintText */
cb_Integer cb_DEFCALL cb_PrintText (HWND hWnd, const char *sText, cb_Integer x, cb_Integer y, COLORREF Clr, cb_Integer bTrans, HDC hDC, void *hFont, cb_Integer iLen)
{
  register HDC DrawHDC = hDC;
  register cb_Integer iOldBkMode;
  if (!DrawHDC) DrawHDC = GetDC(hWnd);
  if (bTrans) iOldBkMode = SetBkMode(DrawHDC, TRANSPARENT);
  if (hFont) hFont = SelectObject(DrawHDC, hFont);
  if (Clr!=CLR_INVALID) SetTextColor(DrawHDC, Clr);
  register cb_Integer a = iLen; if (a<=0) a = cb_StrLen(sText);
  a = TextOut(DrawHDC,x,y,sText,a);
  if (hFont) SelectObject(DrawHDC, hFont);
  if (bTrans) SetBkMode(DrawHDC, iOldBkMode);
  if (!hDC) ReleaseDC(hWnd,DrawHDC);
  return a;
}
/* END MODULE */


/* MODULE::cb_Plot */
cb_Boolean cb_DEFCALL cb_Plot (HWND hWnd, cb_Integer iLeft, cb_Integer iTop, COLORREF iColor, HDC hDCdst)
{
  register HDC hDC = hDCdst;
  register COLORREF iC = iColor;

  if (!hDC) {
      hDC = GetDC(hWnd);
  }
  if (iC==CLR_INVALID) iC = GetBkColor(hDC);
  iC = (COLORREF)SetPixelV(hDC,iLeft,iTop,iC);
  if (!hDCdst) ReleaseDC(hWnd, hDC);
  return (cb_Boolean)iC;
}
/* END MODULE */


/* MODULE::cb_DrawRoundRect */
void cb_DEFCALL cb_DrawRoundRect (HWND hWnd, cb_Integer x, cb_Integer y, cb_Integer w, cb_Integer h, COLORREF Clr1, COLORREF Clr2, cb_Integer iTrans, HDC hDC, HBRUSH hbr, HPEN hpen, cb_Integer iWeight, cb_Integer iStyle, cb_Integer angleW, cb_Integer angleH, cb_Integer flag1)
{
  register HDC hDC1 = hDC, hDC2; if (!hDC1) hDC1 = GetDC(hWnd);
  register HBRUSH hbr1 = hbr;
  register HPEN hpen1 = hpen;
  register HBITMAP hBmp1;
  register HRGN hrgn;
  RECT rc1;
  BLENDFUNCTION bfn;
  cb_Integer x1, y1;

  if (x==cb_MIN_INTEGER || y==cb_MIN_INTEGER || w<=0 || h<=0) {
    GetClientRect(hWnd,&rc1);
    if (x==cb_MIN_INTEGER) x = rc1.left;
    if (y==cb_MIN_INTEGER) y = rc1.top;
    if (w<=0) w = rc1.right - x;
    if (h<=0) h = rc1.bottom - y;
  }
  if (iTrans>0) {
    x1 = 0; y1 = 0;
    hBmp1 = CreateCompatibleBitmap(hDC1,w,h);
    hDC2 = CreateCompatibleDC(hDC1);
    hBmp1 = (HBITMAP)SelectObject(hDC2,hBmp1);
  }
  else {
    x1 = x; y1 = y;
    hDC2 = hDC1;
  }
  if (hpen1) goto Pen0001;
  if (Clr1!=CLR_INVALID) {
    if (iWeight<0) iWeight = 0;
    goto Pen0000;
  }
  if (iWeight>=0) {
    Clr1 = GetBkColor(hDC2);
Pen0000:
    hpen1 = CreatePen(iStyle,iWeight,Clr1);
Pen0001:
    hpen1 = (HPEN)SelectObject(hDC2, hpen1);
  }
  if (hbr1) goto Brush0000;
  if (Clr2==CLR_INVALID) {
    if (hpen1) { hbr1 = (HBRUSH)GetStockObject(HOLLOW_BRUSH); goto Brush0000; }
  }
  else {
    hbr1 = CreateSolidBrush(Clr2);
Brush0000:
    hbr1 = (HBRUSH)SelectObject(hDC2, hbr1);
  }
  if (flag1==2) {
    Rectangle(hDC2, x1, y1, x1+w, y1+h);
    if (iTrans>0) goto Trans0000;
  }
  else {
    if (flag1==1) Ellipse(hDC2, x1, y1, x1+w, y1+h);
    else RoundRect(hDC2, x1, y1, x1+w, y1+h, angleW, angleH);
    if (iTrans>0) {
      if (flag1==1) hrgn = CreateEllipticRgn(x, y, x+w+1, y+h+1);
      else hrgn = CreateRoundRectRgn(x, y, x+w+1, y+h+1, angleW, angleH);
      SelectClipRgn(hDC1,hrgn);
Trans0000:
      bfn.BlendOp = AC_SRC_OVER;
      bfn.BlendFlags = 0;
      bfn.SourceConstantAlpha = iTrans;
      bfn.AlphaFormat = 0;
      AlphaBlend(hDC1,x,y,w,h,hDC2,0,0,w,h,bfn); // Display bitmap
      if (flag1!=2) {
        SelectClipRgn(hDC1,NULL); DeleteObject(hrgn);
      }
      DeleteObject(SelectObject(hDC2,hBmp1));
    }
  }
  if (hpen1) { hpen1 = (HPEN)SelectObject(hDC2, hpen1); if (hpen==NULL) DeleteObject(hpen1); }
  if (hbr1) { hbr1 = (HBRUSH)SelectObject(hDC2, hbr1); if (hbr==NULL) if (Clr2!=CLR_INVALID) DeleteObject(hbr1); }
  if (hDC1!=hDC2) DeleteDC(hDC2);
  if (!hDC) ReleaseDC(hWnd, hDC1);
}
/* END MODULE */


/* MODULE::cb_DrawLine */
void cb_DEFCALL cb_DrawLine (void *Ptr1, cb_Integer x1, cb_Integer y1, cb_Integer x2, cb_Integer y2, COLORREF iColor, cb_Integer iTrans, HDC hDC, HPEN hPen, cb_Integer iWeight, cb_Integer iStyle)
{
  RECT rc1;
  register cb_Integer i;
  register HDC hDC1 = hDC, hDC2;
  register HWND hWnd;
  HPEN hPen1 = hPen;
  HBITMAP hBmp1;
  BLENDFUNCTION bfn;
  POINT pt1;
  HBRUSH hbr1;
  cb_Integer x, y;

  if (hDC1) {
    i = OBJ_DC; hWnd = (HWND)Ptr1;
  }
  else {
    hDC1 = (HDC)Ptr1;
    i = GetObjectType((HGDIOBJ)hDC1);
    if (i==OBJ_DC) hWnd = NULL;
    else { hWnd = (HWND)hDC1; hDC1 = GetDC(hWnd); }
  }
  if (x2<0) {
    if (!hWnd) hWnd = WindowFromDC(hDC1);
    GetClientRect(hWnd,&rc1);
    x2 = rc1.right; goto Bottom0000;
  }
  if (y2<0) {
    if (!hWnd) hWnd = WindowFromDC(hDC1);
    GetClientRect(hWnd,&rc1);
Bottom0000:
    y2 = rc1.bottom;
  }
  if (iTrans>0) {
    if (x1<0 || y1<0) {
      MoveToEx(hDC1, 0, 0, &pt1);
      if (x1<0) x1 = pt1.x;
      if (y1<0) y1 = pt1.y;
    }
    x = x2-x1; y = y2-y1;
    hBmp1 = CreateCompatibleBitmap(hDC1,x,y);
    hDC2 = CreateCompatibleDC(hDC1);
    hBmp1 = (HBITMAP)SelectObject(hDC2,hBmp1);
    hbr1 = CreateSolidBrush(0x00000000);
    if (hbr1) {
      rc1.left = 0; rc1.top = 0; rc1.right = x; rc1.bottom = y;
      FillRect(hDC2,&rc1,hbr1);
      DeleteObject(hbr1);
    }
  }
  else {
    x = x2; y = y2;
    hDC2 = hDC1;
    if (x1>=0) MoveToEx(hDC1, x1, y1, (LPPOINT)NULL);
  }
  if (hPen1) goto Pen0001;
  if (iColor!=CLR_INVALID) {
    if (iWeight<0) iWeight = 0;
    goto Pen0000;
  }
  if (iWeight>=0) {
    iColor = 0;
Pen0000:
    hPen1 = CreatePen(iStyle, iWeight, iColor);
Pen0001:
    hPen1 = (HPEN)SelectObject(hDC2, hPen1);
  }
  LineTo(hDC2, x, y);
  if (iTrans>0) {
    bfn.BlendOp = AC_SRC_OVER; bfn.BlendFlags = 0; bfn.SourceConstantAlpha = iTrans; bfn.AlphaFormat = 0;
    AlphaBlend(hDC1,x1,y1,x,y,hDC2,0,0,x,y,bfn); // Display bitmap
    MoveToEx(hDC1, x2, y2, (LPPOINT)NULL);
    hBmp1 = (HBITMAP)SelectObject(hDC2,hBmp1); DeleteDC(hDC2); DeleteObject(hBmp1);
  }
  if (hPen1) { hPen1 = (HPEN)SelectObject(hDC1, hPen1); if (hPen==NULL) DeleteObject(hPen1); }
  if (i!=OBJ_DC) ReleaseDC(hWnd, hDC1);
}
/* END MODULE */


/* MODULE::cb_DrawLineTo */
void cb_DEFCALL cb_DrawLineTo (void *Ptr1, cb_Integer x, cb_Integer y, COLORREF iColor, cb_Integer iTrans, HDC hDC, HPEN hPen, cb_Integer iWeight, cb_Integer iStyle)
{
  cb_DrawLine(Ptr1,-1,-1,x,y,iColor,iTrans,hDC,hPen,iWeight,iStyle);
}
/* END MODULE */


/* MODULE::cb_DrawGradientRect */
void cb_DEFCALL cb_DrawGradientRect (HDC hDC,cb_Integer x,cb_Integer y,cb_Integer w,cb_Integer h,COLORREF crTop,COLORREF crBot,cb_Integer Di)
{
  GRADIENT_RECT gRect;
  TRIVERTEX vertex[2];
  vertex[0].x = x;
  vertex[0].y = y;
  vertex[0].Red = GetRValue(crTop)<<8;
  vertex[0].Green = GetGValue(crTop)<<8;
  vertex[0].Blue = GetBValue(crTop)<<8;
  vertex[0].Alpha = 0;
  vertex[1].x = w;
  vertex[1].y = h;
  vertex[1].Red = GetRValue(crBot)<<8;
  vertex[1].Green = GetGValue(crBot)<<8;
  vertex[1].Blue = GetBValue(crBot)<<8;
  vertex[1].Alpha = 0;
  gRect.UpperLeft = 0;
  gRect.LowerRight = 1;
  GradientFill(hDC,vertex,2,&gRect,1,Di?GRADIENT_FILL_RECT_V:GRADIENT_FILL_RECT_H);
}
/* END MODULE */


/* MODULE::cb_CreateGradientBMP */
HBITMAP cb_DEFCALL cb_CreateGradientBMP (HWND hWnd, COLORREF clr1, COLORREF clr2, HDC hDC, HDC *pDC, cb_Integer w, cb_Integer h)
{
  register HDC hDC1 = hDC; if (hDC1==NULL) hDC1 = GetDC(hWnd);
  register HDC hDC2 = CreateCompatibleDC(hDC1);
  register HBITMAP hBmp;
  RECT tRECT;

  if (w<0 || h<0) {
    GetClientRect(hWnd, &tRECT);
    if (w<0) w = tRECT.right  - tRECT.left;
    if (h<0) h = tRECT.bottom - tRECT.top;
  }

  hBmp = CreateCompatibleBitmap(hDC1, w, h);
  if (hDC==NULL) ReleaseDC(hWnd, hDC1);
  hBmp = (HBITMAP)SelectObject(hDC2, hBmp);

/*
  ' note: setting mid-point a little LOWER than half-way, so as to
  '   make it appear that the light source is comming from overhead...
  ' note: setting mid-point a little HIGHER than half-way, so as to
  '   make it appear that the light source is comming from overhead...
*/
  cb_DrawGradientRect(hDC2, 0, 0, w, h, clr1, clr2);
  if (pDC) *pDC = hDC2;
  else { hBmp = (HBITMAP)SelectObject(hDC2,hBmp); DeleteDC(hDC2); }

  return hBmp;
}
/* END MODULE */


/* MODULE::cb_PicGetBitmap */
HBITMAP cb_DEFCALL cb_PicGetBitmap (HWND hWnd)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) j = (cb_TPictureBox *)(j->hBmp);
  return (HBITMAP)j;
}
/* END MODULE */


/* MODULE::cb_PicSetBitmap */
HBITMAP cb_DEFCALL cb_PicSetBitmap (HWND hWnd, void *hBmp, cb_Boolean flag1)
{
  register HBITMAP i = NULL;
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) {
    i = j->hBmp; j->hBmp = (HBITMAP)hBmp;
    if (flag1) InvalidateRect(hWnd, NULL, 0);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_PicGetForeColor */
COLORREF cb_DEFCALL cb_PicGetForeColor (HWND hWnd)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) return j->ForeColor;
  return -1;
}
/* END MODULE */


/* MODULE::cb_PicSetForeColor */
void cb_DEFCALL cb_PicSetForeColor (HWND hWnd, COLORREF cColor, cb_Boolean flag1)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) {
    j->ForeColor = cColor;
    if (flag1) InvalidateRect(hWnd, NULL, 0);
  }
}
/* END MODULE */


/* MODULE::cb_PicGetBackColor */
COLORREF cb_DEFCALL cb_PicGetBackColor (HWND hWnd)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) return j->BackColor;
  return -1;
}
/* END MODULE */


/* MODULE::cb_PicSetBackColor */
void cb_DEFCALL cb_PicSetBackColor (HWND hWnd, COLORREF cColor, cb_Boolean flag1)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) {
    j->BackColor = cColor;
    if (j->hBrush) { DeleteObject(j->hBrush); j->hBrush = NULL; }
    if (flag1) InvalidateRect(hWnd, NULL, 0);
  }
}
/* END MODULE */


/* MODULE::cb_PicGetFont */
HFONT cb_DEFCALL cb_PicGetFont (HWND hWnd)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) j = (cb_TPictureBox *)(j->hFont);
  return (HFONT)j;
}
/* END MODULE */


/* MODULE::cb_PicSetFont */
HFONT cb_DEFCALL cb_PicSetFont (HWND hWnd, HFONT hFnt, cb_Boolean flag1)
{
  register HFONT i = NULL;
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) {
    i = j->hFont; j->hFont = hFnt;
    if (flag1) InvalidateRect(hWnd, NULL, 0);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_PicGetStretch */
cb_Boolean cb_DEFCALL cb_PicGetStretch (HWND hWnd)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) j = (cb_TPictureBox *)(j->iStretch & 1);
  return (cb_Boolean)j;
}
/* END MODULE */


/* MODULE::cb_PicSetStretch */
cb_Boolean cb_DEFCALL cb_PicSetStretch (HWND hWnd, cb_Boolean bVal, cb_Boolean flag1)
{
  register cb_Boolean i = FALSE;
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) {
    i = j->iStretch & 1; if (bVal) j->iStretch |= 1; else j->iStretch &= ~1;
    if (flag1) InvalidateRect(hWnd, NULL, 0);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_PicGetTransparency */
cb_Integer cb_DEFCALL cb_PicGetTransparency (HWND hWnd)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) j = (cb_TPictureBox *)(j->iTrans);
  return (cb_Integer)j;
}
/* END MODULE */


/* MODULE::cb_PicSetTransparency */
cb_Integer cb_DEFCALL cb_PicSetTransparency (HWND hWnd, cb_Integer iVal, cb_Boolean flag1)
{
  register cb_Integer i = 0;
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) {
    i = j->iTrans; j->iTrans = iVal;
    if (flag1) InvalidateRect(hWnd, NULL, 0);
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_PicGetUserData */
cb_Integer cb_DEFCALL cb_PicGetUserData (HWND hWnd)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");

  if (j) j = (cb_TPictureBox *)(j->UserData);
  return (cb_Integer)j;
}
/* END MODULE */


/* MODULE::cb_PicSetUserData */
cb_Integer cb_DEFCALL cb_PicSetUserData (HWND hWnd, cb_Integer iVal)
{
  register cb_TPictureBox *j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
  cb_Integer i = 0;

  if (j) {
    i = j->UserData; j->UserData = iVal;
  }
  return i;
}
/* END MODULE */


/* MODULE::cb_PicCls */
void cb_DEFCALL cb_PicCls (HWND hWnd, COLORREF cColor)
{
  if (cColor!=(COLORREF)-2) cb_PicSetBackColor(hWnd, cColor, FALSE);
  InvalidateRect(hWnd, NULL, 0);
}
/* END MODULE */


/* MODULE::cb_SetSubClassWnd */
WNDPROC cb_DEFCALL cb_SetSubClassWnd (HWND hWnd,WNDPROC wnd1,const char *Str1)
{
  register HANDLE i = (HANDLE)SetWindowLongPtr(hWnd,GWLP_WNDPROC,(LONG_PTR)wnd1);
  register const char *sTmp = Str1; if (!sTmp) sTmp = "cb_prevWNDPROC_";
  if (sTmp[0]) SetPropA(hWnd,sTmp,i);
  return (WNDPROC)i;
}
/* END MODULE */


/* MODULE::cb_UnSubClassWnd */
WNDPROC cb_DEFCALL cb_UnSubClassWnd (HWND hWnd,const char *Str1)
{
  register LONG_PTR i;
  register const char *sTmp = Str1; if (!sTmp) sTmp = "cb_prevWNDPROC_";
  i = (LONG_PTR)RemovePropA(hWnd,sTmp);
  if (i) SetWindowLongPtr(hWnd,GWLP_WNDPROC,i);
  return (WNDPROC)i;
}
/* END MODULE */


/* MODULE::cb_SetSubClassCombo */
HWND cb_DEFCALL cb_SetSubClassCombo (HWND hWnd,WNDPROC wnd1,const char *Str1)
{
  COMBOBOXINFO ci1;

  cb_MemSet(&ci1,0,sizeof(ci1));
  ci1.cbSize = sizeof(ci1);
  GetComboBoxInfo(hWnd,&ci1);
  if (wnd1) cb_SetSubClassWnd(ci1.hwndItem,wnd1,Str1);
  return ci1.hwndItem;
}
/* END MODULE */


/* MODULE::cb_SetWndFontEx */
HFONT cb_DEFCALL cb_SetWndFontEx (HWND hWnd,HFONT hFnt,cb_Boolean bRedraw,cb_Boolean flag1)
{
  register HFONT oldhFnt = (HFONT)SendMessage(hWnd, WM_GETFONT, 0, 0);

  SendMessage(hWnd, WM_SETFONT, (WPARAM)(hFnt), (LPARAM)(bRedraw));
  if (oldhFnt) if (flag1) { DeleteObject(oldhFnt); oldhFnt = NULL; }
  return oldhFnt;
}
/* END MODULE */


/* MODULE::cb_MakeRegion */
HRGN cb_DEFCALL cb_MakeRegion (HBITMAP hBmp, HWND hWnd, COLORREF TransparentColor, cb_Integer flag1)
{
  cb_Integer X;
  cb_Integer Y;
  cb_Integer StartLineX;
  HRGN FullRegion = NULL;
  HRGN LineRegion;
  cb_Boolean bInLine;
  COLORREF *lpBits, *Ptr1;
  cb_Boolean bFlag;
  RECT rc1;
  DIBSECTION Bmp1;

  Bmp1.dsBm.bmWidth = 0; Bmp1.dsBm.bmHeight = 0;
  if (GetObject(hBmp,sizeof(Bmp1),&Bmp1)) {
  bFlag = FALSE;
  if (hWnd) if ((flag1&2)!=0) {
    GetWindowRect(hWnd, &rc1);
    Bmp1.dsBmih.biWidth = rc1.right-rc1.left;
    Bmp1.dsBmih.biHeight = rc1.bottom-rc1.top;
    if (Bmp1.dsBm.bmWidth!=Bmp1.dsBmih.biWidth || Bmp1.dsBm.bmHeight!=Bmp1.dsBmih.biHeight) {
      Bmp1.dsBm.bmHeight = Bmp1.dsBmih.biHeight;
      hBmp = cb_StretchBitmap(hBmp,Bmp1.dsBmih.biWidth,Bmp1.dsBmih.biHeight,hWnd);
      bFlag++;
    }
  }
  lpBits = cb_GetBmpBits(hBmp,Bmp1.dsBmih.biWidth,Bmp1.dsBm.bmHeight,hWnd); Ptr1 = lpBits;
  bInLine = FALSE; StartLineX = 0;
  if (TransparentColor==CLR_INVALID) TransparentColor = lpBits[0];
  for(Y=0;Y<Bmp1.dsBm.bmHeight;Y++) {
    for(X=0;X<Bmp1.dsBmih.biWidth;X++) {
      if (lpBits[0]==TransparentColor) {
        if (bInLine) {
          bInLine = FALSE;
          LineRegion = CreateRectRgn(StartLineX,Y,X,Y+1);
          if (FullRegion==NULL) {
            FullRegion = LineRegion;
          }
          else {
            CombineRgn(FullRegion,FullRegion,LineRegion,RGN_OR);
            DeleteObject(LineRegion);
          }
        }
      }
      else if (!bInLine) {
        bInLine = TRUE;
        StartLineX = X;
      }
      lpBits++;    }
  }
  cb_MemFreeM(Ptr1);
  if (bFlag) DeleteObject(hBmp);
  if (hWnd) SetWindowRgn(hWnd, FullRegion, flag1 & TRUE);
  }
  return FullRegion;
}
/* END MODULE */


/* MODULE::cb_IMLReplaceSmallIcon */
cb_Integer cb_DEFCALL cb_IMLReplaceSmallIcon (HIMAGELIST hIml, const char *sFile, cb_Integer Index, SHFILEINFO *shfi)
{
  SHFILEINFO tshfi;
  register cb_Integer i = -1;

  if (shfi==NULL) shfi = &tshfi;
  if (SHGetFileInfo(sFile, 0, shfi, sizeof(SHFILEINFO), SHGFI_SHELLICONSIZE | SHGFI_SYSICONINDEX | SHGFI_ICON | SHGFI_SMALLICON)) {
    i = ImageList_ReplaceIcon(hIml, Index, shfi->hIcon);
    if (shfi->hIcon) DestroyIcon(shfi->hIcon);
  }

  return i;
}

/* END MODULE */


/* MODULE::cb_SetFormBKGColor */
void cb_DEFCALL cb_SetFormBKGColor (HWND hWnd, COLORREF iClr, HBRUSH hBrush, cb_Boolean flag1)
{
  if (!hBrush) hBrush = CreateSolidBrush(iClr);
  DeleteObject((HANDLE)SetClassLongPtr(hWnd,GCLP_HBRBACKGROUND,(LONG_PTR)hBrush));
  if (flag1) InvalidateRect(hWnd,NULL,1);
}
/* END MODULE */


/* MODULE::cb_GetSetFormStyle */
DWORD cb_DEFCALL cb_GetSetFormStyle (HWND hWnd, DWORD dwFlags1, DWORD dwFlags2, cb_Boolean bGet)
{
  register DWORD i = GetClassLongPtr(hWnd,GCL_STYLE); if (bGet) return (i & dwFlags1);
  i &= ~(dwFlags2); i |= dwFlags1;
  return (DWORD)SetClassLongPtr(hWnd,GCL_STYLE,(LONG_PTR)i);
}
/* END MODULE */


/* MODULE::cb_GetSetWndStyle */
DWORD cb_DEFCALL cb_GetSetWndStyle (HWND hWnd, DWORD dwFlags1, DWORD dwFlags2, cb_Integer bGet, cb_Integer iIndex)
{
  register DWORD i = GetWindowLongPtr(hWnd,iIndex); if (bGet>0) return (i & dwFlags1);
  i &= ~(dwFlags2); i |= dwFlags1;
  i = (DWORD)SetWindowLongPtr(hWnd,iIndex,(LONG_PTR)i);
  if (bGet) SetWindowPos(hWnd, NULL, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_FRAMECHANGED);
  return i;
}
/* END MODULE */


/* MODULE::cb_GetSetWndExStyle */
DWORD cb_DEFCALL cb_GetSetWndExStyle (HWND hWnd, DWORD dwFlags1, DWORD dwFlags2, cb_Integer bGet)
{
  return cb_GetSetWndStyle(hWnd,dwFlags1,dwFlags2,bGet,GWL_EXSTYLE);
}
/* END MODULE */


/* MODULE::cb_SetFormIcon */
void cb_DEFCALL cb_SetFormIcon (HWND hWnd, HICON hIcon, cb_Integer iIndex)
{
  SetClassLongPtr(hWnd,iIndex,(LONG_PTR)hIcon);
}
/* END MODULE */


/* MODULE::cb_SetFormCursor */
void cb_DEFCALL cb_SetFormCursor (HWND hWnd, HCURSOR hCursor)
{
  SetClassLongPtr(hWnd,GCLP_HCURSOR,(LONG_PTR)hCursor);
}
/* END MODULE */


/* MODULE::cb_InitCommonControls */
cb_Boolean cb_DEFCALL cb_InitCommonControls (cb_Integer iflags)
{
  INITCOMMONCONTROLSEX iccex;
  iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
  if (iflags==0) iflags = ICC_LISTVIEW_CLASSES | ICC_TREEVIEW_CLASSES | ICC_BAR_CLASSES | ICC_TAB_CLASSES | ICC_UPDOWN_CLASS | ICC_PROGRESS_CLASS | ICC_DATE_CLASSES;
  iccex.dwICC = iflags;
  if (InitCommonControlsEx(&iccex)) return TRUE;
  InitCommonControls();
  return FALSE;
}
/* END MODULE */


/* MODULE::cbApp_InitGUIScale */
void cbApp_InitGUIScale (void)
{
  cbApp_ScaleX = (double)cb_GetDesktopScale() / 96.0;
  cbApp_ScaleY = (double)cb_GetDesktopScale(LOGPIXELSY) / 96.0;
}
/* END MODULE */


/* MODULE::cb_UnregClass */
const char * cb_DEFCALL cb_GetClassName_ (const char *classname)
{
  register const char *c1;

  if (!cbApp_hInstance) cbApp_hInstance = GetModuleHandle(NULL);
  c1 = classname;
  if (!c1 || !c1[0]) {
    c1 = cbApp_ClassName;
  }
  return c1;
}

cb_Boolean cb_DEFCALL cb_UnregClass (const char *classname)
{
  register const char *c1 = cb_GetClassName_(classname);

  return UnregisterClass(c1,cbApp_hInstance);
}
/* END MODULE */


/* MODULE::cb_RegClassEx */
cb_Boolean cb_DEFCALL cb_RegClassEx (const char *classname, WNDPROC fnWndProc, WNDCLASSEX *cWn, DWORD dwStyle, HCURSOR hCursor, HICON hIcon, const PCHAR sMenu, HBRUSH hBrush, cb_Integer iExtra)
{
  register const char *c1;
  register WNDCLASSEX *cWnd;
  c1 = cb_GetClassName_(classname);
  cWnd = cWn; if (!cWnd) cWnd = &cbApp_WndClassEx;
  register cb_Boolean i = GetClassInfoEx(cbApp_hInstance, c1, cWnd); if (i!=0) return i;
  cb_MemSet(cWnd,0,sizeof(WNDCLASSEX));
  cWnd->lpfnWndProc = fnWndProc;
  cWnd->cbWndExtra = iExtra;
  cWnd->hInstance = cbApp_hInstance;
  cWnd->lpszClassName = c1;
  cWnd->cbSize = sizeof(WNDCLASSEX);
  if (dwStyle==(DWORD)-1) cWnd->style = CS_HREDRAW | CS_VREDRAW;
  else if (dwStyle==(DWORD)-2) cWnd->style = CS_HREDRAW | CS_VREDRAW | CS_CLASSDC;
  else if (dwStyle==(DWORD)-3) cWnd->style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
  else cWnd->style = dwStyle;
  cWnd->hIcon = hIcon;
  if (hCursor==(HCURSOR)-1) hCursor = LoadCursor(NULL,IDC_ARROW);
  cWnd->hCursor = hCursor;
  cWnd->hbrBackground = hBrush;
  cWnd->lpszMenuName = sMenu;
  return (cb_Boolean)RegisterClassEx(cWnd);
}
/* END MODULE */


/* MODULE::cb_DoFormEvents */
cb_Integer cb_DEFCALL cb_DoFormEvents (HWND hWnd, HACCEL hAccel, MSG* Msg1, void *func, const void *UserData)
{
  MSG TMsg;
  register MSG *Msg2 = Msg1; if (!Msg2) Msg2 = &TMsg;
  register cb_Integer i;
  do {
    if (func) {
      if (PeekMessage(Msg2,NULL,0,0,PM_REMOVE)) {
        if (Msg2->message==WM_QUIT) break;
        goto Translate0000;
      }
      if (((cbApp_EventsType_)func)(UserData,Msg2)) break;
    }
    else {
      i = GetMessage(Msg2,NULL,0,0);
      if (i==0) break;
      if (i!=-1) {
Translate0000:;
        if (hWnd) {
          if (IsDialogMessage(hWnd,Msg2)) continue;
          if (hAccel) if (TranslateAccelerator(hWnd,hAccel,Msg2)) continue;
        }
        TranslateMessage(Msg2);
        DispatchMessage(Msg2);
      }
    }
  } while(1);
  return (cb_Integer)(Msg2->wParam);
}
/* END MODULE */


/* MODULE::cb_DoMDIFormEvents */
cb_Integer cb_DEFCALL cb_DoMDIFormEvents (HWND hWndClient, HWND hWnd, HACCEL hAccel, MSG* Msg1, void *func, const void *UserData)
{
  if (!hWndClient) { hWndClient = cbApp_hWndMDIClient; if (!hWndClient) return cb_DoFormEvents(hWnd,hAccel,Msg1,func,UserData); }
  MSG TMsg;
  register MSG *Msg2 = Msg1; if (!Msg2) Msg2 = &TMsg;
  register cb_Integer i;
  do {
    if (func) {
      if (PeekMessage(Msg2,NULL,0,0,PM_REMOVE)) {
        if (Msg2->message==WM_QUIT) break;
        goto Translate0000;
      }
      if (((cbApp_EventsType_)func)(UserData,Msg2)) break;
    }
    else {
      i = GetMessage(Msg2,NULL,0,0);
      if (i==0) break;
      if (i!=-1) {
Translate0000:;
        if (!TranslateMDISysAccel(hWndClient,Msg2)) {
          if (hWnd) if (hAccel) if (TranslateAccelerator(hWnd,hAccel,Msg2)) continue;
          TranslateMessage(Msg2);
          DispatchMessage(Msg2);
        }
      }
    }
  } while(1);
  return (cb_Integer)(Msg2->wParam);
}
/* END MODULE */


/* MODULE::cb_CreateControl */
HWND cb_DEFCALL cb_CreateControl (const char *sClass,HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle,CLIENTCREATESTRUCT *cc)
{
  register HWND hWin;
  register cb_Integer W1 = W, H1 = H;
  register const char *c1 = sClass;

  if (!c1) c1 = cbApp_ClassName;
  if (Style==-1) { Style = WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS; if (hWnd) Style|=WS_CHILD; }
  if (ExStyle==-1) ExStyle = WS_EX_CLIENTEDGE;
  if (W1<0 || H1<0) {
    W = cb_GetTextSize(sCaption,&H,NULL,hFnt);
    if (W1<0) W1 = W;
    if (H1<0) H1 = H;
  }
  hWin = CreateWindowEx(ExStyle,c1,sCaption,Style,
    X*cbApp_ScaleX, Y*cbApp_ScaleY, W1*cbApp_ScaleX, H1*cbApp_ScaleY,
    hWnd,(HMENU)id, cbApp_hInstance, cc);
  if (hWin) {
    if (hFnt) SendMessage(hWin,WM_SETFONT,(WPARAM)hFnt,0);
  }
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateListView */
HWND cb_DEFCALL cb_CreateListView (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,cb_Integer Cols,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle,cb_Integer Style1)
{
  HWND hWin;
  LV_COLUMN lvCol =
  { LVCF_FMT|LVCF_WIDTH|LVCF_TEXT|LVCF_SUBITEM, LVCFMT_LEFT, 65, "", 0, 0 };

  if (Style==-1) Style = WS_CHILD | WS_TABSTOP | WS_VISIBLE | LVS_REPORT | LVS_SHAREIMAGELISTS | LVS_EDITLABELS | WS_BORDER | LVS_SINGLESEL;
  hWin = cb_CreateControl("SysListView32",hWnd,X,Y,W,H,id,NULL,hFnt,Style,ExStyle);
  if (Style1==-1) Style1 = LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT|LVS_EX_HEADERDRAGDROP;
  SendMessage(hWin,LVM_SETEXTENDEDLISTVIEWSTYLE,0,(LPARAM)Style1);
  for (;lvCol.iSubItem<Cols;lvCol.iSubItem+=1) ListView_InsertColumn(hWin,0,&lvCol);
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateButton */
HWND cb_DEFCALL cb_CreateButton (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  if (Style==-1) Style = WS_CHILD | WS_VISIBLE | BS_MULTILINE | BS_PUSHBUTTON | WS_TABSTOP;
  if (ExStyle==-1) ExStyle = WS_EX_STATICEDGE;
  HWND hWin = cb_CreateControl("button",hWnd,X,Y,W,H,id,sCaption,hFnt,Style,ExStyle);
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateCheckBox */
HWND cb_DEFCALL cb_CreateCheckBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  HWND hWin;
  if (Style==-1) Style = WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX | WS_TABSTOP;
  if (ExStyle==-1) ExStyle = WS_EX_STATICEDGE;
  hWin = cb_CreateControl("button",hWnd,X,Y,W,H,id,sCaption,hFnt,Style,ExStyle);
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateOptionButton */
HWND cb_DEFCALL cb_CreateOptionButton (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  HWND hWin;
  if (Style==-1) Style = WS_CHILD | WS_TABSTOP | WS_VISIBLE | BS_AUTORADIOBUTTON;
  if (ExStyle==-1) ExStyle = WS_EX_STATICEDGE;
  hWin = cb_CreateControl("button",hWnd,X,Y,W,H,id,sCaption,hFnt,Style,ExStyle);
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateImageButton */
HWND cb_DEFCALL cb_CreateImageButton (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sFile,cb_Integer Res,cb_Boolean flag1,cb_Integer Style,cb_Integer ExStyle,cb_Integer tipe)
{
  register HBITMAP hBmp;
  register cb_Integer tipe1 = tipe;
  register HWND hWin;
  cb_Integer W1 = W, H1 = H;
  if (Style==-1) Style=WS_CHILD | WS_VISIBLE | WS_TABSTOP;
  if (ExStyle==-1) ExStyle = WS_EX_STATICEDGE;
  if (tipe1==IMAGE_BITMAP) Style |= BS_BITMAP;
  else Style |= BS_ICON;
  hBmp = cb_GetImage(sFile,Res,&W,&H,tipe1);
  hWin = cb_CreateControl("button",hWnd,X,Y,W,H,id,NULL,NULL,Style,ExStyle);
  if (hBmp) {
    if (hWin) {
      if (flag1) if (W1>0 || H1>0) { W1 = (cb_Integer)cb_StretchBitmap(hBmp,W,H,NULL,NULL,TRUE); if (W1) hBmp = (HBITMAP)W1; }
      cb_SetWndImage(hWin,hBmp,TRUE,tipe1,BM_SETIMAGE);
    }
    else {
      DeleteObject(hBmp);
    }
  }
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateIconButton */
HWND cb_DEFCALL cb_CreateIconButton (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sFile,cb_Integer Res,cb_Boolean flag1,cb_Integer Style,cb_Integer ExStyle)
{
  return cb_CreateImageButton(hWnd,X,Y,W,H,id,sFile,Res,flag1,Style,ExStyle,IMAGE_ICON);
}
/* END MODULE */


/* MODULE::cb_CreateCursorButton */
HWND cb_DEFCALL cb_CreateCursorButton (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sFile,cb_Integer Res,cb_Boolean flag1,cb_Integer Style,cb_Integer ExStyle)
{
  return cb_CreateImageButton(hWnd,X,Y,W,H,id,sFile,Res,flag1,Style,ExStyle,IMAGE_CURSOR);
}
/* END MODULE */


/* MODULE::cb_CreateEditBox */
HWND cb_DEFCALL cb_CreateEditBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle,cb_Integer bFlags,cb_Integer Limit1)
{
  if (Style==-1) Style = WS_CHILD | WS_VISIBLE | ES_WANTRETURN | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL | ES_NOHIDESEL;
  if ((bFlags&1)!=0) Style |= ES_READONLY;
  HWND hWin = cb_CreateControl("edit",hWnd,X,Y,W,H,id,sCaption,hFnt,Style,ExStyle);
  if (hWin) {
    if (Limit1!=-1) SendMessage(hWin,EM_LIMITTEXT,Limit1,0);
    if ((bFlags&2)!=0) DragAcceptFiles(hWin,TRUE);
  }
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateInputBox */
HWND cb_DEFCALL cb_CreateInputBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  if (Style==-1) Style = WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL;
  return cb_CreateControl("edit",hWnd,X,Y,W,H,id,sCaption,hFnt,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateLabel */
HWND cb_DEFCALL cb_CreateLabel (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  if (Style==-1) Style=WS_CHILD | SS_NOTIFY | SS_LEFT | WS_VISIBLE | SS_ENDELLIPSIS;
  HWND hWin = cb_CreateControl("static",hWnd,X,Y,W,H,id,sCaption,hFnt,Style,ExStyle);
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateComboBox */
HWND cb_DEFCALL cb_CreateComboBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,cb_Integer flags,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  if (Style==-1) Style = WS_CHILD | WS_VISIBLE | CBS_HASSTRINGS | CBS_DROPDOWN | CBS_AUTOHSCROLL | WS_VSCROLL | WS_TABSTOP;
  if ((flags&1)!=0) Style |= CBS_SORT;
  if ((flags&2)!=0) { Style &= ~(CBS_DROPDOWN); Style |= CBS_DROPDOWNLIST; }
  return cb_CreateControl("Combobox",hWnd,X,Y,W,H,id,NULL,hFnt,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateListBox */
HWND cb_DEFCALL cb_CreateListBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,cb_Integer bSort,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  if (Style==-1) Style = LBS_HASSTRINGS | LBS_NOTIFY | WS_BORDER | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | WS_TABSTOP | LBS_USETABSTOPS | LBS_WANTKEYBOARDINPUT;
  if (bSort) Style |= LBS_SORT;
  return cb_CreateControl("Listbox",hWnd,X,Y,W,H,id,NULL,hFnt,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateTreeView */
HWND cb_DEFCALL cb_CreateTreeView (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  if (Style==-1) Style = WS_VISIBLE | WS_CHILD | TVS_HASLINES | TVS_HASBUTTONS | TVS_LINESATROOT;
  return cb_CreateControl(WC_TREEVIEW,hWnd,X,Y,W,H,id,NULL,hFnt,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateRect */
HWND cb_DEFCALL cb_CreateRect (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,cb_Integer iClr,cb_Integer Style,cb_Integer ExStyle)
{
  if (Style==-1) Style = WS_CHILD | SS_NOTIFY | WS_VISIBLE | WS_CLIPCHILDREN;
  if (iClr==0) Style |= SS_BLACKRECT;
  else if (iClr==1) Style |= SS_GRAYRECT;
  else if (iClr==2) Style |= SS_WHITERECT;
  return cb_CreateControl("static",hWnd,X,Y,W,H,id,NULL,NULL,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateShape */
HWND cb_DEFCALL cb_CreateShape (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,cb_Integer iClr,cb_Integer Style,cb_Integer ExStyle)
{
  if (Style==-1) Style = WS_CHILD | SS_NOTIFY | WS_VISIBLE | WS_CLIPCHILDREN;
  if (iClr==0) Style |= SS_BLACKFRAME;
  else if (iClr==1) Style |= SS_GRAYFRAME;
  else if (iClr==2) Style |= SS_WHITEFRAME;
  return cb_CreateControl("static",hWnd,X,Y,W,H,id,NULL,NULL,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateFrameBox */
static LRESULT CALLBACK cb_CreateFrameBoxEvents___ (HWND hWnd, cb_UInteger uMsg, WPARAM wParam, LPARAM lParam)
{
  register cb_TFrameBox *j;
  register cb_Integer i = uMsg;
  register HWND hWin;
  HFONT hFnt;
  HDC hDC;
  RECT rc1;

  if (i==WM_CTLCOLORSTATIC) {
    j = (cb_TFrameBox*)GetPropA(hWnd,"cb_TFrame");
    if (j) {
      hWin = j->hWndLabel;
      if (hWin==(HWND)lParam) return SendMessage(j->hWndP,WM_CTLCOLORSTATIC,wParam,(LPARAM)hWnd);
      return 0;
    }
  }
  if (i==WM_PAINT) {
    hWin = hWnd;
    j = (cb_TFrameBox*)GetPropA(hWin,"cb_TFrame");
    if (j) {
      hDC = GetDC(hWin);
      if (j->hBmp) if (j->iStretch & 1) goto Draw0000;
      i = j->BackColor;
      if (i!=CLR_INVALID) {
        if (j->hBrush==NULL) j->hBrush = CreateSolidBrush(i);
        i = (cb_Integer)(j->hBrush);
      }
      else {
        if (j->hBmp) goto Draw0000;
        i = SendMessage(j->hWndP,WM_CTLCOLORBTN,(WPARAM)hDC,(LPARAM)hWin);
      }
      cb_Clw(hWin,-1,0,(HBRUSH)i,hDC);
      if (j->hBmp) {
Draw0000:
        if (!j->hBmp_) { if (j->iStretch & 1) j->hBmp_ = cb_StretchBitmap(j->hBmp,-1,-1,hWin,NULL,cb_MIN_INTEGER|TRUE); if (!j->hBmp_) j->hBmp_ = j->hBmp; }
        cb_DrawBitmap(j->hBmp, hWin, 0, 0, -1, -1, FALSE, j->iTrans, hDC);
      }
      GetClientRect(hWin,&rc1); rc1.top+=7; DrawEdge(hDC,&rc1,EDGE_ETCHED,BF_RECT);
      ReleaseDC(hWin,hDC);
      i = WM_PAINT; goto Exit0000;
    }
  }
  if (i==WM_ERASEBKGND) return 1;
  if (i==STM_GETIMAGE) {
    j = (cb_TFrameBox*)GetPropA(hWnd,"cb_TFrame");
    if (j) return (LRESULT)(j->hBmp);
  }
  if (i==STM_SETIMAGE) {
    hWin = hWnd;
    j = (cb_TFrameBox*)GetPropA(hWin,"cb_TFrame");
    if (j) {
      i = (cb_Integer)(j->hBmp); j->hBmp = (HBITMAP)lParam;
      if (j->hBmp_) { if (j->hBmp_!=(HBITMAP)i) DeleteObject(j->hBmp_); j->hBmp_ = NULL; }
      if (i) if (j->iStretch & 0x100) { if (!DeleteObject((HBITMAP)i)) if (!DestroyIcon((HICON)i)) DestroyCursor((HCURSOR)i); i = 0; j->iStretch &= 0xFF; }
      InvalidateRect(hWin, NULL, 0);
      return (LRESULT)i;
    }
  }
  if (i==WM_GETTEXT || i==WM_GETFONT || i==WM_GETTEXTLENGTH || i==WM_SETTEXT || i==WM_SETFONT) {
    j = (cb_TFrameBox*)GetPropA(hWnd,"cb_TFrame");
    if (j) {
      hWin = j->hWndLabel;
      i = SendMessage(hWin,i,wParam,lParam);
      if (uMsg==WM_SETTEXT) {
        hFnt = (HFONT)SendMessage(hWin,WM_GETFONT,0,0);
        j = (cb_TFrameBox*)cb_GetTextSize((const char*)lParam,&wParam,hWin,hFnt);
        GetClientRect(hWnd,&rc1);
        if ((GetWindowLongPtr(hWnd,GWL_EXSTYLE)&WS_EX_RTLREADING)!=0) rc1.left-=rc1.right-10-(cb_Integer)j;
        else rc1.left = 10;
        MoveWindow(hWin,rc1.left,0,(cb_Integer)j,wParam,TRUE);
      }
      return i;
    }
  }
  if (i==WM_NCDESTROY) {
    hWin = hWnd;
    j = (cb_TFrameBox*)RemovePropA(hWin,"cb_TFrame");
    i = DefWindowProc(hWin,i,wParam,lParam);
    if (j) {
      if (j->hBmp_) if (j->hBmp_!=j->hBmp) DeleteObject(j->hBmp_);
      if (j->iStretch & 0x100) { hWin = (HWND)(j->hBmp); if (hWin) if (!DeleteObject((HBITMAP)hWin)) if (!DestroyIcon((HICON)hWin)) DestroyCursor((HCURSOR)hWin); }
      if (j->hBrush) DeleteObject(j->hBrush);
      cb_MemFreeM(j);
    }
    if (cb_CreateFrameBoxCnt_) {
      cb_CreateFrameBoxCnt_--;
      if (cb_CreateFrameBoxCnt_<=1) {
        cb_UnregClass(cb_FrameBox_buf_); cb_CreateFrameBoxCnt_ = 0;
      }
    }
    return i;
  }
  if (i==WM_SIZE) {
    j = (cb_TFrameBox*)GetPropA(hWnd,"cb_TFrame");
    if (j) {
      if (j->hBmp_) { if (j->hBmp_!=j->hBmp) DeleteObject(j->hBmp_); j->hBmp_ = NULL; }
    }
  }
Exit0000:
  return DefWindowProc(hWnd,i,wParam,lParam);
}

HWND cb_DEFCALL cb_CreateFrameBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,cb_Integer flag1,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  register HWND hWin;
  register cb_TFrameBox *j;
  register cb_Integer i;
  WNDCLASSEX w1;

  if (!cb_CreateFrameBoxCnt_) {
    cb_MemCopy(cb_FrameBox_buf_,"cb_FrameBox",3+5+3);
    cb_CStr((cb_Integer)cbApp_hInstance,16,cb_FrameBox_buf_+3+5+3);
    cb_CreateFrameBoxCnt_++; cb_RegClassEx(cb_FrameBox_buf_, cb_CreateFrameBoxEvents___, &w1);
  }
  if (Style==-1) Style = WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN;
  hWin = cb_CreateControl(cb_FrameBox_buf_, hWnd, X, Y, W, H, id, NULL, NULL, Style, ExStyle);
  if (hWin) {
    cb_CreateFrameBoxCnt_++;
    j = (cb_TFrameBox*)cb_MemAllocM(sizeof(cb_TFrameBox));
    if (j) {
      cb_MemSet(j,0,sizeof(cb_TFrameBox));
      j->hWndP = hWnd;
      j->BackColor=CLR_INVALID; j->iStretch = flag1 & 1; j->iTrans = flag1 & 0xfe;
      SetPropA(hWin,"cb_TFrame",(HANDLE)j);
      i = cb_GetTextSize(sCaption,&H,hWin,hFnt);
      if ((ExStyle&WS_EX_RTLREADING)!=0) X=W-10-i;
      else X=10;
      j->hWndLabel = cb_CreateLabel(hWin, X, 0, i, H, id, sCaption, hFnt, -1, 0);
    }
  }
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateGroupBox */
static LRESULT CALLBACK cb_CreateGroupBoxEvents___ (HWND hWnd, cb_UInteger uMsg, WPARAM wParam, LPARAM lParam)
{
  register cb_TGroupBox *j = (cb_TGroupBox*)GetPropA(hWnd,"cb_TGroup");
  register cb_Integer i = uMsg;
  register HWND hWin;

  if (i==WM_CTLCOLORSTATIC) {
    if (j) return SendMessage(j->hWndP,WM_CTLCOLORSTATIC,wParam,(LPARAM)hWnd);
  }
  if (i==WM_ERASEBKGND) {
    if (j) {
      hWin = hWnd;
      if (j->hBmp) if (j->iStretch & 1) goto Draw0000;
      i = j->BackColor;
      if (i!=CLR_INVALID) {
        if (j->hBrush==NULL) j->hBrush = CreateSolidBrush(i);
        i = (cb_Integer)(j->hBrush);
      }
      else {
        if (j->hBmp) goto Draw0000;
        i = SendMessage(j->hWndP,WM_CTLCOLORBTN,wParam,(LPARAM)hWin);
      }
      cb_Clw(hWin,-1,0,(HBRUSH)i,(HDC)wParam);
      if (j->hBmp) {
Draw0000:
        if (!j->hBmp_) { if (j->iStretch & 1) j->hBmp_ = cb_StretchBitmap(j->hBmp,-1,-1,hWin,NULL,cb_MIN_INTEGER|TRUE); if (!j->hBmp_) j->hBmp_ = j->hBmp; }
        cb_DrawBitmap(j->hBmp, hWin, 0, 0, -1, -1, FALSE, j->iTrans, (HDC)wParam);
      }
      return 1;
    }
  }
  if (i==STM_GETIMAGE) {
    if (j) return (LRESULT)(j->hBmp);
  }
  if (i==STM_SETIMAGE) {
    if (j) {
      i = (cb_Integer)(j->hBmp); j->hBmp = (HBITMAP)lParam;
      if (j->hBmp_) { if (j->hBmp_!=(HBITMAP)i) DeleteObject(j->hBmp_); j->hBmp_ = NULL; }
      if (i) if (j->iStretch & 0x100) { if (!DeleteObject((HBITMAP)i)) if (!DestroyIcon((HICON)i)) DestroyCursor((HCURSOR)i); i = 0; j->iStretch &= 0xFF; }
      InvalidateRect(hWnd, NULL, 0);
      return (LRESULT)i;
    }
  }
  if (i==WM_NCDESTROY) {
    hWin = hWnd;
    RemovePropA(hWin,"cb_TGroup");
    if (!j)
      i = 0;
    else {
      SetWindowLongPtr(hWin,GWLP_WNDPROC,(LONG_PTR)(j->Events));
      i = CallWindowProc(j->Events,hWin,i,wParam,lParam);
      if (j->hBmp_) if (j->hBmp_!=j->hBmp) DeleteObject(j->hBmp_);
      if (j->iStretch & 0x100) { hWin = (HWND)(j->hBmp); if (hWin) if (!DeleteObject((HBITMAP)hWin)) if (!DestroyIcon((HICON)hWin)) DestroyCursor((HCURSOR)hWin); }
      if (j->hBrush) DeleteObject(j->hBrush);
      cb_MemFreeM(j);
    }
    return i;
  }
  if (i==WM_SIZE) {
    if (j) if (j->hBmp_) { if (j->hBmp_!=j->hBmp) DeleteObject(j->hBmp_); j->hBmp_ = NULL; }
  }
  if (j) j = (cb_TGroupBox *)CallWindowProc(j->Events,hWnd,i,wParam,lParam);
  return (LRESULT)j;
}

HWND cb_DEFCALL cb_CreateGroupBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,cb_Integer flag1,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  register HWND hWin;
  register cb_TGroupBox *j;

  if (Style==-1) Style = WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN;
  hWin = cb_CreateControl("button", hWnd, X, Y, W, H, id, sCaption, hFnt, Style | BS_GROUPBOX, ExStyle);
  if (hWin) {
    j = (cb_TGroupBox*)cb_MemAllocM(sizeof(cb_TGroupBox));
    if (j) {
      cb_MemSet(j,0,sizeof(cb_TGroupBox));
      j->hWndP = hWnd;
      j->BackColor=CLR_INVALID; j->iStretch = flag1 & 1; j->iTrans = flag1 & 0xfe;
      SetPropA(hWin,"cb_TGroup",(HANDLE)j);
      j->Events = (WNDPROC)SetWindowLongPtr(hWin,GWLP_WNDPROC,(LONG_PTR)cb_CreateGroupBoxEvents___);
    }
  }
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateDateTimePicker */
HWND cb_DEFCALL cb_CreateDateTimePicker (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  if (Style==-1) Style=WS_CHILD | WS_TABSTOP | WS_VISIBLE | DTS_LONGDATEFORMAT;
  return cb_CreateControl(DATETIMEPICK_CLASS,hWnd,X,Y,W,H,id,NULL,hFnt,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateRTFBox */
HWND cb_DEFCALL cb_CreateRTFBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sText,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle,cb_Integer bFlags,cb_Integer Limit1)
{
  SETTEXTEX Rtb;
  if (!cb_hRichEditLib) if (GetModuleHandle("RICHED20.DLL")==NULL) cb_hRichEditLib = LoadLibraryA("RICHED20.DLL");
  if (Style==-1) Style=WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL | ES_WANTRETURN | ES_NOHIDESEL;
  if ((bFlags&1)!=0) Style |= ES_READONLY;
  HWND hWin = cb_CreateControl(RICHEDIT_CLASS,hWnd,X,Y,W,H,id,NULL,hFnt,Style,ExStyle);
  if (hWin) {
    if (Limit1!=-1) SendMessage(hWin,EM_EXLIMITTEXT,0,Limit1);
    if (sText!=0 && sText[0]!=0) {
      Rtb.flags=ST_DEFAULT;
      Rtb.codepage=CP_ACP;
      SendMessage(hWin,EM_SETTEXTEX,(WPARAM)&Rtb,(LPARAM)sText);
    }
    Style = ENM_CHANGE|ENM_SELCHANGE|ENM_KEYEVENTS|ENM_MOUSEEVENTS|
        ENM_SCROLL|ENM_LINK/*| ENM_PROTECTED*/|ENM_UPDATE;
    if ((bFlags&2)!=0) Style |= ENM_DROPFILES;
    SendMessage(hWin, EM_SETEVENTMASK, 0, Style);
    if ((bFlags&2)!=0) DragAcceptFiles(hWin,TRUE);
  }
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateImageBox */
HWND cb_DEFCALL cb_CreateImageBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sFile,cb_Integer Res,cb_Integer Style,cb_Integer ExStyle,cb_Integer tipe)
{
  register HBITMAP hBmp;
  register cb_Integer tipe1 = tipe;
  register HWND hWin;
  if (Style==-1) Style = WS_CHILD | WS_VISIBLE | WS_TABSTOP | SS_NOTIFY | SS_REALSIZECONTROL;
  if (tipe1==IMAGE_BITMAP) Style |= SS_BITMAP;
  else Style |= SS_ICON;
  hBmp = cb_GetImage(sFile,Res,&W,&H,tipe1);
  hWin = cb_CreateControl("static",hWnd,X,Y,W,H,id,NULL,NULL,Style,ExStyle);
  if (hBmp) {
    if (hWin) cb_SetWndImage(hWin,hBmp,TRUE,tipe1);
    else DeleteObject(hBmp);
  }
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateIconBox */
HWND cb_DEFCALL cb_CreateIconBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sFile,cb_Integer Res,cb_Integer Style,cb_Integer ExStyle)
{
  return cb_CreateImageBox(hWnd,X,Y,W,H,id,sFile,Res,Style,ExStyle,IMAGE_ICON);
}
/* END MODULE */


/* MODULE::cb_CreateCursorBox */
HWND cb_DEFCALL cb_CreateCursorBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sFile,cb_Integer Res,cb_Integer Style,cb_Integer ExStyle)
{
  return cb_CreateImageBox(hWnd,X,Y,W,H,id,sFile,Res,Style,ExStyle,IMAGE_CURSOR);
}
/* END MODULE */


/* MODULE::cb_CreatePictureBox */
static LRESULT CALLBACK cb_CreatePictureBoxEvents___ (HWND hWnd, cb_UInteger uMsg, WPARAM wParam, LPARAM lParam)
{
  register cb_TPictureBox *j;
  register cb_Integer i = uMsg;
  register HDC hDC;
  register HBITMAP hBmp;
  cb_Integer i1;
  ICONINFO b;

  if (i==WM_PAINT) {
    j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
    if (j) {
PaintBkGnd0000:
      hDC = GetDC(hWnd);
      if (j->hBmp) if (j->iStretch & 1) goto Draw0000;
      i = j->BackColor;
      if (i!=CLR_INVALID) {
        if (j->hBrush==NULL) j->hBrush = CreateSolidBrush(i);
        i = (cb_Integer)(j->hBrush);
      }
      else {
        if (j->hBmp) goto Draw0000;
        i = SendMessage(j->hWndP,WM_CTLCOLORSTATIC,(WPARAM)hDC,(LPARAM)hWnd);
      }
      cb_Clw(hWnd,-1,0,(HBRUSH)i,hDC);
      if (j->hBmp) {
Draw0000:
        if (!j->hBmp_) {
          i1 = cb_MIN_INTEGER|TRUE;
          i = (cb_Integer)(j->hBmp);
          if (GetIconInfo((HICON)i,&b)) {
            i1 = TRUE;
            if (b.hbmMask) DeleteObject(b.hbmMask);
            i = (cb_Integer)b.hbmColor;
            if (!i) {
              i = (cb_Integer)cb_IconCursorToBitmap(j->hBmp,hWnd,hDC,b.fIcon?1|cb_MIN_INTEGER:cb_MIN_INTEGER);
              if (!i) { i = (cb_Integer)(j->hBmp); i1 = cb_MIN_INTEGER|TRUE; }
            }
          }
          if (j->iStretch & 1) j->hBmp_ = cb_StretchBitmap((HBITMAP)i,-1,-1,hWnd,NULL,i1); if (!j->hBmp_) j->hBmp_ = (HBITMAP)i;
        }
        cb_DrawBitmap(j->hBmp_, hWnd, 0, 0, -1, -1, FALSE, j->iTrans, hDC);
      }
      if (j->sCaption) cb_PrintText(hWnd, j->sCaption, 0, 0, j->ForeColor, TRUE, hDC, j->hFont);
      ReleaseDC(hWnd,hDC);
      i = uMsg;
      if (i==WM_SETTEXT) return 1;
      if (i!=WM_PAINT) return (LRESULT)hBmp;
      goto Exit0000;
    }
  }
  if (i==WM_ERASEBKGND) return 1;
  if (i==WM_GETTEXT) {
    j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
    if (j) {
      i = (cb_Integer)(j->sCaption);
      if (i) { cb_StrNCopy((void*)lParam,(void*)i,wParam); i = cb_StrLen((const char*)i); }
      return i;
    }
  }
  if (i==WM_SETTEXT) {
    j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
    if (j) {
      if (lParam) {
        i = cb_StrLen((const char*)lParam)+4;
        i = (cb_Integer)cb_ReMemAllocM(j->sCaption, i);
        if (i) {
          j->sCaption = (char*)i; cb_StrCopy(j->sCaption, (const void*)lParam);
          goto PaintBkGnd0000;
        }
      }
      return FALSE;
    }
  }
  if (i==WM_GETTEXTLENGTH) {
    j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
    if (j) {
      if (j->sCaption) return cb_StrLen(j->sCaption);
      return 0;
    }
  }
  if (i==WM_GETFONT) {
    j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
    if (j) return (LRESULT)(j->hFont);
  }
  if (i==WM_SETFONT) {
    j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
    if (j) {
      hBmp = (HBITMAP)(j->hFont); j->hFont = (HFONT)wParam;
      if (LOWORD(lParam)) goto PaintBkGnd0000;
      return (LRESULT)hBmp;
    }
  }
  if (i==STM_GETIMAGE) {
    j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
    if (j) return (LRESULT)(j->hBmp);
  }
  if (i==STM_SETIMAGE) {
    j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
    if (j) {
      hBmp = j->hBmp; j->hBmp = (HBITMAP)lParam;
      if (j->hBmp_) { if (j->hBmp_!=hBmp) DeleteObject(j->hBmp_); j->hBmp_ = NULL; }
      if (hBmp) if (j->iStretch & 0x100) { if (!DeleteObject(hBmp)) if (!DestroyIcon((HICON)hBmp)) DestroyCursor((HCURSOR)hBmp); hBmp = NULL; j->iStretch &= 0xFF; }
      goto PaintBkGnd0000;
    }
  }
  if (i==WM_NCDESTROY) {
    j = (cb_TPictureBox*)RemovePropA(hWnd,"cb_TPic");
    i = DefWindowProc(hWnd,i,wParam,lParam);
    if (j) {
      if (j->hBmp_) if (j->hBmp_!=j->hBmp) DeleteObject(j->hBmp_);
      if (j->iStretch & 0x100) { hDC = (HDC)(j->hBmp); if (hDC) if (!DeleteObject((HBITMAP)hDC)) if (!DestroyIcon((HICON)hDC)) DestroyCursor((HCURSOR)hDC); }
      if (j->hBrush) DeleteObject(j->hBrush);
      if (j->hFont) DeleteObject(j->hFont);
      if (j->sCaption) cb_MemFreeM(j->sCaption);
      cb_MemFreeM(j);
    }
    if (cb_CreatePictureBoxCnt_) {
      cb_CreatePictureBoxCnt_--;
      if (cb_CreatePictureBoxCnt_<=1) {
        cb_UnregClass(cb_PictureBox_buf_); cb_CreatePictureBoxCnt_ = 0;
      }
    }
    return i;
  }
  if (i==WM_SIZE) {
    j = (cb_TPictureBox*)GetPropA(hWnd,"cb_TPic");
    if (j) {
      if (j->hBmp_) { if (j->hBmp_!=j->hBmp) DeleteObject(j->hBmp_); j->hBmp_ = NULL; }
    }
  }
Exit0000:
  return DefWindowProc(hWnd,i,wParam,lParam);
}

HWND cb_DEFCALL cb_CreatePictureBox (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,const char *sFile,cb_Integer Res,cb_Integer flag1,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle,cb_Integer tipe)
{
  register HBITMAP hBmp;
  register HWND hWin;
  register cb_TPictureBox *j;
  WNDCLASSEX c1;

  if (!cb_CreatePictureBoxCnt_) {
    cb_MemCopy(cb_PictureBox_buf_,"cb_PictureBox",3+7+3);
    cb_CStr((cb_Integer)cbApp_hInstance,16,cb_PictureBox_buf_+3+7+3);
    cb_CreatePictureBoxCnt_++; cb_RegClassEx(cb_PictureBox_buf_, cb_CreatePictureBoxEvents___, &c1, CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS);
  }
  if (ExStyle==-1) ExStyle=WS_EX_STATICEDGE;
  if (Style==-1) Style = WS_CLIPCHILDREN | WS_CHILD | WS_VISIBLE;
  hBmp = cb_GetImage(sFile,Res,&W,&H,tipe);
  hWin = cb_CreateControl(cb_PictureBox_buf_,hWnd,X,Y,W,H,id,NULL,hFnt,Style,ExStyle);
  if (hWin) {
    cb_CreatePictureBoxCnt_++;
    j = (cb_TPictureBox*)cb_MemAllocM(sizeof(cb_TPictureBox));
    if (j) {
      cb_MemSet(j,0,sizeof(cb_TPictureBox));
      j->hWndP = hWnd;
      j->BackColor=CLR_INVALID; j->ForeColor=CLR_INVALID; j->iStretch = flag1 & 1; j->iTrans = flag1 & 0xfe;
      SetPropA(hWin,"cb_TPic",(HANDLE)j);
      if (hBmp) { cb_SetWndImage(hWin,hBmp,TRUE,tipe); j->iStretch |= 0x100; }
      if (sCaption) if (sCaption[0]) SendMessage(hWin,WM_SETTEXT,0,(LPARAM)sCaption);
      goto Exit0000;
    }
  }
  if (hBmp) DeleteObject(hBmp);
Exit0000:
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateProgressBar */
HWND cb_DEFCALL cb_CreateProgressBar (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,cb_Integer Style,cb_Integer ExStyle,cb_Integer iRange,cb_Integer iStep)
{
  HWND hWin;
  if (Style==-1) Style=WS_CHILD|WS_VISIBLE;
  hWin = cb_CreateControl("msctls_progress32",hWnd,X,Y,W,H,id,NULL,NULL,Style,ExStyle);
  if (hWin) {
    SendMessage(hWin,PBM_SETRANGE,0,(LPARAM)iRange);
    SendMessage(hWin,PBM_SETSTEP,(WPARAM)iStep,0);
  }
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateScrollBar */
HWND cb_DEFCALL cb_CreateScrollBar (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,cb_Integer Style,cb_Integer ExStyle)
{
  HWND hWin;
  if (Style==-1) Style = WS_CHILD | WS_VISIBLE | SBS_VERT;
  hWin = cb_CreateControl(WC_SCROLLBAR,hWnd,X,Y,W,H,id,NULL,NULL,Style,ExStyle);
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateTabControl */
HWND cb_DEFCALL cb_CreateTabControl (HWND hWnd, cb_Integer X, cb_Integer Y, cb_Integer W, cb_Integer H, cb_Integer id, HFONT hFnt,cb_Integer Style, cb_Integer ExStyle)
{
  if (Style==-1) Style = WS_CHILD | WS_BORDER | WS_VISIBLE;
  return cb_CreateControl(WC_TABCONTROL,hWnd,X,Y,W,H,id,NULL,hFnt,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateToolBar */
HWND cb_DEFCALL cb_CreateToolBar (HWND hWnd, cb_Integer id, cb_Integer Style, cb_Integer ExStyle)
{
  if (Style==-1) Style = WS_CHILD | WS_BORDER | WS_VISIBLE | CCS_TOP | TBSTYLE_TOOLTIPS;
  return cb_CreateControl(TOOLBARCLASSNAME,hWnd,0,0,0,0,id,NULL,NULL,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateTrackBar */
HWND cb_DEFCALL cb_CreateTrackBar (HWND hWnd, cb_Integer X, cb_Integer Y, cb_Integer W, cb_Integer H, cb_Integer id, cb_Integer Style, cb_Integer ExStyle)
{
  if (Style==-1) Style = WS_CHILD | WS_BORDER | WS_VISIBLE | TBS_BOTH | TBS_NOTICKS;
  return cb_CreateControl(TRACKBAR_CLASS,hWnd,X,Y,W,H,id,NULL,NULL,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateActiveX */
HWND cb_DEFCALL cb_CreateActiveX (const char *sFile,HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle)
{
  if (cb_comAtlAxInit()) return NULL;
  return cb_CreateControl("AtlAxWin",hWnd,X,Y,W,H,id,sFile,hFnt,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateCustomControl */
HWND cb_DEFCALL cb_CreateCustomControl (const char *sClass,HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const char *sCaption,const char *DllName,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle,void *p)
{
  register HMODULE hInst = NULL;

  if (DllName) if (DllName[0]) {
    if (p) goto Load0000;
    if (GetModuleHandle(DllName)==NULL) { Load0000:; hInst = LoadLibrary(DllName); }
  }
  if (p) *(HMODULE*)p = hInst;
  return cb_CreateControl(sClass,hWnd,X,Y,W,H,id,sCaption,hFnt,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateMDIClient */
HWND cb_DEFCALL cb_CreateMDIClient (HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,HMENU hMnu,cb_Integer iStyle,cb_Integer iExStyle)
{
  CLIENTCREATESTRUCT cc1;

  cc1.hWindowMenu = hMnu;
  if (id>0) cc1.idFirstChild = id;
  else cc1.idFirstChild = 5000;
  if (iStyle==-1) iStyle = WS_CHILD | WS_CLIPCHILDREN | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL;
  else iStyle |= WS_CHILD;
  return cb_CreateControl("MDICLIENT",hWnd,X,Y,W,H,0,NULL,NULL,iStyle,iExStyle,&cc1);
}
/* END MODULE */


/* MODULE::cb_CreateMCIWnd */
HWND cb_DEFCALL cb_CreateMCIWnd (HWND hWnd, cb_Integer X, cb_Integer Y, cb_Integer W, cb_Integer H, cb_Integer id, const char *sCaption, HFONT hFnt, cb_Integer Style, cb_Integer ExStyle)
{
  static cb_Integer flag1; if (!flag1) { flag1++; MCIWndRegisterClass(); }
  if (Style==-1) Style = WS_CHILD | WS_BORDER | WS_VISIBLE | MCIWNDF_SHOWALL | MCIWNDF_NOTIFYALL;
  return cb_CreateControl(MCIWND_WINDOW_CLASS,hWnd,X,Y,W,H,id,sCaption,hFnt,Style,ExStyle);
}
/* END MODULE */


/* MODULE::cb_CreateForm */
HWND cb_DEFCALL cb_CreateForm (const char *sCaption,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,const char *sClass,HWND hWnd,HFONT hFnt,cb_Integer Style,cb_Integer ExStyle,cb_Integer bVisible)
{
  if (Style==-1)
    Style= WS_MINIMIZEBOX | WS_SIZEBOX | WS_CAPTION |
        WS_MAXIMIZEBOX | WS_POPUP | WS_SYSMENU | WS_CLIPCHILDREN;
  if ((bVisible&1)!=0) Style|=WS_VISIBLE;
  HWND hWin = cb_CreateControl(sClass,hWnd,X,Y,4+W,12+H,0,sCaption,hFnt,Style,ExStyle);
  if ((bVisible&2)!=0) DragAcceptFiles(hWin,TRUE);
  return hWin;
}
/* END MODULE */


/* MODULE::cb_CreateStatusBar */
HWND cb_DEFCALL cb_CreateStatusBar (HWND hWnd, cb_Integer cParts, cb_Integer *pParts, cb_Integer id, HFONT hFnt, cb_Integer Style, cb_Integer ExStyle)
{
  register cb_Integer nWidth, i;
  register cb_Integer *paParts;
  RECT rcClient;
  HGLOBAL hloc;
  if (Style==-1) Style = WS_CHILD | WS_BORDER | WS_VISIBLE | SBARS_SIZEGRIP;
  HWND hWin = cb_CreateControl(STATUSCLASSNAME,hWnd,0,0,0,0,id,NULL,hFnt,Style,ExStyle);
  if (hWin && cParts>0) {
    paParts = pParts;
    if (!paParts) {
      GetClientRect(hWnd, &rcClient);
      hloc = GlobalAlloc(GMEM_FIXED|GMEM_ZEROINIT, sizeof(cb_Integer) * cParts);
      paParts = (cb_Integer*)GlobalLock(hloc);
      nWidth = rcClient.right / cParts;
      for (i = 0; i < cParts; i++) {
        paParts[i] = nWidth;
        nWidth += nWidth;
      }
    }
    SendMessage(hWin, SB_SETPARTS, (WPARAM)cParts, (LPARAM)paParts);
    if (!pParts) {
      GlobalUnlock(hloc);
      GlobalFree(hloc);
    }
  }
  return hWin;
}
/* END MODULE */


/* MODULE::cb_MsgBox */
cb_Integer cb_DEFCALL cb_MsgBox (const void *sMsg, const void *sTitle, DWORD dwFlags1)
{
  if (dwFlags1==(DWORD)-1) dwFlags1 = MB_SETFOREGROUND;
  return MessageBox(GetActiveWindow(),(LPCSTR)sMsg,(LPCSTR)sTitle,dwFlags1);
}
/* END MODULE */


/* MODULE::cb_MsgBoxW */
cb_Integer cb_DEFCALL cb_MsgBoxW (const void *sMsg, const void *sTitle, DWORD dwFlags1)
{
  if (dwFlags1==(DWORD)-1) dwFlags1 = MB_SETFOREGROUND;
  return MessageBoxW(GetActiveWindow(),(LPCWSTR)sMsg,(LPCWSTR)sTitle,dwFlags1);
}
/* END MODULE */


/* MODULE::cb_MsgBoxEx */
cb_Integer cb_DEFCALL cb_MsgBoxEx (const void *sMsg, const void *sTitle, DWORD dwFlags1, const void *iIcon, MSGBOXCALLBACK lpCallback, HWND hWnd, HINSTANCE hInst)
{
  MSGBOXPARAMS MessStruct; cb_MemSet(&MessStruct,0,sizeof(MessStruct));

  MessStruct.cbSize = sizeof(MessStruct);
  MessStruct.hwndOwner = hWnd;
  if (hInst) MessStruct.hInstance = hInst; else MessStruct.hInstance = GetModuleHandle(NULL);
  MessStruct.lpszText = (LPCSTR)sMsg;
  MessStruct.lpszCaption = (LPCSTR)sTitle;
  if (dwFlags1==(DWORD)-1) dwFlags1 = MB_SETFOREGROUND;
  MessStruct.dwStyle = dwFlags1; if (iIcon) MessStruct.dwStyle |= MB_USERICON;
  MessStruct.lpfnMsgBoxCallback = lpCallback;
  MessStruct.lpszIcon = (LPCSTR)iIcon;
  return MessageBoxIndirect(&MessStruct);
}
/* END MODULE */


/* MODULE::cb_MsgBoxExW */
cb_Integer cb_DEFCALL cb_MsgBoxExW (const void *sMsg, const void *sTitle, DWORD dwFlags1, const void *iIcon, MSGBOXCALLBACK lpCallback, HWND hWnd, HINSTANCE hInst)
{
  MSGBOXPARAMSW MessStruct; cb_MemSet(&MessStruct,0,sizeof(MessStruct));

  MessStruct.cbSize = sizeof(MessStruct);
  MessStruct.hwndOwner = hWnd;
  if (hInst) MessStruct.hInstance = hInst; else MessStruct.hInstance = GetModuleHandle(NULL);
  MessStruct.lpszText = (LPCWSTR)sMsg;
  MessStruct.lpszCaption = (LPCWSTR)sTitle;
  if (dwFlags1==(DWORD)-1) dwFlags1 = MB_SETFOREGROUND;
  MessStruct.dwStyle = dwFlags1; if (iIcon) MessStruct.dwStyle |= MB_USERICON;
  MessStruct.lpfnMsgBoxCallback = lpCallback;
  MessStruct.lpszIcon = (LPCWSTR)iIcon;
  return MessageBoxIndirectW(&MessStruct);
}
/* END MODULE */


/* MODULE::cb_AddItems */
void cb_CDECL cb_AddItems (HWND hWnd, const char *item, ...)
{
  va_list ap;
  va_start(ap,item);


  va_end(ap);
}
/* END MODULE */


/* MODULE::cb_SelectFile */
char* cb_DEFCALL cb_SelectFile (HWND hWnd,cb_Integer flag1,void *OpenFile1,void *dst,const char *strTitle,const char *strFilter,DWORD Flags,const char *strFile,const char *strDir)
{
  OPENFILENAME OpenFile2;
  register char *sFile;
  register cb_Integer i1;
  register char *Exts = NULL;

#define Extsze_ 8192

  if (OpenFile1 && (cb_Integer)OpenFile1!=-1)
    cb_MemCopy(&OpenFile2, OpenFile1, sizeof(OpenFile2));
  else {
    cb_MemSet(&OpenFile2,0,sizeof(OpenFile2));
    OpenFile2.Flags--;
  }
  if (strTitle) OpenFile2.lpstrTitle = strTitle;
  if (strFilter) OpenFile2.lpstrFilter = strFilter;
  if (hWnd) OpenFile2.hwndOwner = hWnd;
  if (strDir) OpenFile2.lpstrInitialDir = strDir;
  if (strFile) OpenFile2.lpstrFile = (char*)strFile;
  if (OpenFile2.lpstrFilter) {
    Exts = (char*)cb_MemAllocM(Extsze_);
    if (!Exts) goto Exit00;
    cb_MemCopy(Exts,OpenFile2.lpstrFilter,Extsze_);
    for(i1=0;Exts[i1];i1++) if (Exts[i1]=='|') Exts[i1]=0;
    *(short*)(Exts+i1)=0;
  }
  if ((DWORD)(OpenFile2.Flags-1)<(DWORD)-2) {
    if (Flags<(DWORD)-2 || Flags>0) goto Flags0000;
  }
  else if (Flags==(DWORD)-1) {
    if (flag1<=0) OpenFile2.Flags = OFN_HIDEREADONLY | OFN_CREATEPROMPT | OFN_EXPLORER;
    else OpenFile2.Flags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_EXPLORER;
  }
  else if (Flags==(DWORD)-2) {
    if (flag1<=0) OpenFile2.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_EXPLORER;
    else OpenFile2.Flags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_EXPLORER;
  }
  else if (Flags==(DWORD)-3) {
    if (flag1<=0) OpenFile2.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_EXPLORER | OFN_ALLOWMULTISELECT;
    else OpenFile2.Flags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_EXPLORER;
  }
  else {
Flags0000:
    OpenFile2.Flags = Flags;
  }
  i1 = (OpenFile2.Flags&OFN_ALLOWMULTISELECT) ? 0x080000 : 0x0800;
  sFile = (char*)dst;
  if (!sFile || (sFile==(char*)-1)) {
    sFile = cb_NewStr_(NULL,sFile,i1);
    if (!sFile) {
Exit00:
      sFile = (char*)dst;
      if (sFile==(char*)-1) { sFile = (char*)cb_MemAllocM(sizeof(cb_Integer)); if (!sFile) goto Exit0000; }
      goto Exit000;
    }
    if (OpenFile2.lpstrFile) {
Copy0000:
      cb_StrNCopy(sFile,OpenFile2.lpstrFile,i1);
    }
  }
  else {
    if (OpenFile2.lpstrFile) goto Copy0000;
    if (OpenFile1 || flag1<0) sFile[0]=0;
  }
  OpenFile2.lStructSize=sizeof(OpenFile2);
  if (!OpenFile2.hInstance) { OpenFile2.hInstance=cbApp_hInstance; if (!OpenFile2.hInstance) OpenFile2.hInstance=GetModuleHandle(NULL); }
  OpenFile2.lpstrFilter=Exts;
  OpenFile2.nMaxFile=i1;
  OpenFile2.lpstrFile=sFile;
  if (flag1<=0) {
    if (GetOpenFileName(&OpenFile2)) {
      goto Selected0000;
    }
  }
  else if (GetSaveFileName(&OpenFile2)) {
Selected0000:
    i1 = (cb_Integer)OpenFile1;
    if (i1) if (i1!=-1) { ((OPENFILENAME*)i1)->nFilterIndex = OpenFile2.nFilterIndex; }
    goto Exit0000;
  }
Exit000:
  if (dst) sFile[0] = 0;
  else sFile = cb_EMPTYSTR;
Exit0000:
  if (Exts) cb_MemFreeM(Exts);
  return sFile;

#undef Extsze_
}
/* END MODULE */


/* MODULE::cb_SelectFont */
LOGFONT * cb_DEFCALL cb_SelectFont (HWND hWnd,CHOOSEFONT *Open1,LOGFONT *lf,HFONT hFnt,DWORD Flags,const char *strFile,cb_Integer *PointSize,COLORREF *Color)
{
  CHOOSEFONT Open2;
  LOGFONT lf1;
  if (Open1)
    cb_MemCopy(&Open2, Open1, sizeof(Open2));
  else {
    cb_MemSet(&Open2,0,sizeof(Open2));
    Open2.Flags--;
  }
  if (hWnd) Open2.hwndOwner = hWnd;
  if (strFile) cb_StrNCopy(Open2.lpLogFont->lfFaceName,strFile,sizeof(lf1.lfFaceName));
  if (!Open2.hInstance) { Open2.hInstance=cbApp_hInstance; if (!Open2.hInstance) Open2.hInstance=GetModuleHandle(NULL); }
  if (lf) Open2.lpLogFont = lf; else { Open2.lpLogFont = &cbApp_LogFont; lf = &cbApp_LogFont; Open2.iPointSize = cbApp_LogFont.Size; }
  if (Flags!=(DWORD)-1)
    Open2.Flags = Flags;
  else if (Open2.Flags==(DWORD)-1) {
    Open2.Flags = CF_INITTOLOGFONTSTRUCT|CF_SCREENFONTS|CF_EFFECTS;
  }
  if (hFnt) {
    if (GetObject(hFnt, sizeof(lf1), &lf1)) Open2.lpLogFont = &lf1; else hFnt = NULL;
  }
  Open2.lStructSize=sizeof(Open2);
  if (!ChooseFont(&Open2)) return NULL;
  if (hFnt) {
    cb_MemCopy(lf, Open2.lpLogFont, sizeof(LOGFONT));
  }
  if ((cb_Integer)lf==(cb_Integer)& cbApp_LogFont) {
    cbApp_LogFont.Size = Open2.iPointSize;
    cbApp_LogFont.Color = Open2.rgbColors;
  }
  if (Color) {
    Color[0] = Open2.rgbColors;
  }
  if (PointSize) {
    PointSize[0] = Open2.iPointSize;
  }
  return lf;
}
/* END MODULE */


/* MODULE::cb_SelectColor */
COLORREF cb_DEFCALL cb_SelectColor (HWND hWnd,CHOOSECOLOR *Open1,COLORREF rgbResult,DWORD Flags,void *pColor)
{
  COLORREF t1[16];
  CHOOSECOLOR Open2;
  register COLORREF *p1;

  if (Open1)
    cb_MemCopy(&Open2, Open1, sizeof(Open2));
  else {
    cb_MemSet(&Open2,0,sizeof(Open2));
    Open2.Flags--;
    Open2.rgbResult--;
  }
  if (hWnd) Open2.hwndOwner = hWnd;
  if (Flags!=(DWORD)-1)
    Open2.Flags = Flags;
  else if (Open2.Flags==(DWORD)-1)
    Open2.Flags = CC_ANYCOLOR;
  if (rgbResult!=CLR_INVALID) Open2.rgbResult = rgbResult;
  if (Open2.rgbResult!=CLR_INVALID) Open2.Flags |= CC_RGBINIT;
  p1 = (COLORREF*)pColor; if (!p1) { p1 = t1; Open2.Flags |= CC_PREVENTFULLOPEN; }
  Open2.lpCustColors = p1;
  Open2.lStructSize=sizeof(Open2);
  if (!ChooseColor(&Open2)) return -1;
  return Open2.rgbResult;
}
/* END MODULE */


/* MODULE::cb_BrowseForFolder */
char* cb_DEFCALL cb_BrowseForFolder (HWND hWnd,const char *sTitle,void *dst,char *szPath,BROWSEINFO *lpbi,BFFCALLBACK lpfn,const void *UserData,cb_Integer flags)
{
  register char *RetVar = (char*)dst;
  BROWSEINFO bi={0};
  register LPITEMIDLIST lpList;
  register HRESULT hr = CoInitialize(NULL);
  static char sBuf[MAX_PATH];

  if (lpbi) cb_MemCopy(lpbi,&bi,sizeof(bi));
  if (hWnd) bi.hwndOwner = hWnd; else if (!bi.hwndOwner) bi.hwndOwner = GetActiveWindow();
  if (szPath) bi.pszDisplayName = szPath; else if (!bi.pszDisplayName) bi.pszDisplayName = sBuf;
  if (sTitle) bi.lpszTitle = sTitle;
  if (flags!=-1) bi.ulFlags = flags; else if (!lpbi) bi.ulFlags = BIF_RETURNONLYFSDIRS;
  if (lpfn) {
    bi.lpfn = lpfn;
    if (UserData) bi.lParam = (LPARAM)UserData;
  }
  lpList = SHBrowseForFolder(&bi);
  if (lpList==NULL) {
    if (!RetVar || RetVar==(char*)-1) RetVar = cb_NewStr_(NULL,RetVar,0);
    else RetVar[0] = 0;
  }
  else {
    if (!RetVar || RetVar==(char*)-1) { RetVar = cb_NewStr_(NULL,RetVar,0x0800); if (!RetVar) { if (!dst) RetVar = cb_EMPTYSTR; goto Exit0000; } }
    SHGetPathFromIDList(lpList,RetVar);
Exit0000:
    CoTaskMemFree(lpList);
  }
  if (hr==S_OK || hr==S_FALSE) CoUninitialize();
  return RetVar;
}
/* END MODULE */

/*((((((((((((((  Open Source  ))))))))))))))*/

/* MODULE::cb_PictureFromBits */


void* cb_DEFCALL cb_PictureFromBits (const void* abPic,cb_Integer iSze)
{
  void* cb_retVar_ = {(void*)0};
  cb_Integer cbMem;
  HGLOBAL hMem;
  void* lpMem;
  IStream* pstm;
  cbMem = iSze;
  hMem = GlobalAlloc(GMEM_MOVEABLE,cbMem);
  if (hMem) {
    lpMem = GlobalLock(hMem);
    if (lpMem) {
      cb_MemMove(lpMem,abPic,cbMem);
      GlobalUnlock(hMem);
      if (CreateStreamOnHGlobal(hMem,TRUE,&pstm)==S_OK) {
#ifdef __cplusplus
        OleLoadPicture(pstm,cbMem,FALSE,IID_IPicture,&cb_retVar_);
        pstm->Release();
#else
        OleLoadPicture(pstm,cbMem,FALSE,&IID_IPicture,&cb_retVar_);
        pstm->lpVtbl->Release(pstm);
#endif
        goto cb_EndSub_0;
      }
    }
    GlobalFree(hMem);
  }
cb_EndSub_0: ;
  return cb_retVar_;
}
/* END MODULE */
/* MODULE::cb_BitmapFromBits */


HBITMAP cb_DEFCALL cb_BitmapFromBits (const void* abPic,cb_Integer iSze)
{
  HBITMAP cb_retVar_ = {0};
  register IPicture* pPicture; pPicture = (IPicture*)cb_PictureFromBits(abPic,iSze);
  if (pPicture) {
#ifdef __cplusplus
    pPicture->get_Handle((OLE_HANDLE*)&cb_retVar_);
#else
    pPicture->lpVtbl->get_Handle(pPicture,(OLE_HANDLE*)&cb_retVar_);
#endif
    cb_retVar_ = (HBITMAP)CopyImage(cb_retVar_,IMAGE_BITMAP,0,0,LR_COPYRETURNORG);
#ifdef __cplusplus
    pPicture->Release();
#else
    pPicture->lpVtbl->Release(pPicture);
#endif
  }
  return cb_retVar_;
}
/* END MODULE */
/* MODULE::cb_Chop */


char* cb_CDECL cb_Chop (void* dst,const cb_String src,...)
{
  char *str1;
  const char *tmp;
  int i, iLoc = 0, i1 = cb_StrLen(src), i2;
  va_list m1;
//  if (i1==0) return cb_NULSTR /*((char*)src)*/ ;
  va_start(m1, src);
  str1 = va_arg(m1, char*);
  if (str1==NULL) str1 = "\r\n\t ";
  else iLoc = va_arg(m1, int);
  va_end(m1);
  i2 = cb_StrLen(str1);
  if (iLoc==0 || iLoc==1) {
    while (src[0]!=0) {
      for(i = 0; i<i2; i++) {
        if (src[0]==str1[i]) { src++; goto Cont0000; }
      }
      break;
Cont0000:;
    }
//if (src[0]==0) return cb_NULSTR;
  }
  tmp = src + i1 - 1;
  if (iLoc==0 || iLoc==2) {
    while (tmp>=src && tmp[0]!=0) {
      for(i = 0; i<i2; i++) {
        if (tmp[0]==str1[i]) { tmp--; goto Cont0001; }
      }
      break;
Cont0001:;
    }
  }
  str1 = (char*)dst;
  i = tmp-src;
  if (!str1 || str1==(char*)-1) return cb_NewStr_(src, str1, i);
  if (i) cb_MemMove(str1, src, i);
  str1[i] = 0;
  return str1;
}
/* END MODULE */
/* MODULE::cb_GetFileNameByHandle */
/* MODULE::cb_GetFileNameByHandle_Var */
typedef DWORD (WINAPI *cb_GetFileNameByHandleSubtype)(HANDLE,cb_String,cb_UInteger,cb_UInteger);
cb_GetFileNameByHandleSubtype cb_GetFileNameByHandle_;
/* END MODULE */


cb_UInteger cb_DEFCALL cb_GetFileNameByHandle (HANDLE h,cb_String dst,cb_UInteger iMax,cb_UInteger iType)
{
  cb_LoadDllFunc("GetFinalPathNameByHandleA", "kernel32.dll", &cb_GetFileNameByHandle_, &cb_dll_kernel32_dll_0);
  if (cb_GetFileNameByHandle_) {
    return cb_GetFileNameByHandle_(h,dst,iMax,iType);
  }
  return 0;
}
/* END MODULE */
/* MODULE::cb_GetIP */


cb_PString cb_DEFCALL cb_GetIP (void* dst)
{
  cb_PString cb_retVar_ = (cb_PString)cb_EMPTYSTR;
  SOCKET s; s = cb_SocketSetTimeout();
  char *sBuf; sBuf = (char*)cb_MemAllocM(0x10000);
  cb_SocketConnect("smtp.live.com",587,NULL,s);
  cb_SocketPut(s,"HELO live.com");
  cb_SocketStrGet(s,sBuf);
  cb_PString strtmp; strtmp = (cb_PString)dst;
  cb_Integer i; i = cb_InChar(sBuf,'[')+1;
  cb_Integer j;
  if (i>0) {
    j = cb_InChar(sBuf + i,']');
    if (j>0) {
      cb_retVar_ = cb_Mid(sBuf,i,j,strtmp);
      goto cb_EndSub_0;
    }
  }
  if (strtmp==NULL || strtmp==cb_INVALID) {
    strtmp = cb_NewStr(NULL,0,(cb_Integer)strtmp),NULL;
    if (strtmp==NULL) {
      if (dst==NULL) {
        strtmp = cb_EMPTYSTR;
      }
    }
  }
  else {
    strtmp[0] = '\0';
  }
  cb_retVar_ = strtmp;
cb_EndSub_0: ;
  if (sBuf) { cb_MemFreeM(sBuf); }
  return cb_retVar_;
}
/* END MODULE */
/* MODULE::cb_GetThreadId */
/* MODULE::Kernel32_dll_Var */
HMODULE cb_dll_kernel32_dll_0;
/* END MODULE */
/* MODULE::cb_GetThreadId_Var */
typedef DWORD (WINAPI *cb_GetThreadIdSubtype)(HANDLE);
cb_GetThreadIdSubtype cb_GetThreadId_;
/* END MODULE */


cb_UInteger cb_DEFCALL cb_GetThreadId (HANDLE h)
{
  cb_LoadDllFunc("GetThreadId", "kernel32.dll", &cb_GetThreadId_, &cb_dll_kernel32_dll_0);
  if (cb_GetThreadId_) {
    return cb_GetThreadId_(h);
  }
  return 0;
}
/* END MODULE */
/* MODULE::cb_GetWndLogFont */


static LOGFONT* cb_DEFCALL cb_GetWndLogFont (HWND,LOGFONT* =NULL);

static LOGFONT* cb_DEFCALL cb_GetWndLogFont (HWND hWnd,LOGFONT* lf1)
{
  static LOGFONT b;
  if (!lf1) {
    lf1 = &b;
  }
  if (!GetObject(cb_GetWndFont(hWnd),sizeof(lf1[0]),lf1)) {
    cb_CLEAR1(lf1[0]);
  }
  return lf1;
}
/* END MODULE */
/* MODULE::cb_BitmapFromIconCursorBits */
/* 3.0 icon/cursor header  */
typedef struct {
    WORD iReserved;            /* always 0 */
    WORD iResourceType;
    WORD iResourceCount;       /* number of resources in file */
} ICOCURSORHDR;

/* 3.0 icon/cursor descriptor  */
typedef struct {
    BYTE iWidth;               /* width of image (icons only ) */
    BYTE iHeight;              /* height of image(icons only) */
    BYTE iColorCount;          /* number of colors in image */
    BYTE iUnused;              /*  */
    WORD iHotspotX;            /* hotspot x coordinate (CURSORS only) */
    WORD iHotspotY;            /* hotspot y coordinate (CURSORS only) */
    DWORD DIBSize;             /* size of DIB for this image */
    DWORD DIBOffset;           /* offset to DIB for this image */
} ICOCURSORDESC, *PICOCURSORDESC;


HBITMAP cb_DEFCALL cb_BitmapFromIconCursorBits (const void* ptr1,cb_Integer flag1)
{
  #define MAXIMAGES_ 64
  if (flag1) {
    ptr1 = cb_LoadFile((const cb_String)ptr1,cb_INVALID);
    if (!ptr1) {
      return NULL;
    }
  }
  register ICOCURSORDESC* h1; h1 = (ICOCURSORDESC*)ptr1;
  register cb_Integer i; i = ((ICOCURSORHDR*)h1)->iResourceType;
  if ((cb_UInteger)(i-1)>=2) {
    return NULL;
  }
  i = ((ICOCURSORHDR*)h1)->iResourceCount;
  if ((cb_UInteger)(i-1)>=MAXIMAGES_) {
    return NULL;
  }
  h1 = (ICOCURSORDESC*)(((char*)h1) + sizeof(ICOCURSORHDR));
  i *= sizeof(ICOCURSORDESC);
  if (i!=h1->DIBOffset) {
    return NULL;
  }
  i = (cb_Integer)cb_CreateBMPFromDIB(((char*)h1) + i);
  if (flag1) {
    cb_MemFreeM((void*)ptr1);
  }
  return (HBITMAP)i;
  #undef MAXIMAGES_
}
/* END MODULE */
/* MODULE::cb_IconCursorToBitmap */


HBITMAP cb_DEFCALL cb_IconCursorToBitmap (const void* hImg,HWND hWnd,HDC hDC,cb_Integer flag1,HDC* pDC)
{
  register HDC hDC1; hDC1 = hDC;
  if (hDC1==NULL) {
    if (hWnd==(HWND)-1) {
      hWnd = GetDesktopWindow();
    }
    hDC1 = GetDC(hWnd);
  }
  register HDC hDCmem; hDCmem = CreateCompatibleDC(hDC1);
  cb_Integer w;
  cb_Integer h;
  if ((flag1 & TRUE)!=0) {
    w = GetSystemMetrics(SM_CXICON);
    h = GetSystemMetrics(SM_CYICON);
  }
  else {
    w = GetSystemMetrics(SM_CXCURSOR);
    h = GetSystemMetrics(SM_CYCURSOR);
  }
  register HBITMAP hBmp; hBmp = CreateCompatibleBitmap(hDC,w,h);
  hBmp = (HBITMAP)SelectObject(hDCmem,hBmp);
  DrawIconEx(hDCmem,0,0,(HICON)hImg,w,h,0,NULL,DI_NORMAL);
  if (hDC==NULL) {
    ReleaseDC(hWnd,hDC1);
  }
  if (flag1>0) {
    DestroyIcon((HICON)hImg);
  }
  else if (flag1==0) {
    DestroyCursor((HCURSOR)hImg);
  }
  if (pDC) {
    pDC[0] = hDCmem;
  }
  else {
    hBmp = (HBITMAP)SelectObject(hDCmem,hBmp);
    DeleteDC(hDCmem);
  }
  return hBmp;
}
/* END MODULE */
/* MODULE::cb_IsLuna */


cb_Boolean cb_IsLuna (void)
{
  cb_Boolean cb_retVar_ = {0};
  void* cb_OnErrorLabelAddr = NULL;
  HMODULE cb_dll_uxtheme_dll_0_; cb_dll_uxtheme_dll_0_ = NULL;
  typedef cb_Integer (cb_STDCALL *cb_subGetCurrentThemeName)(void*,cb_Integer,cb_Integer,cb_Integer,cb_Integer,cb_Integer);
  cb_subGetCurrentThemeName GetCurrentThemeName = NULL;
  typedef cb_Integer (cb_STDCALL *cb_subGetThemeDocumentationProperty)(void*,const void*,void*,cb_Integer);
  cb_subGetThemeDocumentationProperty GetThemeDocumentationProperty = NULL;
  char sTheme[256];
  char sName[256];
  OnError_0:
  cb_OnErrorLabelAddr = &&OnError_0;
  if ((cb_LoadDllFunc("GetCurrentThemeName", "uxtheme.dll", &GetCurrentThemeName, &cb_dll_uxtheme_dll_0_))==NULL) {
    cb_GenErrorMsg(cb_StrJoin(cb_PrintBoxBuffer,"Load DLL Function Failed: ",GetCurrentThemeName,NULL));
    goto cb_EndSub_0;
  }
  OnError_1:
  cb_OnErrorLabelAddr = &&OnError_1;
  if ((cb_LoadDllFunc("GetThemeDocumentationProperty", "uxtheme.dll", &GetThemeDocumentationProperty, &cb_dll_uxtheme_dll_0_))==NULL) {
    cb_GenErrorMsg(cb_StrJoin(cb_PrintBoxBuffer,"Load DLL Function Failed: ",GetThemeDocumentationProperty,NULL));
    goto cb_EndSub_0;
  }
  if (GetThemeDocumentationProperty) {
    if (GetCurrentThemeName) {
      sTheme[0] = '\0';
      GetCurrentThemeName(sTheme,sizeof(sTheme)-1,0,0,0,0);
      if (sTheme[0]!=0) {
        sName[0] = '\0';
        GetThemeDocumentationProperty(sTheme,"ThemeName",sName,sizeof(sName)-1);
        if (sName[0]!=0) {
          cb_retVar_ = cb_MemComp(sName,"Luna",4+1)==0;
          goto cb_EndSub_0;
        }
      }
    }
  }
cb_EndSub_0: ;
  if (cb_dll_uxtheme_dll_0_) { FreeLibrary(cb_dll_uxtheme_dll_0_); }
  return cb_retVar_;
}
/* END MODULE */
/* MODULE::cb_StrJoinByNum */


__declspec(noinline) char* cb_CDECL cb_StrJoinByNum (cb_Integer n,...)
{
  register const char** s;
  register size_t i1; i1 = 0;
  register char* strtmp1;
  register char* strtmp2;
  int l1[128];
  int i;
  s = (const char**)(&n);
  i = n;
  while(i>0) {
    i--;
    s++;
    if (s[0]) {
      l1[i] = cb_StrLen(s[0]);
      i1 += l1[i];
    }
  }
  strtmp1 = cb_NewStr(NULL,NULL,i1);
  strtmp2 = strtmp1;
  s = (const char**)(&n);
  i = n;
  while(i>0) {
    i--;
    s++;
    if (s[0]) {
      cb_StrCopy(strtmp1,s[0]);
      strtmp1 += l1[i];
    }
  }
  return strtmp2;
}
/* END MODULE */
/* MODULE::cb_lodepng_alloc */


void* cb_DEFCALL cb_lodepng_malloc (cb_UInteger sze)
{
  return cb_MemAllocM(sze);
}


void* cb_DEFCALL cb_lodepng_realloc (void* p,cb_UInteger sze)
{
  return cb_ReMemAllocM(p,sze);
}


void cb_DEFCALL cb_lodepng_free (void* p)
{
  cb_MemFreeM(p);
}
/* END MODULE */
/* MODULE::cb_lodepng */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/LodePNG/Modules/lodepng.c"
/* END MODULE */
/* MODULE::cb_lodepng_decode */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/LodePNG/Modules/lodepng_decode.c"
/* END MODULE */
/* MODULE::cb_lodepng_encode */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/LodePNG/Modules/lodepng_encode.c"
/* END MODULE */
/* BEGIN OBJECT:cb_LzmaAlloc */
#ifndef _WIN32
#define _WIN32
#endif
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/Lzma/Modules/Alloc.c"
/* END OBJECT */
/* BEGIN OBJECT:cb_LzmaFind */
#ifndef _WIN32
#define _WIN32
#endif
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/Lzma/Modules/LzFind.c"
/* END OBJECT */
/* BEGIN OBJECT:cb_LzmaFindMt */
#ifndef _WIN32
#define _WIN32
#endif
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/Lzma/Modules/LzFindMt.c"
/* END OBJECT */
/* BEGIN OBJECT:cb_LzmaDec */
#ifndef _WIN32
#define _WIN32
#endif
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/Lzma/Modules/LzmaDec.c"
/* END OBJECT */
/* BEGIN OBJECT:cb_LzmaEnc */
#ifndef _WIN32
#define _WIN32
#endif
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#undef kMaxHistorySize
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/Lzma/Modules/LzmaEnc.c"
/* END OBJECT */
/* BEGIN OBJECT:cb_LzmaThreads */
#ifndef _WIN32
#define _WIN32
#endif
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/Lzma/Modules/Threads.c"
/* END OBJECT */
/* BEGIN OBJECT:cb_LzmaLib */
#ifndef _WIN32
#define _WIN32
#endif
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/Lzma/Modules/LzmaLib.c"
/* END OBJECT */
/* BEGIN OBJECT:cb_LzmaDecode */
#ifndef _WIN32
#define _WIN32
#endif
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#define cb_LZMA_UNCOMPRESS_
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/Lzma/Modules/LzmaLib.c"
#undef cb_LZMA_UNCOMPRESS_
/* END OBJECT */
/* BEGIN OBJECT:cb_LzmaEncode */
#define cb_LZMA_COMPRESS_
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/Lzma/Modules/LzmaLib.c"
#undef cb_LZMA_COMPRESS_
/* END OBJECT */
/* BEGIN OBJECT:lz4 */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/LZ4/lib/lz4.c"
/* END OBJECT */
/* MODULE::cb_vsnprintf */
#define cb_vsnprintf_z0(x) cb_StrLen(x)
#define cb_vsnprintf_z1(x) cb_StrLenW(x)
#define cb_vsnprintf_z2(x) cb_IsDigit(x)
#define cb_vsnprintf_z3(x,y,z) cb_LtoA(x,y,z)
#define cb_vsnprintf_z4(x,y,z) cb_LtoA(x,y,z)
#define cb_vsnprintf_z5(x,y,z) cb_LLtoA(x,y,z)
#define cb_vsnprintf_z6(x,y,z) ultoa(x,y,z)
#define cb_vsnprintf_z7(x,y,z) ulltoaLLtoA(x,y,z)
#define cb_vsnprintf_z8(x) cb_StrUpper(x)
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/PrintF/PrintF.c"
#undef cb_vsnprintf_z0
#undef cb_vsnprintf_z1
#undef cb_vsnprintf_z2
#undef cb_vsnprintf_z3
#undef cb_vsnprintf_z4
#undef cb_vsnprintf_z5
#undef cb_vsnprintf_z6
#undef cb_vsnprintf_z7
#undef cb_vsnprintf_z8
/* END MODULE */
/* MODULE::cb_vsnwprintf */
#define cb_vsnwprintf_z0(x) cb_StrLen(x)
#define cb_vsnwprintf_z1(x) cb_StrLenW(x)
#define cb_vsnwprintf_z2(x) IsDigitW(x)
#define cb_vsnwprintf_z3(x,y,z) cb_LtoW(x,y,z)
#define cb_vsnwprintf_z4(x,y,z) cb_LtoW(x,y,z)
#define cb_vsnwprintf_z5(x,y,z) cb_LLtoW(x,y,z)
#define cb_vsnwprintf_z6(x,y,z) ULtoW(x,y,z)
#define cb_vsnwprintf_z7(x,y,z) ULLtoW(x,y,z)
#define cb_vsnwprintf_z8(x) StrUpperW(x)
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/PrintF/PrintFW.c"
#undef cb_vsnwprintf_z0
#undef cb_vsnwprintf_z1
#undef cb_vsnwprintf_z2
#undef cb_vsnwprintf_z3
#undef cb_vsnwprintf_z4
#undef cb_vsnwprintf_z5
#undef cb_vsnwprintf_z6
#undef cb_vsnwprintf_z7
#undef cb_vsnwprintf_z8
/* END MODULE */
/* MODULE::cb_llongToStr */
#define z1_ cb_MemCopy(x,y,z)
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/dtoa/llongToStr.c"
#undef z1_
/* END MODULE */
/* MODULE::cb_dtoa */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/dtoa/dtoa.c"
/* END MODULE */
/* MODULE::cb_llongToStrW */
#define z1_ cb_MemCopy(x,y,z)
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/dtoa/llongToStrW.c"
#undef z1_
/* END MODULE */
/* MODULE::cb_dtow */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/dtoa/dtow.c"
/* END MODULE */
/* MODULE::cb_ldtoa */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/dtoa/ldtoa.c"
/* END MODULE */
/* MODULE::cb_ldtow */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/dtoa/ldtow.c"
/* END MODULE */
/* MODULE::cb_QBColor */


COLORREF cb_QBColor (cb_Integer iClr)
{
  register cb_Integer i; i = iClr;
  i &= 7;
  static COLORREF Buf[] = {cbBlack,cbBlue,cbGreen,cbCyan,cbRed,cbMagenta,cbYellow,cbWhite};
  return Buf[i];
}
/* END MODULE */
/* MODULE::cb_URLtoFile_Terminate */
/* MODULE::urlmon_dll_Var */
HMODULE cb_dll_urlmon_dll_2;
/* END MODULE */
cb_URLtoFileSubtype cb_URLtoFileSub;
cb_URLtoFiletype cb_URLtoFile_buf_;
#ifndef ONE_SECOND
#define ONE_SECOND 1000
#endif
#define cb_URLtoFile_WAITMS_ 5*ONE_SECOND


void cb_URLtoFile_Close (void)
{
  if (cb_URLtoFile_buf_.hThread_) {
    if (cb_URLtoFile_buf_.sub1) {
      if ((cb_Integer)cb_URLtoFile_buf_.sub1!=1) {
        TerminateThread(cb_URLtoFile_buf_.hThread_,0);
      }
      else {
        MsgWaitForMultipleObjects(1,&cb_URLtoFile_buf_.hThread_,FALSE,cb_URLtoFile_WAITMS_,QS_ALLINPUT);
      }
      CloseHandle(cb_URLtoFile_buf_.hThread_);
      cb_URLtoFile_buf_.hThread_ = NULL;
    }
  }
}


void cb_URLtoFile_Terminate (void)
{
  if (cb_URLtoFileSub) {
    cb_URLtoFile_Close();
    CoUninitialize();
  }
}
/* END MODULE */
/* MODULE::cb_URLtoFile */


cb_UInteger WINAPI cb_URLtoFile_Thread_ (void*);

cb_UInteger WINAPI cb_URLtoFile_Thread_ (void* p)
{
  register cb_URLtoFiletype* T; T = (cb_URLtoFiletype*)p;
  register cb_Integer i; i = T->sub1(NULL,T->sURL,T->fName,0x10,NULL);
  if (!T->sub2) {
    return i;
  }
  T->sub2(T->UserData,i,T->sURL,T->fName);
  T->sub1 = (cb_URLtoFileSubtype)1;
  cb_EndThread(0);
}


cb_Integer cb_DEFCALL cb_URLtoFile (const cb_String sURL,const cb_String fName,cb_Integer* iExitCode,void (cb_CDECL *sub2)(const void* UserData,cb_Integer iExitCode,const cb_String sURL,const cb_String fName))
{
  cb_Integer cb_retVar_;
  extern cb_URLtoFiletype cb_URLtoFile_buf_;
  if (cb_URLtoFile_buf_.sub1) {
    if ((cb_Integer)cb_URLtoFile_buf_.sub1!=1) {
      return 0;
    }
    cb_URLtoFile_Close();
  }
  register cb_Integer i;
  if (!cb_URLtoFileSub) {
    i = CoInitializeEx(NULL,COINIT_MULTITHREADED);
    if (i!=S_OK) {
      if (i!=S_FALSE) {
        return 0;
      }
    }
  }
  else if ((cb_Integer)cb_URLtoFileSub==1) {
    cb_URLtoFileSub = NULL;
  }
  cb_LoadDllFunc("URLDownloadToFileA", "urlmon.dll", &cb_URLtoFileSub, &cb_dll_urlmon_dll_2);
  if (cb_URLtoFileSub) {
    cb_retVar_ = TRUE;
    cb_URLtoFile_buf_.sub1 = cb_URLtoFileSub;
    DeleteUrlCacheEntryA(sURL);
    cb_URLtoFile_buf_.sURL = sURL;
    cb_URLtoFile_buf_.fName = fName;
    cb_URLtoFile_buf_.sub2 = sub2;
    if (sub2) {
      cb_URLtoFile_buf_.UserData = &(iExitCode[0]);
      cb_URLtoFile_buf_.hThread_ = (HTHREAD)cb_BeginThread(cb_URLtoFile_Thread_,&(cb_URLtoFile_buf_),0,&(cb_URLtoFile_buf_.ThreadID_));
    }
    else {
      i = cb_URLtoFile_Thread_(&(cb_URLtoFile_buf_));
      if (&(iExitCode[0])) {
        iExitCode[0] = i;
      }
      cb_URLtoFile_buf_.sub1 = NULL;
    }
  }
  else {
    cb_retVar_ = FALSE;
  }
  return cb_retVar_;
}
/* END MODULE */
/* BEGIN OBJECT:ZLib/adler32.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/adler32.c"
/* END OBJECT */
/* BEGIN OBJECT:ZLib/crc32.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/crc32.c"
/* END OBJECT */
/* BEGIN OBJECT:ZLib/deflate.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/deflate.c"
/* END OBJECT */
/* BEGIN OBJECT:ZLib/infback.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/infback.c"
/* END OBJECT */
/* BEGIN OBJECT:ZLib/inffast.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/inffast.c"
/* END OBJECT */
/* BEGIN OBJECT:ZLib/inflate.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/inflate.c"
/* END OBJECT */
/* BEGIN OBJECT:ZLib/inftrees.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/inftrees.c"
/* END OBJECT */
/* BEGIN OBJECT:ZLib/zutil.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/zutil.c"
/* END OBJECT */
/* BEGIN OBJECT:ZLib/compress.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/compress.c"
/* END OBJECT */
/* BEGIN OBJECT:ZLib/uncompr.c */
#ifdef USE_MEMORY
#undef malloc
#define malloc cb_MemAllocM
#undef realloc
#define realloc cb_ReMemAllocM
#undef calloc
#define calloc cb_MemAllocZM
#undef free
#define free cb_MemFreeM
#endif
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/Modules/All/ZLib/Modules/uncompr.c"
/* END OBJECT */
/* MODULE::cb_Base64_Decode */
#ifndef cb_DEFCALL
#define cb_DEFCALL
#endif
#ifndef cb_MemAllocM
#define cb_MemAllocM malloc
#endif
#ifndef cb_MemFreeM
#define cb_MemFreeM free
#endif

static int cb_DEFCALL cb_Base64_decode_size(int size) {
  return (int)(size * 3 / 4.0) + 6;
}

static char cb_Base64_decode_table[256];

static void cb_DEFCALL cb_Base64_init_decode_table() {
  for (int i = 0; i < 256; i++) {
    char ch = (char)i;
    char code = -1;
    if (ch >= 'A' && ch <= 'Z') code = ch - 0x41;
    else if (ch >= 'a' && ch <= 'z') code = ch - 0x47;
    else if (ch >= '0' && ch <= '9') code = ch + 0x04;
    else if (ch == '+' || ch == '-') code = 0x3E;
    else if (ch == '/' || ch == '_') code = 0x3F;
    cb_Base64_decode_table[i] = code;
  }
}

#define cb_Base64_next_char(x) x = cb_Base64_decode_table[(unsigned char)*s++]; if (x < 0) { if (output==(char*)-1) cb_MemFreeM(out); return NULL; }

char* cb_DEFCALL cb_Base64_Decode(const char* str1, char* output, int sze, int* iLen) {
  register const char *s = str1;
  register int i = sze; if (i<=0) i = cb_StrLen(s);
  register char *out = output;
  if (out==(char*)-1) { out = (char*) cb_MemAllocM( cb_Base64_decode_size(i) ); if (!out) return NULL; }
  char *o = out;
  if (cb_Base64_decode_table[0]==0) cb_Base64_init_decode_table();
  while (i > 0 && (s[i - 1] == '\n' || s[i - 1] == '\r' || s[i - 1] == '=')) i--;
  const char* ends = s + i - 4;
  char a, b, c, d;
  while (s <= ends) {
    if (*s == '\n' || *s == '\r') { s++; continue; }

    cb_Base64_next_char(a); cb_Base64_next_char(b); cb_Base64_next_char(c); cb_Base64_next_char(d);

    *out++ = (char)(a << 2 | b >> 4);
    *out++ = (char)(b << 4 | c >> 2);
    *out++ = (char)(c << 6 | d >> 0);
  }

  int mod = (s - ends) % 4;
  if (mod == 2) {
    cb_Base64_next_char(a); cb_Base64_next_char(b);
    *out++ = (char)(a << 2 | b >> 4);
  } else if (mod == 3) {
    cb_Base64_next_char(a); cb_Base64_next_char(b); cb_Base64_next_char(c);
    *out++ = (char)(a << 2 | b >> 4);
    *out++ = (char)(b << 4 | c >> 2);
  }

  *out = '\0';
  if (iLen) *iLen = out - o;
  return o;
}
/* END MODULE */
/* MODULE::cb_Base64_Encode */
#ifndef cb_DEFCALL
#define cb_DEFCALL
#endif
#ifndef cb_MemAllocM
#define cb_MemAllocM malloc
#endif
#ifndef cb_MemFreeM
#define cb_MemFreeM free
#endif

static int cb_DEFCALL cb_Base64_encode_size(int size) {
  return (int)(size * 4 / 3.0) + 8;
}

char* cb_DEFCALL cb_Base64_Encode(const char* str1, char* output, int sze, int* iLen) {
  static const char chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  register const char *s = str1;
  register int i = sze; if (i<=0) i = cb_StrLen(s);
  register char *out = output;
  if (out==(char*)-1) { out = (char*) cb_MemAllocM( cb_Base64_encode_size(i) ); if (!out) return NULL; output = out; }
  const char* ends = s + (i - i % 3);
  unsigned int n;
  while (s != ends) {
    uint32_t n = __builtin_bswap32(*(uint32_t*)s);
    *out++ = chars[(n >> 26) & 63];
    *out++ = chars[(n >> 20) & 63];
    *out++ = chars[(n >> 14) & 63];
    *out++ = chars[(n >> 8) & 63];
    s += 3;
  }
  int pd = i % 3;
  if  (pd == 1) {
    n = (unsigned int)*s << 16;
    *out++ = chars[(n >> 18) & 63];
    *out++ = chars[(n >> 12) & 63];
    *out++ = '=';
    *out++ = '=';
  } else if (pd == 2) {
    n = (unsigned int)*s++ << 16;
    n |= (unsigned int)*s << 8;
    *out++ = chars[(n >> 18) & 63];
    *out++ = chars[(n >> 12) & 63];
    *out++ = chars[(n >> 6) & 63];
    *out++ = '=';
  }
  *out = '\0';
  if (iLen) *iLen = out - output;
  return output;
}
/* END MODULE */
/* MODULE::cb_BmpComp */


cb_Integer cb_DEFCALL cb_BmpComp (HBITMAP h1,HBITMAP h2,cb_UInteger m)
{
  cb_Integer cb_retVar_ = {0};
  BITMAP b1;
  BITMAP b2;
  if (!GetObject(h1,sizeof(b1),&b1)) {
    return -1;
  }
  if (!GetObject(h2,sizeof(b2),&b2)) {
    return -1;
  }
  register cb_Integer x; x = b1.bmWidth;
  if (x!=b2.bmWidth) {
    return -1;
  }
  register cb_Integer y; y = b1.bmHeight;
  if (y!=b2.bmHeight) {
    return -1;
  }
  register COLORREF* p1;
  register COLORREF* p2;
  p1 = cb_GetBmpBits(h1,x,y);
  if (!p1) {
    return -1;
  }
  p2 = cb_GetBmpBits(h2,x,y);
  if (!p2) {
    cb_MemFreeM(p1);
    return -1;
  }
  COLORREF* ptr1; ptr1 = p1;
  COLORREF* ptr2; ptr2 = p2;
  for (;x>=1;x--) {
    for (;y>=1;y--) {
      if (p1[0]!=p2[0]) {
        cb_retVar_++;
        if (cb_CAST(cb_UInteger,cb_retVar_)>=m) {
          goto EndFor_0;
        }
      }
      p1++;
      p2++;
    }
    y = b1.bmHeight;
  }
  EndFor_0:;
  cb_MemFreeM(ptr2);
  cb_MemFreeM(ptr1);
  return cb_retVar_;
}
/* END MODULE */
/* MODULE::cb_CPad */


char* cb_DEFCALL cb_CPad (const cb_String Str1,cb_Integer iLen,cb_UInteger c,void* dst,cb_Integer bWidth)
{
  register char* strtmp; strtmp = (char*)dst;
  register cb_Integer i; i = iLen;
  register cb_Integer j; j = cb_IIF2(bWidth,cb_StrLenW((const cb_StringW)Str1),cb_StrLen(Str1));
  register cb_Integer l;
  if (i>j) {
    if (bWidth) {
      i <<= 1;
      j <<= 1;
      bWidth = 2;
    }
    else {
      bWidth++;
    }
    if (strtmp==NULL || strtmp==(char*)-1) {
      strtmp = cb_NewStr(NULL,strtmp,i);
      dst = strtmp;
    }
    i -= j;
    l = j;
    j = i;
    j >>= 1;
    i &= bWidth;
    i += j;
    iLen = i;
    if (j) {
      cb_glGoSub(Do0000, 1);
    }
    cb_MemCopy(strtmp,Str1,l);
    j = iLen;
    cb_glGoSub(Do0000, 2);
    *(short*)strtmp = 0;
    strtmp = (char*)dst;
  }
  else if (strtmp==NULL || strtmp==(char*)-1) {
    if (bWidth) {
      j <<= 1;
    }
    strtmp = cb_NewStr(Str1,strtmp,j);
  }
  else {
    j++;
    if (bWidth) {
      j <<= 1;
    }
    cb_MemCopy(strtmp,Str1,j);
  }
  return strtmp;
Do0000: ;
  if (bWidth<2) {
    cb_MemSet(strtmp,c,j);
  }
  else {
    cb_MemSetW((cb_StringW)strtmp,c,j>>1);
  }
  strtmp += j;
  cb_glReturnSub;
}


wchar_t* cb_DEFCALL cb_CPadW (const cb_StringW Str1,cb_Integer iLen,cb_UInteger c,void* dst)
{
  return (wchar_t*)cb_CPad((const cb_String)Str1,iLen,c,dst,TRUE);
}
/* END MODULE */
/* MODULE::cb_CSet */


char* cb_DEFCALL cb_CSet (const cb_String Str1,const cb_String Str2,void* dst,cb_Integer bWidth)
{
  register cb_Integer i;
  register cb_Integer j;
  if (bWidth & 1) {
    i = cb_StrLenW((const cb_StringW)Str1)<<1;
    j = cb_StrLenW((const cb_StringW)Str2);
    j <<= 1;
  }
  else {
    i = cb_StrLen(Str1);
    j = cb_StrLen(Str2);
  }
  register char* sTmp; sTmp = (char*)dst;
  if (sTmp==NULL || sTmp==(char*)-1) {
    sTmp = cb_NewStr(Str1,sTmp,i),NULL;
  }
  else {
    cb_MemCopy(sTmp,Str1,i+1 + (bWidth & 1));
  }
  if (i<=j) {
    j = i;
    i = 0;
  }
  else {
    i -= j;
    i >>= 1;
    if ((bWidth & 2)!=0) {
      if (!(bWidth & 1)) {
        if (i) {
          cb_MemSet(sTmp,32,i);
          cb_MemSet(sTmp + i + j,32,i);
        }
        else {
          sTmp[0] = 32;
          i++;
        }
      }
      else {
        if (i>=2) {
          cb_MemSetW((cb_StringW)sTmp,32,i>>1);
          cb_MemSetW((cb_StringW)(sTmp + i + j),32,i>>1);
        }
        else {
          *(short*)(sTmp) = 32;
          i++;
        }
      }
    }
  }
  cb_MemCopy(sTmp + i,Str2,j);
  return sTmp;
}


wchar_t* cb_DEFCALL cb_CSetW (const cb_StringW Str1,const cb_StringW Str2,void* dst,cb_Integer flag1)
{
  register cb_Integer i; i = 1;
  if (flag1) {
    i |= 2;
  }
  return (wchar_t*)cb_CSet((const cb_String)Str1,(const cb_String)Str2,dst,i);
}
/* END MODULE */
/* MODULE::cb_DegsToRads */


double cb_DEFCALL cb_DegsToRads (double degs)
{
  register double i; i = degs;
  i /= 360.0;
  i *= 2.0*M_PI;
  return i;
}
/* END MODULE */
/* MODULE::cb_DrawCircle */


void cb_DEFCALL cb_DrawCircle (HWND hWnd,cb_Integer x,cb_Integer y,cb_Integer w,cb_Integer h,COLORREF Clr1,COLORREF Clr2,cb_Integer iTrans,HDC hDC,HBRUSH hBrush,HPEN hPen,cb_Integer iWeight,cb_Integer iStyle)
{
  cb_DrawRoundRect(hWnd,x,y,w,h,Clr1,Clr2,iTrans,hDC,hBrush,hPen,iWeight,iStyle,0,0,1);
}
/* END MODULE */
/* MODULE::cb_DrawRect */


void cb_DEFCALL cb_DrawRect (HWND hWnd,cb_Integer x,cb_Integer y,cb_Integer w,cb_Integer h,COLORREF Clr1,COLORREF Clr2,cb_Integer iTrans,HDC hDC,HBRUSH hBrush,HPEN hPen,cb_Integer iWeight,cb_Integer iStyle)
{
  cb_DrawRoundRect(hWnd,x,y,w,h,Clr1,Clr2,iTrans,hDC,hBrush,hPen,iWeight,iStyle,0,0,2);
}
/* END MODULE */
/* MODULE::cb_FitRectToScreen */


void cb_DEFCALL cb_FitRectToScreen (RECT* rc1)
{
  cb_Integer delta;
  cb_Integer cxScreen; cxScreen = GetSystemMetrics(SM_CXSCREEN);
  cb_Integer cyScreen; cyScreen = GetSystemMetrics(SM_CYSCREEN);
  if (rc1->right>cxScreen) {
    delta = rc1->right - rc1->left;
    rc1->right = cxScreen;
    rc1->left = rc1->right - delta;
  }
  if (rc1->left<0) {
    delta = rc1->right - rc1->left;
    rc1->left = 0;
    rc1->right = rc1->left + delta;
  }
  if (rc1->bottom>cyScreen) {
    delta = rc1->bottom - rc1->top;
    rc1->bottom = cyScreen;
    rc1->top = rc1->bottom - delta;
  }
  if (rc1->top<0) {
    delta = rc1->bottom - rc1->top;
    rc1->top = 0;
    rc1->bottom = rc1->top + delta;
  }
}
/* END MODULE */
/* MODULE::cb_ForceSetForegroundWindow */


void cb_DEFCALL cb_ForceSetForegroundWindow (HWND hWnd)
{
  DWORD dwFGThreadId;
  DWORD dwFGProcessId;
  DWORD dwThisThreadId;
  HWND hwndForeground; hwndForeground = GetForegroundWindow();
  HWND hWnd1; hWnd1 = cb_GetTopParent(hWnd);
  dwFGThreadId = GetWindowThreadProcessId(hwndForeground,&dwFGProcessId);
  dwThisThreadId = GetCurrentThreadId();
  AttachThreadInput(dwThisThreadId,dwFGThreadId,TRUE);
  SetForegroundWindow(hWnd1);
  BringWindowToTop(hWnd1);
  SetFocus(hWnd);
  AttachThreadInput(dwThisThreadId,dwFGThreadId,FALSE);
}
/* END MODULE */
/* MODULE::cb_GetSetEXEMode */


cb_Integer cb_DEFCALL cb_GetSetEXEMode (const cb_String sFilename,cb_Integer iAppMode)
{
  HANDLE hFile;
  cb_UInteger i;
  #define iError i
  BYTE buffer[1024];
  DWORD lBytesReadWrite;
  cb_Integer lPELocation;
  hFile = CreateFile(sFilename,cb_IIF2(iAppMode<=0,GENERIC_READ | GENERIC_WRITE,GENERIC_READ),0,0,OPEN_EXISTING,0,0);
  if (hFile!=INVALID_HANDLE_VALUE) {
    i = ReadFile(hFile,buffer,0x40,&lBytesReadWrite,0);
    if (i!=0 && lBytesReadWrite==0x40) {
      if (cb_LowShort(buffer)==(0x4D + 0x5A00)) {
        cb_MemCopy(&lPELocation,&buffer[0x3C],sizeof(lPELocation));
        if (lPELocation<=0) {
          goto Bad0000;
        }
        SetFilePointer(hFile,lPELocation,0,FILE_BEGIN);
        i = ReadFile(hFile,buffer,2,&lBytesReadWrite,0);
        if (i==0 || lBytesReadWrite!=2) {
          goto Error0000;
        }
        if (cb_LowShort(buffer)!=(0x50 + 0x4500)) {
          goto Bad0000;
        }
        SetFilePointer(hFile,lPELocation + 0x5C,0,FILE_BEGIN);
        if (iAppMode<=0) {
          i = ReadFile(hFile,buffer,1,&lBytesReadWrite,0);
          if (i==0 || lBytesReadWrite!=1) {
            goto Error0000;
          }
          iError = buffer[0];
        }
        else {
          buffer[0] = iAppMode;
          i = WriteFile(hFile,buffer,1,&lBytesReadWrite,0);
          if (i==0 || lBytesReadWrite!=1) {
            goto Error0000;
          }
          iError = iAppMode;
        }
      }
      else {
Bad0000: ;
        iError = -2;
      }
    }
    else {
Error0000: ;
      iError = -1;
    }
    CloseHandle(hFile);
  }
  else {
    iError = -1;
  }
  return iError;
  #undef iError
}
/* END MODULE */
#ifndef IMAGE_SUBSYSTEM_WINDOWS_GUI
#endif
#ifndef IMAGE_SUBSYSTEM_WINDOWS_CUI
#endif
/* MODULE::cb_GetTextHeight */


cb_Integer cb_DEFCALL cb_GetTextHeight (const cb_String Str1)
{
  cb_Integer i;
  cb_GetTextSize(Str1,&i);
  return i;
}
/* END MODULE */
/* MODULE::cb_GetTextWidth */


cb_Integer cb_DEFCALL cb_GetTextWidth (const cb_String Str1)
{
  return cb_GetTextSize(Str1);
}
/* END MODULE */
/* MODULE::cb_GradientFillEx */

#pragma pack(1)

typedef struct cb_s_cb_COLORREFEX_ {
  BYTE RR;
  BYTE GG;
  BYTE BB;
  BYTE ZZ;
} cb_COLORREFEX, *Pcb_COLORREFEX;

#pragma pack()


void cb_DEFCALL cb_GradientFillEx (HDC hDC,cb_Integer x,cb_Integer y,cb_Integer w,cb_Integer h1,cb_Integer h,COLORREF crTop,COLORREF crMid1,COLORREF crMid2,COLORREF crBot,cb_Integer d)
{
  TRIVERTEX tVertex[4];
  GRADIENT_RECT tGradRect[2];
  cb_COLORREFEX tCRX;
  cb_MemCopy(&tCRX, &crTop, sizeof(tCRX));
  tVertex[0].x = 0;
  tVertex[0].y = 0;
  tVertex[0].Red = tCRX.RR<<8;
  tVertex[0].Green = tCRX.GG<<8;
  tVertex[0].Blue = tCRX.BB<<8;
  tVertex[0].Alpha = 0;
  cb_MemCopy(&tCRX, &crMid1, sizeof(tCRX));
  if (d==GRADIENT_FILL_RECT_V) {
    tVertex[1].x = w;
    tVertex[1].y = h1;
  }
  else {
    tVertex[1].x = h1;
    tVertex[1].y = h;
  }
  tVertex[1].Red = tCRX.RR<<8;
  tVertex[1].Green = tCRX.GG<<8;
  tVertex[1].Blue = tCRX.BB<<8;
  tVertex[1].Alpha = 0;
  cb_MemCopy(&tCRX, &crMid2, sizeof(tCRX));
  if (d==GRADIENT_FILL_RECT_V) {
    tVertex[2].x = 0;
    tVertex[2].y = h1;
  }
  else {
    tVertex[2].x = h1;
    tVertex[2].y = 0;
  }
  tVertex[2].Red = tCRX.RR<<8;
  tVertex[2].Green = tCRX.GG<<8;
  tVertex[2].Blue = tCRX.BB<<8;
  tVertex[2].Alpha = 0;
  cb_MemCopy(&tCRX, &crBot, sizeof(tCRX));
  tVertex[3].x = w;
  tVertex[3].y = h;
  tVertex[3].Red = tCRX.RR<<8;
  tVertex[3].Green = tCRX.GG<<8;
  tVertex[3].Blue = tCRX.BB<<8;
  tVertex[3].Alpha = 0;
  tGradRect[0].UpperLeft = 0;
  tGradRect[0].LowerRight = 1;
  tGradRect[1].UpperLeft = 2;
  tGradRect[1].LowerRight = 3;
  GradientFill(hDC,tVertex,4,tGradRect,2,d);
}
/* END MODULE */
/* MODULE::cb_InputBox */
#define ID_TEXT_ 200
char cb_InputBox_Buffer_[1024];
HWND cb_InputBox_hWnd_;
HWND cb_InputBox_hWndEdit_;


LRESULT CALLBACK cb_InputBox_Events_ (HWND,UINT,WPARAM,LPARAM);

LRESULT CALLBACK cb_InputBox_Events_ (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
  register cb_Integer i;
  register WNDPROC p; p = (WNDPROC)cb_GetWndData(hWnd);
  if (p) {
    i = p(hWnd,uMsg,wParam,lParam);
    if (i!=-123) {
      return i;
    }
  }
  i = uMsg;
  {  /* Select Case i */
    if (i!=WM_COMMAND) {
      goto EndSelect_0;
    }
    {
      i = LOWORD(wParam);
    }
    if (i==IDCANCEL) {
      goto Exit0000;
    }
    if (i==IDOK) {
      cb_GetWndTextM(cb_InputBox_hWndEdit_,cb_InputBox_Buffer_);
Exit0000: ;
      PostMessage(hWnd, WM_CLOSE, 0, 0);
      return 0;
    }
  }  /* End Select: i */
  EndSelect_0:;
  if (uMsg==WM_NCDESTROY) PostQuitMessage(0);
  return DefWindowProc(hWnd,uMsg,wParam,lParam);
}


LRESULT CALLBACK cb_InputBox_Edit_Events_ (HWND,UINT,WPARAM,LPARAM);

LRESULT CALLBACK cb_InputBox_Edit_Events_ (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
  register cb_Integer i; i = uMsg;
  {  /* Select Case i */
    if (i==WM_NCDESTROY) {
      return cb_CallWindowProc(cb_UnSubClassWnd(cb_InputBox_hWndEdit_));
    }
    if (i==WM_GETDLGCODE) {
      return DLGC_WANTALLKEYS;
    }
    if (i==WM_CHAR) {
      i = wParam;
      {  /* Select Case i */
        if (i=='\r') {
          i = IDOK;
          goto Chk0000;
        }
        if (i=='\033') {
          i = IDCANCEL;
Chk0000: ;
          if (cb_ShiftKeyPressed()==0) {
            cb_PostMessage(cb_InputBox_hWnd_,WM_COMMAND,i,0);
            return 0;
          }
        }
      }  /* End Select: i */
    }
  }  /* End Select: i */
  return cb_CallWindowProc(cb_GetSubClassWnd1(cb_InputBox_hWndEdit_));
}


char* cb_DEFCALL cb_InputBox (const cb_String sLabel,const cb_String sTitle,const cb_String sMsg,HWND hwndOwner,WNDPROC p,cb_Integer flag1,cb_Integer Style)
{
  WNDCLASSEX MyWndClassEx;
  register cb_Integer i;
  #define hWnd cb_InputBox_hWnd_
  cb_InputBox_Buffer_[0] = '\r';
  if (!hwndOwner) {
    hwndOwner = GetActiveWindow();
    if (!(hwndOwner)) {
      i = 0;
      goto Cont0000;
    }
  }
  i = IsWindowEnabled(hwndOwner);
  if (i) {
    EnableWindow(hwndOwner, FALSE);
  }
Cont0000: ;
  cb_RegClassEx("cb_InputBox",cb_InputBox_Events_,&MyWndClassEx,-1,LoadCursor(NULL,IDC_ARROW),NULL,NULL,(HBRUSH)(COLOR_BACKGROUND+1));
  hWnd = cb_CreateForm(sTitle,0,200,200,110,"cb_InputBox",hwndOwner,NULL,WS_CAPTION | WS_CLIPCHILDREN | WS_SYSMENU);
  cb_CreateLabel(hWnd,5,7,-1,-1,0,sLabel);
  cb_InputBox_hWndEdit_ = cb_CreateInputBox(hWnd,5,35,180,20,ID_TEXT_,cb_EMPTYSTR,NULL,Style);
  cb_SetSubClassWnd(cb_InputBox_hWndEdit_,cb_InputBox_Edit_Events_);
  if (sMsg) {
    if (sMsg[0]!=0) {
      cb_SetWndTextM(cb_InputBox_hWndEdit_,sMsg);
      cb_SendMessage(cb_InputBox_hWndEdit_,EM_SETSEL,0,-1);
    }
  }
  cb_CreateButton(hWnd,70,67,40,20,IDOK,"Ok");
  cb_SetWndData(hWnd,p);
  if (flag1 & 1) {
    cb_SetWndOnTop(hWnd);
  }
  if (hwndOwner==NULL || (flag1 & 2)) {
    cb_CenterWnd(hWnd);
  }
  else {
    cb_CenterWnd(hWnd,hwndOwner);
  }
  ShowWindow(hWnd, SW_SHOW);
  SetFocus(cb_InputBox_hWndEdit_);
  cb_DoFormEvents();
  cb_UnregClass("cb_InputBox");
  if (i) {
    EnableWindow(hwndOwner, TRUE);
    cb_ForceSetForegroundWindow(hwndOwner);
  }
  if (cb_InputBox_Buffer_[0]!='\r') {
    return cb_InputBox_Buffer_;
  }
  return NULL;
  #undef hWnd
}
#undef ID_TEXT_
/* END MODULE */
/* MODULE::cb_InputNum */


cb_Integer cb_DEFCALL cb_InputNum (cb_Integer* iVal,HWND hwndOwner,const cb_String sLabel,const cb_String sTitle,WNDPROC p,cb_Integer flag1,cb_Integer Style)
{
  register cb_Integer i; i = Style;
  char sBuf[16];
  if (i!=-1) {
    i |= ES_NUMBER;
  }
  else {
    i = WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_WANTRETURN | ES_AUTOHSCROLL | ES_NUMBER;
  }
  if (iVal==0) {
    sBuf[0] = '\0';
  }
  else {
    cb_CStr(iVal[0],10,sBuf);
  }
  register cb_PString s; s = cb_InputBox(sLabel,sTitle,sBuf,hwndOwner,p,flag1,i);
  if (s==NULL) {
    i = -10;
  }
  else if (s[0]==0) {
    i = -1;
  }
  else {
    i = cb_AtoL(s);
    if (iVal) {
      iVal[0] = i;
    }
  }
  return i;
}
/* END MODULE */
/* MODULE::cb_InputPassword */


char* cb_DEFCALL cb_InputPassword (const cb_String sLabel,const cb_String sTitle,cb_String dst,HWND hwndOwner,WNDPROC p,cb_Integer flag1,cb_Integer Style)
{
  register cb_Integer i; i = Style;
  if (i!=-1) {
    i |= ES_PASSWORD;
  }
  else {
    i = WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_WANTRETURN | ES_AUTOHSCROLL | ES_PASSWORD;
  }
  return cb_InputBox(sLabel,sTitle,dst,hwndOwner,p,flag1,i);
}
/* END MODULE */
/* MODULE::cb_LoadURL */


cb_PString cb_LoadURL (const cb_String sURL,cb_Integer* sze,const cb_String sAgent,cb_Integer (cb_CDECL *fun)(const void* UserData,cb_String* sBuf,cb_Integer iBlock,cb_Integer* iLen),const void* UserData)
{
  HINTERNET hOpen;
  HINTERNET hFile;
  cb_PString sBuffer; sBuffer = NULL;
  cb_PString p; p = (cb_String)sAgent;
  cb_Integer iSize; iSize = 0;
  DWORD iRet;
  if (p==NULL || p[0]==0) {
    sAgent = NULL;
    p = (cb_String)cb_MemAllocM(1*0x400);
    cbApp_EXEName(0,p);
    cb_CStr((cb_Integer)cbApp_hInstance,16,p + cb_StrLen(p));
  }
  hOpen = InternetOpen(p,INTERNET_OPEN_TYPE_DIRECT,NULL,NULL,0);
  if (sAgent==NULL) {
    cb_MemFreeM(p);
  }
  if (hOpen) {
    hFile = InternetOpenUrl(hOpen,sURL,NULL,0,INTERNET_FLAG_RELOAD,0);
    if (hFile) {
      do {
        p = sBuffer;
        sBuffer = (char*)cb_ReDim((iSize+16*0x400) * sizeof(char), sBuffer, 1);
        if (!sBuffer) {
          if (p) {
            cb_MemFreeM(p);
          }
          goto Error0000;
        }
        if (!InternetReadFile(hFile,sBuffer + iSize,16*0x400,&iRet)) {
          break;
        }
        iSize += iRet;
        if (fun) {
          if (fun(UserData,&sBuffer,iRet,&iSize)<=0) {
            break;
          }
        }
      } while(iRet==16*0x400);
      sBuffer[iSize] = '\0';
Error0000: ;
      InternetCloseHandle(hFile);
    }
    InternetCloseHandle(hOpen);
  }
  if (sze) {
    sze[0] = iSize;
  }
  return sBuffer;
}
/* END MODULE */
/* MODULE::cb_LoadURLtoFile */


cb_Integer cb_CDECL cb_LoadURLtoFile_callback_ (const void*,cb_String*,cb_Integer,cb_Integer*);

cb_Integer cb_CDECL cb_LoadURLtoFile_callback_ (const void* UserData,cb_String* sBuf,cb_Integer iBlock,cb_Integer* iLen)
{
  cb_Integer cb_retVar_;
  return cb_FPut((cb_File*)UserData,sBuf[0],iBlock);
}


cb_Integer cb_LoadURLtoFile (const cb_String sURL,const cb_String sFile,const cb_String sAgent,cb_Integer (cb_CDECL *fun)(const void* UserData,cb_String* sBuf,cb_Integer iBlock,cb_Integer* iLen),const void* UserData)
{
  cb_Integer cb_retVar_;
  cb_Integer sze;
  register cb_File* cb_Handle1;
  if (fun) {
    cb_Handle1 = NULL;
  }
  else {
    fun = cb_LoadURLtoFile_callback_;
    cb_Handle1 = cb_FOpen(sFile,"wbs");
    if (cb_Handle1) {
      UserData = cb_Handle1;
    }
    else {
      return 0;
    }
  }
  register cb_PString b; b = cb_LoadURL(sURL,&sze,sAgent,fun,UserData);
  if (b) {
    if (cb_Handle1) {
      cb_FileClose(cb_Handle1);
      cb_retVar_ = sze;
    }
    else {
      cb_Handle1 = cb_FOpen(sFile,"wbs");
      if (cb_Handle1) {
        cb_retVar_ = cb_FPut(cb_Handle1,b,sze);
        cb_FileClose(cb_Handle1);
      }
    }
    cb_MemFreeM(b);
  }
  else if (cb_Handle1) {
    cb_FileClose(cb_Handle1);
  }
  return cb_retVar_;
}
/* END MODULE */
/* MODULE::cb_OutputBox */


LRESULT CALLBACK cb_OutputBox_Events_ (HWND,UINT,WPARAM,LPARAM);

LRESULT CALLBACK cb_OutputBox_Events_ (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
  register WNDPROC p; p = (WNDPROC)cb_GetWndData(hWnd);
  register cb_Integer i;
  if (p) {
    i = p(hWnd,uMsg,wParam,lParam);
    if (i!=-123) {
      return i;
    }
  }
  if (uMsg==WM_NCDESTROY) PostQuitMessage(0);
  return DefWindowProc(hWnd,uMsg,wParam,lParam);
}


void cb_DEFCALL cb_OutputBox (const cb_String sMsg,const cb_String sTitle,HWND hwndOwner,WNDPROC p,cb_Integer flag1)
{
  register HWND hWnd;
  register cb_Integer i;
  WNDCLASSEX MyWndClassEx;
  if (!hwndOwner) {
    hwndOwner = GetActiveWindow();
    if (!(hwndOwner)) {
      i = 0;
      goto Cont0000;
    }
  }
  i = IsWindowEnabled(hwndOwner);
  if (i) {
    EnableWindow(hwndOwner, FALSE);
  }
Cont0000: ;
  cb_RegClassEx("cb_OutputBox",cb_OutputBox_Events_,&MyWndClassEx);
  hWnd = cb_CreateForm(sTitle,0,100,400,150,"cb_OutputBox",hwndOwner,NULL,WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_SIZEBOX | WS_CAPTION | WS_POPUP | WS_SYSMENU | WS_CLIPCHILDREN);
  HWND Edit1; Edit1 = cb_CreateEditBox(hWnd,5,5,390,140,0,NULL,NULL,ES_READONLY | WS_CHILD | WS_VISIBLE | ES_WANTRETURN | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL);
  cb_SetWndTextM(Edit1,sMsg);
  cb_SetWndData(hWnd,p);
  if (flag1 & 1) {
    cb_SetWndOnTop(hWnd);
  }
  if (hwndOwner==NULL || (flag1 & 2)) {
    cb_CenterWnd(hWnd);
  }
  else {
    cb_CenterWnd(hWnd,hwndOwner);
  }
  ShowWindow(hWnd, SW_SHOW);
  cb_DoFormEvents();
  cb_UnregClass("cb_OutputBox");
  if (i) {
    EnableWindow(hwndOwner, TRUE);
    SetForegroundWindow(hwndOwner);
    SetFocus(hwndOwner);
  }
}
/* END MODULE */
/* MODULE::cb_PathCat */


cb_PString cb_DEFCALL cb_PathCat (void* dst,const cb_String sPath)
{
  register cb_PString s; s = (cb_PString)dst;
  register cb_Integer n; n = cb_StrLen(s);
  if (n) {
    n--;
    s += n;
    n = s[0];
    if (n!='/' && n!='\\') {
      s++;
      s[0] = '/';
    }
    s++;
    if (sPath!=NULL) {
      n = sPath[0];
      if (n=='/' || n=='\\') {
        sPath++;
      }
      goto Copy0000;
    }
    s[0] = '\0';
  }
  else if (sPath) {
Copy0000: ;
    cb_StrCopy(s,sPath);
  }
  return (cb_PString)dst;
}
/* END MODULE */
/* MODULE::cb_pbChr */


__declspec(noinline) cb_PString cb_CDECL cb_pbChr (cb_Integer cnt1,...)
{
  static char sBuf[128+1];
  register cb_PString MyPtr1;
  register cb_Integer* Ptr1; Ptr1 = &cnt1;
  register cb_Integer i;
  MyPtr1 = sBuf;
  for (i=cnt1;i>=1;i--) {
    Ptr1++;
    MyPtr1[0] = Ptr1[0];
    MyPtr1++;
  }
  MyPtr1[0] = '\0';
  return sBuf;
}
/* END MODULE */
/* MODULE::cb_paspbChr */


__declspec(noinline) cb_PpasString cb_CDECL cb_paspbChr (cb_Integer cnt1,...)
{
  static char sBuf[128+1];
  register cb_PString MyPtr1;
  register cb_Integer* Ptr1; Ptr1 = &cnt1;
  register cb_Integer i; i = cnt1;
  cb_LowInt(sBuf) = i;
  MyPtr1 = sBuf + sizeof(cb_Integer);
  for (;i>=1;i--) {
    Ptr1++;
    MyPtr1[0] = Ptr1[0];
    MyPtr1++;
  }
  MyPtr1[0] = '\0';
  return cb_CASTrev(sBuf,cb_PpasString);
}
/* END MODULE */
/* MODULE::cb_PlayAnsiSound */


void cb_DEFCALL cb_PlayAnsiSound (const cb_String Str1,cb_Integer (cb_CDECL *f)(HMIDIOUT a,cb_Integer b,cb_Integer c,cb_Integer d),cb_Integer inst,cb_Integer iLoop,cb_Integer* iThread,HMIDIOUT h)
{
  #define Second_ 1000
  #define Tempo_ 32*8
Again0000: ;
  register const cb_PString MyPtr1; MyPtr1 = Str1-1;
  register cb_Integer i; i = 32;
  cb_Integer iLength; iLength = 32;
  cb_Integer iTempo;
  cb_Integer iVel; iVel = 127;
  cb_Integer iOct; iOct = 6;
  cb_Integer iTranspose;
  const cb_PString MyPtr2; MyPtr2 = MyPtr1;
  cb_Integer iRepeat; iRepeat = 0;
  static cb_Integer iNotes[] = {9,11,0,2,4,5,7};
Start0000: ;
  iTempo = Second_*Tempo_/i;
Start000: ;
  iTranspose = iOct*12;
  do {
    MyPtr1++;
    {  /* Select Case MyPtr1[0] */
      if (MyPtr1[0]==0) {
        break;
      }
      if (MyPtr1[0]>='A' && MyPtr1[0]<='G') {
        i = iNotes[MyPtr1[0] - 'A'];
        if (MyPtr1[1]=='#') {
          i++;
          MyPtr1++;
        }
        i += iTranspose;
        cb_MIDIOutMsg(i,iTempo/iLength,inst,iVel,0,1,h,f);
        goto EndSelect_1;
      }
      if (MyPtr1[0]=='I') {
        if (cb_IsDigit(MyPtr1[1])) {
          MyPtr1++;
          i = cb_AtoL(MyPtr1);
          if (i>0) {
            if (i<128) {
              inst = i;
            }
          }
        }
        goto EndSelect_1;
      }
      if (MyPtr1[0]=='L') {
        if (cb_IsDigit(MyPtr1[1])) {
          MyPtr1++;
          i = cb_AtoL(MyPtr1);
          if (i>0) {
            if (i<=128) {
              iLength = i;
            }
          }
        }
        goto EndSelect_1;
      }
      if (MyPtr1[0]=='P') {
        if (cb_IsDigit(MyPtr1[1])) {
          MyPtr1++;
          i = cb_AtoL(MyPtr1);
          if (i>0) {
            if (i<=128) {
              Sleep(iTempo/i);
            }
          }
        }
        goto EndSelect_1;
      }
      if (MyPtr1[0]=='R') {
        if (cb_IsDigit(MyPtr1[1])) {
          MyPtr1++;
          i = cb_AtoL(MyPtr1);
          if (i>0) {
            if (!iRepeat) {
              iRepeat = i;
            }
            else {
              iRepeat--;
            }
            if (iRepeat) {
              MyPtr1 = MyPtr2;
            }
            else {
              MyPtr2 = MyPtr1;
            }
          }
        }
        goto EndSelect_1;
      }
      if (MyPtr1[0]=='T') {
        if (cb_IsDigit(MyPtr1[1])) {
          MyPtr1++;
          i = cb_AtoL(MyPtr1);
          if (i>=16) {
            if (i<Tempo_) {
              goto Start0000;
            }
          }
        }
        goto EndSelect_1;
      }
      if (MyPtr1[0]=='V') {
        if (cb_IsDigit(MyPtr1[1])) {
          MyPtr1++;
          i = cb_AtoL(MyPtr1);
          if (i>0) {
            if (i<128) {
              iVel = i;
            }
          }
        }
        goto EndSelect_1;
      }
      if (MyPtr1[0]=='<') {
        if (iOct>0) {
          iOct--;
          goto Start000;
        }
        goto EndSelect_1;
      }
      if (MyPtr1[0]=='>') {
        if (iOct<=9) {
          iOct++;
          goto Start000;
        }
      }
    }  /* End Select: MyPtr1[0] */
    EndSelect_1:;
  } while(1);
  iLoop--;
  if (iLoop) {
    goto Again0000;
  }
  #undef Tempo_
  #undef Second_
}
/* END MODULE */
/* MODULE::cb_RadsToDegs */


double cb_DEFCALL cb_RadsToDegs (double rads)
{
  register double i; i = rads;
  i /= 2.0*M_PI;
  i *= 360.0;
  return i;
}
/* END MODULE */
/* MODULE::cb_StrCPad */


char* cb_DEFCALL cb_StrCPad (const cb_String Str1,cb_Integer iLen,const cb_String Str2,void* dst,cb_Integer bWidth)
{
  register char* strtmp; strtmp = (char*)dst;
  register cb_Integer i; i = iLen;
  register cb_Integer j; j = cb_IIF2(bWidth,cb_StrLenW((const cb_StringW)Str1),cb_StrLen(Str1));
  register cb_Integer n;
  register cb_Integer l;
  if (i>j) {
    if (Str2) {
      n = cb_IIF2(bWidth,cb_StrLenW((const cb_StringW)Str2),cb_StrLen(Str2));
    }
    else {
      Str2 = " ";
      n = 1;
    }
    if (bWidth) {
      i <<= 1;
      j <<= 1;
      n <<= 1;
      bWidth = 2;
    }
    else {
      bWidth++;
    }
    if (strtmp==NULL || strtmp==(char*)-1) {
      strtmp = cb_NewStr(NULL,strtmp,i);
      dst = strtmp;
    }
    i -= j;
    l = j;
    j = i;
    j >>= 1;
    i &= bWidth;
    i += j;
    iLen = i;
    if (!j) {
      n = bWidth;
    }
    else {
      if (n>j) {
        n = j;
      }
      cb_glGoSub(Do0000, 1);
    }
    cb_MemCopy(strtmp,Str1,l);
    j = iLen;
    cb_glGoSub(Do0000, 2);
    *(short*)strtmp = 0;
    strtmp = (char*)dst;
  }
  else if (strtmp==NULL || strtmp==(char*)-1) {
    if (bWidth) {
      j <<= 1;
    }
    strtmp = cb_NewStr(Str1,strtmp,j);
  }
  else {
    j++;
    if (bWidth) {
      j <<= 1;
    }
    cb_MemCopy(strtmp,Str1,j);
  }
  return strtmp;
Do0000: ;
  do {
    for (i=0;i<n;i++) {
      strtmp[0] = Str2[i];
      strtmp++;
      j--;
      if (j<=0) {
        goto EndDo_0;
      }
    }
  } while(1);
  EndDo_0:;
  cb_glReturnSub;
}


wchar_t* cb_DEFCALL cb_StrCPadW (const cb_StringW Str1,cb_Integer iLen,const cb_StringW Str2,void* dst)
{
  return (wchar_t*)cb_StrCPad((const cb_String)Str1,iLen,(const cb_String)Str2,dst,TRUE);
}
/* END MODULE */
/* MODULE::cb_Shell */


cb_Integer cb_DEFCALL cb_Shell (const cb_String Str1)
{
  return 0;
}
/* END MODULE */
/* MODULE::cb_System */


cb_Integer cb_DEFCALL cb_System (const cb_String Str1,cb_Integer iShow)
{
  cb_Integer cb_retVar_;
  char *p; p = (char*)cb_MemAllocM(8*0x400);
  cb_GetEnv("COMSPEC",p);
  if (p[0]==0) {
    cb_MemCopy(p, "cmd.exe", 7+1);
  }
  if (Str1) {
    if (Str1[0]!=0) {
      cb_StrConCat(p," /C ",Str1, NULL);
    }
  }
  cb_retVar_ = cb_Run(NULL,p,iShow);
  if (p) { cb_MemFreeM(p); }
  return cb_retVar_;
}
/* END MODULE */
/* MODULE::cb_TempName */
#ifndef cb_MAX_FILE_NAME
#define cb_MAX_FILE_NAME 2048
#endif


cb_PString cb_DEFCALL cb_TempName (void* dst,const cb_String sFolder)
{
  static char b[cb_MAX_FILE_NAME];
  register cb_PString p; p = (cb_PString)dst;
  if (p==(void*)-2) {
    goto Set0000;
  }
  p = cb_NewStr(NULL,p,cb_MAX_FILE_NAME);
  if (p==NULL) {
Set0000: ;
    p = b;
  }
  register cb_File* f;
  register cb_Integer n;
  if (sFolder==(const cb_String)-1) {
    sFolder++;
    n =  ~(_O_TEMPORARY);
  }
  else {
    n = -1;
  }
  f = cb_GetTempFileName(sFolder,NULL,NULL,p,n);
  if (f) {
    cb_FileClose(f);
  }
  else {
    p[0] = '\0';
  }
  return p;
}
/* END MODULE */
/* MODULE::cb_vbStrJoin */


char* cb_DEFCALL cb_vbStrJoin (const cb_String* buf,const cb_String sSep,cb_Integer iSize)
{
  register const char** s;
  register const char** strtmp;
  register int i; i = iSize;
  if (i<0) {
    i = 0;
    for (s=buf;s[0];s++) {
      i++;
    }
  }
  if (i<=0) {
    return NULL;
  }
  if (sSep==NULL) {
    sSep = " ";
    goto Shl0000;
  }
  if (sSep[0]==0) {
    sSep = NULL;
  }
  else {
Shl0000: ;
    i--;
    i <<= 1;
    i++;
  }
  iSize = i;
  strtmp = (const char**)cb_MemAllocM(i);
  if (!strtmp) {
    return NULL;
  }
  s = buf;
  cb_StrMove(buf, strtmp);
  do {
    strtmp[0] = s[0];
    i--;
    if (i<=0) {
      break;
    }
    if (sSep) {
      strtmp++;
      strtmp[0] = sSep;
      i--;
    }
    s++;
    strtmp++;
  } while(1);
  i = cb_CallAnyFunction((const void*)cb_StrJoinByNum,iSize,buf);
  free((void*)buf);
  return (cb_String)i;
}
/* END MODULE */
/* MODULE::cb_WndFromPointEx */

typedef struct cb_s_cb_WndFromPointEx__ {
  POINT pt;
  HWND hwnd;
  int fShowHidden;
  DWORD dwArea;
} cb_WndFromPointEx_, *Pcb_WndFromPointEx_;



static BOOL CALLBACK cb_WndFromPointEx_FindBestChildProc (HWND,LPARAM);

static BOOL CALLBACK cb_WndFromPointEx_FindBestChildProc (HWND hwnd,LPARAM lParam)
{
  RECT rect;
  DWORD a;
  cb_WndFromPointEx_* p; p = (cb_WndFromPointEx_*)lParam;
  GetWindowRect(hwnd,&rect);
  if (PtInRect(&rect,p->pt)) {
    a = (rect.right - rect.left)*(rect.bottom - rect.top);
    if (a<p->dwArea) {
      if (p->fShowHidden || IsWindowVisible(hwnd)) {
        p->dwArea = a;
        p->hwnd = hwnd;
      }
    }
  }
  return TRUE;
}


static HWND cb_WndFromPointEx_FindBestChild (HWND,cb_WndFromPointEx_*);

static HWND cb_WndFromPointEx_FindBestChild (HWND hwndFound,cb_WndFromPointEx_* p)
{
  HWND hwnd;
  DWORD dwStyle;
  hwnd = GetParent(hwndFound);
  dwStyle = GetWindowLongPtr(hwndFound,GWL_STYLE);
  if (hwnd==NULL || (dwStyle & WS_POPUP)) {
    hwnd = hwndFound;
  }
  EnumChildWindows(hwnd,cb_WndFromPointEx_FindBestChildProc,MAKELPARAM(p->pt.x,p->pt.y));
  if (p->hwnd) {
    hwnd = p->hwnd;
  }
  return hwnd;
}


HWND cb_DEFCALL cb_WndFromPointEx (POINT pt,cb_Integer fShowHidden)
{
  HWND hWndPoint;
  cb_WndFromPointEx_ b;
  hWndPoint = WindowFromPoint(pt);
  if (hWndPoint==NULL) {
    return NULL;
  }
  b.fShowHidden = fShowHidden;
  b.pt = pt;
  b.dwArea = -1;
  b.hwnd = NULL;
  hWndPoint = cb_WndFromPointEx_FindBestChild(hWndPoint,&b);
  if (!(fShowHidden)) {
    while(hWndPoint && IsWindowVisible(hWndPoint)) {
      hWndPoint = GetParent(hWndPoint);
    }
  }
  return hWndPoint;
}
/* END MODULE */
/* MODULE::cb_cConsole */
#define cb_cConsole_LINE_SIZE_ 4*0x400
static HANDLE cb_cConsole_ConsoleOut_;
static HANDLE cb_cConsole_ConsoleIn_;


static cb_Integer cb_cConsole_Open_ (cb_cConsole*,void*);

static cb_Integer cb_cConsole_Open_ (cb_cConsole* T,void* ptr1)
{
/*
  todo redirect console
  Exit = -1
*/
  return 0;
}


char* cb_cConsole_Get (cb_cConsole* T,void* dst,cb_Integer iMax)
{
  register cb_cConsole* self; self = T;
  register cb_PString MyPtr1; MyPtr1 = (cb_PString)dst;
  register cb_Integer i;
  register HANDLE h; h = self->hIn;
  DWORD i1;
  if (h==INVALID_HANDLE_VALUE) {
    if (cb_cConsole_ConsoleIn_==INVALID_HANDLE_VALUE || cb_cConsole_ConsoleIn_==NULL) {
      cb_cConsole_ConsoleIn_ = GetStdHandle(STD_INPUT_HANDLE);
      if (cb_cConsole_ConsoleIn_==INVALID_HANDLE_VALUE || cb_cConsole_ConsoleIn_==NULL) {
        return NULL;
      }
    }
    h = cb_cConsole_ConsoleIn_;
  }
  if ((cb_UInteger)(MyPtr1-1)>=(cb_UInteger)(-2-1)) {
    MyPtr1 = self->m_Buf;
    i = sizeof(self->m_Buf)-1;
  }
  else {
    i = iMax;
    if (i<=0) {
      i = cb_cConsole_LINE_SIZE_-1;
    }
  }
  i = ReadFile(h,MyPtr1,i,&i1,NULL);
  if (i) {
    i = i1;
  }
  MyPtr1[i] = '\0';
  return MyPtr1;
}


cb_Integer cb_cConsole_Put (cb_cConsole* T,const cb_String s,cb_Integer iMax)
{
  register cb_cConsole* self; self = T;
  #define MyPtr1 s
  register cb_Integer i;
  register HANDLE h; h = self->hOut;
  DWORD i1;
  if (h==INVALID_HANDLE_VALUE) {
    if (cb_cConsole_ConsoleOut_==INVALID_HANDLE_VALUE || cb_cConsole_ConsoleOut_==NULL) {
      cb_cConsole_ConsoleOut_ = GetStdHandle(STD_OUTPUT_HANDLE);
      if (cb_cConsole_ConsoleOut_==INVALID_HANDLE_VALUE || cb_cConsole_ConsoleOut_==NULL) {
        return -1;
      }
    }
    h = cb_cConsole_ConsoleOut_;
  }
  i = iMax;
  if (i<=0) {
    i = cb_StrLen(MyPtr1);
  }
  i = WriteFile(h,MyPtr1,i,&i1,NULL);
  if (i) {
    i = i1;
  }
  return i;
  #undef MyPtr1
}


cb_Integer cb_cConsole_WriteLine (cb_cConsole* T,const cb_String s,cb_Integer iMax)
{
  register cb_cConsole* self; self = T;
  #define MyPtr1 s
  register cb_Integer i; i = iMax;
  if (i<=0) {
    i = cb_StrLen(MyPtr1);
  }
  if ((cb_UInteger)i<(cb_UInteger)(sizeof(self->m_Buf)-4)) {
    cb_MemCopy(self->m_Buf,MyPtr1,i);
    cb_MemCopy(self->m_Buf + i,"\r\n",2+1);
    i += 2;
    return cb_cConsole_Put(self,self->m_Buf,i);
  }
  return 0;
  #undef MyPtr1
}


cb_cConsole* cb_cConsole_Terminate (cb_cConsole* T)
{
  register cb_cConsole* self; self = T;
  if (self->hIn!=INVALID_HANDLE_VALUE) {
    CloseHandle(self->hIn);
  }
  if (self->hOut!=INVALID_HANDLE_VALUE) {
    CloseHandle(self->hOut);
  }
  if (self->flag1_ & TRUE) {
    cb_MemFreeM(self);
    self = NULL;
  }
  return self;
}


cb_cConsole* cb_cConsole_Initialize (cb_cConsole* T)
{
  register cb_cConsole* self; self = T;
  if (!(self)) {
    self = (cb_cConsole*)cb_MemAllocZM(sizeof(cb_cConsole));
    self->flag1_++;
  }
  else {
    cb_CLEAR1(*self);
  }
  self->hIn = INVALID_HANDLE_VALUE;
  self->hOut = INVALID_HANDLE_VALUE;
  return NULL;
}
/* END MODULE */
/* MODULE::cb_cEachFile */
#define cb_cEachFile_DELIM_CHAR_ '\t'
/* MODULE::cb_cEachFile1 */


cb_cEachFile* cb_cEachFile_Terminate (cb_cEachFile* T)
{
  register cb_cEachFile* self; self = T;
  if (self->FileHandle!=INVALID_HANDLE_VALUE) {
    FindClose(self->FileHandle);
    self->FileHandle = INVALID_HANDLE_VALUE;
    (self->sFileName)[0] = '\0';
  }
  if (self->m_buf) { cb_MemFreeM(self->m_buf); self->m_buf = NULL; }
  if (self->flag1_ & TRUE) {
    cb_MemFreeM(self);
    self = NULL;
  }
  return self;
}
/* END MODULE */


cb_Integer cb_cEachFile_OpenV (cb_cEachFile* T,void** ptr1)
{
  register cb_cEachFile* self; self = T;
  register cb_PString* i;
  register cb_Integer n;
  register cb_Integer m;
  if (self->FileHandle!=INVALID_HANDLE_VALUE) {
    FindClose(self->FileHandle);
    self->FileHandle = INVALID_HANDLE_VALUE;
  }
  i = (cb_PString*)ptr1;
  if (i[0]) {
    cb_MemFreeM(self->m_buf);
    n = 0;
    do {
      n += cb_StrLen(i[0])+1;
      i++;
    } while(i[0]);
    n++;
    self->m_buf = (cb_String)cb_MemAllocM(n);
    if (!(self->m_buf)) {
      return -1;
    }
    i = (cb_PString*)ptr1;
    n = 0;
    do {
      m = cb_StrLen(i[0]);
      cb_MemCopy(self->m_buf + n,i[0],m);
      n += m;
      self->m_buf[n] = cb_cEachFile_DELIM_CHAR_;
      n++;
      i++;
    } while(i[0]);
    self->m_buf[n] = '\0';
  }
  self->m_ptr = self->m_buf;
  if (!(self->m_ptr)) {
    return -1;
  }
  return 0;
}


char* cb_cEachFile_Get (cb_cEachFile* T,void* dst,cb_Integer iMask)
{
  register cb_cEachFile* self; self = T;
  register cb_PString MyPtr1;
  register cb_Integer i;
  if (self->m_buf) {
    MyPtr1 = (cb_String)dst;
    if ((cb_UInteger)(MyPtr1-1)>=(cb_UInteger)(-2-1)) {
      MyPtr1 = self->sFileName;
    }
    else {
      (self->sFileName)[0] = '\0';
    }
    if (self->FileHandle!=INVALID_HANDLE_VALUE) {
      cb_FindNext(MyPtr1,self,iMask);
      if (MyPtr1[0]!=0) {
        goto Exit0000;
      }
    }
    do {
      i = cb_InChar(self->m_ptr,cb_cEachFile_DELIM_CHAR_);
      if (i<=0) {
        MyPtr1[0] = '\0';
        break;
      }
      self->m_ptr[i] = '\0';
      cb_FindFirst(self->m_ptr,MyPtr1,self,iMask);
      self->m_ptr[i] = cb_cEachFile_DELIM_CHAR_;
      i++;
      self->m_ptr += i;
    } while(MyPtr1[0]==0);
Exit0000: ;
    return cb_FixPath(MyPtr1,MyPtr1);
  }
  return NULL;
}


cb_Boolean cb_cEachFile_IsFile (cb_cEachFile* T)
{
  register cb_cEachFile* self; self = T;
  if (self->FileHandle!=INVALID_HANDLE_VALUE) {
    if (self->sFileName[0]!=0) {
      if (!(self->dwFileAttributes & _A_SUBDIR)) {
        return TRUE;
      }
    }
  }
  return FALSE;
}


cb_Boolean cb_cEachFile_IsFolder (cb_cEachFile* T)
{
  register cb_cEachFile* self; self = T;
  if (self->FileHandle!=INVALID_HANDLE_VALUE) {
    if (self->sFileName[0]!=0) {
      if (self->dwFileAttributes & _A_SUBDIR) {
        return TRUE;
      }
    }
  }
  return FALSE;
}


cb_cEachFile* cb_cEachFile_Initialize (cb_cEachFile* T)
{
  register cb_cEachFile* self; self = T;
  if (!(self)) {
    self = (cb_cEachFile*)cb_MemAllocZM(sizeof(cb_cEachFile));
    self->flag1_++;
  }
  else {
    cb_CLEAR1(*self);
  }
  self->FileHandle = INVALID_HANDLE_VALUE;
  return self;
}


__declspec(noinline) cb_Integer cb_CDECL cb_cEachFile_Open (cb_cEachFile* self,...)
{
  return cb_cEachFile_OpenV(self,((void**)self)+1);
}


__declspec(noinline) char* cb_CDECL cb_cEachFile_First (cb_cEachFile* self,...)
{
  cb_cEachFile_OpenV(self,((void**)self)+1);
  return cb_cEachFile_Get(self,NULL,cb_MIN_INTEGER32);
}
/* END MODULE */
/* MODULE::cb_cFTP */
/* END MODULE */
/* MODULE::cb_cHTML */
/* END MODULE */
/* MODULE::cb_cNet */
/* END MODULE */
/* MODULE::cb_cSocket */
/* END MODULE */
/* MODULE::cb_cStack */


void* cb_cStack_Pop (cb_cStack* self,void* ptr1,cb_Integer iLen)
{
  register cb_Integer i; i = self->m_Cnt;
  register cb_Integer j; j = iLen;
  if (j<0) {
    j = sizeof(cb_Integer);
  }
  i -= j;
  if (i>=0) {
    self->m_Cnt = i;
    return cb_MemCopy(ptr1,self->m_Buf + i,j);
  }
  return NULL;
}


const void* cb_cStack_Push (cb_cStack* self,const void* ptr1,cb_Integer iLen)
{
  register cb_Integer i; i = iLen;
  register cb_Integer j; j = self->m_Cnt;
  if (i<0) {
    i = sizeof(cb_Integer);
  }
  register BYTE* p1;
  i += j;
  if (i>0) {
    if (i>=self->m_Size) {
      do {
        self->m_Size += cb_cStack_SIZE_;
      } while(i>=self->m_Size);
      p1 = self->m_Buf;
      p1 = (BYTE*)cb_ReDim((self->m_Size) * sizeof(BYTE), p1, 1);
      if (p1==NULL) {
        return NULL;
      }
      self->m_Buf = p1;
    }
    self->m_Cnt = i;
    i -= j;
    return cb_MemCopy(self->m_Buf + j,ptr1,i);
  }
  return NULL;
}


void* cb_cStack_XChange (cb_cStack* self,void* ptr1,cb_Integer iLen)
{
  register cb_Integer i; i = self->m_Cnt;
  register cb_Integer j; j = iLen;
  if (j<0) {
    j = sizeof(cb_Integer);
  }
  i -= j;
  if (i>=0) {
    cb_Swap(ptr1,self->m_Buf + i,j);
    return ptr1;
  }
  return NULL;
}


void* cb_cStack_GetAt (cb_cStack* self,cb_Integer iPos,void* ptr1,cb_Integer iLen)
{
  register cb_Integer i; i = iPos;
  register cb_Integer j;
  if (i>=0) {
    j = iLen;
    if (j<0) {
      j = sizeof(cb_Integer);
    }
    i += j;
    if ((cb_UInteger)i<=(cb_UInteger)(self->m_Cnt)) {
      i -= j;
      return cb_MemCopy(ptr1,self->m_Buf + i,j);
    }
  }
  return NULL;
}


const void* cb_cStack_PutAt (cb_cStack* self,cb_Integer iPos,const void* ptr1,cb_Integer iLen)
{
  register cb_Integer i; i = iPos;
  register cb_Integer j;
  if (i>=0) {
    j = iLen;
    if (j<0) {
      j = sizeof(cb_Integer);
    }
    i += j;
    if ((cb_UInteger)i<=(cb_UInteger)(self->m_Cnt)) {
      i -= j;
      return cb_MemCopy(self->m_Buf + i,ptr1,j);
    }
  }
  return NULL;
}


cb_Integer cb_cStack_Size (cb_cStack* self)
{
  return self->m_Cnt;
}


const void* cb_cStack_Buf (cb_cStack* self)
{
  return self->m_Buf;
}


static void cb_cStack_Terminate_ (cb_cStack*);

static void cb_cStack_Terminate_ (cb_cStack* self)
{
  if (self->m_Buf) { cb_MemFreeM(self->m_Buf); self->m_Buf = NULL; }
  self->m_Cnt = 0;
  self->m_Size = 0;
}


cb_cStack* cb_cStack_Initialize (cb_cStack* self,void* clsParent,void* clsMain)
{
  if (self) {
    cb_CLEAR1(*self);
  }
  else {
    self = (cb_cStack*)cb_MemAllocM(sizeof(cb_cStack));
    if (self==NULL) {
      return NULL;
    }
    cb_CLEAR1(*self);
    self->flag1_++;
  }
  self->clsParent = clsParent;
  self->clsMain = clsMain;
  return self;
}


void cb_cStack_Terminate (cb_cStack* self)
{
  cb_cStack_Terminate_(self);
  if ((self->flag1_ & TRUE)!=0) {
    cb_MemFreeM(self);
  }
  else {
    self->clsMain = NULL;
    self->clsParent = NULL;
  }
}
/* END MODULE */
#ifndef MAX_FILE_NAME
#endif
#ifndef NOT_TRUE
#endif
#ifndef ONE_SECOND
#endif
#ifndef ONE_MINUTE
#endif
#if !defined(USER_LIBRARY) && !defined(USE_CFILE)
#endif
#ifdef USE_LICE_BITMAP
#endif
#ifndef USE_CRT
#endif
#ifdef USE_MEMORY
#endif
#ifdef USE_MEMORY
#endif
#ifndef USE_CRT
#endif
#ifdef USE_FILE
#endif
#ifndef DriveComboBox_Type_Def
#endif
#ifndef IMAGE_SUBSYSTEM_WINDOWS_GUI
#endif
#ifndef IMAGE_SUBSYSTEM_WINDOWS_CUI
#endif


/* MODULE::cb_Abort */
void cb_DEFCALL cb_Abort (cb_Integer codeAbort,const char *msgAbort)
{
  if (msgAbort) { cb_PrintF("%s\n", msgAbort); cb_MsgBox(msgAbort, "Application Abort", 0); }
  cb_End(codeAbort);
}
/* END MODULE */

/*((((((((((((((  User Code  ))))))))))))))*/
/* "pffft/pffft.inc" */
/* "picoc/picoc.inc" */
#ifndef MAX_FILE_NAME
#endif
#ifndef NOT_TRUE
#endif
#ifndef ONE_SECOND
#endif
#ifndef ONE_MINUTE
#endif
/* "All/regexp/regexp.inc" */
/* MODULE::cb_cCollection */

enum {
  cb_cCollection_AUTOFREE_bit_ = 2,
  cb_cCollection_AUTOREDIM_bit_ = cb_cCollection_AUTOFREE_bit_ << 1
};

#define cb_cCollection_VECTOR_SIZE_ 1024


cb_Integer cb_cCollection_InsertAt (cb_cCollection* self,const void* ptr1,cb_Integer Index)
{
  register BYTE* p;
  register cb_Integer i; i = Index;
  register cb_Integer j; j = self->m_Cnt;
  register cb_UInteger l;
  register cb_UInteger n;
  if (i<0) {
    i = j;
  }
  j++;
  if (i>=j) {
    return -1;
  }
  n = self->m_UBound;
  p = self->m_Items;
  l = self->m_ElementSize;
  if (j>=n) {
    n += self->m_Vector;
    p = (BYTE*)cb_ReDim((n*l) * sizeof(BYTE), p, 1);
    if (!p) {
      return -1;
    }
    self->m_Items = p;
    self->m_UBound = n;
  }
  self->m_Cnt = j;
  j--;
  j -= i;
  n = i;
  i *= l;
  p += i;
  if (j>0) {
    cb_MemMove(p + l,p,j*l);
  }
  if (l==sizeof(const void*)) {
    *(const void**)p = ptr1;
  }
  else {
    cb_MemCopy(p,ptr1,l);
  }
  return n;
}


cb_Integer cb_cCollection_Count (cb_cCollection* self)
{
  return self->m_Cnt;
}


const void* cb_cCollection_Items (cb_cCollection* self)
{
  return self->m_Items;
}


cb_Integer cb_cCollection_Find (cb_cCollection* self,const void* ptr1)
{
  register cb_UInteger i;
  register const void** p; p = (const void**)(self->m_Items);
  register cb_UInteger l;
  if (ptr1==cb_INVALID) {
    i = -1;
    do {
      i++;
      if (i>=self->m_Cnt) {
        i = -1;
        break;
      }
      if (p[0]==NULL) {
        break;
      }
      p++;
    } while(1);
  }
  else {
    i = self->m_Cnt;
    l = self->m_ElementSize;
    if (l==sizeof(const void*)) {
      p += i;
      do {
        i--;
        if (i==-1) {
          break;
        }
        p--;
      } while(!(p[0]==ptr1));
    }
    else {
      p = (const void**)((cb_UInteger)p + (i*l));
      do {
        i--;
        if (i==-1) {
          break;
        }
        p = (const void**)((cb_UInteger)p - l);
      } while(!(0==cb_MemComp(p,ptr1,l)));
    }
  }
  return i;
}


cb_Integer cb_cCollection_FreeAt (cb_cCollection* self,cb_Integer Index,cb_Boolean flag1)
{
  register cb_UInteger i; i = Index;
  register void** p1;
  if (i>=self->m_Cnt) {
    return -1;
  }
  p1 = (void**)(self->m_Items);
  p1 += i;
  if (p1[0]) { cb_MemFreeM(p1[0]); p1[0] = NULL; }
  if (flag1) {
    self->m_Cnt--;
    if (i<self->m_Cnt) {
      cb_MemCopy(&(p1[0]), &(p1[1]), (self->m_Cnt - i)*sizeof(p1[0]));
    }
  }
  return i;
}


cb_Integer cb_cCollection_RemoveAt (cb_cCollection* self,cb_Integer Index)
{
  register cb_Integer i; i = Index;
  register cb_Integer j; j = self->m_Cnt;
  register cb_UInteger l;
  register cb_UInteger n;
  BYTE* p;
  if (i<0) {
    i = j;
    if (i>0) {
      i--;
    }
  }
  if (i>=j) {
    return -1;
  }
  if ((self->flag1_ & cb_cCollection_AUTOFREE_bit_)!=0) {
    cb_cCollection_FreeAt(self,i,FALSE);
  }
  p = self->m_Items;
  l = self->m_ElementSize;
  j--;
  self->m_Cnt = j;
  j -= i;
  if (j>0) {
    cb_MemCopy(p + ((cb_UInteger)i*l),p + ((cb_UInteger)(i+1)*l),(cb_UInteger)j*l);
  }
  if ((self->flag1_ & cb_cCollection_AUTOREDIM_bit_)!=0) {
    j += i;
    j += self->m_Vector;
    n = self->m_UBound;
    if ((cb_UInteger)j<n) {
      n -= self->m_Vector;
      p = (BYTE*)cb_ReDim((n*l) * sizeof(BYTE), p, 1);
      if (p) {
        self->m_Items = p;
        self->m_UBound = n;
      }
    }
  }
  return i;
}


const void* cb_cCollection_GetAt (cb_cCollection* self,cb_Integer Index)
{
  register cb_UInteger i; i = Index;
  if (i<self->m_Cnt) {
    return *(const void**)(self->m_Items + (i*sizeof(const void*)));
  }
  return NULL;
}


const void* cb_cCollection_PutAt (cb_cCollection* self,const void* ptr1,cb_Integer Index)
{
  const void* cb_retVar_;
  register cb_UInteger i; i = Index;
  register cb_UInteger l;
  register BYTE* p;
  cb_retVar_ = NULL;
  if (i==-2) {
    i = cb_cCollection_GetFreeLocation(self);
    if (i<0) {
      cb_cCollection_Add(self,ptr1);
      goto Exit0000;
    }
  }
  if (i<self->m_Cnt) {
    l = self->m_ElementSize;
    p = self->m_Items;
    p += (cb_UInteger)i*l;
    if (l==sizeof(const void*)) {
      cb_retVar_ = *(const void**)p;
      *(const void**)p = ptr1;
    }
  }
  else {
    cb_MemCopy(p,ptr1,l);
  }
Exit0000: ;
  return cb_retVar_;
}


cb_Boolean cb_cCollection_GetAutoFree (cb_cCollection* self)
{
  return cb_CBOOL((self->flag1_ & cb_cCollection_AUTOFREE_bit_)!=0);
}


void cb_cCollection_SetAutoFree (cb_cCollection* self,cb_Boolean flag1)
{
  if (!self->m_Cnt) {
    if (flag1) {
      self->flag1_ |= cb_cCollection_AUTOFREE_bit_;
    }
    else {
      self->flag1_ &=  ~cb_cCollection_AUTOFREE_bit_;
    }
  }
}


cb_Integer cb_cCollection_GetElementSize (cb_cCollection* self)
{
  return self->m_ElementSize;
}


void cb_cCollection_SetElementSize (cb_cCollection* self,cb_Integer iNum)
{
  if (!self->m_Cnt) {
    if (iNum<=0) {
      self->m_ElementSize = sizeof(const void*);
    }
    else {
      self->m_ElementSize = iNum;
    }
  }
}


cb_Boolean cb_cCollection_GetAutoReDim (cb_cCollection* self)
{
  return cb_CBOOL((self->flag1_ & cb_cCollection_AUTOREDIM_bit_)!=0);
}


void cb_cCollection_SetAutoReDim (cb_cCollection* self,cb_Boolean flag1)
{
  if (flag1) {
    self->flag1_ |= cb_cCollection_AUTOREDIM_bit_;
  }
  else {
    self->flag1_ &=  ~cb_cCollection_AUTOREDIM_bit_;
  }
}


cb_Integer cb_cCollection_SetVectorSize (cb_cCollection* self,cb_Integer iVector)
{
  register cb_Integer i; i = iVector;
  if (i<=0) {
    i = cb_cCollection_VECTOR_SIZE_;
  }
  self->m_Vector = i;
  return i;
}


static cb_Integer cb_CDECL cb_cCollection_SortFunc_ (const void*,const void*,const void*);

static __declspec(noinline) cb_Integer cb_CDECL cb_cCollection_SortFunc_ (const void* self,const void* ptr1,const void* ptr2)
{
  if (ptr1>ptr2) {
    return 1;
  }
  if (ptr1<ptr2) {
    return -1;
  }
  return 0;
}


void cb_cCollection_Sort (cb_cCollection* self,cb_Integer (cb_CDECL *func1)(const void* cls1,const void* Ptr1,const void* Ptr2))
{
  if (func1==NULL) {
    func1 = &cb_cCollection_SortFunc_;
  }
  cb_QSort(self->m_Items, self->m_Cnt, sizeof(const void*), func1, self);
}


static void cb_cCollection_onTerminate (cb_cCollection*);

static void cb_cCollection_onTerminate (cb_cCollection* self)
{
  register cb_Integer i;
  if ((self->flag1_ & cb_cCollection_AUTOFREE_bit_)!=0) {
    i = self->m_Cnt;
    while(i>0) {
      i--;
      cb_cCollection_FreeAt(self,i,FALSE);
    }
  }
  if (self->m_Items) { cb_MemFreeM(self->m_Items); self->m_Items = NULL; }
  self->m_Cnt = 0;
  self->m_UBound = 0;
  self->m_Vector = cb_cCollection_VECTOR_SIZE_;
  self->m_ElementSize = sizeof(const void*);
  self->flag1_ &= TRUE;
}


static cb_Integer cb_cCollection_onInitialize (cb_cCollection*);

static cb_Integer cb_cCollection_onInitialize (cb_cCollection* self)
{
  self->m_Vector = cb_cCollection_VECTOR_SIZE_;
  self->m_ElementSize = sizeof(const void*);
  return 0;
}


cb_cCollection* cb_cCollection_Initialize (cb_cCollection* self,void* clsParent,void* clsMain)
{
  if (self) {
    cb_CLEAR1(*self);
  }
  else {
    self = (cb_cCollection*)cb_MemAllocM(sizeof(cb_cCollection));
    if (self==NULL) {
      return NULL;
    }
    cb_CLEAR1(*self);
    self->flag1_++;
  }
  self->clsParent = clsParent;
  self->clsMain = clsMain;
  cb_cCollection_onInitialize(self);
  return self;
}


void cb_cCollection_Terminate (cb_cCollection* self)
{
  cb_cCollection_onTerminate(self);
  if ((self->flag1_ & TRUE)!=0) {
    cb_MemFreeM(self);
  }
  else {
    self->clsMain = NULL;
    self->clsParent = NULL;
  }
}
/* END MODULE */
/* MODULE::cb_cFString */
/* MODULE::cb_cFString1 */


void* cb_cFString_Initialize (cb_Integer sze,void* T)
{
  register cb_cFString* self; self = (struct cb_s_cb_cFString_*)T;
  if (self) {
    if (sze>(sizeof(struct cb_s_cb_cFString_)+2)) {
      cb_CLEAR1(*self);
      self->flag1_ |= 4;
      self->m_Size = sze - sizeof(struct cb_s_cb_cFString_);
    }
    else {
      self = NULL;
    }
  }
  else if (sze<=2) {
    sze = cb_cFString_DEFAULT_ADDLENGTH>>1;
  }
  self = (struct cb_s_cb_cFString_*)cb_MemAllocZM(sizeof(struct cb_s_cb_cFString_) + sze);
  if (self) {
    self->m_Size = cb_cFString_DEFAULT_ADDLENGTH>>1;
    self->flag1_++;
  }
  return self;
}


void cb_cFString_Terminate (void* T)
{
  register cb_cFString* self; self = (struct cb_s_cb_cFString_*)T;
  if (self) {
    if (self->flag1_ & TRUE) {
      cb_MemFreeM(T);
    }
  }
}
/* END MODULE */
/* MODULE::cb_cFString2 */


void* cb_cFString_SetBufferSize (void* T,cb_Integer newSize,cb_Boolean bFlag)
{
  cb_cFString* self; self = NULL;
  if (newSize>=0) {
    newSize += sizeof(struct cb_s_cb_cFString_) + (cb_cFString_DEFAULT_ADDLENGTH>>1);
    self = (cb_cFString*)T;
    if (self->m_Size<newSize) {
      if (self->flag1_ & 4) {
        return NULL;
      }
      newSize += (cb_cFString_DEFAULT_ADDLENGTH<<1)-1;
      newSize &=  ~((cb_cFString_DEFAULT_ADDLENGTH>>1)-1);
      self = (cb_cFString*)cb_ReDim(newSize,self,bFlag);
      if (self) {
        self->m_Size = newSize;
      }
    }
  }
  return self;
}
/* END MODULE */


void* cb_cFString_New (cb_Integer i)
{
  register cb_cFString* self; self = (cb_cFString*)cb_cFString_Initialize(0,NULL);
  if (self) {
    return cb_cFString_SetBufferSize(self,i,FALSE);
  }
  return NULL;
}


void* cb_cFString_SetBuffer (void* T,void* p,cb_Integer newLen)
{
  struct cb_s_cb_cFString_* self; self = (cb_cFString*)p;
  struct cb_s_cb_cFString_* T1;
  cb_Integer i;
  if (self) {
    i = self->m_Size;
    if (i>=0) {
      T1 = (cb_cFString*)T;
      if (newLen>(i - sizeof(short))) {
        i = newLen;
        if (!T1) {
          goto Set0000;
        }
        if (i>=T1->m_Size) {
          goto Set0000;
        }
        goto Set000;
      }
      if (T1) {
        if (i<T1->m_Size) {
Set000: ;
          i = T1->m_Size;
Set0000: ;
          self = (cb_cFString*)cb_cFString_SetBufferSize(self,i,FALSE);
          if (!self) {
            return NULL;
          }
        }
      }
      if (T1) {
        i = T1->m_Len;
        cb_MemCopy(self->m_Buffer,T1->m_Buffer,i + sizeof(short));
        cb_MemFreeM(T1);
      }
      else {
        i = 0;
      }
      if (i<newLen) {
        i = newLen;
      }
      self->m_Len = i;
      *(short*)(self->m_Buffer + i) = '\0';
      return self;
    }
  }
  return NULL;
}


const cb_PString cb_cFString_StrPtr (const void* T)
{
  const cb_cFString* self; self = (const cb_cFString*)T;
  return cb_StrPtr(&self->m_Buffer[0]);
}


cb_Integer cb_cFString_GetLength (const void* T)
{
  return ((const cb_cFString*)T)->m_Len;
}


void* cb_cFString_SetLength (void* T,cb_Integer newValue)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i; i = newValue;
  if (i<0) {
    i = self->m_Pos;
  }
  self = (cb_cFString*)cb_cFString_SetBufferSize(self,i,TRUE);
  if (self) {
    self->m_Len = i;
    *(short*)(self->m_Buffer + i) = '\0';
  }
  return self;
}


void* cb_cFString_ChangeLength (void* T,cb_Integer newValue)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i; i = newValue;
  if (i<0) {
    i = self->m_Pos;
  }
  self->m_Size = i;
  self = (cb_cFString*)cb_cFString_SetBufferSize(self,i,TRUE);
  if (self) {
    self->m_Len = i;
    *(short*)(self->m_Buffer + i) = '\0';
  }
  return self;
}


void cb_cFString_Clear (void* T)
{
  cb_cFString* self; self = (cb_cFString*)T;
  self->m_Len = 0;
  *(short*)(self->m_Buffer) = '\0';
}


cb_PString cb_cFString_GetAt (void* T,cb_Integer iOfs,void* dst)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_UInteger i; i = iOfs;
  if (i>(cb_UInteger)self->m_Len) {
    i = self->m_Len;
  }
  return cb_NewStr(self->m_Buffer + i,dst,self->m_Len - i);
}


void* cb_cFString_PutAt (void* T,const void* newValue,cb_Integer iOfs,cb_Integer iNum)
{
  register cb_cFString* self; self = (cb_cFString*)T;
  register cb_Integer i; i = iNum;
  register cb_Integer j; j = iOfs;
  if (i<0) {
    i = cb_StrLen((const cb_String)newValue);
  }
  if (j<0) {
    j = self->m_Pos;
  }
  self = (cb_cFString*)cb_cFString_SetBufferSize(self,i + j,TRUE);
  if (self) {
    if (i>0) {
      cb_MemCopy(self->m_Buffer + j,newValue,i);
    }
    i += j;
    if (iOfs>=0) {
      goto Len0000;
    }
    self->m_Pos = i;
    if (i>self->m_Len) {
Len0000: ;
      self->m_Len = i;
      *(short*)(self->m_Buffer + i) = '\0';
    }
  }
  return self;
}


void* cb_cFString_Copy (void* T,const void* T1)
{
  cb_cFString* self; self = (cb_cFString*)T1;
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cFString_StrCopy(T,s,0,self->m_Len);
  }
  return NULL;
}


void* cb_cFString_StrNCopy (void* T,const void* newValue,cb_Integer iMax,cb_Integer iOfs,cb_Integer iNum)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i; i = iNum;
  if (i<0) {
    i = cb_StrLen((const cb_String)newValue);
  }
  if ((cb_UInteger)i>(cb_UInteger)iMax) {
    i = iMax;
  }
  return cb_cFString_StrCopy(self,newValue,iOfs,i);
}


void* cb_cFString_NCopy (void* T,const void* newValue,cb_Integer iMax,cb_Integer iOfs)
{
  cb_cFString* self; self = (cb_cFString*)newValue;
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cFString_StrNCopy(T,s,iMax,iOfs,self->m_Len);
  }
  return NULL;
}


void* cb_cFString_Dup (void* T,void* p)
{
  void* cb_retVar_;
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i;
  cb_retVar_ = p;
  if (!cb_retVar_) {
    if (self) {
      goto Set0000;
    }
  }
  else if (!self) {
    self = (cb_cFString*)cb_retVar_;
Set0000: ;
    i = self->m_Size;
    cb_retVar_ = cb_MemAllocM(i);
  }
  else {
    i = ((cb_cFString*)cb_retVar_)->m_Size;
    if (i<self->m_Size) {
      cb_retVar_ = cb_cFString_SetBufferSize(cb_retVar_,i,FALSE);
    }
  }
  if (cb_retVar_) {
    cb_MemCopy(cb_retVar_,self,self->m_Size);
    ((cb_cFString*)cb_retVar_)->m_Size = i;
  }
  return cb_retVar_;
}


void* cb_cFString_StrInsertAt (void* T,const void* newValue,cb_Integer iOfs,cb_Integer iNum,cb_Integer iReplace)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i; i = iNum;
  if (i<0) {
    i = cb_StrLen((const cb_String)newValue);
  }
  cb_Integer j; j = iOfs;
  if (j<0) {
    j = self->m_Pos;
  }
  if (iReplace<0) {
    iReplace = i;
  }
  i -= iReplace;
  j += iReplace;
  self = (cb_cFString*)cb_cFString_SetBufferSize(self,i + cb_IIF2(j>=self->m_Len,j,self->m_Len),TRUE);
  if (self) {
    if (self->m_Len>j) {
      if (i!=0) {
        cb_MemMove(self->m_Buffer + j + i,self->m_Buffer + j,self->m_Len - j);
      }
    }
    else if (j>self->m_Len) {
      j -= self->m_Len;
      cb_FILL2(self->m_Buffer[self->m_Len],j,' ');
      self->m_Len += j;
      j += self->m_Len;
    }
    self->m_Len = self->m_Len + i;
    j -= iReplace;
    i += iReplace;
    if (i>0) {
      cb_MemCopy(self->m_Buffer + j,newValue,i);
      if (iOfs<0) {
        self->m_Pos += i;
      }
    }
    i = self->m_Len;
    *(short*)(self->m_Buffer + i) = '\0';
  }
  return self;
}


void* cb_cFString_InsertAt (void* T,const void* newValue,cb_Integer iOfs,cb_Integer iReplace)
{
  cb_cFString* self; self = (cb_cFString*)newValue;
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cFString_StrInsertAt(T,s,iOfs,self->m_Len,iReplace);
  }
  return NULL;
}


cb_PString cb_cFString_GetMid (void* T,cb_Integer StartPos,cb_Integer NumChars,void* dst)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer bytes;
  cb_Integer n; n = StartPos;
  if (n<0) {
    n = self->m_Pos;
  }
  if (n>=self->m_Len) {
    bytes = 0;
  }
  else {
    bytes = NumChars;
    if (bytes<0 || n>self->m_Len - bytes) {
      bytes = self->m_Len - n;
    }
  }
  if (dst==NULL || dst==cb_INVALID) {
    dst = cb_NewStr(self->m_Buffer + n,dst,bytes);
  }
  else {
    *(short*)((BYTE*)dst + bytes) = '\0';
    if (bytes>0) {
      cb_MemCopy(dst,self->m_Buffer + n,bytes);
    }
  }
  if (StartPos<0) {
    self->m_Pos += bytes;
  }
  return (cb_PString)dst;
}


cb_PString cb_cFString_GetLeft (void* T,cb_Integer NumChars,void* dst)
{
  return cb_cFString_GetMid(T,0,NumChars,dst);
}


cb_PString cb_cFString_GetRight (void* T,cb_Integer NumChars,void* dst)
{
  cb_cFString* self; self = (cb_cFString*)T;
  if ((cb_UInteger)NumChars>(cb_UInteger)self->m_Len) {
    NumChars = self->m_Len;
  }
  if (dst==NULL || dst==cb_INVALID) {
    return cb_NewStr(self->m_Buffer + self->m_Len - NumChars,dst,NumChars);
  }
  *(short*)((BYTE*)dst + NumChars) = '\0';
  if (NumChars>0) {
    cb_MemCopy(dst,self->m_Buffer + self->m_Len - NumChars,NumChars);
  }
  return (cb_PString)dst;
}


void* cb_cFString_SetMid (void* T,const void* newValue,cb_Integer iOfs,cb_Integer iReplace,cb_Integer iNum)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i;
  if (iReplace<0) {
    i = iOfs;
    if (i<0) {
      i = self->m_Pos;
    }
    iReplace = self->m_Len - i;
    if (iReplace<0) {
      iReplace = 0;
    }
  }
  return cb_cFString_StrInsertAt(self,newValue,iOfs,iNum,iReplace);
}


cb_Integer cb_cFString_Asc (void* T,cb_UInteger Index)
{
  cb_cFString* self; self = (cb_cFString*)T;
  if ((cb_UInteger)self->m_Len>Index) {
    return self->m_Buffer[Index];
  }
  return -1;
}


void cb_cFString_SetChar (void* T,cb_UInteger index,BYTE newValue)
{
  cb_cFString* self; self = (cb_cFString*)T;
  if (index<(cb_UInteger)self->m_Len) {
    self->m_Buffer[index] = newValue;
  }
}


cb_Integer cb_cFString_InStr (void* T,const cb_String s,cb_Integer iOfs,cb_Integer iFlag)
{
  return cb_InStr(((cb_cFString*)T)->m_Buffer,s,iOfs,iFlag);
}


cb_Integer cb_cFString_In (void* T,const void* T1,cb_Integer iOfs,cb_Integer iFlag)
{
  return cb_InStr(((cb_cFString*)T)->m_Buffer,(const cb_String)(((cb_cFString*)T1)->m_Buffer),iOfs,iFlag);
}


cb_Integer cb_cFString_StrFind (void* T,const cb_String search,cb_Integer StartPos,cb_Boolean bFlag,cb_Integer searchLen)
{
  cb_Integer cb_retVar_;
  cb_cFString* self; self = (cb_cFString*)T;
  BYTE* searchChars;
  BYTE* Buf;
  BYTE firstChar;
  cb_Integer i;
  cb_Integer j;
  if (searchLen<=0) {
    searchLen = cb_StrLen(search);
  }
  if (searchLen==0) {
    return StartPos;
  }
  searchChars = (BYTE*)search;
  cb_retVar_ = -1;
  if (StartPos + searchLen>self->m_Len) {
    goto cb_EndSub_0;
  }
  i = StartPos;
  if (bFlag==FALSE) {
    firstChar = searchChars[0];
Again0000: ;
    Buf = &(self->m_Buffer[i]);
    for (;i<self->m_Len;i++) {
      if (self->m_Buffer[i]==firstChar) {
        for (j=1;j<searchLen;j++) {
          Buf++;
          searchChars++;
          if (Buf[0]!=searchChars[0]) {
            searchChars = (BYTE*)search;
            i++;
            goto Again0000;
          }
        }
        cb_retVar_ = i;
        break;
      }
      Buf++;
    }
  }
  else {
    firstChar = cb_ToLower(searchChars[0]);
Again000: ;
    Buf = &(self->m_Buffer[i]);
    for (;i<self->m_Len;i++) {
      if (cb_ToLower(Buf[0])==firstChar) {
        for (j=1;j<searchLen;j++) {
          Buf++;
          searchChars++;
          if (cb_ToLower(Buf[0])!=cb_ToLower(searchChars[0])) {
            searchChars = (BYTE*)search;
            i++;
            goto Again000;
          }
        }
        cb_retVar_ = i;
        break;
      }
      Buf++;
    }
  }
cb_EndSub_0: ;
  return cb_retVar_;
}


cb_Integer cb_cFString_Find (void* T,const void* T1,cb_Integer StartPos,cb_Boolean bFlag,cb_Integer searchLen)
{
  cb_cFString* self; self = (cb_cFString*)T1;
  if (searchLen<=0) {
    searchLen = self->m_Len;
  }
  return cb_cFString_StrFind(T,(const cb_String)self->m_Buffer,StartPos,bFlag,searchLen);
}


void* cb_cFString_UCase (void* T)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i;
  cb_Integer c;
  for (i=0;i<self->m_Len;i++) {
    c = self->m_Buffer[i];
    if (c>='a' && c<='z') {
      self->m_Buffer[i] = c-32;
    }
  }
  return self;
}


void* cb_cFString_LCase (void* T)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i;
  cb_Integer c;
  for (i=0;i<self->m_Len;i++) {
    c = self->m_Buffer[i];
    if (c>='A' && c<='Z') {
      self->m_Buffer[i] = c+32;
    }
  }
  return self;
}


void* cb_cFString_Reverse (void* T)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i;
  BYTE c;
  for (i=0;i<=self->m_Len/2-1;i++) {
    c = self->m_Buffer[i];
    self->m_Buffer[i] = self->m_Buffer[self->m_Len-1 - i];
    self->m_Buffer[self->m_Len-1 - i] = c;
  }
  return self;
}


void* cb_cFString_StrAppend (void* T,const void* arg,cb_Integer lLen)
{
  cb_cFString* self; self = NULL;
  cb_Integer newLength;
  cb_Integer argLen; argLen = lLen;
  if (argLen<0) {
    argLen = cb_StrLen((const cb_String)arg);
  }
  if (argLen>0) {
    self = (cb_cFString*)T;
    newLength = argLen;
    if (self) {
      newLength += self->m_Len;
    }
    self = (cb_cFString*)cb_cFString_SetBufferSize(self,newLength,TRUE);
    if (self) {
      cb_MemCopy(&(self->m_Buffer[self->m_Len]),arg,argLen);
      *(short*)(self->m_Buffer + newLength) = '\0';
      self->m_Len = newLength;
    }
  }
  return self;
}


void* cb_cFString_Append (void* T,const void* T1)
{
  cb_cFString* self; self = (cb_cFString*)T1;
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cFString_StrAppend(T,s,self->m_Len);
  }
  return NULL;
}


void* cb_cFString_LineAppend (void* T,const cb_String arg,cb_Integer lLen)
{
  T = cb_cFString_StrAppend(T,arg,lLen);
  if (T) {
    return cb_cFString_StrAppend(T,"\r\n",2);
  }
  return NULL;
}


void* cb_cFString_StrNAppend (void* T,const void* newValue,cb_Integer iMax,cb_Integer iNum)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer n; n = self->m_Len;
  if ((cb_UInteger)n>(cb_UInteger)iMax) {
    return NULL;
  }
  iMax -= n;
  cb_Integer i; i = iNum;
  if (i<0) {
    i = cb_StrLen((const cb_String)newValue);
  }
  if ((cb_UInteger)i>(cb_UInteger)iMax) {
    i = iMax;
  }
  return cb_cFString_StrAppend(self,newValue,i);
}


void* cb_cFString_NAppend (void* T,const void* newValue,cb_Integer iMax)
{
  cb_cFString* self; self = (cb_cFString*)newValue;
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cFString_StrNAppend(T,s,iMax,self->m_Len);
  }
  return NULL;
}


void* cb_cFString_CharAppend (void* T,char arg)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer newLength;
  #define argLen ((cb_Integer)1)
  newLength = self->m_Len + argLen;
  if (!cb_cFString_SetBufferSize(self,newLength,TRUE)) {
    return NULL;
  }
  cb_ASC2(self->m_Buffer,self->m_Len) = arg;
  *(short*)(self->m_Buffer + newLength) = '\0';
  self->m_Len = newLength;
  return self;
  #undef argLen
}


__declspec(noinline) void* cb_CDECL cb_cFString_StrJoin (void* T,const cb_String arg,...)
{
  cb_cFString* self; self = (cb_cFString*)T;
  const cb_PString* MyPtr1;
  cb_PString MyPtr2;
  cb_Integer i;
  cb_Integer j;
  i = 0;
  for (MyPtr1=&arg;MyPtr1[0];MyPtr1++) {
    i += cb_StrLen(MyPtr1[0]);
  }
  self = (cb_cFString*)cb_cFString_SetBufferSize(self,i,FALSE);
  if (self) {
    i = 0;
    MyPtr2 = (cb_String)(self->m_Buffer);
    for (MyPtr1=&arg;MyPtr1[0];MyPtr1++) {
      j = cb_StrLen(MyPtr1[0]);
      cb_MemCopy(MyPtr2 + i,MyPtr1[0],j);
      i += j;
    }
    self->m_Len = i;
    *(short*)(MyPtr2 + i) = '\0';
  }
  return self;
}


__declspec(noinline) void* cb_CDECL cb_cFString_Join (void* T,const void* arg,...)
{
  cb_cFString* self; self = (cb_cFString*)T;
  const cb_cFString** Ptr1;
  cb_PString MyPtr1;
  cb_Integer i;
  cb_Integer j;
  i = 0;
  for (Ptr1=(const cb_cFString**)(&arg);Ptr1[0];Ptr1++) {
    i += cb_cFString_Len(Ptr1[0]);
  }
  self = (cb_cFString*)cb_cFString_SetBufferSize(self,i,FALSE);
  if (self) {
    i = 0;
    MyPtr1 = (cb_PString)self->m_Buffer;
    for (Ptr1=(const cb_cFString**)(&arg);Ptr1[0];Ptr1++) {
      j = cb_cFString_Len(Ptr1[0]);
      cb_MemCopy(MyPtr1,cb_cFString_Str(Ptr1[0]),j);
      i += j;
      MyPtr1 += j;
    }
    self->m_Len = i;
    *(short*)MyPtr1 = '\0';
  }
  return self;
}


__declspec(noinline) void* cb_CDECL cb_cFString_StrConCat (void* T,const cb_String arg,...)
{
  cb_cFString* self; self = (cb_cFString*)T;
  const cb_PString* MyPtr1;
  cb_PString MyPtr2;
  cb_Integer i;
  cb_Integer j;
  if (self) {
    i = self->m_Len;
  }
  else {
    i = 0;
  }
  for (MyPtr1=&arg;MyPtr1[0];MyPtr1++) {
    i += cb_StrLen(MyPtr1[0]);
  }
  self = (cb_cFString*)cb_cFString_SetBufferSize(self,i,TRUE);
  if (self) {
    i = self->m_Len;
    MyPtr2 = (cb_String)(self->m_Buffer);
    for (MyPtr1=&arg;MyPtr1[0];MyPtr1++) {
      j = cb_StrLen(MyPtr1[0]);
      cb_MemCopy(MyPtr2 + i,MyPtr1[0],j);
      i += j;
    }
    self->m_Len = i;
    *(short*)(MyPtr2 + i) = '\0';
  }
  return self;
}


__declspec(noinline) void* cb_CDECL cb_cFString_ConCat (void* T,const void* arg,...)
{
  cb_cFString* self; self = (cb_cFString*)T;
  const cb_cFString** Ptr1;
  cb_PString MyPtr1;
  cb_Integer i;
  cb_Integer j;
  if (self) {
    i = self->m_Len;
  }
  else {
    i = 0;
  }
  for (Ptr1=(const cb_cFString**)(&arg);Ptr1[0];Ptr1++) {
    i += cb_cFString_Len(Ptr1[0]);
  }
  self = (cb_cFString*)cb_cFString_SetBufferSize(self,i,TRUE);
  if (self) {
    i = self->m_Len;
    MyPtr1 = (cb_PString)self->m_Buffer + i;
    for (Ptr1=(const cb_cFString**)(&arg);Ptr1[0];Ptr1++) {
      j = cb_cFString_Len(Ptr1[0]);
      cb_MemCopy(MyPtr1,cb_cFString_Str(Ptr1[0]),j);
      i += j;
      MyPtr1 += j;
    }
    self->m_Len = i;
    *(short*)MyPtr1 = '\0';
  }
  return self;
}


__declspec(noinline) void* cb_CDECL cb_cFString_SPrintF (void* T,const cb_String Str1,...)
{
  register cb_cFString* self; self = (cb_cFString*)T;
  if (!self) {
    goto Set0000;
  }
  if (self->m_Size<64*0x400) {
Set0000: ;
    self = (cb_cFString*)cb_cFString_SetBufferSize(self,64*0x400,FALSE);
    if (!self) {
      return NULL;
    }
  }
  self->m_Len = cb_vsprintf((cb_String)(self->m_Buffer),Str1,(&Str1)+1);
  *(short*)(self->m_Buffer + self->m_Len) = 0;
  return self;
}


cb_Integer cb_cFString_StrCompareCase (const void* T,const cb_String Str1)
{
  const cb_cFString* self; self = (const cb_cFString*)T;
  return cb_MemComp(Str1,self->m_Buffer,self->m_Len+1);
}


cb_Integer cb_cFString_StrCompareNoCase (const void* T,const cb_String Str1)
{
  const cb_cFString* self; self = (const cb_cFString*)T;
  return cb_MemIComp(Str1,self->m_Buffer,self->m_Len+1);
}


cb_Integer cb_cFString_CompareCase (const void* T,const void* p)
{
  const cb_cFString* self; self = (const cb_cFString*)T;
  return cb_MemComp(((const cb_cFString*)p)->m_Buffer,self->m_Buffer,self->m_Len+1);
}


cb_Integer cb_cFString_CompareNoCase (const void* T,const void* p)
{
  const cb_cFString* self; self = (const cb_cFString*)T;
  return cb_MemIComp(((const cb_cFString*)p)->m_Buffer,self->m_Buffer,self->m_Len+1);
}


const char* cb_cFString_CharToken (void* T,cb_Integer iDelim,const cb_String Str1,void* dst)
{
  register cb_cFString* self; self = (cb_cFString*)T;
  register cb_Integer i;
  register const cb_PString MyPtr1; MyPtr1 = Str1;
  if (!(MyPtr1)) {
    i = self->m_Pos;
    if ((cb_UInteger)i>=(cb_UInteger)(self->m_Len)) {
      return NULL;
    }
    MyPtr1 = (const cb_String)(self->m_Buffer);
    MyPtr1 += i;
  }
  do {
    if (MyPtr1[0]==0) {
      return NULL;
    }
    if (MyPtr1[0]!=iDelim) {
      break;
    }
    MyPtr1++;
  } while(1);
  if (Str1) {
    self = (cb_cFString*)cb_cFString_StrCopy(self,MyPtr1);
    if (!(self)) {
      return NULL;
    }
    i = 0;
    MyPtr1 = (const cb_String)(self->m_Buffer);
  }
  self->m_Pos = i;
  i = cb_InChar(MyPtr1,iDelim);
  if (i<0) {
    i = self->m_Len;
    i -= self->m_Pos;
    self->m_Pos = self->m_Len;
  }
  else {
    i++;
    self->m_Pos += i;
    i--;
  }
  if (dst==(cb_INVALID)-2) {
    cb_ASC2(MyPtr1,i) = '\0';
    return MyPtr1;
  }
  return cb_NewStr(MyPtr1,dst,i);
}


const char* cb_cFString_StrToken (void* T,const cb_String sDelim,const cb_String Str1,void* dst)
{
  register cb_cFString* self; self = (cb_cFString*)T;
  register cb_Integer i;
  register const cb_PString MyPtr1; MyPtr1 = Str1;
  register cb_Integer n;
  if (sDelim==NULL) {
    return NULL;
  }
  if (!(MyPtr1)) {
    i = self->m_Pos;
    if ((cb_UInteger)i>=(cb_UInteger)(self->m_Len)) {
      return NULL;
    }
    MyPtr1 = (const cb_String)(self->m_Buffer);
    MyPtr1 += i;
  }
  n = cb_StrLen(sDelim);
  do {
    if (MyPtr1[0]==0) {
      return NULL;
    }
    if (0!=cb_MemComp(MyPtr1,sDelim,n)) {
      break;
    }
    MyPtr1 += n;
    i += n;
  } while(1);
  if (Str1) {
    self = (cb_cFString*)cb_cFString_StrCopy(self,MyPtr1);
    if (!(self)) {
      return NULL;
    }
    i = 0;
    MyPtr1 = (const cb_String)(self->m_Buffer);
  }
  self->m_Pos = i;
  i = (cb_Integer)cb_StrStr(MyPtr1,sDelim);
  if (i==0) {
    i = self->m_Len;
    i -= self->m_Pos;
    self->m_Pos = self->m_Len;
  }
  else {
    i -= (cb_Integer)MyPtr1;
    self->m_Pos += i + n;
  }
  if (dst==(cb_INVALID)-2) {
    cb_ASC2(MyPtr1,i) = '\0';
    return MyPtr1;
  }
  return cb_NewStr(MyPtr1,dst,i);
}


cb_Integer cb_cFString_Backspace (void* T,cb_Integer Spaces)
{
  cb_cFString* self; self = (cb_cFString*)T;
  if (Spaces>self->m_Len) {
    Spaces = self->m_Len;
  }
  if (Spaces>0) {
    self->m_Len = self->m_Len - Spaces;
    *(short*)(self->m_Buffer + self->m_Len) = '\0';
  }
  return Spaces;
}


void cb_cFString_Delete (void* T,cb_Integer Length,cb_Integer iPos)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer iLen; iLen = Length;
  if (iLen<=0) {
    return;
  }
  cb_Integer i; i = iPos;
  if ((cb_UInteger)i>=(cb_UInteger)(self->m_Len)) {
    return;
  }
  iLen += i;
  if ((cb_UInteger)iLen>(cb_UInteger)(self->m_Len)) {
    iLen = self->m_Len;
  }
  self->m_Len -= Length;
  if (self->m_Len>0) {
    cb_MemCopy(self->m_Buffer + i,self->m_Buffer + iLen,self->m_Len);
  }
  self->m_Len += i;
  *(short*)(self->m_Buffer + self->m_Len) = '\0';
  if (self->m_Pos>i) {
    iLen -= i;
    self->m_Pos -= iLen;
  }
}


char* cb_cFString_Get (void* T,void* dst,cb_Integer iLen,void* iRet,cb_Integer iPos,cb_Boolean bPeek)
{
  cb_cFString* self; self = (cb_cFString*)T;
  register char* MyPtr1; MyPtr1 = (char*)dst;
  register cb_Integer i; i = iLen;
  register cb_Integer n; n = iPos;
  if (n<0) {
    n = self->m_Pos;
  }
  if (i<=0 || i + n>self->m_Len) {
    i = self->m_Len - n;
    if (i<=0) {
      MyPtr1 = cb_NewStr(NULL,MyPtr1,0);
      if (!MyPtr1) {
        goto Error0000;
      }
      i = 0;
      goto Exit0000;
    }
  }
  MyPtr1 = cb_Mid(self->m_Buffer,n,i,MyPtr1);
  if (MyPtr1) {
    if (!bPeek) {
      if (iPos>=0) {
        cb_cFString_DeleteChars(self,i);
      }
      else {
        self->m_Pos += i;
      }
    }
Exit0000: ;
    if (iRet) {
      *(cb_Integer*)iRet = i;
    }
  }
Error0000: ;
  return MyPtr1;
}


char* cb_cFString_Peek (void* T,void* dst,cb_Integer iLen,void* iRet,cb_Integer iPos)
{
  return cb_cFString_Get(T,dst,iLen,iRet,iPos,TRUE);
}


char* cb_cFString_GetLine (void* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax,cb_Integer bPeek)
{
  cb_cFString* self; self = (cb_cFString*)T;
  register cb_Integer lngLineEnd; lngLineEnd = iPos;
  if (lngLineEnd<0) {
    lngLineEnd = self->m_Pos;
  }
  register char* MyPtr1;
  cb_Integer i;
  if (lngLineEnd>=self->m_Len) {
Exit0000: ;
    MyPtr1 = cb_NewStr(NULL,dst,0);
    lngLineEnd = 0;
  }
  else {
    i = lngLineEnd;
    lngLineEnd += (cb_Integer)(self->m_Buffer);
    if (cb_ASC1(lngLineEnd)=='\n') {
      if (self->m_LastChar=='\r') {
        lngLineEnd++;
        if (iPos<0) {
          i++;
        }
      }
    }
    MyPtr1 = (char*)lngLineEnd;
    for (;;lngLineEnd++) {
      if (cb_ASC1(lngLineEnd)=='\r' || cb_ASC1(lngLineEnd)=='\n') {
        break;
      }
      if (cb_ASC1(lngLineEnd)=='\0') {
        if ((lngLineEnd - (cb_Integer)(self->m_Buffer))>=self->m_Len) {
          if (bPeek<0) {
            goto Exit0000;
          }
          break;
        }
      }
    }
    lngLineEnd -= (cb_Integer)MyPtr1;
    if ((cb_UInteger)(lngLineEnd+2)>=(cb_UInteger)iMax) {
      lngLineEnd = iMax;
      lngLineEnd -= 2+1;
      if (lngLineEnd<0) {
        goto Exit0000;
      }
    }
    MyPtr1 = cb_NewStr(MyPtr1,dst,lngLineEnd+2);
    if (MyPtr1==NULL) {
      goto Error0000;
    }
    self->m_LastChar = cb_ASC2(MyPtr1,lngLineEnd);
    if (self->m_LastChar=='\r') {
      lngLineEnd++;
    }
    if (cb_ASC2(MyPtr1,lngLineEnd)=='\n') {
      lngLineEnd++;
      self->m_LastChar = '\n';
    }
    if (bPeek<=0) {
      if (iPos>=0) {
        cb_cFString_DeleteChars(self,lngLineEnd,i);
      }
      else {
        self->m_Pos = i + lngLineEnd;
      }
    }
    MyPtr1[lngLineEnd] = '\0';
  }
  if (iRet) {
    *(cb_Integer*)iRet = lngLineEnd;
  }
Error0000: ;
  return MyPtr1;
}


char* cb_cFString_PeekLine (void* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax)
{
  return cb_cFString_GetLine(T,dst,iRet,iPos,iMax,TRUE);
}


char* cb_cFString_ReadLine (void* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax)
{
  return cb_cFString_GetLine(T,dst,iRet,iPos,iMax,-1);
}


wchar_t* cb_cFString_GetLineW (void* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax,cb_Integer bPeek)
{
  return NULL;
}


wchar_t* cb_cFString_PeekLineW (void* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax)
{
  return cb_cFString_GetLineW(T,dst,iRet,iPos,iMax,TRUE);
}


wchar_t* cb_cFString_ReadLineW (void* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax)
{
  return cb_cFString_GetLineW(T,dst,iRet,iPos,iMax,-1);
}


cb_Integer cb_cFString_HasLine (void* T,cb_Integer iPos)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i; i = iPos;
  if (i<0) {
    i = self->m_Pos;
  }
  if (i<self->m_Len) {
    return cb_InChars(self->m_Buffer,"\r\n")+1;
  }
  return 0;
}


cb_Integer cb_cFString_EOS (void* T)
{
  register cb_cFString* self; self = (cb_cFString*)T;
  return cb_CBOOL((cb_UInteger)(self->m_Pos)>=(cb_UInteger)(self->m_Len));
}


void cb_cFString_Rewind (void* T)
{
  register cb_cFString* self; self = (cb_cFString*)T;
  self->m_Pos = 0;
}


void* cb_cFString_GetTag (void* T)
{
  register cb_cFString* self; self = (cb_cFString*)T;
  return self->UserData;
}


void* cb_cFString_SetTag (void* T,void* n)
{
  void* cb_retVar_;
  register cb_cFString* self; self = (cb_cFString*)T;
  cb_retVar_ = self->UserData;
  self->UserData = n;
  return cb_retVar_;
}


cb_Integer cb_cFString_WriteFile (void* T,cb_File* FileNum)
{
  cb_Integer cb_retVar_;
  cb_cFString* self; self = (cb_cFString*)T;
  return cb_FPut(FileNum,self->m_Buffer,self->m_Len);
}


cb_Integer cb_cFString_WriteFileName (void* self,const cb_String sfName)
{
  cb_Integer cb_retVar_;
  cb_File* h;
  h = cb_FOpen(sfName,"wbs");
  if (h==NULL) {
    cb_retVar_ = -1;
  }
  else {
    cb_retVar_ = cb_cFString_WriteFile(self,h);
    cb_FileClose(h);
  }
  return cb_retVar_;
}


void* cb_cFString_ReadFile (void* T,cb_File* FileNum,cb_Integer iPos)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i;
  cb_Integer n; n = iPos;
  if (n<0) {
    n = self->m_Pos;
  }
  cb_Integer d;
  i = cb_Lof(FileNum);
  self = (cb_cFString*)cb_cFString_SetBufferSize(self,i + n,FALSE);
  if (self) {
    if (cb_FGet(FileNum,self->m_Buffer + n,&d,i)) {
      i = d;
      if (iPos<0) {
        self->m_Pos += i;
      }
      i += n;
      *(short*)(self->m_Buffer + i) = '\0';
      self->m_Len = i;
      return self;
    }
  }
  return NULL;
}


void* cb_cFString_ReadFileName (void* self,const cb_String sfName,cb_Integer iPos)
{
  void* cb_retVar_;
  cb_File* h;
  h = cb_FOpen(sfName,"rbs");
  if (h==NULL) {
    cb_retVar_ = NULL;
  }
  else {
    cb_retVar_ = cb_cFString_ReadFile(self,h,iPos);
    cb_FileClose(h);
  }
  return cb_retVar_;
}


cb_Integer cb_cFString_Seek (void* T,cb_Integer iPos,cb_Integer iOrg)
{
  cb_cFString* self; self = (cb_cFString*)T;
  register cb_Integer i; i = iPos;
  if (iOrg==SEEK_CUR) {
    i += self->m_Pos;
  }
  else if (iOrg==SEEK_END) {
    i += self->m_Len;
  }
  if (i>=0) {
    self->m_Pos = i;
  }
  else {
    i = -1;
  }
  return i;
}


cb_Integer cb_cFString_Tell (void* T)
{
  cb_cFString* self; self = (cb_cFString*)T;
  return self->m_Pos;
}


char* cb_cFString_Read (void* T,cb_Integer* iRet,void* dst,cb_Integer iNum)
{
  cb_cFString* self; self = (cb_cFString*)T;
  cb_Integer i;
  BYTE* s;
  i = self->m_Len;
  i -= self->m_Pos;
  s = self->m_Buffer;
  if (i<=0) {
    i = 0;
  }
  else {
    s += self->m_Pos;
    if ((cb_UInteger)i>(cb_UInteger)iNum) {
      i = iNum;
    }
  }
  dst = cb_NewStr(s,dst,i);
  if (dst) {
    self->m_Pos += i;
    if (iRet) {
      cb_LowInt(iRet[0]) = i;
    }
  }
  return (char*)dst;
}


void* cb_cFString_Write (void* T,const void* Str1,cb_Integer iLen)
{
  cb_cFString* self; self = (cb_cFString*)T;
  if ((self->flag1_ & cb_cFString_APPEND_bit_)!=0) {
    if (self->m_Pos<self->m_Len) {
      self->m_Pos = self->m_Len;
    }
  }
  return cb_cFString_PutAt(self,Str1,-1,iLen);
}
/* END MODULE */
/* MODULE::cb_cString */
/* MODULE::cb_cString1 */


cb_cString* cb_cString_Initialize (cb_cString* T)
{
  register cb_cString* self; self = T;
  if (!self) {
    self = (cb_cString*)cb_MemAllocZM(sizeof(cb_cString));
    if (self) {
      self->flag1_++;
    }
  }
  else {
    cb_CLEAR1(*self);
  }
  return self;
}


void cb_cString_Terminate (cb_cString* T)
{
  cb_cString* self; self = T;
  if (self->m_Buffer) {
    if (!(self->flag1_ & 2)) {
      cb_MemFreeM(self->m_Buffer);
    }
  }
  if ((self->flag1_ & TRUE)!=0) {
    cb_MemFreeM(self);
  }
  else {
    cb_CLEAR1(*self);
  }
}
/* END MODULE */
/* MODULE::cb_cString2 */


cb_cString* cb_cString_SetBufferSize (cb_cString* T,cb_Integer newSize,cb_Boolean bFlag)
{
  cb_cString* self; self = NULL;
  BYTE* Buf;
  if (newSize>=0) {
    self = T;
    newSize += cb_cString_DEFAULT_ADDLENGTH>>1;
    if (self->m_Size<newSize) {
      newSize += (cb_cString_DEFAULT_ADDLENGTH<<1)-1;
      newSize &=  ~((cb_cString_DEFAULT_ADDLENGTH>>1)-1);
      Buf = self->m_Buffer;
      if (bFlag) {
        Buf = (BYTE*)cb_ReDim(newSize * sizeof(BYTE), Buf, 1);
      }
      else {
        Buf = (BYTE*)cb_ReDim(newSize * sizeof(BYTE), Buf);
      }
      if (!Buf) {
        return NULL;
      }
      self->m_Buffer = Buf;
      self->m_Size = newSize;
    }
  }
Exit0000: ;
  return self;
}
/* END MODULE */


cb_cString* cb_cString_New (cb_Integer i)
{
  register cb_cString* self; self = cb_cString_Initialize(NULL);
  if (self) {
    return cb_cString_SetBufferSize(self,i,FALSE);
  }
  return NULL;
}


cb_cString* cb_cString_SetBuffer (cb_cString* T,void* p,cb_Integer newLen)
{
  cb_cString* self; self = T;
  cb_Integer i;
  if (p) {
    i = cb_MemSizeM(p);
    if (i>=0) {
      if (self->m_Buffer) {
        cb_MemFreeM(self->m_Buffer);
      }
      self->m_Buffer = (BYTE*)p;
      self->m_Size = i;
      if (i<sizeof(short)) {
        if (!cb_cString_SetBufferSize(self,sizeof(short),FALSE)) {
          return NULL;
        }
      }
      i = newLen;
      if (i<0) {
        i = cb_StrLen((const cb_String)p);
      }
      if (cb_CASTrev(i,cb_UInteger)>cb_CASTrev((self->m_Size - sizeof(short)),cb_UInteger)) {
        i = self->m_Size - sizeof(short);
      }
      self->m_Len = i;
      *(short*)(self->m_Buffer + i) = '\0';
      return self;
    }
  }
  return NULL;
}


cb_cString* cb_cString_Attatch (cb_cString* T,void* p,cb_Integer iLen,cb_Integer flag1)
{
  cb_cString* self; self = cb_cString_SetBuffer(T,p,iLen);
  if (self) {
    if (flag1) {
      self->flag1_ |= 4;
    }
  }
  return self;
}


cb_PString cb_cString_Release (cb_cString* T,cb_Integer* iLen)
{
  cb_PString cb_retVar_;
  cb_cString* self; self = T;
  cb_retVar_ = (cb_PString)(self->m_Buffer);
  cb_LowShort(cb_retVar_[self->m_Len]) = '\0';
  if (iLen) {
    iLen[0] = self->m_Len;
  }
  self->m_Buffer = NULL;
  self->m_Len = 0;
  self->m_Size = 0;
  self->flag1_ &=  ~4;
  return cb_retVar_;
}


const cb_PString cb_cString_StrPtr (const cb_cString* T)
{
  return cb_StrPtr(&T->m_Buffer[0]);
}


cb_Integer cb_cString_GetLength (const cb_cString* self)
{
  return self->m_Len;
}


cb_cString* cb_cString_SetLength (cb_cString* T,cb_Integer newValue)
{
  cb_cString* self; self = T;
  cb_Integer i; i = newValue;
  if (i<0) {
    i = self->m_Pos;
  }
  if (!cb_cString_SetBufferSize(self,i,TRUE)) {
    return NULL;
  }
  self->m_Len = i;
  *(short*)(self->m_Buffer + i) = '\0';
  return self;
}


cb_cString* cb_cString_ChangeLength (cb_cString* T,cb_Integer newValue)
{
  cb_cString* self; self = T;
  cb_Integer i; i = newValue;
  if (i<0) {
    i = self->m_Pos;
  }
  self->m_Size = i;
  if (!cb_cString_SetBufferSize(self,i,TRUE)) {
    return NULL;
  }
  self->m_Len = i;
  *(short*)(self->m_Buffer + i) = '\0';
  return self;
}


void cb_cString_Clear (cb_cString* self)
{
  self->m_Len = 0;
  *(short*)(self->m_Buffer) = '\0';
}


cb_PString cb_cString_GetAt (cb_cString* T,cb_Integer iOfs,void* dst)
{
  cb_cString* self; self = T;
  cb_UInteger i; i = iOfs;
  if ((cb_UInteger)i>self->m_Len) {
    i = self->m_Len;
  }
  return cb_NewStr(self->m_Buffer + i,dst,self->m_Len - i);
}


cb_cString* cb_cString_PutAt (cb_cString* T,const void* newValue,cb_Integer iOfs,cb_Integer iNum)
{
  register cb_cString* self; self = T;
  register cb_Integer i; i = iNum;
  register cb_Integer j; j = iOfs;
  if (i<0) {
    i = cb_StrLen((const cb_String)newValue);
  }
  if (j<0) {
    j = self->m_Pos;
  }
  if (!cb_cString_SetBufferSize(self,i + j,TRUE)) {
    return NULL;
  }
  if (i>0) {
    cb_MemCopy(self->m_Buffer + j,newValue,i);
  }
  i += j;
  if (iOfs>=0) {
    goto Len0000;
  }
  self->m_Pos = i;
  if (i>self->m_Len) {
Len0000: ;
    self->m_Len = i;
    *(short*)(self->m_Buffer + i) = '\0';
  }
  return self;
}


cb_cString* cb_cString_Copy (cb_cString* T,const cb_cString* self)
{
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cString_PutAt(T,s,0,self->m_Len);
  }
  return NULL;
}


cb_cString* cb_cString_StrNCopy (cb_cString* self,const void* newValue,cb_Integer iMax,cb_Integer iOfs,cb_Integer iNum)
{
  cb_Integer i; i = iNum;
  if (i<0) {
    i = cb_StrLen((const cb_String)newValue);
  }
  if ((cb_UInteger)i>(cb_UInteger)iMax) {
    i = iMax;
  }
  return cb_cString_StrCopy(self,newValue,iOfs,i);
}


cb_cString* cb_cString_NCopy (cb_cString* T,const cb_cString* self,cb_Integer iMax,cb_Integer iOfs)
{
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cString_StrNCopy(T,s,iMax,iOfs,self->m_Len);
  }
  return NULL;
}


cb_cString* cb_cString_Dup (cb_cString* self,cb_cString* p)
{
  cb_cString* cb_retVar_;
  cb_retVar_ = p;
  if (!cb_retVar_) {
    cb_retVar_ = (cb_cString*)cb_MemAllocM(sizeof(cb_cString));
  }
  return (cb_cString*)cb_MemCopy(cb_retVar_,self,sizeof(cb_cString));
}


cb_cString* cb_cString_StrInsertAt (cb_cString* self,const void* newValue,cb_Integer iOfs,cb_Integer iNum,cb_Integer iReplace)
{
  cb_Integer i; i = iNum;
  if (i<0) {
    i = cb_StrLen((const cb_String)newValue);
  }
  cb_Integer j; j = iOfs;
  if (j<0) {
    j = self->m_Pos;
  }
  if (iReplace<0) {
    iReplace = i;
  }
  i -= iReplace;
  j += iReplace;
  if (!cb_cString_SetBufferSize(self,i + cb_IIF2(j>=self->m_Len,j,self->m_Len),TRUE)) {
    return NULL;
  }
  if (self->m_Len>j) {
    if (i!=0) {
      cb_MemMove(self->m_Buffer + j + i,self->m_Buffer + j,self->m_Len - j);
    }
  }
  else if (j>self->m_Len) {
    j -= self->m_Len;
    cb_FILL2(self->m_Buffer[self->m_Len],j,' ');
    self->m_Len += j;
    j += self->m_Len;
  }
  self->m_Len = self->m_Len + i;
  j -= iReplace;
  i += iReplace;
  if (i>0) {
    cb_MemCopy(self->m_Buffer + j,newValue,i);
    if (iOfs<0) {
      self->m_Pos += i;
    }
  }
  i = self->m_Len;
  *(short*)(self->m_Buffer + i) = '\0';
  return self;
}


cb_cString* cb_cString_InsertAt (cb_cString* T,const cb_cString* self,cb_Integer iOfs,cb_Integer iReplace)
{
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cString_StrInsertAt(T,s,iOfs,self->m_Len,iReplace);
  }
  return NULL;
}


cb_PString cb_cString_GetMid (cb_cString* self,cb_Integer StartPos,cb_Integer NumChars,void* dst)
{
  cb_Integer bytes;
  cb_Integer n; n = StartPos;
  if (n<0) {
    n = self->m_Pos;
  }
  if (n>=self->m_Len) {
    bytes = 0;
  }
  else {
    bytes = NumChars;
    if (bytes<0 || n>self->m_Len - bytes) {
      bytes = self->m_Len - n;
    }
  }
  if (dst==NULL || dst==cb_INVALID) {
    dst = cb_NewStr(self->m_Buffer + n,dst,bytes);
  }
  else {
    *(short*)((BYTE*)dst + bytes) = '\0';
    if (bytes>0) {
      cb_MemCopy(dst,self->m_Buffer + n,bytes);
    }
  }
  if (StartPos<0) {
    self->m_Pos += bytes;
  }
  return (cb_PString)dst;
}


cb_PString cb_cString_GetLeft (cb_cString* self,cb_Integer NumChars,void* dst)
{
  return cb_cString_GetMid(self,0,NumChars,dst);
}


cb_PString cb_cString_GetRight (cb_cString* self,cb_Integer NumChars,void* dst)
{
  if ((cb_UInteger)NumChars>(cb_UInteger)self->m_Len) {
    NumChars = self->m_Len;
  }
  if (dst==NULL || dst==cb_INVALID) {
    return cb_NewStr(self->m_Buffer + self->m_Len - NumChars,dst,NumChars);
  }
  *(short*)((BYTE*)dst + NumChars) = '\0';
  if (NumChars>0) {
    cb_MemCopy(dst,self->m_Buffer + self->m_Len - NumChars,NumChars);
  }
  return (cb_PString)dst;
}


cb_cString* cb_cString_SetMid (cb_cString* self,const void* newValue,cb_Integer iOfs,cb_Integer iReplace,cb_Integer iNum)
{
  cb_Integer i;
  if (iReplace<0) {
    i = iOfs;
    if (i<0) {
      i = self->m_Pos;
    }
    iReplace = self->m_Len - i;
    if (iReplace<0) {
      iReplace = 0;
    }
  }
  return cb_cString_StrInsertAt(self,newValue,iOfs,iNum,iReplace);
}


cb_Integer cb_cString_Asc (cb_cString* self,cb_UInteger Index)
{
  if ((cb_UInteger)self->m_Len>Index) {
    return self->m_Buffer[Index];
  }
  return -1;
}


void cb_cString_SetChar (cb_cString* self,cb_UInteger index,BYTE newValue)
{
  if (index<(cb_UInteger)self->m_Len) {
    self->m_Buffer[index] = newValue;
  }
}


cb_Integer cb_cString_InStr (cb_cString* self,const cb_String s,cb_Integer iOfs,cb_Integer iFlag)
{
  return cb_InStr(self->m_Buffer,s,iOfs,iFlag);
}


cb_Integer cb_cString_In (cb_cString* self,const cb_cString* T1,cb_Integer iOfs,cb_Integer iFlag)
{
  return cb_InStr(self->m_Buffer,(const cb_String)(T1->m_Buffer),iOfs,iFlag);
}


cb_Integer cb_cString_StrFind (cb_cString* T,const cb_String search,cb_Integer StartPos,cb_Boolean bFlag,cb_Integer searchLen)
{
  cb_Integer cb_retVar_;
  cb_cString* self; self = T;
  BYTE* searchChars;
  BYTE* Buf;
  BYTE firstChar;
  cb_Integer i;
  cb_Integer j;
  if (searchLen<=0) {
    searchLen = cb_StrLen(search);
  }
  if (searchLen<=0) {
    return StartPos;
  }
  searchChars = (BYTE*)search;
  cb_retVar_ = -1;
  if (StartPos + searchLen>self->m_Len) {
    goto cb_EndSub_0;
  }
  i = StartPos;
  if (bFlag==FALSE) {
    firstChar = searchChars[0];
Again0000: ;
    Buf = &(self->m_Buffer[i]);
    for (;i<self->m_Len;i++) {
      if (Buf[0]==firstChar) {
        for (j=1;j<searchLen;j++) {
          Buf++;
          searchChars++;
          if (Buf[0]!=searchChars[0]) {
            searchChars = (BYTE*)search;
            i++;
            goto Again0000;
          }
        }
        cb_retVar_ = i;
        break;
      }
      Buf++;
    }
  }
  else {
    firstChar = cb_ToLower(searchChars[0]);
Again000: ;
    Buf = &(self->m_Buffer[i]);
    for (;i<self->m_Len;i++) {
      if (cb_ToLower(Buf[0])==firstChar) {
        for (j=1;j<searchLen;j++) {
          Buf++;
          searchChars++;
          if (cb_ToLower(Buf[0])!=cb_ToLower(searchChars[0])) {
            searchChars = (BYTE*)search;
            goto Again000;
          }
        }
        cb_retVar_ = i;
        break;
      }
      Buf++;
    }
  }
cb_EndSub_0: ;
  return cb_retVar_;
}


cb_Integer cb_cString_Find (cb_cString* T,const cb_cString* self,cb_Integer StartPos,cb_Boolean bFlag,cb_Integer searchLen)
{
  if (searchLen<=0) {
    searchLen = self->m_Len;
  }
  return cb_cString_StrFind(T,(const cb_String)(self->m_Buffer),StartPos,bFlag,searchLen);
}


cb_cString* cb_cString_UCase (cb_cString* T)
{
  cb_cString* self; self = T;
  cb_Integer i;
  cb_Integer c;
  for (i=0;i<self->m_Len;i++) {
    c = self->m_Buffer[i];
    if (c>='a' && c<='z') {
      self->m_Buffer[i] = c-32;
    }
  }
  return self;
}


cb_cString* cb_cString_LCase (cb_cString* T)
{
  cb_cString* self; self = T;
  cb_Integer i;
  cb_Integer c;
  for (i=0;i<self->m_Len;i++) {
    c = self->m_Buffer[i];
    if (c>='A' && c<='Z') {
      self->m_Buffer[i] = c+32;
    }
  }
  return self;
}


cb_cString* cb_cString_ReverseStr (cb_cString* T)
{
  cb_cString* self; self = T;
  cb_Integer i;
  BYTE c;
  for (i=self->m_Len/2-1;i>=0;i--) {
    c = self->m_Buffer[i];
    self->m_Buffer[i] = self->m_Buffer[self->m_Len-1 - i];
    self->m_Buffer[self->m_Len-1 - i] = c;
  }
  return self;
}


cb_cString* cb_cString_StrAppend (cb_cString* T,const void* arg,cb_Integer lLen)
{
  cb_cString* self; self = T;
  cb_Integer newLength;
  cb_Integer argLen; argLen = lLen;
  if (argLen<0) {
    argLen = cb_StrLen((const cb_String)arg);
  }
  if (argLen>0) {
    newLength = self->m_Len + argLen;
    if (!cb_cString_SetBufferSize(self,newLength,TRUE)) {
      return NULL;
    }
    cb_MemCopy(&(self->m_Buffer[self->m_Len]),arg,argLen);
    *(short*)(self->m_Buffer + newLength) = '\0';
    self->m_Len = newLength;
  }
  return self;
}


cb_cString* cb_cString_LineAppend (cb_cString* self,const cb_String arg,cb_Integer lLen)
{
  cb_cString_StrAppend(self,arg,lLen);
  return cb_cString_StrAppend(self,"\r\n",2);
}


cb_cString* cb_cString_Append (cb_cString* T,const cb_cString* self)
{
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cString_StrAppend(T,s,self->m_Len);
  }
  return NULL;
}


cb_cString* cb_cString_StrNAppend (cb_cString* self,const void* newValue,cb_Integer iMax,cb_Integer iNum)
{
  cb_Integer n; n = self->m_Len;
  if ((cb_UInteger)n>(cb_UInteger)iMax) {
    return NULL;
  }
  iMax -= n;
  cb_Integer i; i = iNum;
  if (i<0) {
    i = cb_StrLen((const cb_String)newValue);
  }
  if ((cb_UInteger)i>(cb_UInteger)iMax) {
    i = iMax;
  }
  return cb_cString_StrAppend(self,newValue,i);
}


cb_cString* cb_cString_NAppend (cb_cString* T,const cb_cString* self,cb_Integer iMax)
{
  register const cb_PString s; s = (const cb_PString)(self->m_Buffer);
  if (s) {
    return cb_cString_StrNAppend(T,s,iMax,self->m_Len);
  }
  return NULL;
}


cb_cString* cb_cString_CharAppend (cb_cString* T,char arg)
{
  cb_cString* self; self = T;
  cb_Integer newLength;
  #define argLen ((cb_Integer)1)
  newLength = self->m_Len + argLen;
  if (!cb_cString_SetBufferSize(self,newLength,TRUE)) {
    return NULL;
  }
  cb_ASC2(self->m_Buffer,self->m_Len) = arg;
  *(short*)(self->m_Buffer + newLength) = '\0';
  self->m_Len = newLength;
  return self;
  #undef argLen
}


__declspec(noinline) cb_cString* cb_CDECL cb_cString_StrJoin (cb_cString* self,const cb_String arg,...)
{
  const cb_PString* MyPtr1;
  cb_PString MyPtr2;
  cb_Integer i;
  cb_Integer j;
  i = 0;
  for (MyPtr1=&arg;MyPtr1[0];MyPtr1++) {
    i += cb_StrLen(MyPtr1[0]);
  }
  if (!cb_cString_SetBufferSize(self,i,FALSE)) {
    return NULL;
  }
  i = 0;
  MyPtr2 = (cb_String)self->m_Buffer;
  for (MyPtr1=&arg;MyPtr1[0];MyPtr1++) {
    j = cb_StrLen(MyPtr1[0]);
    cb_MemCopy(MyPtr2 + i,MyPtr1[0],j);
    i += j;
  }
  self->m_Len = i;
  *(short*)(MyPtr2 + i) = '\0';
  return self;
}


__declspec(noinline) cb_cString* cb_CDECL cb_cString_Join (cb_cString* self,const cb_cString* arg,...)
{
  const cb_cString** Ptr1;
  cb_PString MyPtr1;
  cb_Integer i;
  cb_Integer j;
  i = 0;
  for (Ptr1=&arg;Ptr1[0];Ptr1++) {
    i += cb_cString_Len(Ptr1[0]);
  }
  if (!cb_cString_SetBufferSize(self,i,FALSE)) {
    return NULL;
  }
  i = 0;
  MyPtr1 = (cb_String)self->m_Buffer;
  for (Ptr1=&arg;Ptr1[0];Ptr1++) {
    j = cb_cString_Len(Ptr1[0]);
    cb_MemCopy(MyPtr1,cb_cString_Str(Ptr1[0]),j);
    i += j;
    MyPtr1 += j;
  }
  self->m_Len = i;
  *(short*)MyPtr1 = '\0';
  return self;
}


__declspec(noinline) cb_cString* cb_CDECL cb_cString_StrConCat (cb_cString* self,const cb_String arg,...)
{
  const cb_PString* MyPtr1;
  cb_PString MyPtr2;
  cb_Integer i;
  cb_Integer j;
  i = self->m_Len;
  for (MyPtr1=&arg;MyPtr1[0];MyPtr1++) {
    i += cb_StrLen(MyPtr1[0]);
  }
  if (!cb_cString_SetBufferSize(self,i,TRUE)) {
    return NULL;
  }
  i = self->m_Len;
  MyPtr2 = (cb_String)self->m_Buffer;
  for (MyPtr1=&arg;MyPtr1[0];MyPtr1++) {
    j = cb_StrLen(MyPtr1[0]);
    cb_MemCopy(MyPtr2 + i,MyPtr1[0],j);
    i += j;
  }
  self->m_Len = i;
  *(short*)(MyPtr2 + i) = '\0';
  return self;
}


__declspec(noinline) cb_cString* cb_CDECL cb_cString_ConCat (cb_cString* self,const cb_cString* arg,...)
{
  const cb_cString** Ptr1;
  cb_PString MyPtr1;
  cb_Integer i;
  cb_Integer j;
  i = self->m_Len;
  for (Ptr1=&arg;Ptr1[0];Ptr1++) {
    i += cb_cString_Len(Ptr1[0]);
  }
  if (!cb_cString_SetBufferSize(self,i,TRUE)) {
    return NULL;
  }
  i = self->m_Len;
  MyPtr1 = (cb_String)self->m_Buffer + i;
  for (Ptr1=&arg;Ptr1[0];Ptr1++) {
    j = cb_cString_Len(Ptr1[0]);
    cb_MemCopy(MyPtr1,cb_cString_Str(Ptr1[0]),j);
    i += j;
    MyPtr1 += j;
  }
  self->m_Len = i;
  *(short*)MyPtr1 = '\0';
  return self;
}


__declspec(noinline) cb_cString* cb_CDECL cb_cString_SPrintF (cb_cString* T,const cb_String Str1,...)
{
  register cb_cString* self; self = T;
  if (!self) {
    goto Set0000;
  }
  if (self->m_Size<64*0x400) {
Set0000: ;
    self = cb_cString_SetBufferSize(self,64*0x400,FALSE);
    if (!self) {
      return NULL;
    }
  }
  self->m_Len = cb_vsprintf((cb_String)(self->m_Buffer),Str1,(&Str1)+1);
  *(short*)(self->m_Buffer + self->m_Len) = 0;
  return self;
}


cb_Integer cb_cString_StrCompareCase (cb_cString* self,const cb_String Str1)
{
  return cb_MemComp(Str1,self->m_Buffer,self->m_Len+1);
}


cb_Integer cb_cString_StrCompareNoCase (cb_cString* self,const cb_String Str1)
{
  return cb_MemIComp(Str1,self->m_Buffer,self->m_Len+1);
}


cb_Integer cb_cString_CompareCase (cb_cString* self,const cb_cString* p)
{
  return cb_MemComp(p->m_Buffer,self->m_Buffer,self->m_Len+1);
}


cb_Integer cb_cString_CompareNoCase (cb_cString* self,const cb_cString* p)
{
  return cb_MemIComp(p->m_Buffer,self->m_Buffer,self->m_Len+1);
}


const char* cb_cString_CharToken (cb_cString* T,cb_Integer iDelim,const cb_String Str1,void* dst)
{
  register cb_cString* self; self = T;
  register cb_Integer i;
  register const cb_PString MyPtr1; MyPtr1 = Str1;
  if (!(MyPtr1)) {
    i = self->m_Pos;
    if ((cb_UInteger)i>=(cb_UInteger)(self->m_Len)) {
      return NULL;
    }
    MyPtr1 = (const cb_String)(self->m_Buffer);
    MyPtr1 += i;
  }
  do {
    if (MyPtr1[0]==0) {
      return NULL;
    }
    if (MyPtr1[0]!=iDelim) {
      break;
    }
    MyPtr1++;
  } while(1);
  if (Str1) {
    if (!(cb_cString_StrCopy(self,MyPtr1))) {
      return NULL;
    }
    i = 0;
    MyPtr1 = (const cb_String)(self->m_Buffer);
  }
  self->m_Pos = i;
  i = cb_InChar(MyPtr1,iDelim);
  if (i<0) {
    i = self->m_Len;
    i -= self->m_Pos;
    self->m_Pos = self->m_Len;
  }
  else {
    i++;
    self->m_Pos += i;
    i--;
  }
  if (dst==(cb_INVALID)-2) {
    cb_ASC2(MyPtr1,i) = '\0';
    return MyPtr1;
  }
  return cb_NewStr(MyPtr1,dst,i);
}


const char* cb_cString_StrToken (cb_cString* T,const cb_String sDelim,const cb_String Str1,void* dst)
{
  register cb_cString* self; self = T;
  register cb_Integer i;
  register const cb_PString MyPtr1; MyPtr1 = Str1;
  register cb_Integer n;
  if (sDelim==NULL) {
    return NULL;
  }
  if (!(MyPtr1)) {
    i = self->m_Pos;
    if ((cb_UInteger)i>=(cb_UInteger)(self->m_Len)) {
      return NULL;
    }
    MyPtr1 = (const cb_String)(self->m_Buffer);
    MyPtr1 += i;
  }
  n = cb_StrLen(sDelim);
  do {
    if (MyPtr1[0]==0) {
      return NULL;
    }
    if (0!=cb_MemComp(MyPtr1,sDelim,n)) {
      break;
    }
    MyPtr1 += n;
    i += n;
  } while(1);
  if (Str1) {
    if (!(cb_cString_StrCopy(self,MyPtr1))) {
      return NULL;
    }
    i = 0;
    MyPtr1 = (const cb_String)(self->m_Buffer);
  }
  self->m_Pos = i;
  i = (cb_Integer)cb_StrStr(MyPtr1,sDelim);
  if (i==0) {
    i = self->m_Len;
    i -= self->m_Pos;
    self->m_Pos = self->m_Len;
  }
  else {
    i -= (cb_Integer)MyPtr1;
    self->m_Pos += i + n;
  }
  if (dst==(cb_INVALID)-2) {
    cb_ASC2(MyPtr1,i) = '\0';
    return MyPtr1;
  }
  return cb_NewStr(MyPtr1,dst,i);
}


cb_Integer cb_cString_Backspace (cb_cString* T,cb_Integer Spaces)
{
  cb_cString* self; self = T;
  if (Spaces>self->m_Len) {
    Spaces = self->m_Len;
  }
  if (Spaces>0) {
    self->m_Len = self->m_Len - Spaces;
    *(short*)(self->m_Buffer + self->m_Len) = '\0';
  }
  return Spaces;
}


void cb_cString_Delete (cb_cString* T,cb_Integer Length,cb_Integer iPos)
{
  cb_cString* self; self = T;
  cb_Integer iLen; iLen = Length;
  if (iLen<=0) {
    return;
  }
  cb_Integer i; i = iPos;
  if ((cb_UInteger)i>=(cb_UInteger)(self->m_Len)) {
    return;
  }
  iLen += i;
  if ((cb_UInteger)iLen>(cb_UInteger)(self->m_Len)) {
    iLen = self->m_Len;
  }
  self->m_Len -= iLen;
  if (self->m_Len>0) {
    cb_MemCopy(self->m_Buffer + i,self->m_Buffer + iLen,self->m_Len);
  }
  self->m_Len += i;
  cb_LowShort(self->m_Buffer[self->m_Len]) = '\0';
  if (self->m_Pos>i) {
    iLen -= i;
    self->m_Pos -= iLen;
  }
}


char* cb_cString_Get (cb_cString* T,void* dst,cb_Integer iLen,void* iRet,cb_Integer iPos,cb_Boolean bPeek)
{
  cb_cString* self; self = T;
  register char* MyPtr1; MyPtr1 = (char*)dst;
  register cb_Integer i; i = iLen;
  register cb_Integer n; n = iPos;
  if (n<0) {
    n = self->m_Pos;
  }
  if (i<=0 || i + n>self->m_Len) {
    i = self->m_Len - n;
    if (i<=0) {
      MyPtr1 = cb_NewStr(NULL,MyPtr1,0);
      if (!MyPtr1) {
        goto Error0000;
      }
      i = 0;
      goto Exit0000;
    }
  }
  MyPtr1 = cb_Mid(self->m_Buffer,n,i,MyPtr1);
  if (MyPtr1) {
    if (!bPeek) {
      if (iPos>=0) {
        cb_cString_DeleteChars(self,i);
      }
      else {
        self->m_Pos += i;
      }
    }
Exit0000: ;
    if (iRet) {
      *(cb_Integer*)iRet = i;
    }
  }
Error0000: ;
  return MyPtr1;
}


char* cb_cString_Peek (cb_cString* T,void* dst,cb_Integer iLen,void* iRet,cb_Integer iPos)
{
  return cb_cString_Get(T,dst,iLen,iRet,iPos,TRUE);
}


char* cb_cString_GetLine (cb_cString* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax,cb_Integer bPeek)
{
  cb_cString* self; self = T;
  register cb_Integer lngLineEnd; lngLineEnd = iPos;
  if (lngLineEnd<0) {
    lngLineEnd = self->m_Pos;
  }
  register char* MyPtr1;
  cb_Integer i;
  if (lngLineEnd>=self->m_Len) {
Exit0000: ;
    MyPtr1 = cb_NewStr(NULL,dst,0);
    lngLineEnd = 0;
  }
  else {
    i = lngLineEnd;
    lngLineEnd += (cb_Integer)(self->m_Buffer);
    if (cb_ASC1(lngLineEnd)=='\n') {
      if (self->m_LastChar=='\r') {
        lngLineEnd++;
        if (iPos<0) {
          i++;
        }
      }
    }
    MyPtr1 = (char*)lngLineEnd;
    for (;;lngLineEnd++) {
      if (cb_ASC1(lngLineEnd)=='\r' || cb_ASC1(lngLineEnd)=='\n') {
        break;
      }
      if (cb_ASC1(lngLineEnd)=='\0') {
        if ((lngLineEnd - (cb_Integer)(self->m_Buffer))>=self->m_Len) {
          if (bPeek<0) {
            goto Exit0000;
          }
          break;
        }
      }
    }
    lngLineEnd -= (cb_Integer)MyPtr1;
    if ((cb_UInteger)(lngLineEnd+2)>=(cb_UInteger)iMax) {
      lngLineEnd = iMax;
      lngLineEnd -= 2+1;
      if (lngLineEnd<0) {
        goto Exit0000;
      }
    }
    MyPtr1 = cb_NewStr(MyPtr1,dst,lngLineEnd+2);
    if (MyPtr1==NULL) {
      goto Error0000;
    }
    self->m_LastChar = cb_ASC2(MyPtr1,lngLineEnd);
    if (self->m_LastChar=='\r') {
      lngLineEnd++;
    }
    if (cb_ASC2(MyPtr1,lngLineEnd)=='\n') {
      lngLineEnd++;
      self->m_LastChar = '\n';
    }
    if (bPeek<=0) {
      if (iPos>=0) {
        cb_cString_DeleteChars(self,lngLineEnd,i);
      }
      else {
        self->m_Pos = i + lngLineEnd;
      }
    }
    MyPtr1[lngLineEnd] = '\0';
  }
  if (iRet) {
    *(cb_Integer*)iRet = lngLineEnd;
  }
Error0000: ;
  return MyPtr1;
}


char* cb_cString_PeekLine (cb_cString* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax)
{
  return cb_cString_GetLine(T,dst,iRet,iPos,iMax,TRUE);
}


char* cb_cString_ReadLine (cb_cString* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax)
{
  return cb_cString_GetLine(T,dst,iRet,iPos,iMax,-1);
}


wchar_t* cb_cString_GetLineW (cb_cString* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax,cb_Integer bPeek)
{
  return NULL;
}


wchar_t* cb_cString_PeekLineW (cb_cString* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax)
{
  return cb_cString_GetLineW(T,dst,iRet,iPos,iMax,TRUE);
}


wchar_t* cb_cString_ReadLineW (cb_cString* T,void* dst,void* iRet,cb_Integer iPos,cb_Integer iMax)
{
  return cb_cString_GetLineW(T,dst,iRet,iPos,iMax,-1);
}


cb_Integer cb_cString_HasLine (cb_cString* self,cb_Integer iPos)
{
  cb_Integer i; i = iPos;
  if (i<0) {
    i = self->m_Pos;
  }
  if (i<self->m_Len) {
    return cb_InChars(self->m_Buffer + i,"\r\n")+1;
  }
  return 0;
}


cb_Integer cb_cString_EOS (cb_cString* self)
{
  return cb_CBOOL((cb_UInteger)(self->m_Pos)>=(cb_UInteger)(self->m_Len));
}


void cb_cString_Rewind (cb_cString* self)
{
  self->m_Pos = 0;
}


void* cb_cString_GetTag (cb_cString* self)
{
  return self->UserData;
}


void* cb_cString_SetTag (cb_cString* self,void* n)
{
  void* cb_retVar_;
  cb_retVar_ = self->UserData;
  self->UserData = n;
  return cb_retVar_;
}


cb_Integer cb_cString_WriteFile (cb_cString* self,cb_File* FileNum)
{
  cb_Integer cb_retVar_;
  return cb_FPut(FileNum,self->m_Buffer,self->m_Len);
}


cb_Integer cb_cString_WriteFileName (cb_cString* self,const cb_String sfName)
{
  cb_Integer cb_retVar_;
  cb_File* h;
  h = cb_FOpen(sfName,"wbs");
  if (h==NULL) {
    cb_retVar_ = -1;
  }
  else {
    cb_retVar_ = cb_cString_WriteFile(self,h);
    cb_FileClose(h);
  }
  return cb_retVar_;
}


cb_cString* cb_cString_ReadFile (cb_cString* T,cb_File* FileNum,cb_Integer iPos)
{
  cb_cString* self; self = T;
  cb_Integer i;
  cb_Integer n; n = iPos;
  if (n<0) {
    n = self->m_Pos;
  }
  cb_Integer d;
  i = cb_Lof(FileNum);
  if (cb_cString_SetBufferSize(self,i + n,FALSE)) {
    if (cb_FGet(FileNum,self->m_Buffer + n,&d,i)) {
      i = d;
      if (iPos<0) {
        self->m_Pos += i;
      }
      i += n;
      *(short*)(self->m_Buffer + i) = '\0';
      self->m_Len = i;
      return self;
    }
  }
  return NULL;
}


cb_cString* cb_cString_ReadFileName (cb_cString* self,const cb_String sfName,cb_Integer iPos)
{
  cb_cString* cb_retVar_;
  cb_File* h;
  h = cb_FOpen(sfName,"rbs");
  if (h==NULL) {
    cb_retVar_ = NULL;
  }
  else {
    cb_retVar_ = cb_cString_ReadFile(self,h,iPos);
    cb_FileClose(h);
  }
  return cb_retVar_;
}


cb_Integer cb_cString_Seek (cb_cString* T,cb_Integer iPos,cb_Integer iOrg)
{
  cb_cString* self; self = T;
  register cb_Integer i; i = iPos;
  if (iOrg==SEEK_CUR) {
    i += self->m_Pos;
  }
  else if (iOrg==SEEK_END) {
    i += self->m_Len;
  }
  if (i>=0) {
    self->m_Pos = i;
  }
  else {
    i = -1;
  }
  return i;
}


cb_Integer cb_cString_Tell (cb_cString* self)
{
  return self->m_Pos;
}


char* cb_cString_Read (cb_cString* T,cb_Integer* iRet,void* dst,cb_Integer iNum)
{
  cb_cString* self; self = T;
  cb_Integer i;
  BYTE* s;
  i = self->m_Len;
  i -= self->m_Pos;
  s = self->m_Buffer;
  if (i<=0) {
    i = 0;
  }
  else {
    s += self->m_Pos;
    if ((cb_UInteger)i>(cb_UInteger)iNum) {
      i = iNum;
    }
  }
  dst = cb_NewStr(s,dst,i);
  if (dst!=NULL) {
    self->m_Pos += i;
    if (iRet) {
      cb_LowInt(iRet[0]) = i;
    }
  }
  return (char*)dst;
}


cb_cString* cb_cString_Write (cb_cString* self,const void* Str1,cb_Integer iLen)
{
  if ((self->flag1_ & cb_cString_APPEND_bit_)!=0) {
    if (self->m_Pos<self->m_Len) {
      self->m_Pos = self->m_Len;
    }
  }
  return cb_cString_PutAt(self,Str1,-1,iLen);
}
/* END MODULE */
/* MODULE::cb_cFile */
#define cb_cFile_DEFAULT_ADDLENGTH 2*0x400
/* MODULE::cb_cFile1 */
cb_cFile* cb_cFile_ArrayFiles_;
cb_Integer cb_cFile_MaxFiles_;
cb_Integer cb_cFile_FilesNum_;
void* cb_cFile_StdIn;
void* cb_cFile_StdErr;
void* cb_cFile_StdOut;
/* END MODULE */
/* MODULE::cb_cFile2 */


static cb_Integer cb_cFile_Close_ (cb_cFile*);

static cb_Integer cb_cFile_Close_ (cb_cFile* T)
{
  register cb_cFile* self; self = T;
  if (self->m_hFile!=NULL) {
    if (!(self->flag1_ & 2)) {
      if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
        cb_MemFreeM(self->m_hFile);
      }
      else {
        if ((self->flag1_ & cb_cFile_SOCKET_BIT)!=0) {
        }
        else if ((self->flag1_ & cb_cFile_FTP_BIT)!=0) {
        }
        else if ((self->flag1_ & cb_cFile_STD_BITS_)!=0) {
        }
        else {
          CloseHandle(self->m_hFile);
          if ((self->flag1_ & cb_cFile_TEMP_BIT)!=0) {
            DeleteFile(self->m_sFile);
          }
        }
        (self->m_sFile)[0] = '\0';
      }
    }
    self->m_hFile = NULL;
  }
  self->flag1_ = FALSE;
  return 0;
}


cb_Integer cb_cFile_Close (void* T)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  if ((self->flag1_ & cb_cFile_STD_BITS_)!=0) {
    _close((cb_Integer)(self->m_hFile));
  }
  return cb_cFile_Close_(self);
}


cb_Integer cb_cFile_CloseAll (void)
{
  register cb_cFile* self; self = cb_cFile_ArrayFiles_;
  register cb_Integer i;
  for (i=0;i<cb_cFile_FilesNum_;i++) {
    cb_cFile_Close_(self);
    self++;
  }
  cb_cFile_FilesNum_ = 0;
  return i;
}


void cb_cFile_Terminate (void)
{
  cb_cFile_CloseAll();
  cb_cFile_StdIn = NULL;
  cb_cFile_StdErr = NULL;
  cb_cFile_StdOut = NULL;
  cb_cFile_MaxFiles_ = 0;
  if (cb_cFile_ArrayFiles_) { cb_MemFreeM(cb_cFile_ArrayFiles_); cb_cFile_ArrayFiles_ = NULL; }
}
#if !defined(USER_LIBRARY) && !defined(USE_CFILE)


void cb_cFile_OnEnd_ (void)
{
  cb_cFile_Terminate();
}
#endif
/* END MODULE */
/* MODULE::cb_cFile3 */
#define cb_cFile_REDIM_SIZE_ 50


cb_cFile* cb_cFile_FreeFile_ (void)
{
  register cb_cFile* self; self = cb_cFile_ArrayFiles_;
  register cb_Integer i;
  for (i=0;i<cb_cFile_FilesNum_;i++) {
    if (self->m_hFile==NULL) {
      goto Found0000;
    }
    self++;
  }
  i++;
  cb_cFile_FilesNum_ = i;
  if (i>cb_cFile_MaxFiles_) {
    cb_cFile_MaxFiles_ += cb_cFile_REDIM_SIZE_;
    self = cb_cFile_ArrayFiles_;
    self = (struct cb_s_cb_cFile_*)cb_ReDim(cb_cFile_MaxFiles_ * sizeof(struct cb_s_cb_cFile_), self, 1);
    if (!self) {
      cb_cFile_MaxFiles_ -= cb_cFile_REDIM_SIZE_;
      goto Exit0000;
    }
    cb_cFile_ArrayFiles_ = self;
    i--;
    self += i;
  }
Found0000: ;
  cb_CLEAR1(*self);
Exit0000: ;
  return self;
}


void cb_cFile_Initialize (void)
{
  if (!cb_cFile_StdIn) {
    cb_cFile_StdIn = cb_cFile_FreeFile_();
    ((cb_cFile*)cb_cFile_StdIn)->flag1_ = cb_cFile_STDIN_BIT_;
    ((cb_cFile*)cb_cFile_StdIn)->m_hFile = stdin;
    cb_cFile_StdIn = cb_cFile_PtrOf_(cb_cFile_StdIn);
  }
  if (!cb_cFile_StdErr) {
    cb_cFile_StdErr = cb_cFile_FreeFile_();
    ((cb_cFile*)cb_cFile_StdErr)->flag1_ = cb_cFile_STDERR_BIT_;
    ((cb_cFile*)cb_cFile_StdErr)->m_hFile = stderr;
    cb_cFile_StdErr = cb_cFile_PtrOf_(cb_cFile_StdErr);
  }
  if (!cb_cFile_StdOut) {
    cb_cFile_StdOut = cb_cFile_FreeFile_();
    ((cb_cFile*)cb_cFile_StdOut)->flag1_ = cb_cFile_STDOUT_BIT_;
    ((cb_cFile*)cb_cFile_StdOut)->m_hFile = stdout;
    cb_cFile_StdOut = cb_cFile_PtrOf_(cb_cFile_StdOut);
  }
}
/* END MODULE */


static cb_Integer cb_cFile_Parse_ (const cb_String);

static cb_Integer cb_cFile_Parse_ (const cb_String sMode)
{
  register cb_Integer i; i = 0;
  register const cb_PString MyPtr1; MyPtr1 = sMode;
  if (MyPtr1[0]=='w') {
    i |= cb_cFile_WRITE_BIT | cb_cFile_NEW_BIT;
  }
  else if (MyPtr1[0]=='m') {
    i |= cb_cFile_MEM_BIT | cb_cFile_RDWR_BIT;
  }
  else if (MyPtr1[0]=='a') {
    i |= cb_cFile_WRITE_BIT | cb_cFile_APPEND_BIT;
  }
  else {
    i |= cb_cFile_READ_BIT;
  }
  for (;MyPtr1[0]!=0;MyPtr1++) {
    if (MyPtr1[0]=='b') {
      i |= cb_cFile_BINARY_BIT;
    }
    else if (MyPtr1[0]=='a') {
      i |= cb_cFile_APPEND_BIT | cb_cFile_WRITE_BIT;
    }
    else if (MyPtr1[0]=='+') {
      i |= cb_cFile_READ_BIT | cb_cFile_WRITE_BIT;
    }
    else if (MyPtr1[0]=='p') {
      i &=  ~(cb_cFile_NEW_BIT);
    }
    else if (MyPtr1[0]=='s') {
      i |= cb_cFile_SEQUENTIAL_BIT;
    }
    else if (MyPtr1[0]=='x') {
      i |= cb_cFile_EXCLUSIVE_BIT;
    }
/* todo [S]equential(no random)  [Z]ero(truncate exisiting) [P]reserve(no truncate) [N]ew(fail if exist) */
  }
  if (i) {
    if ((i & cb_cFile_SEQUENTIAL_BIT)==FALSE) {
      i |= cb_cFile_RANDOM_BIT;
    }
    else if ((i & (cb_cFile_BINARY_BIT | cb_cFile_MEM_BIT | cb_cFile_RANDOM_BIT | cb_cFile_TEMP_BIT | cb_cFile_TEXT_BIT))==0) {
      i |= cb_cFile_TEXT_BIT;
    }
  }
  return i;
}


void* cb_cFile_TempName (void)
{
  register cb_cFile* self; self = cb_cFile_FreeFile_();
  if (!self) {
    return NULL;
  }
  cb_TempFileName(NULL,NULL,NULL,self->m_sFile);
  self->flag1_ = cb_cFile_TEMP_BIT | cb_cFile_READ_BIT | cb_cFile_WRITE_BIT;
  return cb_cFile_PtrOf_(self);
}


void* cb_cFile_Open (const cb_String sFile,cb_Integer iMode,cb_Integer iRecLen)
{
  register cb_cFile* self; self = cb_cFile_FreeFile_();
  if (!self) {
    return NULL;
  }
  register cb_Integer i; i = cb_IIF2(sFile==NULL,cb_cFile_MEM_BIT,cb_IIF2(sFile[0]=='\0',cb_cFile_TEMP_BIT,0));
  register cb_Integer j;
  register cb_Integer n;
  register cb_Integer o;
  i |= iMode;
  if (i<=0) {
    i = cb_cFile_READ_BIT | cb_cFile_BINARY_BIT;
  }
  if ((i & cb_cFile_MEM_BIT)!=0) {
    self->flag1_ = i;
  }
  else {
    if ((i & cb_cFile_TEMP_BIT)!=0) {
      cb_TempFileName(NULL,NULL,NULL,self->m_sFile);
      n = FILE_FLAG_DELETE_ON_CLOSE;
    }
    else {
      cb_StrMove(self->m_sFile, sFile);
      n = 0;
    }
    self->flag1_ = i;
    j = 0;
    if ((i & (cb_cFile_READ_BIT | cb_cFile_APPEND_BIT | cb_cFile_TEMP_BIT | cb_cFile_WRITE_BIT))==cb_cFile_READ_BIT) {
      j = GENERIC_READ;
      o = OPEN_EXISTING;
    }
    if ((i & (cb_cFile_WRITE_BIT | cb_cFile_APPEND_BIT | cb_cFile_TEMP_BIT))!=0) {
      j |= GENERIC_WRITE;
      if ((i & cb_cFile_NEW_BIT)!=0) {
        o = CREATE_ALWAYS;
      }
      else if (!(i & cb_cFile_EXCLUSIVE_BIT)) {
        o = OPEN_ALWAYS;
      }
    }
    if (i & cb_cFile_EXCLUSIVE_BIT) {
      o = OPEN_EXISTING;
    }
    if ((i & cb_cFile_RANDOM_BIT)!=0) {
      n |= FILE_FLAG_RANDOM_ACCESS;
    }
    self->m_hFile = CreateFile(sFile,j,0,NULL,o,n,NULL);
  }
  self->m_RecLen = iRecLen;
  return cb_cFile_PtrOf_(self);
}


void* cb_cFile_FOpen (const cb_String sFile,const cb_String sMode)
{
  register cb_Integer i; i = cb_IIF2(sMode,cb_cFile_Parse_(sMode),0);
  return cb_cFile_Open(sFile,i,0);
}


void* cb_cFile_DOpen (void* f,cb_Integer iMode,cb_Integer iRecLen)
{
/*
  todo
  Register Me As . = ._FreeFile_() : If Not Me Then Exit Function
  Register i% = IIF(sFile=NULL,._MEM_BIT/- OR ._NEW_BIT OR ._READ_BIT OR ._WRITE_BIT-/,IIF(sFile[0]=NUL,._TEMP_BIT,0)), j%, n%, o%
  i OR = iMode : If i <= 0 Then i = ._READ_BIT OR ._BINARY_BIT
  If (i BAND ._MEM_BIT) <> 0 Then
    Me.flag1_ = i
    'm_hFile = NULL
  Else
    If /-Not sFile-/(i BAND ._TEMP_BIT) <> 0 Then
      'If Not i Then Exit = Me
      'Me = ._AddressOf_(Me) : OR i, ._TEMP_BIT : Me.flag1_ = i
      TempFileName(NULL,NULL,NULL,m_sFile)
      n = FILE_FLAG_DELETE_ON_CLOSE
    Else
      m_sFile$ = sFile : n = 0
    End If
    Me.flag1_ = i
    j = 0
    If (i BAND (._READ_BIT BOR ._APPEND_BIT BOR ._TEMP_BIT BOR ._WRITE_BIT)) = ._READ_BIT Then j = GENERIC_READ : o = OPEN_EXISTING
    If (i BAND (._WRITE_BIT BOR ._APPEND_BIT BOR ._TEMP_BIT)) <> 0 Then _
      j OR = GENERIC_WRITE : _
      If (i BAND ._NEW_BIT) <> 0 Then o = CREATE_ALWAYS ElseIf False(i BAND ._EXCLUSIVE_BIT) Then o = OPEN_ALWAYS
    If (i BAND ._EXCLUSIVE_BIT) Then o = OPEN_EXISTING
    If (i BAND ._RANDOM_BIT) <> 0 Then n OR = FILE_FLAG_RANDOM_ACCESS
    m_hFile = CreateFile(sFile,j,0,NULL,o,n,NULL)
  End If
  m_RecLen = iRecLen
  Exit = ._PtrOf_(Me)
*/
  return NULL;
}


void* cb_cFile_FDOpen (void* f,const cb_String sMode)
{
  register cb_Integer i; i = cb_IIF2(sMode,cb_cFile_Parse_(sMode),0);
  return cb_cFile_DOpen(f,i,0);
}


void* cb_cFile_PipeOpen (const cb_String sFile,cb_Integer iMode)
{
/*
  todo
  Register Me As . = ._FreeFile_() : If Not Me Then Exit Function
  Register i% = IIF(sFile=NULL,._MEM_BIT/- OR ._NEW_BIT OR ._READ_BIT OR ._WRITE_BIT-/,IIF(sFile[0]=NUL,._TEMP_BIT,0)), j%, n%, o%
  i OR = iMode : If i <= 0 Then i = ._READ_BIT OR ._BINARY_BIT
  If (i BAND ._MEM_BIT) <> 0 Then
    Me.flag1_ = i
    'm_hFile = NULL
  Else
    If /-Not sFile-/(i BAND ._TEMP_BIT) <> 0 Then
      'If Not i Then Exit = Me
      'Me = ._AddressOf_(Me) : OR i, ._TEMP_BIT : Me.flag1_ = i
      TempFileName(NULL,NULL,NULL,m_sFile)
      n = FILE_FLAG_DELETE_ON_CLOSE
    Else
      m_sFile$ = sFile : n = 0
    End If
    Me.flag1_ = i
    j = 0
    If (i BAND (._READ_BIT BOR ._APPEND_BIT BOR ._TEMP_BIT BOR ._WRITE_BIT)) = ._READ_BIT Then j = GENERIC_READ : o = OPEN_EXISTING
    If (i BAND (._WRITE_BIT BOR ._APPEND_BIT BOR ._TEMP_BIT)) <> 0 Then _
      j OR = GENERIC_WRITE : _
      If (i BAND ._NEW_BIT) <> 0 Then o = CREATE_ALWAYS ElseIf False(i BAND ._EXCLUSIVE_BIT) Then o = OPEN_ALWAYS
    If (i BAND ._EXCLUSIVE_BIT) Then o = OPEN_EXISTING
    If (i BAND ._RANDOM_BIT) <> 0 Then n OR = FILE_FLAG_RANDOM_ACCESS
    m_hFile = CreateFile(sFile,j,0,NULL,o,n,NULL)
  End If
  Exit = ._PtrOf_(Me)
*/
  return NULL;
}


void* cb_cFile_POpen (const cb_String sFile,const cb_String sMode)
{
  register cb_Integer i; i = cb_IIF2(sMode,cb_cFile_Parse_(sMode),0);
  return cb_cFile_PipeOpen(sFile,i);
}


void* cb_cFile_MemFile (void* ptr1,cb_Integer iSize,cb_Integer iMode)
{
  register cb_cFile* self; self = cb_cFile_FreeFile_();
  if (!self) {
    return NULL;
  }
  register cb_Integer i; i = (cb_Integer)ptr1;
  if (i) {
    self->m_hFile = (void*)i;
    i = cb_MemSizeM((void*)i);
    if (i<0) {
      self->m_hFile = NULL;
      return NULL;
    }
    self->m_Size = i;
    if ((cb_UInteger)i>(cb_UInteger)iSize) {
      i = iSize;
    }
    self->m_Len = i;
  }
  i = iMode;
  i |= cb_cFile_MEM_BIT;
  self->flag1_ = i;
  return cb_cFile_PtrOf_(self);
}


void* cb_cFile_Release (void* T,cb_Integer* iLen)
{
  void* cb_retVar_;
  cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return NULL;
  }
  self = cb_cFile_AddressOf_(self);
  cb_retVar_ = self->m_hFile;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    *(short*)(((cb_String)cb_retVar_) + self->m_Len) = '\0';
  }
  if (iLen) {
    iLen[0] = self->m_Len;
  }
  self->m_hFile = NULL;
  self->m_Len = 0;
  self->m_Size = 0;
  self->m_Pos = 0;
  self->flag1_ &= 1;
  return cb_retVar_;
}


void* cb_cFile_Attatch (void* T,void* p,cb_Integer iLen,cb_Integer flag)
{
  void* cb_retVar_;
  cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return NULL;
  }
  self = cb_cFile_AddressOf_(self);
  cb_Integer i; i = self->flag1_;
  cb_retVar_ = cb_cFile_Release(T,NULL);
  if (flag) {
    i |= 2;
  }
  self->flag1_ = i;
  if ((i & cb_cFile_MEM_BIT)!=0) {
    i = cb_MemSizeM(p);
    if (i>0) {
      self->m_Size = i;
    }
    if (iLen>i) {
      iLen = i;
    }
    if (iLen>0) {
      self->m_Len = iLen;
    }
    self->m_Pos = 0;
  }
  self->m_hFile = p;
  return cb_retVar_;
}


cb_Integer cb_cFile_Flush (void* T)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  if ((self->flag1_ & cb_cFile_MEM_BIT)==0) {
#ifndef cFile_USE_CONSOLE
    if ((self->flag1_ & cb_cFile_STD_BITS_)!=0) {
#ifdef USE_STREAM_FILE
      return fflush((FILE*)(self->m_hFile));
#else
      return _commit((cb_Integer)(self->m_hFile));
#endif
    }
#endif
    if (!(FlushFileBuffers(self->m_hFile))) {
      return -1;
    }
  }
  return 0;
}


cb_Integer cb_cFile_Attr (void* T)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return 0;
  }
  self = cb_cFile_AddressOf_(self);
/* todo */
  return -1;
}


cb_PString cb_cFile_FileName (void* T,void* sBuf)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return (cb_PString)cb_EMPTYSTR;
  }
  self = cb_cFile_AddressOf_(self);
  register void* s; s = sBuf;
  if (s==cb_INVALID || s==NULL) {
    return cb_NewStr(self->m_sFile,s);
  }
  return cb_StrCopy(s,self->m_sFile);
}


long long cb_cFile_GetPos (void* T)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  LARGE_INTEGER i;
  self->m_Error = 0;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    return (DWORD)self->m_Pos;
  }
  if ((self->flag1_ & cb_cFile_STD_BITS_)==0) {
    i.QuadPart = 0;
    if (SetFilePointerEx(self->m_hFile,i,&i,FILE_CURRENT)) {
      return i.QuadPart;
    }
Error0000: ;
    self->m_Error = -1;
  }
  return -1;
}


long long cb_cFile_SetPos (void* T,long long iPos,cb_Integer iMode)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  LARGE_INTEGER i;
  self->m_Error = 0;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    if (iMode) {
      if (iMode==1) {
        iPos += self->m_Pos;
      }
      else {
        iPos += self->m_Len;
      }
    }
    if (iPos>=0) {
      return (self->m_Pos = (cb_Integer)iPos);
    }
    goto Error0000;
  }
  if ((self->flag1_ & cb_cFile_STD_BITS_)==0) {
    i.QuadPart = iPos;
    if (SetFilePointerEx(self->m_hFile,i,NULL,iMode)) {
      return i.QuadPart;
    }
Error0000: ;
    self->m_Error = -1;
  }
  return -1;
}


long long cb_cFile_ResetPos (void* T)
{
  return cb_cFile_SetPos(T,0,0);
}


cb_Integer cb_cFile_GetEOF (void* T)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  LARGE_INTEGER i1;
  LARGE_INTEGER i2;
  self->m_Error = 0;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    return cb_CBOOL(self->m_Pos==self->m_Len);
  }
  if ((self->flag1_ & cb_cFile_STD_BITS_)==0) {
    i1.QuadPart = 0;
    if (SetFilePointerEx(self->m_hFile,i1,&i1,FILE_CURRENT)!=0) {
      i2.QuadPart = 0;
      if (SetFilePointerEx(self->m_hFile,i2,&i2,FILE_END)!=0) {
        if (i1.QuadPart==i2.QuadPart) {
          return TRUE;
        }
        SetFilePointerEx(self->m_hFile,i1,NULL,FILE_CURRENT);
        return 0;
      }
    }
  }
  self->m_Error = -1;
  return 0;
}


long long cb_cFile_SetEOF (void* T,long long iNum)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  register cb_Integer i;
  register BYTE* p;
  LARGE_INTEGER iPos;
  self->m_Error = 0;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    i = iNum;
    if (i<0) {
      i = self->m_Pos;
    }
    i = self->m_Pos;
    if (i<0) {
      goto Error0000;
    }
    if (i>self->m_Size) {
      i += (cb_cFile_DEFAULT_ADDLENGTH<<1)-1;
      i &=  ~((cb_cFile_DEFAULT_ADDLENGTH>>1)-1);
      if (i<=0) {
        goto Error0000;
      }
      p = (BYTE*)self->m_hFile;
      p = (BYTE*)cb_ReDim(i * sizeof(BYTE), p, 1);
      if (!p) {
        goto Error0000;
      }
      self->m_hFile = p;
      self->m_Size = i;
      i = self->m_Pos;
    }
    self->m_Len = i;
    return i;
  }
  if ((self->flag1_ & cb_cFile_STD_BITS_)==0) {
    if (iNum==-1) {
      iPos.QuadPart = 0;
      i = FILE_END;
    }
    else {
      iPos.QuadPart = iNum;
      i = FILE_BEGIN;
    }
    if (SetFilePointerEx(self->m_hFile,iPos,&iPos,i)!=0) {
      if (SetEndOfFile(self->m_hFile)!=0) {
        return iPos.QuadPart;
      }
    }
Error0000: ;
    self->m_Error = -1;
  }
  return -1;
}


long long cb_cFile_SeekEOF (void* T)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  LARGE_INTEGER iPos;
  self->m_Error = 0;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    return (self->m_Pos = self->m_Len);
  }
  if ((self->flag1_ & cb_cFile_STD_BITS_)==0) {
    if (SetFilePointerEx(self->m_hFile,iPos,&iPos,FILE_END)!=0) {
      return iPos.QuadPart;
    }
    self->m_Error = -1;
  }
  return -1;
}


long long cb_cFile_GetSize (void* T,long long* iPos)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  LARGE_INTEGER iPos1;
  LARGE_INTEGER iPos2;
  self->m_Error = 0;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    if (iPos) {
      iPos[0] = self->m_Pos;
    }
    return self->m_Len;
  }
  if ((self->flag1_ & cb_cFile_STD_BITS_)==0) {
    iPos1.QuadPart = 0;
    if (SetFilePointerEx(self->m_hFile,iPos1,&iPos1,FILE_CURRENT)!=0) {
      iPos2.QuadPart = 0;
      if (SetFilePointerEx(self->m_hFile,iPos2,&iPos2,FILE_END)!=0) {
        if (iPos1.QuadPart!=iPos2.QuadPart) {
          if (SetFilePointerEx(self->m_hFile,iPos1,NULL,FILE_CURRENT)==0) {
            iPos1.QuadPart = iPos2.QuadPart;
          }
        }
        if (iPos) {
          iPos[0] = iPos1.QuadPart;
        }
        return iPos2.QuadPart;
      }
    }
    self->m_Error = -1;
  }
  return -1;
}


long long cb_cFile_SetSize (void* T,long long iSize)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  register long long i; i = iSize;
  register BYTE* p;
  self->m_Error = 0;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    if (i<0) {
      goto Error0000;
    }
    if (i>self->m_Size) {
      i += (cb_cFile_DEFAULT_ADDLENGTH<<1)-1;
      i &=  ~((cb_cFile_DEFAULT_ADDLENGTH>>1)-1);
      if (i<=0) {
        goto Error0000;
      }
      p = (BYTE*)cb_ReDim(i * sizeof(BYTE), p, 1);
      if (!p) {
        goto Error0000;
      }
      self->m_hFile = p;
      self->m_Size = i;
      i = iSize;
    }
    self->m_Len = i;
    if (self->m_Pos>i) {
      self->m_Pos = i;
    }
    return i;
  }
  LARGE_INTEGER i1;
  if ((self->flag1_ & cb_cFile_STD_BITS_)==0) {
    i1.QuadPart = i;
    if (SetFilePointerEx(self->m_hFile,i1,NULL,FILE_BEGIN)!=0) {
      if (SetEndOfFile(self->m_hFile)!=0) {
        return i;
      }
    }
Error0000: ;
    self->m_Error = -1;
  }
  return -1;
}


void* cb_cFile_Read (void* T,void* buf,cb_Integer iLen,void* iRead)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    goto Error0000;
  }
  self = cb_cFile_AddressOf_(self);
  if (!self->m_hFile) {
    goto Error0000;
  }
  register cb_Integer i; i = iLen;
  register void* p;
  long long i1;
  long long i2;
  if (i<0) {
    i1 = cb_cFile_GetSize(self,&i2);
    if (i1<0) {
      goto Error0000;
    }
    i1 -= i2;
    if ((unsigned long long)i1>(unsigned long long)cb_MAX_INTEGER32) {
      goto Error0000;
    }
    i = (cb_Integer)i1;
    iLen = i;
  }
  p = buf;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    i = self->m_Len;
    i -= self->m_Pos;
    if (i>iLen) {
      i = iLen;
    }
    if (i<0) {
      goto Error0000;
    }
    if (p==NULL || p==cb_INVALID) {
      p = cb_NewStr(NULL,p,i);
      if (!p) {
        goto Error000;
      }
    }
    if (i>0) {
      cb_MemCopy(p,((BYTE*)self->m_hFile) + self->m_Pos,i);
      self->m_Pos += i;
    }
    if (iRead) {
      *(cb_Integer*)iRead = i;
    }
  }
  else {
    if (p==NULL || p==cb_INVALID) {
      p = cb_NewStr(NULL,p,i);
      if (!p) {
        goto Error000;
      }
    }
    if (ReadFile(self->m_hFile,p,i,(LPDWORD)iRead,NULL)==0) {
Error000: ;
      self->m_Error = -1;
Error0000: ;
      if (iRead) {
        *(cb_Integer*)iRead = -1;
      }
      return NULL;
    }
  }
  self->m_Error = 0;
  return p;
}


cb_Integer cb_cFile_FileRead (void* T,void* buf,cb_Integer iLen)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  long long i1;
  register long long i; i = cb_cFile_GetSize(self,&i1);
  DWORD i2;
  if (cb_cFile_Read(self,buf,iLen,&i2)) {
    if (i2==0) {
      if (i>0) {
        return i - i1;
      }
    }
    return i2;
  }
  return -1;
}


cb_Integer cb_cFile_Write (void* T,const void* buf,cb_Integer iLen)
{
  register cb_cFile* self; self = (cb_cFile*)T;
  if ((cb_Integer)self<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  self = cb_cFile_AddressOf_(self);
  register cb_Integer i; i = iLen;
  if (i<0) {
    goto Error0000;
  }
  register BYTE* p;
  DWORD dwWrite;
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    if ((self->flag1_ & cb_cFile_APPEND_BIT)!=0) {
      if (self->m_Pos<self->m_Len) {
        self->m_Pos = self->m_Len;
      }
    }
    i += self->m_Pos;
    if (i<=iLen) {
      goto Error0000;
    }
    p = (BYTE*)self->m_hFile;
    if (i>self->m_Size) {
      i += (cb_cFile_DEFAULT_ADDLENGTH<<1)-1;
      i &=  ~((cb_cFile_DEFAULT_ADDLENGTH>>1)-1);
      if (i<=0) {
        goto Error0000;
      }
      p = (BYTE*)cb_ReDim(i * sizeof(BYTE), p, 1);
      if (!p) {
        goto Error0000;
      }
      self->m_hFile = p;
      self->m_Size = i;
    }
    i = iLen;
    if (i>0) {
      cb_MemCopy(p + self->m_Pos,buf,i);
      self->m_Pos += i;
      if (self->m_Pos>self->m_Len) {
        self->m_Len = self->m_Pos;
      }
    }
  }
  else {
    if (WriteFile(self->m_hFile,buf,i,&dwWrite,NULL)==0) {
Error0000: ;
      self->m_Error = -1;
      return -1;
    }
    i = dwWrite;
  }
  self->m_Error = 0;
  return i;
}


void* cb_cFile_StrRead (void* T,void* buf,cb_Integer iLen,void* iRead,cb_Integer flag1)
{
  register cb_PString p1; p1 = (cb_String)buf;
  register cb_PString p2;
  register cb_Integer i; i = iLen;
  i--;
  iLen--;
  register cb_cFile* self; self = cb_cFile_AddressOf_(T);
  cb_Integer i1;
  cb_PString p3; p3 = NULL;
  LARGE_INTEGER iPos;
Loop0000: ;
  if (i>2048) {
    i = 2048;
  }
  p1 = (cb_PString)cb_cFile_Read(T,p1,i,&i1);
  i = i1;
  if (p1) {
    p2 = p1;
    if (p3==NULL) {
      p3 = p1;
    }
    do {
      if (i<=0) {
        i = i1;
        if (i<iLen) {
          iLen -= i;
          i = iLen;
          goto Loop0000;
        }
        break;
      }
      i--;
      if (p1[0]=='\r') {
        if (i>0 && p1[1]=='\n') {
          p1++;
          i--;
          if ((self->flag1_ & cb_cFile_TEXT_BIT)==0) {
            p2[0] = '\r';
            p2++;
          }
        }
        else if ((self->flag1_ & cb_cFile_TEXT_BIT)!=0) {
          p1[0] = '\n';
        }
      }
      p2[0] = p1[0];
      p2++;
      if (!flag1) {
        if (p1[0]=='\n' || p1[0]=='\r') {
          p2[0] = '\0';
          if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
            self->m_Pos -= i;
          }
          else {
            iPos.QuadPart = 0 - i;
            SetFilePointerEx(self->m_hFile,iPos,NULL,FILE_CURRENT);
          }
          p1++;
          break;
        }
      }
      p1++;
    } while(1);
    p2 = p3;
    p1 -= (cb_Integer)p2;
    i = (cb_Integer)p1;
    p1 = p2;
  }
  if (iRead) {
    *(cb_Integer*)iRead = i;
  }
  return p1;
}


cb_Integer cb_cFile_FRead (void* T,void* sBuf,cb_Integer iLen)
{
  cb_Integer i1;
  if (cb_cFile_StrRead(T,sBuf,iLen,&i1,TRUE)) {
    return i1;
  }
  return -1;
}


cb_Integer cb_cFile_GetS (void* T,void* sBuf,cb_Integer iLen)
{
  cb_Integer i1;
  if (cb_cFile_StrRead(T,sBuf,iLen,&i1,FALSE)) {
    return i1;
  }
  return -1;
}


cb_Integer cb_cFile_StrWrite (void* T,const void* buf,cb_Integer iLen)
{
  if ((cb_Integer)T<cb_cFile_FAKE_BASE_) {
    return -1;
  }
  register cb_PString p1; p1 = (cb_String)buf;
  register cb_PString p2; p2 = NULL;
  register cb_Integer i; i = iLen;
  if (i<0) {
    i = cb_StrLen(p1);
  }
  if ((cb_cFile_AddressOf_(T)->flag1_ & (cb_cFile_TEXT_BIT))==cb_cFile_TEXT_BIT) {
    p2 = cb_NewStr(p1,cb_INVALID,i<<1);
    if (!p2) {
      return -1;
    }
    buf = p2;
    for (;i>=1;i--) {
      if (p1[0]=='\r') {
        p1++;
        if (p1[0]=='\n') {
          i--;
          goto Cr0000;
        }
        p1--;
      }
      else if (p1[0]=='\n') {
Cr0000: ;
        p2[0] = '\r';
        p2++;
      }
      p2[0] = p1[0];
      p2++;
      p1++;
    }
    p1 = (cb_String)buf;
    i = (cb_Integer)p2;
    i -= (cb_Integer)p1;
  }
  i = cb_cFile_Write(T,p1,i);
  if (p2) {
    cb_MemFreeM(p1);
  }
  return i;
}


cb_Integer cb_cFile_PutC (void* T,cb_Integer c)
{
/* todo */
  return -1;
}


void cb_cFile_Clear (void* T)
{
  register cb_cFile* self; self = cb_cFile_AddressOf_(T);
  self->m_Error = 0;
}


cb_Integer cb_cFile_Error (void* T)
{
  register cb_cFile* self; self = cb_cFile_AddressOf_(T);
  return self->m_Error;
}


cb_Integer cb_cFile_Delete (void* T,cb_Integer iLen,long long iPos)
{
  register cb_cFile* self; self = cb_cFile_AddressOf_(T);
  register cb_Integer i; i = iLen;
  register cb_Integer j;
  if (iPos!=-1) {
    if (cb_cFile_Seek(self,iPos)<0) {
      return -1;
    }
  }
  j = self->m_Len - self->m_Pos;
  if (i>j) {
    i = j;
  }
  if (i<0) {
    return -1;
  }
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    cb_MemCopy(((BYTE*)self->m_hFile) + self->m_Pos,((BYTE*)self->m_hFile) + self->m_Pos + i,j - i);
    self->m_Len -= i;
  }
  else if ((self->flag1_ & cb_cFile_STD_BITS_)!=0) {
    return -1;
  }
  else {
/* todo */
  }
  self->m_Error = 0;
  return i;
}


cb_Integer cb_cFile_Insert (void* T,const void* buf,cb_Integer iLen,long long iPos)
{
  register cb_cFile* self; self = cb_cFile_AddressOf_(T);
  register cb_Integer i; i = iLen;
  if (i<0) {
    return -1;
  }
  register BYTE* p;
  if (iPos!=-1) {
    if (cb_cFile_Seek(self,iPos)<0) {
      return -1;
    }
  }
  if ((self->flag1_ & cb_cFile_MEM_BIT)!=0) {
    if (self->m_Pos>self->m_Len) {
      i += self->m_Pos;
    }
    else {
      i += self->m_Len;
    }
    if (i<iLen) {
      return -1;
    }
    if (i<self->m_Size) {
      i += (cb_cFile_DEFAULT_ADDLENGTH<<1)-1;
      i &=  ~((cb_cFile_DEFAULT_ADDLENGTH>>1)-1);
      if (i<=0) {
        goto Error0000;
      }
      p = (BYTE*)self->m_hFile;
      p = (BYTE*)cb_ReDim(i * sizeof(BYTE), p, 1);
      if (!p) {
Error0000: ;
        self->m_Error = -1;
        return -1;
      }
      self->m_hFile = p;
      i = iLen;
    }
    cb_MemMove(p + i + self->m_Pos,p + self->m_Pos,self->m_Len - self->m_Pos);
    cb_MemCopy(p + self->m_Pos,buf,i);
    if (self->m_Len<self->m_Pos) {
      self->m_Len = self->m_Pos;
    }
    self->m_Len += i;
    self->m_Pos += i;
  }
  else if ((self->flag1_ & cb_cFile_STD_BITS_)!=0) {
    return -1;
  }
  else {
/* todo */
  }
  self->m_Error = 0;
  return i;
}
/* END MODULE */
/* MODULE::cb_cTimer */
#define cb_cTimer_REDIM_FACTOR_ 0x40
static cb_cTimer** cb_cTimer_arr_;
static cb_Integer cb_cTimer_MaxHandles_;


static cb_cTimer* cb_DEFCALL cb_cTimer_Find_ (cb_Integer);

static cb_cTimer* cb_DEFCALL cb_cTimer_Find_ (cb_Integer id)
{
  cb_Integer i; i = cb_cTimer_MaxHandles_;
  cb_cTimer** p; p = &cb_cTimer_arr_[i];
  cb_cTimer* self;
  while(i>0) {
    i--;
    p--;
    self = p[0];
    if (id==self->idTimer_) {
      return self;
    }
  }
  return NULL;
}


static void CALLBACK cb_cTimer_TimerEvents_ (HWND,UINT,UINT,DWORD);

static void CALLBACK cb_cTimer_TimerEvents_ (HWND hWnd,UINT uMsg,UINT idEvent,DWORD dwTime)
{
  register cb_cTimer* self; self = cb_cTimer_Find_(idEvent);
  if (self->bEnabled>0) {
    if (self->OnTimer) {
      if (self->flag1_<4 || (self->flag1_ & 2)!=0) {
        self->flag1_ += 4;
        self->OnTimer(self);
        self->flag1_ -= 4;
      }
    }
  }
}


void cb_DEFCALL cb_cTimer_SetEnabled (cb_cTimer* T,cb_Integer bVal,cb_UInteger iVal)
{
  cb_cTimer* self; self = T;
  cb_Integer i;
  self->bEnabled = FALSE;
  if (bVal<=0 || iVal==0) {
    i = cb_MAX_INTEGER32;
  }
  else {
    if ((cb_Integer)iVal>0) {
      self->iInterval = iVal;
    }
    i = self->iInterval;
    self->bEnabled = TRUE;
  }
  self->idTimer_ = SetTimer(NULL,self->idTimer_,i,&cb_cTimer_TimerEvents_);
}


void cb_DEFCALL cb_cTimer_Kill (cb_cTimer* T)
{
  register cb_cTimer* self; self = T;
  if (self->idTimer_) {
    KillTimer(NULL,self->idTimer_);
    self->idTimer_ = 0;
  }
}


cb_Integer cb_DEFCALL cb_cTimer_Initialize_ (cb_cTimer* =NULL);

cb_Integer cb_DEFCALL cb_cTimer_Initialize_ (cb_cTimer* self)
{
  register cb_Integer i;
  for (i=0;i<cb_cTimer_MaxHandles_;i++) {
    if (cb_cTimer_arr_[i]==NULL) {
      goto Found0000;
    }
  }
  i++;
  cb_cTimer_arr_ = (cb_cTimer**)cb_ReDim((i + cb_cTimer_REDIM_FACTOR_) * sizeof(cb_cTimer*), cb_cTimer_arr_, 1|2);
  cb_cTimer_MaxHandles_ = i + cb_cTimer_REDIM_FACTOR_;
  i--;
Found0000: ;
  cb_cTimer_arr_[i] = self;
  i++;
  self->Ndx_ = i;
  return 0;
}


void cb_cTimer_Terminate_ (cb_cTimer* =NULL);

void cb_cTimer_Terminate_ (cb_cTimer* self)
{
  cb_cTimer_Kill(self);
  register cb_Integer i; i = self->Ndx_;
  if (i) {
    i--;
    cb_cTimer_arr_[i] = NULL;
  }
  for (i=0;i<cb_cTimer_MaxHandles_;i++) {
    if (cb_cTimer_arr_[i]) {
      return;
    }
  }
  if (cb_cTimer_arr_) { cb_MemFreeM(cb_cTimer_arr_); cb_cTimer_arr_ = NULL; }
}


cb_cTimer* cb_cTimer_Initialize (cb_cTimer* self,void* clsParent,void* clsMain)
{
  if (self) {
    cb_CLEAR1(*self);
  }
  else {
    self = (cb_cTimer*)cb_MemAllocM(sizeof(cb_cTimer));
    if (self==NULL) {
      return NULL;
    }
    cb_CLEAR1(*self);
    self->flag1_++;
  }
  self->clsParent = clsParent;
  self->clsMain = clsMain;
  cb_cTimer_Initialize_(self);
  return self;
}


void cb_cTimer_Terminate (cb_cTimer* self)
{
  cb_cTimer_Terminate_(self);
  if ((self->flag1_ & TRUE)!=0) {
    cb_MemFreeM(self);
  }
  else {
    self->clsMain = NULL;
    self->clsParent = NULL;
  }
}
/* END MODULE */
#ifdef USE_LICE_BITMAP
#endif
/* MODULE::cb_cDC */

enum {
  cb_cDC_HASRECT_bit = 0x10
};

#define cb_cDC_DEFAULT_BACKCOLOR_ 0
#define cb_cDC_DEFAULT_TEXT_ "aAbBcCdDeEfFmMnNuUvVwWxXyYzZ"


COLORREF cb_cDC_GetBackColor (cb_cDC* T)
{
  return T->clrBack;
}


void cb_cDC_SetBackColor (cb_cDC* T,COLORREF iClr)
{
  T->clrBack = iClr;
}


COLORREF cb_cDC_GetForeColor (cb_cDC* T)
{
  return T->clrFore;
}


void cb_cDC_SetForeColor (cb_cDC* T,COLORREF iClr)
{
  T->clrFore = iClr;
}


BYTE cb_cDC_GetBackR (cb_cDC* T)
{
  return GetRValue(T->clrBack);
}


void cb_cDC_SetBackR (cb_cDC* T,BYTE iClr)
{
  T->clrBack &= 0x00FFFF00;
  T->clrBack |= iClr;
}


BYTE cb_cDC_GetBackG (cb_cDC* T)
{
  return GetGValue(T->clrBack);
}


void cb_cDC_SetBackG (cb_cDC* T,BYTE iClr)
{
  T->clrBack &= 0x00FF00FF;
  T->clrBack |= iClr<<8;
}


BYTE cb_cDC_GetBackB (cb_cDC* T)
{
  return GetBValue(T->clrBack);
}


void cb_cDC_SetBackB (cb_cDC* T,BYTE iClr)
{
  T->clrBack &= 0x0000FFFF;
  T->clrBack |= iClr<<16;
}


BYTE cb_cDC_GetForeR (cb_cDC* T)
{
  return GetRValue(T->clrFore);
}


void cb_cDC_SetForeR (cb_cDC* T,BYTE iClr)
{
  T->clrFore &= 0x00FFFF00;
  T->clrFore |= iClr;
}


BYTE cb_cDC_GetForeG (cb_cDC* T)
{
  return GetGValue(T->clrFore);
}


void cb_cDC_SetForeG (cb_cDC* T,BYTE iClr)
{
  T->clrFore &= 0x00FF00FF;
  T->clrFore |= iClr<<8;
}


BYTE cb_cDC_GetForeB (cb_cDC* T)
{
  return GetBValue(T->clrFore);
}


void cb_cDC_SetForeB (cb_cDC* T,BYTE iClr)
{
  T->clrFore &= 0x0000FFFF;
  T->clrFore |= iClr<<16;
}


COLORREF cb_cDC_GetBkColor (cb_cDC* T)
{
  register cb_cDC* self; self = T;
  register HDC hDC; hDC = self->hDC_;
  if (hDC==NULL) {
    hDC = GetDC(self->hWnd);
  }
  register COLORREF c; c = GetBkColor(hDC);
  if (self->hDC_==NULL) {
    ReleaseDC(self->hWnd,hDC);
  }
  return c;
}


void cb_cDC_SetBkColor (cb_cDC* T,COLORREF iClr)
{
  register cb_cDC* self; self = T;
  register HDC hDC; hDC = self->hDC_;
  if (hDC==NULL) {
    hDC = GetDC(self->hWnd);
  }
  SetBkColor(hDC,iClr);
  if (self->hDC_==NULL) {
    ReleaseDC(self->hWnd,hDC);
  }
}


COLORREF cb_cDC_GetTextColor (cb_cDC* T)
{
  register cb_cDC* self; self = T;
  register HDC hDC; hDC = self->hDC_;
  if (hDC==NULL) {
    hDC = GetDC(self->hWnd);
  }
  register COLORREF c; c = GetTextColor(hDC);
  if (self->hDC_==NULL) {
    ReleaseDC(self->hWnd,hDC);
  }
  return c;
}


void cb_cDC_SetTextColor (cb_cDC* T,COLORREF iClr)
{
  register cb_cDC* self; self = T;
  register HDC hDC; hDC = self->hDC_;
  if (hDC==NULL) {
    hDC = GetDC(self->hWnd);
  }
  SetTextColor(hDC,iClr);
  if (self->hDC_==NULL) {
    ReleaseDC(self->hWnd,hDC);
  }
}


HDC cb_cDC_Get (cb_cDC* T)
{
  register cb_cDC* self; self = T;
#ifdef USE_LICE_BITMAP
  if (bmp_) {
    return bmp_->getDC();
  }
#endif
  return self->hDC_;
}


HDC cb_cDC_Set (cb_cDC* T,HDC hDC,HBITMAP hBmp)
{
  register cb_cDC* self; self = T;
  register HDC h; h = hDC;
  register HBITMAP b; b = self->hOldBmp_;
  register HDC h1;
  RECT rc1;
  if (b) {
    SetBkMode(self->hDC_,self->bkMode_);
    b = (HBITMAP)SelectObject(self->hDC_,b);
    if (self->hOldFnt_) {
      SelectObject(self->hDC_,self->hOldFnt_);
    }
    DeleteDC(self->hDC_);
    if (h==(HDC)-4) {
      h1 = (HDC)b;
      h = NULL;
      goto Exit000;
    }
    cb_DeleteObject(b);
  }
#ifdef USE_LICE_BITMAP
  if (self->bmp_) {
    delete self->bmp_;
    bmp_ = NULL;
    b = cb_CASTrev(1,HBITMAP);
  }
#endif
  if ((cb_UInteger)h>=(cb_UInteger)-3) {
    if (self->flag1_ & cb_cDC_HASRECT_bit) {
      cb_MemCopy(&rc1, &(self->rc_), sizeof(rc1));
    }
    else {
      GetClientRect(self->hWnd,&rc1);
    }
    self->X_ = 0;
    self->Y_ = 0;
    rc1.right -= rc1.left;
    self->W_ = rc1.right;
    rc1.bottom -= rc1.top;
    self->H_ = rc1.bottom;
#ifdef USE_LICE_BITMAP
    if (h==(HDC)-3 || cb_CASTrev(b,cb_Integer)==1) {
      self->bmp_ = LICE_FromDC(NULL,rc1.right,rc1.bottom);
      self->iMode_ = LICE_BLIT_MODE_COPY;
      self->A_ = 1;
      h1 = bmp_->getDC();
      h = NULL;
      goto Exit000;
    }
#endif
    if ((cb_Integer)h==-2 || b) {
      if (self->flag1_ & cb_cDC_HASRECT_bit) {
        h = cb_CASTrev(self->hWnd,HDC);
      }
      else {
        h = GetDC(self->hWnd);
      }
      b = hBmp;
      if (b) {
//get dimension
        goto Skip0000;
      }
      b = CreateCompatibleBitmap(h,rc1.right,rc1.bottom);
Skip0000: ;
      hDC = CreateCompatibleDC(h);
      if (!(self->flag1_ & cb_cDC_HASRECT_bit)) {
        ReleaseDC(self->hWnd,h);
      }
      h = hDC;
      self->hOldBmp_ = (HBITMAP)SelectObject(h,b);
      self->bkMode_ = SetBkMode(h,TRANSPARENT);
      self->hBmp_ = b;

#if defined _DEBUG_
      if (self->hOldBmp_==NULL) {
        self->hOldBmp_ = (HBITMAP)-1;
        cb_MsgBox("Something very strange happened with windows...");
      }
#endif  /* _DEBUG_ */

      h1 = h;
      goto Exit0000;
    }
    h = self->hDC_;
  }
  else {
    if (h==(HDC)-4) {
      h = NULL;
    }
    h1 = h;
  }
Exit000: ;
  self->hOldBmp_ = NULL;
  self->hBmp_ = NULL;
  self->flag1_ &=  ~cb_cDC_HASRECT_bit;
Exit0000: ;
  self->hOldFnt_ = NULL;
  self->hDC_ = h;
  self->TextH = 0;
  return h1;
}


HBITMAP cb_cDC_GetBmp (cb_cDC* T)
{
  register cb_cDC* self; self = T;
  if (self->hBmp_) {
    return self->hBmp_;
  }
  return cb_WndShot(self->hWnd);
}


void cb_cDC_SetBmp (cb_cDC* T,HBITMAP hBmp)
{
  register cb_cDC* self;
  register HBITMAP h;
  if (hBmp) {
    self = T;
    if (self->hDC_) {
      h = (HBITMAP)SelectObject(self->hDC_,hBmp);
      if (h!=self->hBmp_) {
        if (h!=self->hOldBmp_) {
          cb_DeleteObject(h);
        }
      }
      h = hBmp;
    }
    else {
      cb_SetWndImage(self->hWnd,hBmp);
      h = NULL;
    }
    if (self->hBmp_) {
      cb_DeleteObject(self->hBmp_);
    }
    self->hBmp_ = h;
  }
}


void cb_cDC_Flush (cb_cDC* T,HDC hDC)
{
  register cb_cDC* self; self = T;
  register HDC h;
  register HDC h1; h1 = self->hDC_;
  if (!h1) {
#ifdef USE_LICE_BITMAP
    if (!self->bmp_) {
      return;
    }
    h1 = self->bmp_->getDC();
#else
    return;
#endif
  }
  h = hDC;
  if (h==NULL) {
    if (self->flag1_ & cb_cDC_HASRECT_bit) {
      h = cb_CASTrev(self->hWnd,HDC);
    }
    else {
      h = GetDC(self->hWnd);
    }
  }
  BitBlt(h,0,0,self->W_,self->H_,h1,0,0,SRCCOPY);
  if (hDC==NULL) {
    if (!(self->flag1_ & cb_cDC_HASRECT_bit)) {
      ReleaseDC(self->hWnd,h);
    }
  }
}


cb_Integer cb_cDC_GetLeft (cb_cDC* T)
{
  return T->X_;
}


void cb_cDC_SetLeft (cb_cDC* T,cb_Integer x)
{
  T->X_ = x;
}


cb_Integer cb_cDC_GetTop (cb_cDC* T)
{
  return T->Y_;
}


void cb_cDC_SetTop (cb_cDC* T,cb_Integer y)
{
  T->Y_ = y;
}


cb_Integer cb_cDC_GetWidth (cb_cDC* T)
{
  return T->W_;
}


void cb_cDC_SetWidth (cb_cDC* T,cb_Integer w)
{
  T->W_ = w;
}


cb_Integer cb_cDC_GetHeight (cb_cDC* T)
{
  return T->H_;
}


void cb_cDC_SetHeight (cb_cDC* T,cb_Integer h)
{
  T->H_ = h;
}


cb_Integer cb_cDC_GetTransparency (cb_cDC* T)
{
  return T->A_;
}


void cb_cDC_SetTransparency (cb_cDC* T,cb_Integer iVal)
{
  T->A_ = iVal;
}


cb_Integer cb_cDC_Line (cb_cDC* T,cb_Integer x,cb_Integer y,cb_Integer x2,cb_Integer y2,cb_Integer z)
{
  register cb_cDC* self; self = T;
  register cb_Integer x_; x_ = y;
  if (x_>y2) {
    y = y2;
    y2 = x_;
  }
  x_ = x;
  if (x_>x2) {
    x_ = x2;
    x2 = x;
  }
  cb_DrawLine(self->hWnd,x_,y,x2,y2,self->clrFore,0,self->hDC_);
  return 0;
}


cb_Integer cb_cDC_LineTo (cb_cDC* T,cb_Integer x,cb_Integer y,cb_Integer z)
{
  register cb_cDC* self; self = T;
  cb_cDC_Line(self,self->X_,self->Y_,x,y,z);
  self->X_ = x;
  self->Y_ = y;
  return 0;
}


cb_Integer cb_cDC_Rect (cb_cDC* T,cb_Integer x,cb_Integer y,cb_Integer w,cb_Integer h)
{
  register cb_cDC* self; self = T;
  cb_DrawRect(self->hWnd,x,y,w,h,self->clrBack,self->clrFore,self->A_,self->hDC_);
  return 0;
}


cb_Integer cb_cDC_RectTo (cb_cDC* T,cb_Integer x,cb_Integer y)
{
  register cb_cDC* self; self = T;
  register cb_Integer x1; x1 = self->X_;
  register cb_Integer y1; y1 = self->Y_;
  self->X_ = x,self->Y_ = y;
  x -= x1;
  if (x<0) {
    x1 += x;
    x = -x;
  }
  y -= y1;
  if (y<0) {
    y1 += y;
    y = -y;
  }
  cb_DrawRect(self->hWnd,x1,y1,x,y,self->clrBack,self->clrFore,self->A_,self->hDC_);
  return 0;
}


cb_Integer cb_cDC_Circle (cb_cDC* T,cb_Integer x,cb_Integer y,cb_Integer w,cb_Integer h)
{
  register cb_cDC* self; self = T;
  cb_DrawCircle(self->hWnd,x,y,w,h,self->clrBack,self->clrFore,self->A_,self->hDC_);
  return 0;
}


cb_Integer cb_cDC_CircleTo (cb_cDC* T,cb_Integer x,cb_Integer y)
{
  register cb_cDC* self; self = T;
  register cb_Integer x1; x1 = self->X_;
  register cb_Integer y1; y1 = self->Y_;
  if (x1<x) {
    if (y1<y) {
      self->X_ = x;
      self->Y_ = y;
      cb_DrawCircle(self->hWnd,x1,y1,x - x1,y - y1,self->clrBack,self->clrFore,self->A_,self->hDC_);
    }
  }
  return 0;
}


cb_Integer cb_cDC_Arc (cb_cDC* T,cb_Integer x,cb_Integer y)
{
  return 0;
}


cb_Integer cb_cDC_Triangle (cb_cDC* T,cb_Integer x,cb_Integer y)
{
  register cb_cDC* self; self = T;
/* todo */
  return 0;
}


cb_Integer cb_cDC_GetPixel (cb_cDC* T,cb_Integer* r,cb_Integer* g,cb_Integer* b)
{
  register cb_cDC* self; self = T;
  register HDC hDC; hDC = self->hDC_;
  if (!hDC) {
    hDC = GetDC(self->hWnd);
  }
  register COLORREF i; i = GetPixel(hDC,self->X_,self->Y_);
  if (!self->hDC_) {
    ReleaseDC(self->hWnd,hDC);
  }
  r[0] = i & 0xFF;
  i >>= 8;
  g[0] = i & 0xFF;
  i >>= 8;
  b[0] = i & 0xFF;
  return 0;
}


cb_Integer cb_cDC_SetPixel (cb_cDC* T,cb_Integer r,cb_Integer g,cb_Integer b)
{
  register cb_cDC* self; self = T;
  register HDC hDC; hDC = self->hDC_;
  if (!hDC) {
    hDC = GetDC(self->hWnd);
  }
  register cb_Integer i; i = SetPixel(hDC,self->X_,self->Y_,RGB(r,g,b));
  if (!self->hDC_) {
    ReleaseDC(self->hWnd,hDC);
  }
  return i;
}


HWND cb_cDC_GethWnd (cb_cDC* T)
{
  return T->hWnd;
}


HWND cb_cDC_SethWnd (cb_cDC* T,HWND hWin)
{
  T->hWnd = hWin;
  return hWin;
}


HFONT cb_cDC_SetFont (cb_cDC* T,HFONT hFnt,cb_Integer bRefresh)
{
  HFONT cb_retVar_;
  register cb_cDC* self; self = T;
  self->TextH = 0;
  if (!self->hDC_) {
    cb_retVar_ = cb_GetWndFont(self->hWnd);
    cb_SetWndFont(self->hWnd,hFnt,bRefresh);
  }
  else {
    cb_retVar_ = (HFONT)SelectObject(self->hDC_,hFnt);
    if (self->hOldBmp_!=NULL) {
      if (self->hOldFnt_==NULL) {
        self->hOldFnt_ = cb_retVar_;
        cb_retVar_ = NULL;
      }
    }
  }
  return cb_retVar_;
}


cb_Integer cb_cDC_GetTextHeight (cb_cDC* T,const cb_String s)
{
  register cb_cDC* self; self = T;
  if (self->TextH<=0) {
    if (s==NULL) {
      s = cb_cDC_DEFAULT_TEXT_;
    }
    cb_GetTextSize(s,&self->TextH,self->hWnd,NULL,self->hDC_);
  }
  return self->TextH;
}


cb_Integer cb_cDC_Clw (cb_cDC* T,COLORREF c)
{
  register cb_cDC* self; self = T;
  if (c==CLR_INVALID) {
    c = self->clrBack;
    if (c==CLR_INVALID) {
      c = cb_cDC_DEFAULT_BACKCOLOR_;
    }
  }
  cb_Clw(self->hWnd,c,self->A_,NULL,self->hDC_);
  return 0;
}


cb_Integer cb_cDC_Blit (cb_cDC* T,HBITMAP hBmp,float scale,float rotation)
{
  register cb_cDC* self; self = T;
  register HBITMAP h1; h1 = hBmp;
  register HBITMAP h2;
  if (rotation!=0.0) {
    h1 = cb_RotateBitmap(h1,rotation,0);
  }
  if (scale!=1.0) {
    h2 = h1;
    h1 = cb_StretchBitmap(h1,0,0,self->hWnd);
    if (h2!=hBmp) {
      cb_DeleteObject(h2);
    }
  }
  cb_DrawBitmap(h1,self->hWnd,self->X_,self->Y_,0,0,FALSE,self->A_,self->hDC_);
  if (h1!=hBmp) {
    cb_DeleteObject(h1);
  }
  return 0;
}


cb_Integer cb_cDC_BlitExt (cb_cDC* T,HBITMAP hBmp,cb_Integer* b,float rotation)
{
  register cb_cDC* self; self = T;
  register HBITMAP hbm; hbm = hBmp;
  register HDC hDC; hDC = self->hDC_;
  register HDC MemHDC;
  cb_Integer X;
  cb_Integer Y;
  cb_Integer W;
  cb_Integer H;
  HDC hDC_;
  if (!hDC) {
    hDC = GetDC(self->hWnd);
  }
  X = b[4];
  Y = b[5];
  W = b[6];
  H = b[7];
  if (X==b[0] && Y==b[1] && W==b[2] && H==b[3]) {
    hDC_ = NULL;
  }
  else {
    MemHDC = CreateCompatibleDC(hDC);
    hBmp = (HBITMAP)SelectObject(MemHDC,hbm);
    hDC_ = CreateCompatibleDC(hDC);
    hbm = CreateCompatibleBitmap(hDC,W,H);
    hbm = (HBITMAP)SelectObject(hDC_,hbm);
    StretchBlt(hDC_,0,0,W,H,MemHDC,b[0],b[1],b[2],b[3],SRCCOPY);
    hBmp = (HBITMAP)SelectObject(MemHDC,hBmp);
    cb_DeleteObject(MemHDC);
  }
  if (rotation!=0.0) {
    if (hbm!=hBmp) {
      hbm = (HBITMAP)SelectObject(hDC_,hbm);
      DeleteDC(hDC_);
    }
    hbm = cb_RotateBitmap(hbm,rotation,0,&hDC_);
  }
  hbm = cb_DrawBMP(hbm,hDC,&hDC_,X,Y,W,H,FALSE,self->A_,self->iMode_);
  hbm = (HBITMAP)SelectObject(hDC_,hbm);
  DeleteDC(hDC_);
  if (hbm!=hBmp) {
    cb_DeleteObject(hbm);
  }
  if (!self->hDC_) {
    ReleaseDC(self->hWnd,hDC);
  }
  return 0;
}


cb_Integer cb_cDC_DrawText (cb_cDC* T,const cb_String s,cb_Integer iLen)
{
  register cb_cDC* self; self = T;
  register cb_Integer i;
  register cb_Integer j;
  register HDC hDC; hDC = self->hDC_;
  SIZE p;
  if (!hDC) {
#ifdef USE_LICE_BITMAP
    if (self->bmp_) {
      LICE_DrawText(self->bmp_,self->X_,self->Y_,s,CLR_INVALID,self->A_,self->iMode_);
      return 0;
    }
#endif
    hDC = GetDC(self->hWnd);
    goto Setbkmode0000;
  }
  if (!self->hOldBmp_) {
Setbkmode0000: ;
    j = SetBkMode(hDC,TRANSPARENT);
  }
  i = self->clrBack;
  if (i!=CLR_INVALID) {
    SetBkColor(hDC,i);
  }
  i = self->clrFore;
  if (i!=CLR_INVALID) {
    SetTextColor(hDC,i);
  }
  i = iLen;
  if (i<0) {
    i = cb_StrLen(s);
  }
  if (i>0) {
    i--;
    if (s[i]!='\n') {
      i++;
      goto Draw0000;
    }
    if (i>0) {
Draw0000: ;
      TextOut(hDC,self->X_,self->Y_,s,i);
      if (GetTextExtentPoint32(hDC,s,i,&p)) {
        self->X_ += p.cx;
        goto Cont0000;
      }
    }
  }
  p.cy = 0;
Cont0000: ;
  if (!self->hOldBmp_) {
    SetBkMode(hDC,j);
    if (!self->hDC_) {
      ReleaseDC(self->hWnd,hDC);
    }
  }
  return p.cy;
}


cb_Integer cb_cDC_DrawChar (cb_cDC* self,cb_UInteger c)
{
  char b[sizeof(cb_Integer)];
  cb_LowInt(b) = c;
  return cb_cDC_DrawText(self,b,1);
}


cb_Integer cb_cDC_DrawNumber (cb_cDC* self,double n,cb_Integer c)
{
  char b[64];
  register cb_Integer i; i = cb_dtoa(n,b,c);
  return cb_cDC_DrawText(self,b,i);
}


cb_Integer cb_cDC_PrintFV (cb_cDC* self,cb_String buf,const cb_String s,void* p)
{
  cb_Integer cb_retVar_;
  register cb_PString b; b = buf;
  register cb_Integer i;
  if (b) {
    buf = NULL;
  }
  else {
    b = (cb_PString)cb_MemAllocM(24*0x400);
    buf = b;
  }
  i = cb_vsprintf(b,s,p);
  cb_retVar_ = i;
  do {
    s = cb_StrChar(b,'\n');
    if (!s) {
      cb_cDC_DrawText(self,b,i);
      break;
    }
    i = cb_cDC_DrawText(self,b,(cb_Integer)s - (cb_Integer)b);
    self->Y_ += i;
    self->X_ = 0;
    b = (cb_String)s;
    b++;
    i = -1;
  } while(1);
  if (buf) {
    cb_MemFreeM(buf);
  }
  return cb_retVar_;
}


__declspec(noinline) cb_Integer cb_CDECL cb_cDC_PrintF (cb_cDC* self,cb_String buf,const cb_String s,...)
{
  return cb_cDC_PrintFV(self,buf,s,(&s)+1);
}


cb_Integer cb_cDC_MeasureText (cb_cDC* self,const cb_String s,cb_Integer* h)
{
  return cb_GetTextSize(s,h,self->hWnd,NULL,self->hDC_);
}


void cb_cDC_Open (cb_cDC* T,void* hWin,cb_Integer flag1,RECT* rc)
{
  register cb_cDC* self; self = T;
  RECT rc1;
  self->hWnd = cb_CASTrev(hWin,HWND);
  self->A_ = 0;
  self->iMode_ = SRCCOPY;
  self->clrBack = CLR_INVALID;
  self->clrFore = CLR_INVALID;
  if (!flag1) {
    self->TextH = 0;
    self->X_ = 0;
    self->Y_ = 0;
    GetClientRect(cb_CASTrev(hWin,HWND),&rc1);
    self->W_ = rc1.right;
    self->H_ = rc1.bottom;
  }
  else if (flag1>0) {
    if (rc) {
      cb_MemCopy(&(self->rc_), &rc, sizeof(self->rc_));
      self->flag1_ |= cb_cDC_HASRECT_bit;
    }
#ifdef USE_LICE_BITMAP
    if (flag1==TRUE) {
#endif
      cb_cDC_CreateMem(self);
#ifdef USE_LICE_BITMAP
    }
    else {
      cb_cDC_LICECreateMem(self);
    }
#endif
  }
}


void cb_cDC_Settings (cb_cDC* T,COLORREF r,COLORREF g,COLORREF b,cb_Integer a,cb_Integer m)
{
  register cb_cDC* self; self = T;
  register cb_UInteger i;
  i = r;
  if (i!=-1) {
    i &= 0x00FF;
    self->clrFore &= 0x00FFFF00;
    self->clrFore |= i;
  }
  i = g;
  if (i!=-1) {
    i &= 0x00FF;
    i <<= 8;
    self->clrFore &= 0x00FF00FF;
    self->clrFore |= i;
  }
  i = b;
  if (i!=-1) {
    i &= 0x00FF;
    i <<= 16;
    self->clrFore &= 0x0000FFFF;
    self->clrFore |= i;
  }
  i = a;
  if (i<=255) {
    self->A_ = i;
  }
  i = m;
  if (i!=-1) {
    self->iMode_ = i;
  }
}


void cb_cDC_Reset (cb_cDC* T)
{
  cb_cDC_ReStart(T);
}


void cb_cDC_Close (cb_cDC* T)
{
  register cb_cDC* self; self = T;
  cb_cDC_Clear(self);
  self->hWnd = NULL;
}


void cb_cDC_Initialize (cb_cDC* T)
{
  cb_CLEAR1(T[0]);
}
/* END MODULE */
/* MODULE::cb_HRTimerThreadFunction_ */


void cb_DEFCALL cb_HRTimerThreadFunction_ (HWND hWnd,cb_UInteger id,void* HRInterval,cb_Integer* iFlag,void (cb_CDECL *onTimer)(void* T,cb_UInteger lParam))
{
  register unsigned long long ElapsedMicroseconds;
  register cb_UInteger HRInterval_;
  LARGE_INTEGER StartingTime;
  LARGE_INTEGER EndingTime;
  LARGE_INTEGER Frequency;
  do {
    QueryPerformanceFrequency(&Frequency);
    QueryPerformanceCounter(&StartingTime);
    HRInterval_ = *(cb_UInteger*)HRInterval;
    do {
      if (iFlag[0]==-1234) {
        return;
      }
      if ((iFlag[0] & 4)!=0) {
        iFlag[0] &=  ~4;
        break;
      }
      QueryPerformanceCounter(&EndingTime);
      ElapsedMicroseconds = EndingTime.QuadPart - StartingTime.QuadPart;
      ElapsedMicroseconds *= 1000000;
      ElapsedMicroseconds /= Frequency.QuadPart;
      if ((iFlag[0] & (1 | 2))==1) {
        if (ElapsedMicroseconds>=HRInterval_) {
          StartingTime.QuadPart = EndingTime.QuadPart;
          iFlag[0] |= 2;
          if (onTimer) {
            onTimer((void*)id,ElapsedMicroseconds);
            iFlag[0] &=  ~2;
          }
          else {
            cb_PostMessage(hWnd,WM_HRTIMER_,id,ElapsedMicroseconds);
          }
        }
      }
    } while(1);
  } while(1);
}
/* END MODULE */
/* MODULE::cb_cHRTimer */
static HWND cb_cHRTimer_hWnd_;
static cb_Integer cb_cHRTimer_iCnt_;
#define cb_cHRTimer_MSG_TIMER_ WM_HRTIMER_
#define cb_cHRTimer_CLASSNAME_ "cb_cHRTimer"
#define cb_cHRTimer_WAIT_MS_ 5*ONE_SECOND


static cb_UInteger WINAPI cb_cHRTimer_ThreadFunction_ (void*);

static cb_UInteger WINAPI cb_cHRTimer_ThreadFunction_ (void* T)
{
  register cb_cHRTimer* self; self = (cb_cHRTimer*)T;
  cb_HRTimerThreadFunction_(self->hWnd,(cb_UInteger)self,&self->Interval,&self->iFlag_,self->OnDirectTimer);
  self->iFlag_ = 0;
  return 0;
}


void cb_cHRTimer_Notify (cb_cHRTimer* self)
{
  self->iFlag_ &=  ~2;
}


void cb_cHRTimer_End (cb_cHRTimer* self)
{
  if (self->hThread_) {
#ifdef cHRTimer_DEBUG_
    cb_PutS("cHRTimer_Destroy :  Before killthread IsThreadAlive = \n");
    cb_IsThreadAlive(self->hThread_);
#endif
    if (self->iFlag_) {
      self->iFlag_ = -1234;
      do {
      } while(self->iFlag_);
    }
#ifdef cHRTimer_DEBUG_
    cb_PutS(", After killthread IsThreadAlive = \n");
    cb_IsThreadAlive(self->hThread_);
#endif
    MsgWaitForMultipleObjectsEx(1,&self->hThread_,cb_cHRTimer_WAIT_MS_,QS_ALLINPUT,MWMO_INPUTAVAILABLE);
    CloseHandle(self->hThread_);
    self->hThread_ = NULL;
  }
  self->hWnd = NULL;
}


static LRESULT CALLBACK cb_cHRTimer_Events_ (HWND,UINT,WPARAM,LPARAM);

static LRESULT CALLBACK cb_cHRTimer_Events_ (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
  register cb_cHRTimer* self;
  {  /* Select Case uMsg? */
    if (uMsg==cb_cHRTimer_MSG_TIMER_) {
      self = (cb_cHRTimer*)wParam;
      if (self->OnTimer) self->OnTimer(self,lParam);
      self->iFlag_ &=  ~(2);
      goto EndSelect_0;
    }
    if (uMsg==WM_NCDESTROY) {
/* todo unregister class */
    }
  }  /* End Select: uMsg? */
  EndSelect_0:;
  return DefWindowProc(hWnd,uMsg,wParam,lParam);
}


static void cb_cHRTimer_ChkSethWnd_ (cb_cHRTimer*);

static void cb_cHRTimer_ChkSethWnd_ (cb_cHRTimer* self)
{
  if (!cb_cHRTimer_hWnd_) {
/* todo register + create window */
  }
  self->hWnd = cb_cHRTimer_hWnd_;
}


static void cb_cHRTimer_onTerminate (cb_cHRTimer* =NULL);

static void cb_cHRTimer_onTerminate (cb_cHRTimer* self)
{
  cb_cHRTimer_End(self);
  if (cb_cHRTimer_iCnt_>0) {
    cb_cHRTimer_iCnt_--;
    if (!cb_cHRTimer_iCnt_) {
      if (cb_cHRTimer_hWnd_) {
        DestroyWindow(cb_cHRTimer_hWnd_);
        cb_cHRTimer_hWnd_ = NULL;
      }
    }
  }
}


static cb_Integer cb_DEFCALL cb_cHRTimer_onInitialize (cb_cHRTimer* =NULL);

static cb_Integer cb_DEFCALL cb_cHRTimer_onInitialize (cb_cHRTimer* self)
{
  cb_cHRTimer_iCnt_++;
  return 0;
}


void cb_cHRTimer_SetEnabled (cb_cHRTimer* self,cb_Integer bVal,cb_UInteger iVal)
{
  register cb_UInteger i; i = iVal;
  if (bVal<=0 || i==0) {
    if (self->iFlag_) {
      if (bVal<0) {
        self->iFlag_ &=  ~1;
      }
      else {
        cb_cHRTimer_End(self);
      }
    }
  }
  else {
    if (!self->hWnd) {
      cb_cHRTimer_ChkSethWnd_(self);
    }
    if (i!=-1) {
      self->Interval = i;
    }
    if (self->iFlag_) {
      self->iFlag_ |= 1 | 4;
    }
    else {
      self->iFlag_ = 1 | 8;
      self->hThread_ = (HANDLE)cb_BeginThread(&cb_cHRTimer_ThreadFunction_,self,0,NULL);
    }
  }
}


cb_cHRTimer* cb_cHRTimer_Initialize (cb_cHRTimer* self,void* clsParent,void* clsMain)
{
  if (self) {
    cb_CLEAR1(*self);
  }
  else {
    self = (cb_cHRTimer*)cb_MemAllocM(sizeof(cb_cHRTimer));
    if (self==NULL) {
      return NULL;
    }
    cb_CLEAR1(*self);
    self->flag1_++;
  }
  self->clsParent = clsParent;
  self->clsMain = clsMain;
  cb_cHRTimer_onInitialize(self);
  return self;
}


void cb_cHRTimer_Terminate (cb_cHRTimer* self)
{
  cb_cHRTimer_onTerminate(self);
  if ((self->flag1_ & TRUE)!=0) {
    cb_MemFreeM(self);
  }
  else {
    self->clsMain = NULL;
    self->clsParent = NULL;
  }
}
/* END MODULE */
/* MODULE::cb_cPalette */


cb_Integer cb_cPalette_ClosestIndex (cb_cPalette* T,COLORREF iClr)
{
  cb_cPalette* self; self = T;
  cb_Integer i;
  cb_Integer r1;
  cb_Integer r2;
  cb_Integer g1;
  cb_Integer g2;
  cb_Integer b1;
  cb_Integer b2;
  cb_Integer iER;
  cb_Integer iEG;
  cb_Integer iEB;
  cb_Integer iMinER; iMinER = 255;
  cb_Integer iMinEG; iMinEG = 255;
  cb_Integer iMinEB; iMinEB = 255;
  COLORREF* p; p = self->m_Buf;
  COLORREF c;
  cb_Integer iIndex;
  iClr &= 0x00FFFFFF;
  r1 = GetRValue(iClr);
  b1 = GetBValue(iClr);
  g1 = GetGValue(iClr);
  for (i=self->m_Len;i>=1;i--) {
    c = p[0];
    c &= 0x00FFFFFF;
    if (c==iClr) {
      return i;
    }
    r2 = GetRValue(c);
    b2 = GetBValue(c);
    g2 = GetGValue(c);
    iER = cb_Abs(r1 - r2);
    iEG = cb_Abs(g1 - g2);
    iEB = cb_Abs(b1 - b2);
    if (iER + iEG + iEB<iMinER + iMinEG + iMinEB) {
      iMinER = iER;
      iMinEG = iEG;
      iMinEB = iEB;
      iIndex = i;
    }
    p++;
  }
  return iIndex;
}


COLORREF cb_cPalette_Color (cb_cPalette* self,cb_Integer iIndex)
{
  register cb_UInteger i; i = iIndex;
  if (i<self->m_Len) {
    return self->m_Buf[i];
  }
  return (COLORREF)-1;
}


void cb_cPalette_Apply (cb_cPalette* T,cb_Integer iWidth,cb_Integer iHeight,COLORREF* p1,COLORREF* p2)
{
  register cb_cPalette* self; self = T;
  if (p2==NULL) {
    p2 = p1;
  }
  {
   register cb_Integer y;
   for (y=0;y<iHeight;y++) {
    {
     register cb_Integer x;
     for (x=0;x<iWidth;x++) {
      p2[0] = (COLORREF)cb_cPalette_ClosestIndex(self,p1[0]);
      p1++;
      p2++;
     }
    }
   }
  }
}
/* END MODULE */
#ifndef USE_CRT
#endif
/* MODULE::cppCollection */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/cppClasses/All/Collection/Collection.cpp"
/* END MODULE */
#ifdef USE_MEMORY
#endif
/* MODULE::cppMem */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/cppClasses/All/Mem/Mem.cpp"
/* END MODULE */
#ifdef USE_MEMORY
#endif
#ifndef USE_CRT
#endif
/* MODULE::cppString */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/cppClasses/All/String/String.cpp"
/* END MODULE */
#ifdef USE_FILE
#endif
/* MODULE::cppFile */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/cppClasses/All/File/File.cpp"
/* END MODULE */
/* MODULE::cppStringArray */
#include "C:/Programs/Win32/CodeBase/Source/CodeBase/cppClasses/All/Misc/StringArray.cpp"
/* END MODULE */
/* MODULE::cbGUI_LoadCursor */


void cb_DEFCALL cbGUI_LoadCursor (void* ptr1,HWND hWin)
{
}
/* END MODULE */
/* MODULE::cbGUI_LoadIcon */


void cb_DEFCALL cbGUI_LoadIcon (void* ptr1,HWND hWin)
{
}
/* END MODULE */
/* MODULE::cbGUI_LoadImage */


void cb_DEFCALL cbGUI_LoadImage (void* ptr1,HWND hWin)
{
}
/* END MODULE */
/* MODULE::cbGUI_SetLocked */


void cb_DEFCALL cbGUI_SetLocked (HWND hWin,cb_Integer flag1)
{
  register cb_UInteger i; i = GetWindowLongPtr(hWin,GWL_STYLE);
  if (flag1) {
    i |= ES_READONLY;
  }
  else {
    i &=  ~(ES_READONLY);
  }
  cb_SetWindowLongPtr(hWin,GWL_STYLE,i);
}


cb_Integer cb_DEFCALL cbGUI_GetLocked (HWND hWin)
{
  return cb_CBOOL(GetWindowLongPtr(hWin,GWL_STYLE) & ES_READONLY);
}
/* END MODULE */
/* MODULE::cbGUI_SetScrollPos */


void cb_DEFCALL cbGUI_SetScrollPos (HWND hWin,cb_Integer Value)
{
  SetScrollPos(hWin,SB_CTL,Value,TRUE);
}


cb_Integer cb_DEFCALL cbGUI_GetScrollPos (HWND hWin)
{
  return GetScrollPos(hWin,SB_CTL);
}
/* END MODULE */
/* MODULE::cbGUI_SetTaskVisible */


void cb_DEFCALL cbGUI_SetTaskVisible (HWND hWin,cb_Integer flag1)
{
  if (flag1) {
    cb_GetSetWndExStyle(hWin,WS_EX_APPWINDOW,WS_EX_TOOLWINDOW,-1);
  }
  else {
    cb_GetSetWndExStyle(hWin,WS_EX_TOOLWINDOW,WS_EX_APPWINDOW,-1);
  }
}


cb_Integer cb_DEFCALL cbGUI_GetTaskVisible (HWND hWin)
{
  return cb_CBOOL(cb_GetWndExStyle(hWin,WS_EX_APPWINDOW));
}
/* END MODULE */
/* MODULE::cbGUI_vbGetDC */
#define cbGUI_vbMAX_DCs_ 128
static HDC cbGUI_vbHDC_[cbGUI_vbMAX_DCs_];
static HWND cbGUI_vbHWND_[cbGUI_vbMAX_DCs_];
static cb_Integer cbGUI_vbDCCnt_;


HDC cb_DEFCALL cbGUI_vbGetDC (HWND hWnd)
{
  register cb_Integer i;
  for (i=0;i<cbGUI_vbDCCnt_;i++) {
    if (cbGUI_vbHWND_[i]==hWnd) {
      return cbGUI_vbHDC_[i];
    }
  }
  i = cbGUI_vbDCCnt_;
  if (i<cbGUI_vbMAX_DCs_) {
    cbGUI_vbDCCnt_++;
    cbGUI_vbHWND_[i] = hWnd;
    return cbGUI_vbHDC_[i] = GetDC(hWnd);
  }
  return NULL;
}


void cbGUI_vbReleaseDC (void)
{
  while(cbGUI_vbDCCnt_>0) {
    cbGUI_vbDCCnt_--;
    ReleaseDC(cbGUI_vbHWND_[cbGUI_vbDCCnt_],cbGUI_vbHDC_[cbGUI_vbDCCnt_]);
  }
}
/* END MODULE */
/* MODULE::cbGUI_GetFileSmallIcon */


HICON cb_DEFCALL cbGUI_GetFileSmallIcon (const cb_String sfName)
{
  SHFILEINFO shfi;
  if (SHGetFileInfo(sfName,0,&shfi,sizeof(SHFILEINFO),SHGFI_SHELLICONSIZE | SHGFI_SYSICONINDEX | SHGFI_ICON | SHGFI_SMALLICON)) {
    return shfi.hIcon;
  }
  return NULL;
}
/* END MODULE */
#ifndef DriveComboBox_Type_Def
#endif
/* MODULE::ucDriveComboBox */
#define id_ucDriveComboBox_Combo1 id
cb_Integer ucDriveComboBox_refCnt_;


void ucDriveComboBox_SetBackColor (ucDriveComboBox* self,COLORREF iColor,cb_Integer bRefresh)
{
  self->BackColor = iColor;
  if (self->hBrush) {
    cb_DeleteObject(self->hBrush);
    self->hBrush = NULL;
  }
  if (bRefresh) {
    InvalidateRect(self->hWnd, 0, 0);
  }
}


const cb_PString ucDriveComboBox_GetPath (ucDriveComboBox* self)
{
  return self->m_sPath;
}


cb_Integer ucDriveComboBox_SetPath (ucDriveComboBox* self,const cb_String sPath)
{
  cb_Integer cb_retVar_;
  char *sBuf; sBuf = (char*)cb_MemAllocM(cb_MAX_FILE_NAME);
  if (sPath==NULL || sPath[0]==0) {
    sPath = cb_GetCurrentDir(0,sBuf);
  }
  if (cb_MemComp(sPath,"..",2+1)==0) {
    cb_GetFilePath(self->m_sPath,self->m_sPath);
  }
  else if (cb_MemComp(sPath,".",1+1)!=0) {
    if (cb_InChars(sPath,":\\/")<0) {
      cb_StrConCat(self->m_sPath,"\\",sPath,NULL);
    }
    else {
      if (sPath[0]=='\\' || sPath[0]=='/') {
        sPath++;
      }
      cb_retVar_ = cb_StrLen(sPath);
      if (cb_retVar_) {
        cb_retVar_--;
        if (sPath[cb_retVar_]!='\\' && sPath[cb_retVar_]!='/') {
          cb_retVar_++;
          goto Copy0000;
        }
        if (cb_retVar_) {
Copy0000: ;
          cb_MemCopy(self->m_sPath,sPath,cb_retVar_);
        }
      }
      self->m_sPath[cb_retVar_] = '\0';
    }
  }
  cb_retVar_ = cb_DCBFill(self->hWnd);
  if (sBuf) { cb_MemFreeM(sBuf); }
  return cb_retVar_;
}


cb_PString ucDriveComboBox_GetText (ucDriveComboBox* self,cb_Integer Index,void* dst,cb_Integer iLen)
{
  if (dst==NULL) {
    dst = self->m_sTemp;
  }
  return cb_DCBGetText(self->hWnd,Index,dst,iLen);
}


cb_Integer ucDriveComboBox_DoEvents (ucDriveComboBox* self,HWND hWnd,cb_UInteger uMsg,WPARAM wParam,LPARAM lParam)
{
  {  /* Select Case uMsg? */
    register cb_Integer cb_caseVar_1; cb_caseVar_1 = (cb_Integer)(uMsg);
    if (cb_caseVar_1==WM_MEASUREITEM) {
      if (wParam==self->m_id) {
        DriveComboBox_Measure(&self->buf,self->Combo1,(MEASUREITEMSTRUCT*)lParam);
        return TRUE;
      }
      goto EndSelect_0;
    }
    if (cb_caseVar_1==WM_DRAWITEM) {
      if (wParam==self->m_id) {
        DriveComboBox_Draw(&self->buf,self->Combo1,(DRAWITEMSTRUCT*)lParam,TRUE);
        return TRUE;
      }
    }
  }  /* End Select: cb_caseVar_1 */
  EndSelect_0:;
  return 0;
}


cb_Integer ucDriveComboBox_CallWindowProc (ucDriveComboBox* self,HWND hWnd,cb_UInteger uMsg,cb_UInteger wParam,cb_UInteger lParam)
{
  return self->oldWndProc(hWnd,uMsg,wParam,lParam);
}


static LRESULT CALLBACK ucDriveComboBox_Events_ (HWND,UINT,WPARAM,LPARAM);

static LRESULT CALLBACK ucDriveComboBox_Events_ (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
  register ucDriveComboBox* self; self = (ucDriveComboBox*)cb_GetWndData(hWnd);
  register cb_Integer i; i = uMsg;
  WNDPROC old;
  cb_Integer iRet;
  old = self->oldWndProc;
  {  /* Select Case i */
    if (i==WM_NCDESTROY) {
      if (self->OnEvents) self->OnEvents(self,hWnd,i,wParam,lParam,&iRet);
      cb_SetWindowLongPtr(hWnd,GWLP_WNDPROC,old);
      ucDriveComboBox_Destroy(self);
      goto EndSelect_0;
    }
    if (self->OnEvents) {
      if (self->OnEvents(self,hWnd,i,wParam,lParam,&iRet)) {
        i = iRet;
        goto EndCase_00;
      }
    }
    {
      i = CallWindowProc(old,hWnd,i,wParam,lParam);
    }
    EndCase_00:;
    if (uMsg==CBN_SELCHANGE) {
      self->m_Ndx = cb_CBGetIndexM(hWnd);
    }
    return i;
  }  /* End Select: i */
  EndSelect_0:;
  return DefWindowProc(hWnd,uMsg,wParam,lParam);
}


void ucDriveComboBox_Terminate (ucDriveComboBox* =NULL,HWND =NULL);

void ucDriveComboBox_Terminate (ucDriveComboBox* self,HWND hWnd)
{
  ImageList_Destroy(self->buf.hImgList);
}


cb_Integer cb_DEFCALL ucDriveComboBox_Initialize (ucDriveComboBox* =NULL,HWND =NULL,cb_Integer =cb_MIN_INTEGER32,cb_Integer =cb_MIN_INTEGER32,cb_Integer =-1,cb_Integer =-1,cb_Integer =0,const cb_String =NULL,HFONT =NULL,cb_Integer =-1,cb_Integer =-1);

cb_Integer cb_DEFCALL ucDriveComboBox_Initialize (ucDriveComboBox* self,HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const cb_String sCaption,HFONT hFont,cb_Integer iStyle,cb_Integer iExStyle)
{
  self->buf.nBitmapYOff = -1;
  hWnd = self->Combo1;
  self->hWnd = hWnd;
  self->oldWndProc = cb_SetSubClassWnd(hWnd,&ucDriveComboBox_Events_,cb_EMPTYSTR);
  COMBOBOXINFO c1;
  cb_CLEAR1(c1);
  c1.cbSize = sizeof(c1);
  GetComboBoxInfo(hWnd,&c1);
  int s; s = GetWindowLongPtr(hWnd,GWL_STYLE);
  cb_SendMessage(hWnd,WM_SETREDRAW,FALSE,0);
  cb_DCBFill(hWnd);
  DriveComboBox_SetSmallIcons(&self->buf,hWnd);
  cb_SendMessage(hWnd,CB_SETCURSEL,0,0);
  cb_SendMessage(hWnd,WM_SETREDRAW,TRUE,0);
  if ((s & WS_VISIBLE)!=0) {
    cb_Redraw(hWnd);
  }
  else {
    cb_SetWindowLongPtr(hWnd,GWL_STYLE,s);
  }
  self->m_id = id;
  return 0;
}


ucDriveComboBox* ucDriveComboBox_Create (ucDriveComboBox* self,HWND hWnd,void* clsParent,void* clsMain,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const cb_String sCaption,HFONT hFont,cb_Integer iStyle,cb_Integer iExStyle)
{
  if (self) {
    cb_CLEAR1(*self);
  }
  else {
    self = (ucDriveComboBox*)cb_MemAllocM(sizeof(ucDriveComboBox));
    if (self==NULL) {
      return NULL;
    }
    cb_CLEAR1(*self);
    self->flag1_++;
  }
  register HWND hWin; hWin = hWnd;
  self->hWndParent = hWin;
  self->clsParent = clsParent;
  self->clsMain = clsMain;
  if (!(clsMain)) {
    self->clsMain = self;
  }
  self->Combo1 = cb_CreateComboBox(hWin,X,Y,W,100,id_ucDriveComboBox_Combo1,0,NULL,iStyle | CBS_HASSTRINGS | CBS_DROPDOWNLIST | CBS_OWNERDRAWFIXED | CBS_AUTOHSCROLL | WS_VSCROLL | WS_CHILD | CBS_DROPDOWN | WS_TABSTOP | WS_VISIBLE,-1);
  cb_SetWndData(self->Combo1,self);
  ucDriveComboBox_Initialize(self,hWin,X,Y,W,H,id,sCaption,hFont,iStyle,iExStyle);
  return self;
}


void ucDriveComboBox_Destroy (ucDriveComboBox* self)
{
  #define hWin self->hWndParent
  cb_DeleteObject(self->hBrush);
  self->hBrush = NULL;
  ucDriveComboBox_Terminate(self,hWin);
  cb_DeleteObject(self->hBrush);
  self->hBrush = NULL;
  if ((self->flag1_ & TRUE)!=0) {
    cb_MemFreeM(self);
  }
  else {
    self->clsMain = NULL;
    self->clsParent = NULL;
    self->hWnd = NULL;
    self->hWndParent = NULL;
  }
  #undef hWin
}
/* END MODULE */
/* MODULE::ucDirListBox */
#define id_ucDirListBox_List1 id
cb_Integer ucDirListBox_refCnt_;


void ucDirListBox_SetBackColor (ucDirListBox* self,COLORREF iColor,cb_Integer bRefresh)
{
  self->BackColor = iColor;
  if (self->hBrush) {
    cb_DeleteObject(self->hBrush);
    self->hBrush = NULL;
  }
  if (bRefresh) {
    InvalidateRect(self->hWnd, 0, 0);
  }
}


const cb_PString ucDirListBox_GetPath (ucDirListBox* self)
{
  return self->m_sPath;
}


cb_Integer ucDirListBox_SetPath (ucDirListBox* self,const cb_String sPath,cb_Integer iFlag)
{
  cb_Integer cb_retVar_;
  char *sBuf; sBuf = (char*)cb_MemAllocM(cb_MAX_FILE_NAME*2);
  if (sPath==NULL || sPath[0]==0) {
    sPath = cb_GetCurrentDir(0,sBuf);
  }
  #define Buf1 (sBuf + cb_MAX_FILE_NAME)
  cb_StrCopy(Buf1,self->m_sPath);
  if (cb_MemComp(sPath,"..",2+1)==0) {
    cb_GetFilePath(self->m_sPath,self->m_sPath);
  }
  else if (cb_MemComp(sPath,".",1+1)!=0) {
    if (cb_InChars(sPath,":\\/")<0) {
      cb_StrConCat(self->m_sPath,"\\",sPath,NULL);
    }
    else {
      if (sPath[0]=='\\' || sPath[0]=='/') {
        sPath++;
      }
      cb_retVar_ = cb_StrLen(sPath);
      if (cb_retVar_) {
        cb_retVar_--;
        if (sPath[cb_retVar_]!='\\' && sPath[cb_retVar_]!='/') {
          cb_retVar_++;
          goto Copy0000;
        }
        if (cb_retVar_) {
Copy0000: ;
          cb_MemCopy(self->m_sPath,sPath,cb_retVar_);
        }
      }
      self->m_sPath[cb_retVar_] = '\0';
    }
  }
  int s; s = GetWindowLongPtr(self->hWnd,GWL_STYLE);
  cb_SendMessage(self->hWnd,WM_SETREDRAW,FALSE,0);
  do {
    cb_DLBDir(self->hWnd,"*.*",self->m_sPath);
    if (!iFlag) {
      break;
    }
    cb_retVar_ = cb_LBGetCount(self->hWnd);
    if (cb_retVar_>0 || Buf1[0]==0) {
      break;
    }
    cb_StrCopy(self->m_sPath,Buf1);
    Buf1[0] = '\0';
  } while(1);
  cb_SendMessage(self->hWnd,LB_SETCURSEL,0,0);
  cb_SendMessage(self->hWnd,WM_SETREDRAW,TRUE,0);
  if ((s & WS_VISIBLE)!=0) {
    cb_Redraw(self->hWnd);
  }
  else {
    cb_SetWindowLongPtr(self->hWnd,GWL_STYLE,s);
  }
  if (sBuf) { cb_MemFreeM(sBuf); }
  return cb_retVar_;
  #undef Buf1
}


cb_PString ucDirListBox_GetText (ucDirListBox* self,cb_Integer Index,void* dst)
{
  if (dst==NULL) {
    dst = self->m_sTemp;
  }
  return cb_FLBGetText(self->hWnd,Index,dst);
}


cb_Integer ucDirListBox_DoEvents (ucDirListBox* self,HWND hWnd,cb_UInteger uMsg,WPARAM wParam,LPARAM lParam)
{
  {  /* Select Case uMsg? */
    register cb_Integer cb_caseVar_1; cb_caseVar_1 = (cb_Integer)(uMsg);
    if (cb_caseVar_1==WM_MEASUREITEM) {
      if (wParam==self->m_id) {
        DirListBox_Measure(&self->buf,self->List1,(MEASUREITEMSTRUCT*)lParam);
        return TRUE;
      }
      goto EndSelect_0;
    }
    if (cb_caseVar_1==WM_DRAWITEM) {
      if (wParam==self->m_id) {
        DirListBox_Draw(&self->buf,self->List1,(DRAWITEMSTRUCT*)lParam,TRUE);
        return TRUE;
      }
    }
  }  /* End Select: cb_caseVar_1 */
  EndSelect_0:;
  return 0;
}


cb_Integer ucDirListBox_CallWindowProc (ucDirListBox* self,HWND hWnd,cb_UInteger uMsg,cb_UInteger wParam,cb_UInteger lParam)
{
  return self->oldWndProc(hWnd,uMsg,wParam,lParam);
}


static LRESULT CALLBACK ucDirListBox_Events_ (HWND,UINT,WPARAM,LPARAM);

static LRESULT CALLBACK ucDirListBox_Events_ (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
  register ucDirListBox* self; self = (ucDirListBox*)cb_GetWndData(hWnd);
  register cb_Integer i; i = uMsg;
  WNDPROC old;
  cb_Integer iRet;
  WIN32_FIND_DATA b;
  old = self->oldWndProc;
  {  /* Select Case i */
    if (i==LB_DIR) {
      iRet = (cb_Integer)FindFirstFile((const cb_String)lParam,&b);
      i = LB_ERR;
      if (iRet) {
        do {
          if (b.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            if (cb_LowShort(b.cFileName)!='.') {
              i = cb_LBAddStr(hWnd,b.cFileName);
              if (i<0) {
                break;
              }
            }
          }
        } while(FindNextFile((HANDLE)iRet,&b));
        CloseHandle((HANDLE)iRet);
      }
      return i;
    }
    if (i==WM_NCDESTROY) {
      if (self->OnEvents) self->OnEvents(self,hWnd,i,wParam,lParam,&iRet);
      cb_SetWindowLongPtr(hWnd,GWLP_WNDPROC,old);
      ucDirListBox_Destroy(self);
      goto EndSelect_0;
    }
    if (self->OnEvents) {
      if (self->OnEvents(self,hWnd,i,wParam,lParam,&iRet)) {
        i = iRet;
        goto EndCase_00;
      }
    }
    {
      i = CallWindowProc(old,hWnd,i,wParam,lParam);
    }
    EndCase_00:;
    if (uMsg==LBN_SELCHANGE) {
      self->m_Ndx = cb_LBGetIndexM(hWnd);
    }
    return i;
  }  /* End Select: i */
  EndSelect_0:;
  return DefWindowProc(hWnd,uMsg,wParam,lParam);
}


void ucDirListBox_Terminate (ucDirListBox* =NULL,HWND =NULL);

void ucDirListBox_Terminate (ucDirListBox* self,HWND hWnd)
{
  ImageList_Destroy(self->buf.hImgList);
}


cb_Integer cb_DEFCALL ucDirListBox_Initialize (ucDirListBox* =NULL,HWND =NULL,cb_Integer =cb_MIN_INTEGER32,cb_Integer =cb_MIN_INTEGER32,cb_Integer =-1,cb_Integer =-1,cb_Integer =0,const cb_String =NULL,HFONT =NULL,cb_Integer =-1,cb_Integer =-1);

cb_Integer cb_DEFCALL ucDirListBox_Initialize (ucDirListBox* self,HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const cb_String sCaption,HFONT hFont,cb_Integer iStyle,cb_Integer iExStyle)
{
  self->buf.nBitmapYOff = -1;
  hWnd = self->List1;
  self->hWnd = hWnd;
  self->oldWndProc = cb_SetSubClassWnd(hWnd,&ucDirListBox_Events_,cb_EMPTYSTR);
  self->m_id = id;
  DirListBox_SetSmallIcons(&self->buf,hWnd);
  return 0;
}


ucDirListBox* ucDirListBox_Create (ucDirListBox* self,HWND hWnd,void* clsParent,void* clsMain,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const cb_String sCaption,HFONT hFont,cb_Integer iStyle,cb_Integer iExStyle)
{
  if (self) {
    cb_CLEAR1(*self);
  }
  else {
    self = (ucDirListBox*)cb_MemAllocM(sizeof(ucDirListBox));
    if (self==NULL) {
      return NULL;
    }
    cb_CLEAR1(*self);
    self->flag1_++;
  }
  register HWND hWin; hWin = hWnd;
  self->hWndParent = hWin;
  self->clsParent = clsParent;
  self->clsMain = clsMain;
  if (!(clsMain)) {
    self->clsMain = self;
  }
  self->List1 = cb_CreateListBox(hWin,X,Y,W,H,id_ucDirListBox_List1,0,NULL,iStyle | LBS_HASSTRINGS | LBS_NOTIFY | LBS_NOINTEGRALHEIGHT | LBS_OWNERDRAWFIXED | WS_HSCROLL | WS_VSCROLL | LBS_WANTKEYBOARDINPUT | WS_CHILD | WS_TABSTOP | WS_VISIBLE,-1);
  cb_SetWndData(self->List1,self);
  ucDirListBox_Initialize(self,hWin,X,Y,W,H,id,sCaption,hFont,iStyle,iExStyle);
  return self;
}


void ucDirListBox_Destroy (ucDirListBox* self)
{
  #define hWin self->hWndParent
  cb_DeleteObject(self->hBrush);
  self->hBrush = NULL;
  ucDirListBox_Terminate(self,hWin);
  cb_DeleteObject(self->hBrush);
  self->hBrush = NULL;
  if ((self->flag1_ & TRUE)!=0) {
    cb_MemFreeM(self);
  }
  else {
    self->clsMain = NULL;
    self->clsParent = NULL;
    self->hWnd = NULL;
    self->hWndParent = NULL;
  }
  #undef hWin
}
/* END MODULE */
/* MODULE::ucFileListBox */
#define id_ucFileListBox_List1 id
cb_Integer ucFileListBox_refCnt_;


void ucFileListBox_SetBackColor (ucFileListBox* self,COLORREF iColor,cb_Integer bRefresh)
{
  self->BackColor = iColor;
  if (self->hBrush) {
    cb_DeleteObject(self->hBrush);
    self->hBrush = NULL;
  }
  if (bRefresh) {
    InvalidateRect(self->hWnd, 0, 0);
  }
}


const cb_PString ucFileListBox_GetPath (ucFileListBox* self)
{
  return self->m_sPath;
}


cb_Integer ucFileListBox_SetPath (ucFileListBox* self,const cb_String sPath)
{
  cb_Integer cb_retVar_;
  char *sBuf; sBuf = (char*)cb_MemAllocM(cb_MAX_FILE_NAME);
  if (sPath==NULL || sPath[0]==0) {
    sPath = cb_GetCurrentDir(0,sBuf);
  }
  if (cb_MemComp(sPath,"..",2+1)==0) {
    cb_GetFilePath(self->m_sPath,self->m_sPath);
  }
  else if (cb_MemComp(sPath,".",1+1)!=0) {
    if (cb_InChars(sPath,":\\/")<0) {
      cb_StrConCat(self->m_sPath,"\\",sPath,NULL);
    }
    else {
      if (sPath[0]=='\\' || sPath[0]=='/') {
        sPath++;
      }
      cb_retVar_ = cb_StrLen(sPath);
      if (cb_retVar_) {
        cb_retVar_--;
        if (sPath[cb_retVar_]!='\\' && sPath[cb_retVar_]!='/') {
          cb_retVar_++;
          goto Copy0000;
        }
        if (cb_retVar_) {
Copy0000: ;
          cb_MemCopy(self->m_sPath,sPath,cb_retVar_);
        }
      }
      self->m_sPath[cb_retVar_] = '\0';
    }
  }
  int s; s = GetWindowLongPtr(self->hWnd,GWL_STYLE);
  cb_SendMessage(self->hWnd,WM_SETREDRAW,FALSE,0);
  cb_FLBDir(self->hWnd,"*.*",self->m_sPath);
  cb_retVar_ = cb_LBGetCount(self->hWnd);
  cb_SendMessage(self->hWnd,LB_SETCURSEL,0,0);
  cb_SendMessage(self->hWnd,WM_SETREDRAW,TRUE,0);
  if ((s & WS_VISIBLE)!=0) {
    cb_Redraw(self->hWnd);
  }
  else {
    cb_SetWindowLongPtr(self->hWnd,GWL_STYLE,s);
  }
  if (sBuf) { cb_MemFreeM(sBuf); }
  return cb_retVar_;
}


cb_PString ucFileListBox_GetText (ucFileListBox* self,cb_Integer Index,void* dst)
{
  if (dst==NULL) {
    dst = self->m_sTemp;
  }
  return cb_FLBGetText(self->hWnd,Index,dst);
}


cb_Integer ucFileListBox_DoEvents (ucFileListBox* self,HWND hWnd,cb_UInteger uMsg,WPARAM wParam,LPARAM lParam)
{
  {  /* Select Case uMsg? */
    register cb_Integer cb_caseVar_1; cb_caseVar_1 = (cb_Integer)(uMsg);
    if (cb_caseVar_1==WM_MEASUREITEM) {
      if (wParam==self->m_id) {
        FileListBox_Measure(&self->buf,self->List1,(MEASUREITEMSTRUCT*)lParam);
        return TRUE;
      }
      goto EndSelect_0;
    }
    if (cb_caseVar_1==WM_DRAWITEM) {
      if (wParam==self->m_id) {
        FileListBox_Draw(&self->buf,self->List1,(DRAWITEMSTRUCT*)lParam,TRUE);
        return TRUE;
      }
    }
  }  /* End Select: cb_caseVar_1 */
  EndSelect_0:;
  return 0;
}


cb_Integer ucFileListBox_CallWindowProc (ucFileListBox* self,HWND hWnd,cb_UInteger uMsg,cb_UInteger wParam,cb_UInteger lParam)
{
  return self->oldWndProc(hWnd,uMsg,wParam,lParam);
}


static LRESULT CALLBACK ucFileListBox_Events_ (HWND,UINT,WPARAM,LPARAM);

static LRESULT CALLBACK ucFileListBox_Events_ (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
  register ucFileListBox* self; self = (ucFileListBox*)cb_GetWndData(hWnd);
  register cb_Integer i; i = uMsg;
  WNDPROC old;
  cb_Integer iRet;
  old = self->oldWndProc;
  {  /* Select Case i */
    if (i==WM_NCDESTROY) {
      if (self->OnEvents) self->OnEvents(self,hWnd,i,wParam,lParam,&iRet);
      cb_SetWindowLongPtr(hWnd,GWLP_WNDPROC,old);
      ucFileListBox_Destroy(self);
      goto EndSelect_0;
    }
    if (self->OnEvents) {
      if (self->OnEvents(self,hWnd,i,wParam,lParam,&iRet)) {
        i = iRet;
        goto EndCase_00;
      }
    }
    {
      i = CallWindowProc(old,hWnd,i,wParam,lParam);
    }
    EndCase_00:;
    if (uMsg==LBN_SELCHANGE) {
      self->m_Ndx = cb_LBGetIndexM(hWnd);
    }
    return i;
  }  /* End Select: i */
  EndSelect_0:;
  return DefWindowProc(hWnd,uMsg,wParam,lParam);
}


cb_Integer cb_DEFCALL ucFileListBox_Initialize (ucFileListBox* =NULL,HWND =NULL,cb_Integer =cb_MIN_INTEGER32,cb_Integer =cb_MIN_INTEGER32,cb_Integer =-1,cb_Integer =-1,cb_Integer =0,const cb_String =NULL,HFONT =NULL,cb_Integer =-1,cb_Integer =-1);

cb_Integer cb_DEFCALL ucFileListBox_Initialize (ucFileListBox* self,HWND hWnd,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const cb_String sCaption,HFONT hFont,cb_Integer iStyle,cb_Integer iExStyle)
{
  self->buf.sPath = self->m_sPath;
  self->buf.nBitmapYOff = -1;
  hWnd = self->List1;
  self->hWnd = hWnd;
  self->oldWndProc = cb_SetSubClassWnd(hWnd,&ucFileListBox_Events_,cb_EMPTYSTR);
  self->m_id = id;
  return 0;
}


ucFileListBox* ucFileListBox_Create (ucFileListBox* self,HWND hWnd,void* clsParent,void* clsMain,cb_Integer X,cb_Integer Y,cb_Integer W,cb_Integer H,cb_Integer id,const cb_String sCaption,HFONT hFont,cb_Integer iStyle,cb_Integer iExStyle)
{
  if (self) {
    cb_CLEAR1(*self);
  }
  else {
    self = (ucFileListBox*)cb_MemAllocM(sizeof(ucFileListBox));
    if (self==NULL) {
      return NULL;
    }
    cb_CLEAR1(*self);
    self->flag1_++;
  }
  register HWND hWin; hWin = hWnd;
  self->hWndParent = hWin;
  self->clsParent = clsParent;
  self->clsMain = clsMain;
  if (!(clsMain)) {
    self->clsMain = self;
  }
  self->List1 = cb_CreateListBox(hWin,X,Y,W,H,id_ucFileListBox_List1,0,NULL,iStyle | LBS_HASSTRINGS | LBS_NOTIFY | LBS_NOINTEGRALHEIGHT | LBS_OWNERDRAWFIXED | WS_HSCROLL | WS_VSCROLL | LBS_WANTKEYBOARDINPUT | WS_CHILD | WS_TABSTOP | WS_VISIBLE,-1);
  cb_SetWndData(self->List1,self);
  ucFileListBox_Initialize(self,hWin,X,Y,W,H,id,sCaption,hFont,iStyle,iExStyle);
  return self;
}


void ucFileListBox_Destroy (ucFileListBox* self)
{
  #define hWin self->hWndParent
  cb_DeleteObject(self->hBrush);
  self->hBrush = NULL;
  cb_DeleteObject(self->hBrush);
  self->hBrush = NULL;
  if ((self->flag1_ & TRUE)!=0) {
    cb_MemFreeM(self);
  }
  else {
    self->clsMain = NULL;
    self->clsParent = NULL;
    self->hWnd = NULL;
    self->hWndParent = NULL;
  }
  #undef hWin
}
/* END MODULE */
/* MODULE::knr2ansi */


cb_Integer knr2ansi_convert (cb_String str1,cb_Integer sze,cb_Integer indent)
{
  #define isid(x) (x=='_' || cb_IsDigit(x) || cb_IsAlpha(x))
  char* p1; p1 = str1;
  char* p2;
  char* p3; p3 = NULL;
  char* p4;
  cb_Integer i;
  cb_Integer in; in = 0;
  cb_Integer n;
  cb_Integer o;
  cb_Integer h;
  cb_Integer f; f = indent & (-1 ^ (knr2ansi_MAX_INDENT-1));
#ifndef knr2ansi__
  cb_Integer c; c = 0;
  char* p5;
  char* p6; p6 = NULL;
  char* p7; p7 = NULL;
#endif
  cb_PString buf1;
  cb_PString buf2;
  char buf[1*0x400];
  indent &= knr2ansi_MAX_INDENT-1;
  if (sze<0) {
    sze = cb_StrLen(p1);
  }
  n = sze;
  sze++;
  goto Start0000;
Quotes0000: ;
  o = p1[0];
  do {
    p1++;
    sze--;
    if (sze<=0) {
      goto Exitfor0000;
    }
    if (p1[0]==o) {
      break;
    }
    if (p1[0]=='\\') {
      p1++;
      sze--;
      if (sze<=0) {
        goto Exitfor0000;
      }
    }
  } while(1);
  cb_glReturnSub;
Rtrim0000: ;
  p2 = p1;
  while(p1!=str1) {
    p1--;
    if (cb_ASC1(p1)>' ' || p1[0]=='\r' || p1[0]=='\n') {
      p1++;
      break;
    }
  }
  if (p1!=p2) {
    if (sze>0) {
      cb_MemCopy(p1,p2,sze);
    }
    n -= (cb_Integer)p2 - (cb_Integer)p1;
  }
  cb_glReturnSub;
Again0000: ;
  for (;sze>=1;sze--) {
    {  /* Select Case cb_ASC1(p1) */
      if ((cb_ASC1(p1)=='\'') || (cb_ASC1(p1)=='"')) {
        cb_glGoSub(Quotes0000, 1);
        goto Chk0000;
Comments000: ;
        if (f & (cb_MIN_INTEGER32 | 1)) {
          if (sze>0) {
            cb_MemCopy(p4,p1,sze);
          }
          n -= (int)p1 - (int)p4;
          p1 = p4;
        }
        cb_glReturnSub;
Comments0000: ;
        p4 = p1;
        h = sze;
        p1++;
        sze--;
        if (p1[0]=='/') {
#ifdef knr2ansi__
Comments0001: ;
#endif
          do {
            p1++;
            sze--;
            if (sze<=0) {
              cb_glGoSub(Comments000, 2);
              cb_glGoSub(Rtrim0000, 3);
Exitfor0000: ;
              cb_glResumeForward;
              goto EndFor_2;
            }
          } while(!(p1[0]=='\r' || p1[0]=='\n'));
          cb_glGoSub(Comments000, 4);
          cb_glReturnSub;
        }
        if (p1[0]!='*') {
          p1--;
          sze++;
          cb_glReturnSub;
        }
        do {
          p1++;
          sze--;
          if (sze<=0) {
            break;
          }
          if (p1[0]=='"') {
            cb_glGoSub(Quotes0000, 5);
            continue;
          }
          while(p1[0]=='*') {
            p1++;
            sze--;
            if (sze<=0) {
              goto EndRepeat_5;
            }
            if (p1[0]=='/') {
              p1++;
              sze--;
              cb_glGoSub(Comments000, 6);
              f |= 2;
              cb_glReturnSub;
            }
          }
        } while(1);
        EndRepeat_5:;
        p1 = p4;
        sze = h;
        cb_glReturnSub;
      }
      if (cb_ASC1(p1)=='/') {
        if (sze>1) {
          cb_glGoSub(Comments0000, 7);
          if (f & 2) {
            f &=  ~2;
            goto Again0000;
          }
          if (p1[0]=='\n') {
            goto Lf0000;
          }
          if (p1[0]=='\r') {
            goto Cr0000;
          }
        }
Chk0000: ;
        if (!p3) {
          goto EndCase_30;
        }
        goto EndSelect_3;
      }
      if (cb_ASC1(p1)=='\r') {
Cr0000: ;
        cb_glGoSub(Rtrim0000, 8);
        if (p3) {
          goto Endline0000;
        }
        if (sze>1) {
          if (p1[1]=='\n') {
            p1++;
            sze--;
          }
          goto Lf0001;
Getline0000: ;
          f |= 1;
        }
        goto EndSelect_3;
      }
      if (cb_ASC1(p1)=='\n') {
Lf0000: ;
        cb_glGoSub(Rtrim0000, 9);
        if (p3) {
Endline0000: ;
          f &=  ~1;
          o = p1[0];
          cb_glReturnSub;
        }
Lf0001: ;
        do {
          p1++;
Start0000: ;
          p2 = p1;
          do {
            sze--;
Again000: ;
            if (sze<=0) {
              n -= cb_CASTrev(p1,cb_Integer) - cb_CASTrev(p2,cb_Integer);
              goto EndFor_2;
            }
            if (cb_ASC1(p1)>' ') {
              break;
            }
            if (p1[0]=='\n') {
              if (in>0) {
                if (p1!=p2) {
                  n -= cb_CASTrev(p1,cb_Integer) - cb_CASTrev(p2,cb_Integer);
                  p1 = (char*)cb_MemCopy(p2,p1,sze);
                }
              }
              goto IterateDo_7;
            }
            if (p1[0]=='\r') {
              if (in>0) {
                if (p1!=p2) {
                  n -= cb_CASTrev(p1,cb_Integer) - cb_CASTrev(p2,cb_Integer);
                  p1 = (char*)cb_MemCopy(p2,p1,sze);
                }
              }
              goto Cont0001;
            }
            p1++;
          } while(1);
          if (p1[0]=='/') {
            cb_glGoSub(Comments0000, 10);
            if (f & 2) {
              f &=  ~2;
              if (!(f & (cb_MIN_INTEGER32 | 1))) {
                p2 = p1;
              }
              goto Again000;
            }
            if (p1[0]=='/') {
#ifdef knr2ansi__
              break;
#else
              goto Reset0000;
#endif
            }
            cb_glGoSub(Rtrim0000, 11);
#ifdef knr2ansi__
          }
          else if (p1[0]==';') {
            p4 = p1;
            cb_glGoSub(Comments0001, 12);
            cb_glGoSub(Rtrim0000, 13);
#endif
          }
          else {
#ifdef knr2ansi__
            p3 = p1;
            if (p1[0]!='.') {
              cb_glGoSub(Getword0000, 14);
              if (p3==p1) {
                break;
              }
              p1[0] = '\0';
              if (cb_InWord(p3,"add and cmp dec inc mov or pop push sub xor")>=0) {
                p1[0] = o;
                p3 = p1;
                cb_glGoSub(Getline0000, 15);
                h = p1[0];
                p1[0] = '\0';
                p4 = p1;
                p1 = cb_LTrim(p3,(void*)-2);
                do {
                  p2 = p1;
                  cb_glGoSub(Getword0000, 16);
                  if (p2==p1) {
                    p1 = p4;
                    p1[0] = h;
                    break;
                  }
                  cb_LCaseX(p2,buf,cb_CASTrev(p1,cb_Integer) - cb_CASTrev(p2,cb_Integer));
                  o = cb_InWord(buf," dword qword word byte offset ptr al ah bl bh cl ch dl dh ax bx cx dx si di bp sp eax ebx ecx edx esi edi ebp esp rax rbx rcx rdx rsi rdi rbp rsp ");
                  if (o<0) {
                    p4[0] = h;
                    for (;cb_ASC1(p1)>' ';p1++) {
                    }
                    cb_StrMove(p1+1, p1);
                    p1[0] = ']';
                    cb_StrMove(p2+1, p2);
                    p2[0] = '[';
                    p1 = p4;
                    p1 += 2;
                    n += 2;
                    break;
                  }
                  p1 = cb_LTrim(p1,(void*)-2);
                  if (p1[0]==',') {
                    p1 = cb_LTrim(p1+1,(void*)-2);
                  }
                } while(1);
              }
              else {
                p1[0] = o;
                i = cb_CASTrev(p1,cb_Integer);
                i -= cb_CASTrev(p3,cb_Integer);
                p1 = cb_LTrim(p1,(void*)-2);
                p2 = p1;
                cb_glGoSub(Getword0000, 17);
                p1[0] = '\0';
                {  /* Select Case o */
                  if (o!='\t' && o!=' ') {
                    goto EndSelect_B;
                  }
                  /* Select Case p2$ */
                  if (cb_MemComp(p2,"proc",4+1)==0) {
                    cb_MemMove(p3+4+1,p3,i);
                    cb_MemCopy(p3,"proc ",4+1);
                    goto EndSelect_B;
                  }
                  if (cb_MemComp(p2,"macro",5+1)==0) {
                    cb_MemMove(p3+5+1,p3,i);
                    cb_MemCopy(p3,"macro ",5+1);
                    goto EndSelect_B;
                  }
                  if (cb_MemComp(p2,"endp",4+1)==0) {
                    cb_StrMove(p3,p2);
                    goto EndSelect_B;
                  }
                  if (cb_MemComp(p2,"endm",4+1)==0) {
                    cb_StrMove(p3,p2);
                    cb_MemCopy(p3,"}   ",1+3);
                    goto EndSelect_B;
                  }
                  if (cb_MemComp(p2,"include",7+1)==0) {
                    p1[0] = o;
                    cb_glGoSub(Getline0000, 18);
                    p1[0] = '\0';
                    p2 = cb_LTrim(p2+7,(void*)-2);
                    buf1 = cb_CASTrev(cb_MemAllocM(knr2ansi_MAX_FILE_NAME*2),cb_String);
                    cb_StrCopy(buf1,p2);
                    cb_CharsRemove(buf1, "\"", buf1);
                    h = cb_InCharsRev(buf1,"/" ".");
                    if (h>=0) {
                      if (buf1[h]=='.') {
                        buf1[h] = '\0';
                      }
                    }
                    if (f & knr2ansi_INCLUDE_BIT) {
                      p4 = cb_CASTrev(knr2ansi_file(buf1,&h,f | indent),cb_String);
                      if (!p3) {
                        goto Includeerror0000;
                      }
                      buf2 = buf1 + knr2ansi_MAX_FILE_NAME;
                      buf2[0] = '\0';
/* todo after include */
                      goto Includeok0000;
                    }
                    buf2 = cb_StrJoin(buf1 + knr2ansi_MAX_FILE_NAME,buf1,"_cvt", NULL);
                    if (h>=0) {
                      if (buf1[h]=='\0') {
                        buf1[h] = '.';
                        cb_StrCat(buf2, buf1 + h);
                      }
                    }
                    if (knr2ansi_filename(buf1,buf2,NULL,NULL,f || indent)) {
#ifdef knr2ansi__
                      cb_CharEnclose(buf2, '\'', 0, buf2);
#else
                      cb_CharEnclose(buf2, '"', 0, buf2);
#endif
Includeok0000: ;
                      h = cb_StrLen(buf2);
                      i = cb_StrLen(p2);
                      p1[0] = o;
                      cb_StrMove(p2 + h, p2 + i);
                      cb_MemCopy(p2,buf2,h);
                      i -= h;
                      p1 -= i;
                      n -= i;
                    }
                    else {
Includeerror0000: ;
                      p1[0] = o;
                    }
                    if (buf1) { cb_MemFreeM(buf1); buf1 = NULL; }
                    goto Cont0000;
                  }
                  if (cb_MemComp(p2,"includelib",10+1)==0) {
                    p1[0] = o;
                    cb_glGoSub(Getline0000, 19);
                    p3[0] = ';';
                    goto Cont0000;
                  }
                }  /* End Select: p2$ */
                EndSelect_B:;
                p1[0] = o;
              }
//todo chk for register/var and surround with '[]' if needed
              p3 = NULL;
              break;
            }
#else
            if (p1[0]!='#') {
              break;
            }
            p3 = p1;
#endif
            cb_glGoSub(Getline0000, 20);
            p1[0] = '\0';
            p2 = p3+1;
#ifdef knr2ansi__
            if ((*(int*)p2 & 0x00df)=='FI') {
              if (!(isid(p2[2]))) {
                cb_MemCopy(p3,"if ",2+1);
              }
            }
            else if ((*(cb_Int64*)p2 & (cb_Int64)0x00dfdfdfdfdfdf)==0x464945534C45/*'FIESLE'*/) {
              if (!(isid(p2[6]))) {
                cb_MemCopy(p3,"else if",4+1+2);
                p2 += 6;
                p2 -= (int)p3-4-1-2;
                if (p2) {
                  cb_StrSet((int)p2, ' ',p3+4+1+2);
                }
              }
            }
            else if ((*(cb_Int64*)p2 & (cb_Int64)0x00dfdfdfdfdf)==0x4649444E45/*'FIDNE'*/) {
              if (!(isid(p2[5]))) {
                cb_MemCopy(p3,"end if",3+1+2);
                p2 += 5;
                p2 -= (int)p3-3-1-2;
                if (p2) {
                  cb_StrSet((int)p2, ' ',p3+3+1+2);
                }
              }
            }
            else if ((*(int*)p2 & 0x00dfdfdfdf)=='EDOC') {
              if (!(isid(p2[4]))) {
                cb_StrMove(p2+7+1+7,p2);
                cb_MemCopy(p3,"section '.text' ",7+1+7+1);
                cb_StrMove(p2+7+1+7+1+4+1+8+1+10,p2+7+1+7+1+4);
                cb_MemCopy(p2+7+1+7+1+4," readable executable",1+8+1+10);
              }
            }
            else if ((*(int*)p2 & 0x00dfdfdfdf)=='ATAD') {
              if (p2[4]=='\?') {
                cb_StrMove(p3+7+1+6+1+8+1+9,p2+4+1);
                cb_MemCopy(p3,"section '.bss' readable writeable",7+1+6+1+8+1+9);
              }
            }
            else if (!(isid(p2[4]))) {
              cb_StrMove(p2+7+1+7,p2);
              cb_MemCopy(p3,"section '.data' ",7+1+7+1);
              cb_StrMove(p2+7+1+7+1+4+1+8+1+9,p2+7+1+7+1+4);
              cb_MemCopy(p2+7+1+7+1+4," readable writeable",1+8+1+9);
            }
            else {
              p3[0] = ';';
            }
#else
            if ((*(cb_Int64*)p2 & (cb_Int64)0x00dfdfdfdfdfdfdf)==0x4544554C434E49/*'EDULCNI'*/) {
              if (!(isid(p2[7]))) {
                p2 = cb_LTrim(p2+7,(void*)-2);
                buf1 = cb_CASTrev(cb_MemAllocM(knr2ansi_MAX_FILE_NAME*2),cb_String);
                cb_StrCopy(buf1,p2);
                cb_CharsRemove(buf1, "\"", buf1);
                h = cb_InCharsRev(buf1,"/" ".");
                if (h>=0) {
                  if (buf1[h]=='.') {
                    buf1[h] = '\0';
                  }
                }
                if (f & knr2ansi_INCLUDE_BIT) {
                  p4 = cb_CASTrev(knr2ansi_file(buf1,&h,f | indent),cb_String);
                  if (!p3) {
                    goto Includeerror0000;
                  }
                  buf2 = buf1 + knr2ansi_MAX_FILE_NAME;
                  buf2[0] = '\0';
/* todo after include */
                  goto Includeok0000;
                }
                buf2 = cb_StrJoin(buf1 + knr2ansi_MAX_FILE_NAME,buf1,"_cvt", NULL);
                if (h>=0) {
                  if (buf1[h]=='\0') {
                    buf1[h] = '.';
                    cb_StrCat(buf2, buf1 + h);
                  }
                }
                if (knr2ansi_filename(buf1,buf2,NULL,NULL,f || indent)) {
#ifdef knr2ansi__
                  cb_CharEnclose(buf2, '\'', 0, buf2);
#else
                  cb_CharEnclose(buf2, '"', 0, buf2);
#endif
Includeok0000: ;
                  h = cb_StrLen(buf2);
                  i = cb_StrLen(p2);
                  p1[0] = o;
                  cb_StrMove(p2 + h, p2 + i);
                  cb_MemCopy(p2,buf2,h);
                  i -= h;
                  p1 -= i;
                  n -= i;
                }
                else {
Includeerror0000: ;
                  p1[0] = o;
                }
                if (buf1) { cb_MemFreeM(buf1); buf1 = NULL; }
                goto Cont0000;
              }
            }
            else if ((*(cb_Int64*)p2 & (cb_Int64)0x00dfdfdfdfdfdf)==0x454E49464544/*'ENIFED'*/) {
              if (!(isid(p2[6]))) {
              }
            }
#endif
            p1[0] = o;
Cont0000: ;
            p3 = NULL;
            if (o=='\r') {
Cont0001: ;
              if (sze>1) {
                if (p1[1]=='\n') {
                  p1++;
                  sze--;
                }
              }
            }
          }
IterateDo_7:;
        } while(1);
        if (in>0) {
          n -= cb_CASTrev(p1,cb_Integer) - cb_CASTrev(p2,cb_Integer);
          if (p1[0]=='}') {
            in -= indent;
          }
          cb_MemMove(p2 + in,p1,sze);
          p1 = p2;
          if (in>0) {
            cb_MemSet(p1,' ',in);
            n += in;
            p1 += in;
          }
        }
        if (cb_ASC1(p1)!='}') {
          goto Again0000;
        }
        goto Reset0000;
      }
      if ((p3) || (cb_ASC1(p1)<=' ')) {
        goto EndSelect_3;
      }
      if (cb_ASC1(p1)=='(') {
        if (!c) {
          if (!p6) {
            p6 = p1;
          }
        }
        c++;
        goto EndSelect_3;
      }
      if (cb_ASC1(p1)==')') {
        if (c<=0) {
          goto Reset0001;
        }
        c--;
        if (c==0) {
          if (p6) {
            p7 = p1;
            i = -1;
          }
        }
        goto EndSelect_3;
      }
      if (cb_ASC1(p1)==';') {
        if (c==0) {
          if (p7) {
            if (i==-1) {
              goto Reset0001;
            }
            p5 = p1;
            i = '\0';
          }
        }
        goto EndSelect_3;
      }
      if (cb_ASC1(p1)=='{') {
        in += indent;
        if (c==0) {
          if (p7) {
            if (cb_CASTrev(i,cb_UInteger)<=' ') {
              p6++;
              i = cb_CASTrev(cb_LTrim(p7+1,(void*)-2),cb_Integer);
              o = i;
              o -= (cb_Integer)str1;
              o = n - o;
              p7 = p5;
              p5[0] = ')';
              while(cb_CASTrev(p5,cb_UInteger)>cb_CASTrev(i,cb_UInteger)) {
                p5--;
                if (p5[0]==';') {
                  p5[0] = ',';
                }
              }
              cb_MemCopy(p6,cb_CASTrev(i,const cb_String),o);
              i -= (cb_Integer)p6;
              n -= i;
              p1 -= i;
              p7 -= i;
              goto Leftbracket0000;
            }
            if (i==-1) {
Leftbracket0000: ;
              if (f & knr2ansi_LEFTBRACKET_BIT) {
                do {
                  p7++;
                  if (p7==p1) {
                    break;
                  }
                  p7[0] = ' ';
                } while(1);
              }
            }
          }
        }
        goto Reset0000;
      }
      if (cb_ASC1(p1)=='}') {
        in -= indent;
        goto Reset0001;
      }
      EndCase_30:;
      if (c==0) {
        if (p7!=NULL) {
          c = i;
          i = cb_ASC1(p1);
          if (!cb_IsAlpha(i)) {
            if (!cb_IsDigit(i)) {
              if (!cb_StrChar("_[]*,.",i)) {
Reset0000: ;
                c = 0;
Reset0001: ;
                p6 = NULL;
                p7 = NULL;
                goto EndSelect_3;
              }
            }
          }
          i &= c;
          c = 0;
          if (!i) {
            p1++;
            p5 = p1;
            continue;
          }
        }
      }
    }  /* End Select: cb_ASC1(p1) */
    EndSelect_3:;
    p1++;
  }
  EndFor_2:;
  if (p3) {
    cb_glResumeForward;
  }
  return n;
  #undef isid
}


cb_Integer knr2ansi_filename (const cb_String str1,const cb_String str2,cb_File* cb_Handle1,cb_Integer* iRet,cb_Integer indent)
{
  register char* p1;
  register cb_Integer i; i = cb_FileLen(str1);
  if (i<=0) {
    return 0;
  }
  cb_Integer sze;
  p1 = (char*)cb_MemAllocM(i+2*0x100000);
  if (!p1) {
    return 0;
  }
  if (!cb_LoadFile(str1,p1,&sze,i)) {
    goto Error0000;
  }
  if (i==sze) {
    if (cb_Handle1==NULL) {
      cb_Handle1 = cb_FOpen(str2,"wbs");
      if (cb_Handle1==NULL) {
        goto Error0000;
      }
    }
    i = knr2ansi_convert(p1,i,indent);
    if (cb_Handle1!=cb_CASTrev(-1,cb_File*)) {
      if (i>0) {
        cb_FPut(cb_Handle1,p1,i);
      }
      cb_FileClose(cb_Handle1);
    }
    else if (i>0) {
      if (iRet) {
        iRet[0] = i;
      }
      return cb_CASTrev(p1,cb_Integer);
    }
  }
  else {
Error0000: ;
    i = 0;
  }
  if (p1) { cb_MemFreeM(p1); p1 = NULL; }
  return i;
}
/* END MODULE */

static void cb_UnloadUserDll (void)
{
#ifndef MAX_FILE_NAME
#endif
#ifndef NOT_TRUE
#endif
#ifndef ONE_SECOND
#endif
#ifndef ONE_MINUTE
#endif
#if !defined(USER_LIBRARY) && !defined(USE_CFILE)
#endif
#ifdef USE_LICE_BITMAP
#endif
#ifndef USE_CRT
#endif
#ifdef USE_MEMORY
#endif
#ifdef USE_MEMORY
#endif
#ifndef USE_CRT
#endif
#ifdef USE_FILE
#endif
#ifndef DriveComboBox_Type_Def
#endif
  if (cb_dll_kernel32_dll_0) FreeLibrary(cb_dll_kernel32_dll_0);
  if (cb_dll_urlmon_dll_2) FreeLibrary(cb_dll_urlmon_dll_2);
#ifndef IMAGE_SUBSYSTEM_WINDOWS_GUI
#endif
#ifndef IMAGE_SUBSYSTEM_WINDOWS_CUI
#endif
}

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Implementation -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


/*-=-=-=-=-=<  Termination  >=-=-=-=-=-*/

EXTERN_C void CodeBase_Terminate (void)
{
  register cb_Integer i;
#if !defined(USER_LIBRARY) && !defined(USE_CFILE)
  cb_cFile_OnEnd_();
#endif
  cb_URLtoFile_Terminate();
  if (cbApp_FindData.FileHandle!=INVALID_HANDLE_VALUE) { FindClose(cbApp_FindData.FileHandle); cbApp_FindData.FileHandle = INVALID_HANDLE_VALUE; }
  if (cb_hInet_) { InternetCloseHandle(cb_hInet_); cb_hInet_ = NULL; }
  cb_MIDIOutCloseDevice();
  cb_FreeTmpDynStr();
  if (cb_SocketStartedup_) WSACleanup();
  if (cbApp_hStdIn!=INVALID_HANDLE_VALUE) { CloseHandle(cbApp_hStdIn); cbApp_hStdIn = INVALID_HANDLE_VALUE; }
  if (cbApp_hStdOut!=INVALID_HANDLE_VALUE) { CloseHandle(cbApp_hStdOut); cbApp_hStdOut = INVALID_HANDLE_VALUE; }
  if (cbApp_hBrush) { DeleteObject(cbApp_hBrush); cbApp_hBrush = NULL; }
  if (cb_hRichEditLib) { FreeLibrary(cb_hRichEditLib); cb_hRichEditLib = NULL; }
  cb_comAtlAxTerm();
  if (cb_comWasInitialization) { cb_comClearTmp(); OleUninitialize(); cb_comWasInitialization--; }
  if (cb_CommandLinePtr) { cb_MemFreeM(cb_CommandLinePtr); cb_CommandLinePtr = NULL; }
  i = cb_DllCyclesMax_; do { if (cb_DllCyclesBuf_[i]) FreeLibrary(cb_DllCyclesBuf_[i]); i--; } while(i);
  cb_FileTerminate();
  cb_UnloadUserDll();
}
