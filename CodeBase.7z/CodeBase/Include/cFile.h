
#ifndef cb_cFile1_H_
#define cb_cFile1_H_

#define cb_cFile void

#endif
