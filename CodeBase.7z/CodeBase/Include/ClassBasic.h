/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*    This file was generated with    */
/*    ClassBasic - A Basic Compiler Frontend To C/C++ Compilers - (Version 1.00)    */
/*    Copyright � M.P. Labs.  All rights reserved. (R)    */
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

#ifndef ClassBasic_h_
#define ClassBasic_h_


/*((((((((((((((  Compilers/Platforms Definitions  ))))))))))))))*/


#ifdef __cplusplus
#define cb_EXPORT EXTERN_C __declspec(dllexport)
#define cb_IMPORT EXTERN_C __declspec(dllimport)
#else
#define cb_EXPORT __declspec(dllexport)
#define cb_IMPORT __declspec(dllimport)
#endif
#define cb_CDECL __cdecl
#define cb_STDCALL __stdcall
#define cb_FASTCALL __fastcall
#define cb_PASCAL PASCAL

#define __forceinline inline
#define cb_CLIBCALL cb_CDECL
#if defined(__GNUC__) || defined(__GNUG__)
#if defined __clang__
#define cb_DEFCALL
#else
#define cb_DEFCALL cb_CDECL
#endif
#else
#define cb_DEFCALL cb_STDCALL
#endif
#define cb_STRING_SIZE 4096
#define cb_MAX_FILE_NAME 2048
#define cb_INVALID ((void*)-1)
#define cb_MAX_TMPDYNSTR_CYCLES_ 0x400
#define cb_MAX_DLL_CYCLES_ 0x200
#define cb_MAX_INTEGER64 ((long long)0x7FFFFFFFFFFFFFFF)
#define cb_MAX_INTEGER32 ((long)0x7FFFFFFF)
#define cb_MAX_INTEGER16 ((short)0x7FFF)
#define cb_MAX_INTEGER8 ((char)0x7f)
#define cb_MIN_INTEGER64 ((long long)0x8000000000000000)
#define cb_MIN_INTEGER32 ((long)0x80000000)
#define cb_MIN_INTEGER16 ((short)0x8000)
#define cb_MIN_INTEGER8 ((char)0x80)
#define cb_MAX_INTEGER cb_MAX_INTEGER32
#define cb_MIN_INTEGER cb_MIN_INTEGER32
#define cb_PTR_SIZE64 8
#define cb_PTR_SIZE32 4
#define cb_PATH_SEPARATOR '\\'
#define cb_PATH_SEPARATOR_STR "\\"
#define cb_PATH_SEPARATOR_STRW "\\"
#define cb_ASC1(x) (*(unsigned char*)(x))
#define cb_ASC1W(x) (*(wchar_t*)(x))
#define cb_ASC2(x,y) (((unsigned char*)(x))[y])
#define cb_ASC2W(x,y) (((wchar_t*)(x))[y])
#define cb_AS(x) x
#define cb_CAST(x,y) ((x)(y))
#define cb_CASTRev(x,y) ((y)(x))
#define cb_CBYTE(x) ((BYTE)(x))
#define cb_CCHAR(x) ((char)(x))
#define cb_CDWD(x) ((DWORD)(x))
#define cb_CINT(x) ((int)(x))
#define cb_CLNG(x) ((long)(x))
#define cb_CSHORT(x) ((short)(x))
#define cb_CUINT(x) ((UINT)(x))
#define cb_CULNG(x) ((unsigned long)(x))
#define cb_CLNGLNG(x) ((long long)(x))
#define cb_CULNGLNG(x) ((unsigned long long)(x))
#define cb_CSNG(x) ((float)(x))
#define cb_CDBL(x) ((double)(x))
#define cb_CLDBL(x) ((long double)(x))
#define cb_CWORD(x) ((WORD)(x))
#define cb_CBOOL(x) ((x)?1:0)
#define cb_CBOOLSTR(x) ((x) ? "True" : "False")
#define cb_EQV(x,y) ~((x)^(y))
#define cb_Max(x,y) ((x)>(y)?(x):(y))
#define cb_Min(x,y) ((x)<(y)?(x):(y))
#define NOT !
#define cb_StrPtr(x) ((char*)(x))
#define cb_UBOUND1(x) ((int)((sizeof(x)/sizeof((x)[0]))-1))
#define cb_CountOf1(x) ((int)(sizeof(x)/sizeof((x)[0])))
#define cb_HIGH(x,y) ((x*)&(y))[1]
#define cb_LOW(x,y) ((x*)&(y))[0]
#define cb_HighByte(x) ((BYTE*)&(x))[1]
#define cb_LowByte(x) ((BYTE*)&(x))[0]
#define cb_HighChar(x) ((char*)&(x))[1]
#define cb_LowChar(x) ((char*)&(x))[0]
#define cb_HighDWord(x) ((DWORD*)&(x))[1]
#define cb_LowDWord(x) ((DWORD*)&(x))[0]
#define cb_HighInt(x) ((int*)&(x))[1]
#define cb_LowInt(x) ((int*)&(x))[0]
#define cb_HighLong(x) ((long*)&(x))[1]
#define cb_LowLong(x) ((long*)&(x))[0]
#define cb_HighShort(x) ((short*)&(x))[1]
#define cb_LowShort(x) ((short*)&(x))[0]
#define cb_HighUInt(x) ((UINT*)&(x))[1]
#define cb_LowUInt(x) ((UINT*)&(x))[0]
#define cb_HighWord(x) ((WORD*)&(x))[1]
#define cb_LowWord(x) ((WORD*)&(x))[0]
#define cb_IIF1(x,z) ((x) ? : (z))
#define cb_IIF2(x,y,z) ((x) ? (y) : (z))
#define cb_MkGB(x) (int)((x)*1073741824.0)
#define cb_MkKB(x) (int)((x)*1024.0)
#define cb_MkMB(x) (int)((x)*1048576.0)
#define  cbBlack  RGB(0,0,0)
#define  cbDarkBlue  RGB(0,0,192)
#define  cbBlue  RGB(0,0,224)
#define  cbLightBlue  RGB(0,0,255)
#define  cbBrown  RGB(0xA6,0x2A,0x2A)
#define  cbDarkCyan  RGB(0,192,192)
#define  cbCyan  RGB(0,224,224)
#define  cbLightCyan  RGB(0,255,255)
#define  cbDarkSilver  RGB(48,48,48)
#define  cbSilver  RGB(80,80,80)
#define  cbLightSilver  RGB(112,112,112)
#define  cbDarkGreen  RGB(0,192,0)
#define  cbGreen  RGB(0,224,0)
#define  cbLightGreen  RGB(0,255,0)
#define  cbDarkMagenta  RGB(192,0,192)
#define  cbMagenta  RGB(224,0,224)
#define  cbLightMagenta  RGB(255,0,255)
#define  cbDarkOrange  RGB(192,64,0)
#define  cbOrange  RGB(224,96,0)
#define  cbLightOrange  RGB(255,128,0)
#define  cbDarkPink  RGB(0x8C,0x5F,0x5F)
#define  cbPink  RGB(0xAC,0x7F,0x7F)
#define  cbLightPink  RGB(0xCC,0x9F,0x9F)
#define  cbDarkPurple  RGB(80,0,80)
#define  cbPurple  RGB(112,0,112)
#define  cbLightPurple  RGB(144,0,144)
#define  cbDarkRed  RGB(192,0,0)
#define  cbRed  RGB(224,0,0)
#define  cbLightRed  RGB(255,0,0)
#define  cbDarkGray  RGB(144,144,144)
#define  cbGray  RGB(176,176,176)
#define  cbLightGray  RGB(208,208,208)
#define  cbDarkViolet  RGB(192,64,192)
#define  cbViolet  RGB(224,96,224)
#define  cbLightViolet  RGB(255,128,255)
#define  cbWhite  RGB(255,255,255)
#define  cbDarkYellow  RGB(192,192,0)
#define  cbYellow  RGB(224,224,0)
#define  cbLightYellow  RGB(255,255,0)
#ifndef cb_ABORT_EXIT_CODE
#define cb_ABORT_EXIT_CODE EXIT_FAILURE
#endif
#ifdef __cplusplus
#define cb_ExtendsStruct(x) : x {
#else
#define cb_ExtendsStruct(x) { x;
#endif
#define _O_MEMORY 0x80000000

/*((((((((((((((  System Types  ))))))))))))))*/


#define cb_Bit BYTE
#define cb_Bits cb_Bit*
#define cb_comObject VARIANT
#define Pcb_comObject VARIANT*
#define cb_File void
#define cb_Int8 signed char
#define cb_UInt8 unsigned char
#define cb_Int16 signed short int
#define cb_UInt16 unsigned short int
#define cb_Int32 signed long int
#define cb_UInt32 unsigned long int
#define cb_Int64 signed long long int
#define cb_UInt64 unsigned long long int
#define cb_PString char*
#define cb_PStringT _TCHAR*
#define cb_PStringW wchar_t*
#define cb_String char*
#define cb_StringT _TCHAR*
#define cb_StringW wchar_t*

typedef struct cb_FIND_DATA_
#ifdef __cplusplus
 : WIN32_FIND_DATA
#endif
{
#ifndef __cplusplus
  WIN32_FIND_DATA;
#endif
  char  sPath[0x0800];
  HANDLE  FileHandle;
}cb_FIND_DATA;

typedef struct cb_FIND_DATAW_
#ifdef __cplusplus
 : WIN32_FIND_DATAW
#endif
{
#ifndef __cplusplus
  WIN32_FIND_DATAW;
#endif
  wchar_t  sPath[0x0800];
  HANDLE  FileHandle;
}cb_FIND_DATAW;
typedef int (cb_CDECL *cb_AppEventsType_)(const void*,MSG*);

typedef struct cb_LOGFONT_
#ifdef __cplusplus
 : LOGFONT
#endif
{
#ifndef __cplusplus
  LOGFONT;
#endif
  int Size;
  COLORREF Color;
}cb_LOGFONT;

typedef struct cb_Error_ {
  int Number;
  char Description[2048];
}cb_structError;

typedef struct cb_App_ {
  char Path[0x0800];
  char *EXEName;
  DWORD ProcessId;
  DWORD ThreadId;
  HINSTANCE  hInstance;
  char *ClassName;
  int  ShowCmd;
}cb_structApp;

typedef struct cb_TGroupBox_ {
  WNDPROC Events;
  HWND hWndP;
  COLORREF BackColor;
  HBITMAP hBmp, hBmp_;
  HBRUSH hBrush;
  int iStretch;
  int iTrans;
  int UserData;
}cb_TGroupBox;

typedef struct cb_TFrameBox_ {
  HWND hWndP;
  HWND hWndLabel;
  COLORREF BackColor;
  HBITMAP hBmp, hBmp_;
  HBRUSH hBrush;
  int iStretch;
  int iTrans;
  int UserData;
}cb_TFrameBox;

typedef struct cb_TPictureBox_ {
  HWND hWndP;
  COLORREF BackColor;
  COLORREF ForeColor;
  HBITMAP hBmp, hBmp_;
  HBRUSH hBrush;
  HFONT hFont;
  int iStretch;
  int iTrans;
  char *sCaption;
  int UserData;
}cb_TPictureBox;

/*((((((((((((((  System Variables  ))))))))))))))*/

extern char  cb_EMPTYSTR[4];

/*((((((((((((((  Public Declarations  ))))))))))))))*/

void ClassBasic_Terminate (void);

/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Declarations -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


#endif  // ClassBasic_h_
