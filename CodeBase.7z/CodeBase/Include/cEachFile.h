
#ifndef cb_cEachFile1_H_
#define cb_cEachFile1_H_

typedef struct cb_s_cb_cEachFile_
  cb_ExtendsStruct(cb_FIND_DATA)
  char sFileName[cb_MAX_FILE_NAME];
  cb_PString m_buf;
  cb_PString m_ptr;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cEachFile, *Pcb_cEachFile;

#endif
