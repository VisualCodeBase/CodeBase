
#ifndef cb_cSocket1_H_
#define cb_cSocket1_H_

typedef struct cb_s_cb_cSocket_ {
  cb_Boolean m_Enabled;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cSocket, *Pcb_cSocket;

#endif
