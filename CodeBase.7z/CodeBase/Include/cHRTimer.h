
#ifndef cb_cHRTimer1_H_
#define cb_cHRTimer1_H_

typedef struct cb_s_cb_cHRTimer_ {
  cb_UInteger Interval;
  cb_Integer iFlag_;
  HANDLE hThread_;
  cb_UInteger idThread_;
  HWND hWnd;
  void (cb_CDECL *OnTimer)(struct cb_s_cb_cHRTimer_*,cb_UInteger);
  void (cb_CDECL *OnDirectTimer)(void*,cb_UInteger);
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cHRTimer, *Pcb_cHRTimer;

#endif
