
#ifndef cb_cFTP1_H_
#define cb_cFTP1_H_

typedef struct cb_s_cb_cFTP_ {
  cb_Boolean m_Enabled;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cFTP, *Pcb_cFTP;

#endif
