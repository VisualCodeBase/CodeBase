/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*    This file was generated with    */
/*    CodeBase - A Compiler Frontend To C/C++ Compilers - (Version 1.00)    */
/*    Copyright � SoftBase Labs.  All rights reserved. (R)    */
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

#ifndef cppClasses_h_
#define cppClasses_h_

#include <wchar.h>

/*((((((((((((((  Compilers/Platforms Definitions  ))))))))))))))*/

#define cb_CLIBCALL cb_CDECL
#if defined(__GNUC__) || defined(__GNUG__) || defined(__clang__)
#endif

/*((((((((((((((  Public Headers  ))))))))))))))*/


/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-  End of Declarations -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */
/* -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:- */


#endif  // cppClasses_h_
