
#ifndef cb_cNet1_H_
#define cb_cNet1_H_

typedef struct cb_s_cb_cNet_ {
  cb_Boolean m_Enabled;
  void* UserData;
  void* clsMain;
  void* clsParent;
  cb_Integer flag1_;
} cb_cNet, *Pcb_cNet;

#endif
